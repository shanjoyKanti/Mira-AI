"""Account routes (authentication, user management) - MongoDB"""
from fastapi import APIRouter, Depends, HTTPException, status, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse
from datetime import datetime
from typing import Optional

from app.core.dependencies import get_current_user, get_current_active_user
from app.core.rate_limiter import limiter
from app.core.config import settings
from app.core.security import encrypt_data, decrypt_data
from app.api.v1.accounts import schemas, service
from app.db.mongodb_models import User
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(tags=["Step 1 — Onboarding & Project Setup"])


@router.post(
    "/signup",
    response_model=schemas.UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user",
    description="Create a new user account. Email verification link will be sent."
)
@limiter.limit(settings.SIGNUP_RATE_LIMIT)
async def signup(
    request: Request,
    user_data: schemas.UserCreate
):
    """Register a new user with email verification"""
    # Check if user already exists
    existing_user = await service.get_user_by_email(user_data.email)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    user = await service.create_user(user_data)
    # Convert MongoDB User to UserResponse schema
    return schemas.UserResponse.from_mongo_user(user)


@router.post(
    "/login",
    response_model=schemas.LoginResponse,
    summary="User login",
    description="Authenticate user and return JWT tokens with user data"
)
@limiter.limit(settings.LOGIN_RATE_LIMIT)
async def login(
    request: Request,
    credentials: schemas.UserLogin
):
    """Login user and return access token with user data"""
    user = await service.authenticate_user(credentials.email, credentials.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Optional: Check if email is verified
    # if not user.is_email_verified:
    #     raise HTTPException(
    #         status_code=status.HTTP_403_FORBIDDEN,
    #         detail="Please verify your email address before logging in"
    #     )
    
    tokens = await service.create_user_tokens(user)
    user_response = schemas.UserResponse.from_mongo_user(user)
    
    return schemas.LoginResponse(
        access_token=tokens.access_token,
        refresh_token=tokens.refresh_token,
        token_type=tokens.token_type,
        expires_in=tokens.expires_in,
        user=user_response
    )


@router.post(
    "/refresh",
    response_model=schemas.TokenResponse,
    summary="Refresh access token",
    description="Get new access token using refresh token"
)
@limiter.limit("10/minute")
async def refresh_token(
    request: Request,
    token_request: schemas.RefreshTokenRequest
):
    """Refresh access token using refresh token"""
    tokens = await service.refresh_user_tokens(token_request.refresh_token)
    return tokens


@router.post(
    "/logout",
    response_model=schemas.MessageResponse,
    summary="User logout",
    description="Logout user and revoke refresh token"
)
async def logout(
    token_request: schemas.RefreshTokenRequest
):
    """Logout user by revoking refresh token"""
    await service.revoke_refresh_token(token_request.refresh_token)
    return schemas.MessageResponse(message="Successfully logged out")


@router.get(
    "/verify-email",
    response_class=HTMLResponse,
    summary="Verify email address (GET)",
    description="Verify user email with verification token from query parameter"
)
async def verify_email_get(
    token: str,
    request: Request
):
    """Verify user email with token from query parameter (for email links)"""
    try:
        await service.verify_email(token)
        # Return success HTML page
        return HTMLResponse(content=f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Email Verified - {settings.APP_NAME}</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="refresh" content="3;url={settings.FRONTEND_URL}/login">
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                    margin: 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                }}
                .container {{
                    background: white;
                    padding: 40px;
                    border-radius: 10px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                    text-align: center;
                    max-width: 500px;
                }}
                h1 {{
                    color: #28a745;
                    margin-bottom: 20px;
                }}
                p {{
                    color: #333;
                    line-height: 1.6;
                    margin-bottom: 30px;
                }}
                .success-icon {{
                    font-size: 64px;
                    margin-bottom: 20px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="success-icon">✅</div>
                <h1>Email Verified Successfully!</h1>
                <p>Your email address has been verified. You can now log in to your account.</p>
                <p>Redirecting to login page in <span id="countdown">3</span> seconds...</p>
                <p><a href="{settings.FRONTEND_URL}/login" style="color: #667eea; text-decoration: none;">Click here if you are not redirected automatically</a></p>
            </div>
            <script>
                // Automatic redirect after 3 seconds
                setTimeout(function() {{
                    window.location.href = "{settings.FRONTEND_URL}/login";
                }}, 3000);
                
                // Countdown timer
                let countdown = 3;
                const countdownElement = document.getElementById("countdown");
                const interval = setInterval(function() {{
                    countdown--;
                    if (countdownElement) {{
                        countdownElement.textContent = countdown;
                    }}
                    if (countdown <= 0) {{
                        clearInterval(interval);
                    }}
                }}, 1000);
            </script>
        </body>
        </html>
        """)
    except HTTPException as e:
        # Return error HTML page
        return HTMLResponse(
            status_code=e.status_code,
            content=f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Verification Failed - {settings.APP_NAME}</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                    margin: 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                }}
                .container {{
                    background: white;
                    padding: 40px;
                    border-radius: 10px;
                    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                    text-align: center;
                    max-width: 500px;
                }}
                h1 {{
                    color: #dc3545;
                    margin-bottom: 20px;
                }}
                p {{
                    color: #333;
                    line-height: 1.6;
                    margin-bottom: 30px;
                }}
                .error-icon {{
                    font-size: 64px;
                    margin-bottom: 20px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="error-icon">❌</div>
                <h1>Verification Failed</h1>
                <p>{e.detail}</p>
                <p><a href="{settings.FRONTEND_URL}/signup" style="color: #667eea; text-decoration: none;">Back to Sign Up</a></p>
            </div>
        </body>
        </html>
        """
        )


@router.post(
    "/verify-email",
    response_model=schemas.MessageResponse,
    summary="Verify email address (POST)",
    description="Verify user email with verification token"
)
async def verify_email_post(
    verification: schemas.EmailVerificationRequest
):
    """Verify user email with token (POST endpoint for API calls)"""
    await service.verify_email(verification.token)
    return schemas.MessageResponse(
        message="Email verified successfully",
        detail="You can now log in to your account"
    )


@router.post(
    "/resend-verification",
    response_model=schemas.MessageResponse,
    summary="Resend verification email",
    description="Resend email verification link"
)
@limiter.limit("3/hour")
async def resend_verification(
    request: Request,
    email_request: schemas.ForgotPasswordRequest
):
    """Resend verification email"""
    await service.resend_verification_email(email_request.email)
    return schemas.MessageResponse(
        message="Verification email sent",
        detail="Please check your email inbox"
    )


@router.post(
    "/forgot-password",
    response_model=schemas.MessageResponse,
    summary="Request password reset",
    description="Send password reset link to email"
)
@limiter.limit(settings.PASSWORD_RESET_RATE_LIMIT)
async def forgot_password(
    request: Request,
    password_request: schemas.ForgotPasswordRequest
):
    """Request password reset"""
    await service.request_password_reset(password_request.email)
    return schemas.MessageResponse(
        message="Password reset email sent",
        detail="If the email exists, you will receive reset instructions"
    )


@router.post(
    "/reset-password",
    response_model=schemas.MessageResponse,
    summary="Reset password",
    description="Reset password with reset token"
)
async def reset_password(
    reset_request: schemas.ResetPasswordRequest
):
    """Reset password with token"""
    await service.reset_password(reset_request.token, reset_request.new_password)
    return schemas.MessageResponse(
        message="Password reset successful",
        detail="You can now log in with your new password"
    )


@router.post(
    "/change-password",
    response_model=schemas.MessageResponse,
    summary="Change password",
    description="Change password for authenticated user"
)
async def change_password(
    password_change: schemas.ChangePasswordRequest,
    current_user: User = Depends(get_current_active_user)
):
    """Change user password"""
    await service.change_password(
        current_user,
        password_change.current_password,
        password_change.new_password
    )
    return schemas.MessageResponse(
        message="Password changed successfully",
        detail="All active sessions have been logged out"
    )


@router.get(
    "/me",
    response_model=schemas.UserResponse,
    summary="Get current user",
    description="Get current authenticated user information"
)
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user)
):
    """Get current user information"""
    return schemas.UserResponse.from_mongo_user(current_user)


@router.put(
    "/me",
    response_model=schemas.UserResponse,
    summary="Update current user",
    description="Update current authenticated user information"
)
async def update_current_user(
    user_update: schemas.UserUpdate,
    current_user: User = Depends(get_current_active_user)
):
    """Update current user information"""
    updated_user = await service.update_user(str(current_user.id), user_update)
    return schemas.UserResponse.from_mongo_user(updated_user)


@router.delete(
    "/me",
    response_model=schemas.MessageResponse,
    summary="Delete current user account",
    description="Soft delete current user account"
)
async def delete_current_user(
    current_user: User = Depends(get_current_active_user)
):
    """Delete current user account (soft delete)"""
    current_user.is_active = False
    await current_user.save()
    return schemas.MessageResponse(
        message="Account deactivated successfully",
        detail="Your account has been deactivated and will be deleted after 30 days"
    )


# Admin-only routes
@router.get(
    "/users/{user_id}",
    response_model=schemas.UserResponse,
    summary="Get user by ID (Admin only)",
    description="Get any user information by ID - requires admin role"
)
async def get_user(
    user_id: str,
    current_user: User = Depends(get_current_active_user)
):
    """Get user by ID (admin only)"""
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    user = await service.get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    return schemas.UserResponse.from_mongo_user(user)
