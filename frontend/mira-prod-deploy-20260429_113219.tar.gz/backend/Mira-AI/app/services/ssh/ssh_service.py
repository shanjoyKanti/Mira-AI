"""SSH service for connecting to user VMs using Paramiko"""
import paramiko
import socket
from typing import Optional, List, Dict, Any
from pathlib import Path
from io import StringIO
from app.core.logging import get_logger
from app.core.security import encrypt_data, decrypt_data

logger = get_logger(__name__)


class SSHConnection:
    """SSH connection wrapper for Paramiko"""
    
    def __init__(self, hostname: str, port: int, username: str, password: Optional[str] = None, 
                 private_key: Optional[str] = None, private_key_password: Optional[str] = None):
        """
        Initialize SSH connection
        
        Args:
            hostname: VM hostname or IP address
            port: SSH port (default 22)
            username: SSH username
            password: SSH password (if using password auth)
            private_key: Private key content (if using key auth)
            private_key_password: Password for encrypted private key
        """
        self.hostname = hostname
        self.port = port
        self.username = username
        self.password = password
        self.private_key = private_key
        self.private_key_password = private_key_password
        self.client: Optional[paramiko.SSHClient] = None
        self.sftp: Optional[paramiko.SFTPClient] = None
    
    def connect(self) -> bool:
        """Establish SSH connection"""
        # Clean up any existing connection first
        self.disconnect()
        
        try:
            # Create fresh SSH client for each connection attempt
            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            # Connection parameters with optimized settings
            connect_kwargs = {
                "hostname": self.hostname,
                "port": self.port,
                "username": self.username,
                "timeout": 10,  # Connection timeout — keep low so 3 retries finish well under nginx proxy_read_timeout
                "allow_agent": False,  # Disable SSH agent
                "look_for_keys": False,  # Don't look for keys in default locations
                "banner_timeout": 10,  # Reduced banner timeout
                "auth_timeout": 20,  # Authentication timeout
                "compress": False,  # Disable compression for faster connection
            }
            
            # Use private key if provided, otherwise use password
            if self.private_key and self.private_key.strip():  # Explicitly check for non-empty
                try:
                    # Only use private_key_password if it's not empty
                    key_password = self.private_key_password.strip() if self.private_key_password and self.private_key_password.strip() else None
                    
                    # Try different key types
                    try:
                        private_key_obj = paramiko.RSAKey.from_private_key(
                            StringIO(self.private_key),
                            password=key_password
                        ) if key_password else paramiko.RSAKey.from_private_key(
                            StringIO(self.private_key)
                        )
                    except:
                        # Try Ed25519 or ECDSA if RSA fails
                        private_key_obj = paramiko.Ed25519Key.from_private_key(
                            StringIO(self.private_key),
                            password=key_password
                        ) if key_password else paramiko.Ed25519Key.from_private_key(
                            StringIO(self.private_key)
                        )
                    connect_kwargs["pkey"] = private_key_obj
                except Exception as e:
                    logger.error(f"Failed to load private key: {e}")
                    return False
            elif self.password and self.password.strip():  # Explicitly check for non-empty
                connect_kwargs["password"] = self.password
            else:
                logger.error(f"No authentication method provided (password or private_key required). Password: {bool(self.password)}, PrivateKey: {bool(self.private_key)}")
                return False
            
            # Attempt connection with retry logic
            max_retries = 3  # Increased retries
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    # Create fresh client for each retry attempt
                    if attempt > 0:
                        if self.client:
                            try:
                                self.client.close()
                            except:
                                pass
                        self.client = paramiko.SSHClient()
                        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    
                    logger.info(f"Attempting SSH connection to {self.hostname}:{self.port} (attempt {attempt + 1}/{max_retries})")
                    
                    # Try connection
                    self.client.connect(**connect_kwargs)
                    
                    # Verify connection is actually working
                    try:
                        # Test connection with a simple command
                        stdin, stdout, stderr = self.client.exec_command("echo 'test'", timeout=5)
                        stdout.channel.recv_exit_status()
                    except Exception as test_error:
                        logger.warning(f"Connection established but test command failed: {test_error}")
                        # Connection might be unstable, but continue anyway
                    
                    # Open SFTP session for file operations
                    self.sftp = self.client.open_sftp()
                    
                    logger.info(f"Successfully connected to {self.hostname}:{self.port} as {self.username}")
                    return True
                    
                except paramiko.AuthenticationException as e:
                    logger.error(f"Authentication failed for {self.hostname}:{self.port}: {e}")
                    # Don't retry on auth failures - re-raise so callers get error details
                    raise
                except (paramiko.SSHException, paramiko.BadHostKeyException) as e:
                    logger.warning(f"SSH error connecting to {self.hostname}:{self.port} (attempt {attempt + 1}): {e}")
                    last_exception = e
                    if attempt < max_retries - 1:
                        import time
                        wait_time = 2 * (attempt + 1)  # Exponential backoff
                        logger.info(f"Waiting {wait_time}s before retry...")
                        time.sleep(wait_time)
                except (TimeoutError, socket.timeout, OSError) as e:
                    logger.warning(f"Connection timeout to {self.hostname}:{self.port} (attempt {attempt + 1}): {e}")
                    last_exception = e
                    if attempt < max_retries - 1:
                        import time
                        wait_time = 2 * (attempt + 1)  # Exponential backoff
                        logger.info(f"Waiting {wait_time}s before retry...")
                        time.sleep(wait_time)
                except Exception as e:
                    logger.error(f"Unexpected connection error to {self.hostname}:{self.port} (attempt {attempt + 1}): {e}")
                    last_exception = e
                    if attempt < max_retries - 1:
                        import time
                        wait_time = 2 * (attempt + 1)
                        time.sleep(wait_time)
            
            # If all retries failed
            if last_exception:
                error_msg = f"Failed to connect to {self.hostname}:{self.port} after {max_retries} attempts: {last_exception}"
                logger.error(error_msg)
                # Clean up failed connection
                self.disconnect()
            return False
            
        except paramiko.AuthenticationException:
            # Let auth exceptions propagate to callers for proper error reporting
            self.disconnect()
            raise
        except Exception as e:
            logger.error(f"Failed to connect to {self.hostname}:{self.port}: {str(e)}", exc_info=True)
            self.disconnect()
            return False
    
    def disconnect(self):
        """Close SSH connection"""
        try:
            if self.sftp:
                try:
                    self.sftp.close()
                except:
                    pass
                self.sftp = None
        except:
            pass
        
        try:
            if self.client:
                try:
                    self.client.close()
                except:
                    pass
                self.client = None
        except:
            pass
    
    # Default timeouts (seconds). Long-running commands (SonarQube scan, composer install)
    # use CMD_TIMEOUT_LONG; quick file-existence checks use CMD_TIMEOUT_SHORT.
    CMD_TIMEOUT_SHORT: int = 30
    CMD_TIMEOUT_DEFAULT: int = 300   # 5 minutes — covers most remote commands
    CMD_TIMEOUT_LONG: int = 1800     # 30 minutes — SonarQube scans on large projects

    def execute_command(
        self,
        command: str,
        use_sudo: bool = False,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Execute a command on the remote VM.

        Args:
            command: Shell command to run.
            use_sudo: Wrap with sudo -S when True (requires stored password).
            timeout: Seconds to wait for the command to finish before raising
                     TimeoutError (default: CMD_TIMEOUT_DEFAULT = 300 s).
                     Pass CMD_TIMEOUT_LONG for SonarQube scans, composer installs,
                     or other long-running operations.

        Returns:
            Dict with stdout, stderr, exit_code, success.
        """
        if not self.client:
            raise ValueError("SSH connection not established")

        effective_timeout = timeout if timeout is not None else self.CMD_TIMEOUT_DEFAULT

        try:
            if use_sudo and self.password:
                escaped_password = self.password.replace("'", "'\"'\"'")
                sudo_command = f"echo '{escaped_password}' | sudo -S {command}"
                stdin, stdout, stderr = self.client.exec_command(sudo_command)
            else:
                stdin, stdout, stderr = self.client.exec_command(command)

            # recv_exit_status() blocks until the command finishes — set a channel
            # timeout so we never hang indefinitely on a frozen remote process.
            stdout.channel.settimeout(effective_timeout)
            try:
                exit_code = stdout.channel.recv_exit_status()
            except Exception as te:
                # Channel timed out or was reset — treat as failure
                logger.error(
                    "SSH command timed out after %ss: %s — %s",
                    effective_timeout, command[:200], te,
                )
                return {
                    "stdout": "",
                    "stderr": f"Command timed out after {effective_timeout}s",
                    "exit_code": -1,
                    "success": False,
                }

            return {
                "stdout": stdout.read().decode("utf-8", errors="replace"),
                "stderr": stderr.read().decode("utf-8", errors="replace"),
                "exit_code": exit_code,
                "success": exit_code == 0,
            }
        except Exception as e:
            logger.error(f"Failed to execute command '{command}': {str(e)}", exc_info=True)
            return {
                "stdout": "",
                "stderr": str(e),
                "exit_code": -1,
                "success": False,
            }
    
    # Maximum file size to read into memory. Files larger than this are skipped
    # rather than causing OOM. 10 MB is well above any realistic PHP source file.
    MAX_READ_BYTES: int = 10 * 1024 * 1024  # 10 MB

    def read_file(self, remote_path: str, max_bytes: Optional[int] = None) -> Optional[str]:
        """Read a file from the remote VM with automatic encoding detection.

        Args:
            remote_path: Absolute path on the remote server.
            max_bytes:   If the file is larger than this, log a warning and return None
                         (avoids OOM on huge legacy files). Defaults to MAX_READ_BYTES (10 MB).
        """
        if not self.sftp:
            raise ValueError("SFTP connection not established")

        limit = max_bytes if max_bytes is not None else self.MAX_READ_BYTES

        try:
            # Check file size before reading
            try:
                stat = self.sftp.stat(remote_path)
                file_size = stat.st_size or 0
                if file_size > limit:
                    logger.warning(
                        "Skipping large file '%s' (%s bytes > limit %s bytes). "
                        "Increase SSHService.MAX_READ_BYTES or pass max_bytes= to override.",
                        remote_path, file_size, limit,
                    )
                    return None
            except Exception:
                pass  # If stat fails, try reading anyway

            with self.sftp.open(remote_path, 'rb') as f:
                raw_content = f.read()
            
            # Try different encodings
            encodings = ['utf-8', 'utf-16', 'utf-16-le', 'utf-16-be', 'latin-1', 'cp1252']
            
            for encoding in encodings:
                try:
                    # Handle BOM (Byte Order Mark)
                    if encoding == 'utf-8' and raw_content.startswith(b'\xef\xbb\xbf'):
                        return raw_content[3:].decode('utf-8')
                    elif encoding in ('utf-16', 'utf-16-le') and raw_content.startswith(b'\xff\xfe'):
                        return raw_content.decode('utf-16-le')
                    elif encoding in ('utf-16', 'utf-16-be') and raw_content.startswith(b'\xfe\xff'):
                        return raw_content.decode('utf-16-be')
                    else:
                        return raw_content.decode(encoding)
                except (UnicodeDecodeError, LookupError):
                    continue
            
            # Last resort: decode with errors ignored
            return raw_content.decode('utf-8', errors='replace')
        except Exception as e:
            logger.error(f"Failed to read file '{remote_path}': {str(e)}", exc_info=True)
            return None
    
    def _remote_free_bytes(self, remote_dir: str) -> Optional[int]:
        """Return free bytes at ``remote_dir`` via ``df -P --block-size=1``; None on failure."""
        try:
            res = self.execute_command(
                f"df -P --block-size=1 '{remote_dir}' 2>/dev/null | tail -1 | awk '{{print $4}}'"
            )
            if res.get("success"):
                s = (res.get("stdout") or "").strip()
                if s.isdigit():
                    return int(s)
        except Exception as e:
            logger.debug(f"_remote_free_bytes({remote_dir}) failed: {e}")
        return None

    def write_file(self, remote_path: str, content: str, backup: bool = False) -> bool:
        """Write a file to the remote VM.

        Safety: before writing, check remote free disk space and require ≥ 2× content size
        (so backups + new file both fit). After writing, verify the file size on disk matches
        what we intended to send. A silent partial-write on a full disk is the worst failure
        mode — this guard turns it into a hard error instead.

        Args:
            remote_path: Absolute path on the remote server.
            content:     UTF-8 file content to write.
            backup:      When True, copy the existing file to <remote_path>.bak before
                         overwriting. Silently skips the backup if the file does not yet
                         exist. This is required by the SonarQube fix step so that every
                         original can be restored if a LLM-generated fix is wrong.
        """
        if not self.sftp:
            raise ValueError("SFTP connection not established")

        import time as _time
        _t0 = _time.monotonic()

        def _fail(reason: str) -> bool:
            try:
                from app.core.metrics import mira_ssh_upload_failures_total
                mira_ssh_upload_failures_total.labels(reason=reason).inc()
            except Exception:
                pass
            return False

        try:
            # Create parent directories if they don't exist
            remote_dir = '/'.join(remote_path.split('/')[:-1])
            if remote_dir:
                self.execute_command(f"mkdir -p '{remote_dir}'")

            encoded = content.encode('utf-8')
            expected_size = len(encoded)

            # Pre-check: free space must be at least 2× expected (content + optional backup).
            free = self._remote_free_bytes(remote_dir or "/")
            if free is not None and free < expected_size * 2:
                logger.error(
                    f"Refusing write to '{remote_path}': remote has {free} bytes free, "
                    f"need at least {expected_size * 2} (2× file size including backup)."
                )
                return _fail("disk_full")

            if backup:
                self.execute_command(
                    f"[ -f '{remote_path}' ] && cp -p '{remote_path}' '{remote_path}.bak' || true"
                )

            with self.sftp.open(remote_path, 'w') as f:
                f.write(encoded)

            # Post-verify size
            try:
                actual_size = self.sftp.stat(remote_path).st_size
            except Exception as stat_err:
                logger.error(f"Could not stat '{remote_path}' after write: {stat_err}")
                return _fail("stat_error")
            if actual_size != expected_size:
                logger.error(
                    f"Size mismatch after writing '{remote_path}': "
                    f"expected {expected_size} bytes, found {actual_size}."
                )
                return _fail("size_mismatch")

            logger.info(f"Successfully wrote file '{remote_path}' ({expected_size} bytes)" + (" (backup created)" if backup else ""))
            try:
                from app.core.metrics import mira_ssh_upload_seconds
                mira_ssh_upload_seconds.observe(_time.monotonic() - _t0)
            except Exception:
                pass
            return True
        except Exception as e:
            logger.error(f"Failed to write file '{remote_path}': {str(e)}", exc_info=True)
            return _fail("exception")
    
    def list_files(self, remote_path: str, recursive: bool = False) -> List[str]:
        """List files in a remote directory"""
        if not self.sftp:
            raise ValueError("SFTP connection not established")
        
        try:
            files = []
            if recursive:
                result = self.execute_command(f"find {remote_path} -type f")
                if result["success"]:
                    files = [f.strip() for f in result["stdout"].split('\n') if f.strip()]
            else:
                items = self.sftp.listdir_attr(remote_path)
                files = [item.filename for item in items if item.st_mode & 0o100000]  # Regular files only
            
            return files
        except Exception as e:
            logger.error(f"Failed to list files in '{remote_path}': {str(e)}", exc_info=True)
            return []
    
    def file_exists(self, remote_path: str) -> bool:
        """Check if a file exists on the remote VM"""
        if not self.sftp:
            raise ValueError("SFTP connection not established")
        
        try:
            self.sftp.stat(remote_path)
            return True
        except FileNotFoundError:
            return False
        except Exception as e:
            logger.error(f"Error checking file '{remote_path}': {str(e)}", exc_info=True)
            return False
    
    def create_directory(self, remote_path: str) -> bool:
        """Create a directory on the remote VM"""
        try:
            result = self.execute_command(f"mkdir -p {remote_path}")
            return result["success"]
        except Exception as e:
            logger.error(f"Failed to create directory '{remote_path}': {str(e)}", exc_info=True)
            return False
    
    def delete_file(self, remote_path: str) -> bool:
        """Delete a file from the remote VM"""
        if not self.sftp:
            raise ValueError("SFTP connection not established")
        
        try:
            self.sftp.remove(remote_path)
            logger.info(f"Successfully deleted file '{remote_path}'")
            return True
        except Exception as e:
            logger.error(f"Failed to delete file '{remote_path}': {str(e)}", exc_info=True)
            return False
    
    def get_file_size(self, remote_path: str) -> Optional[int]:
        """Get file size in bytes"""
        if not self.sftp:
            raise ValueError("SFTP connection not established")
        
        try:
            stat = self.sftp.stat(remote_path)
            return stat.st_size
        except Exception as e:
            logger.error(f"Failed to get file size for '{remote_path}': {str(e)}", exc_info=True)
            return None
    
    def __enter__(self):
        """Context manager entry"""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.disconnect()


class SSHService:
    """Service for managing SSH connections to user VMs"""
    
    @staticmethod
    def create_connection(hostname: str, port: int, username: str, 
                          password: Optional[str] = None,
                          private_key: Optional[str] = None,
                          private_key_password: Optional[str] = None) -> SSHConnection:
        """Create and return an SSH connection"""
        return SSHConnection(
            hostname=hostname,
            port=port,
            username=username,
            password=password,
            private_key=private_key,
            private_key_password=private_key_password
        )
    
    @staticmethod
    def test_connection(hostname: str, port: int, username: str,
                       password: Optional[str] = None,
                       private_key: Optional[str] = None,
                       private_key_password: Optional[str] = None) -> Dict[str, Any]:
        """Test SSH connection"""
        try:
            conn = SSHService.create_connection(
                hostname=hostname,
                port=port,
                username=username,
                password=password,
                private_key=private_key,
                private_key_password=private_key_password
            )
            
            if conn.connect():
                # Test with a simple command
                result = conn.execute_command("echo 'SSH connection test successful'")
                conn.disconnect()
                
                return {
                    "success": True,
                    "message": "SSH connection successful",
                    "test_output": result.get("stdout", "")
                }
            else:
                return {
                    "success": False,
                    "message": "Failed to establish SSH connection"
                }
        except Exception as e:
            logger.error(f"SSH connection test failed: {str(e)}", exc_info=True)
            return {
                "success": False,
                "message": f"SSH connection test failed: {str(e)}"
            }

