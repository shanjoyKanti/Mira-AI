"""LLM provider abstraction layer"""

