"""Local/On-premises LLM provider (LLaMA, etc.)"""
from typing import List, Dict, Any, AsyncIterator
import requests
from app.services.llm.base_provider import BaseLLMProvider, LLMMessage, LLMResponse
from app.core.logging import get_logger

logger = get_logger(__name__)


class LocalLLMProvider(BaseLLMProvider):
    """Local/On-premises LLM provider (supports LLaMA, Ollama, etc.)"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get("base_url", "http://localhost:11434")  # Default Ollama
        self.api_key = config.get("api_key")  # Optional for local
        self.model = config.get("model", "llama2")
        self.provider_type = config.get("provider_type", "ollama")  # ollama, vllm, etc.
    
    def generate(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Generate response using local LLM"""
        try:
            if self.provider_type == "ollama":
                return self._generate_ollama(messages, **kwargs)
            elif self.provider_type == "vllm":
                return self._generate_vllm(messages, **kwargs)
            else:
                return self._generate_generic(messages, **kwargs)
        except Exception as e:
            logger.error(f"Local LLM generation failed: {str(e)}", exc_info=True)
            raise
    
    def _generate_ollama(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Generate using Ollama API"""
        # Format messages for Ollama
        prompt = self._format_messages_for_prompt(messages)
        
        url = f"{self.base_url}/api/generate"
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": kwargs.get("temperature", self.temperature),
                "num_predict": kwargs.get("max_tokens", self.max_tokens)
            }
        }
        
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        # 40 minutes timeout for complex LLM workflows
        response = requests.post(url, json=payload, headers=headers, timeout=2400)
        response.raise_for_status()
        
        data = response.json()
        
        return LLMResponse(
            content=data.get("response", ""),
            model=self.model,
            usage={
                "prompt_tokens": data.get("prompt_eval_count", 0),
                "completion_tokens": data.get("eval_count", 0),
                "total_tokens": data.get("prompt_eval_count", 0) + data.get("eval_count", 0)
            },
            finish_reason="stop"
        )
    
    def _generate_vllm(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Generate using vLLM API (OpenAI-compatible)"""
        url = f"{self.base_url}/v1/chat/completions"
        formatted_messages = [
            {"role": msg.role, "content": msg.content}
            for msg in messages
        ]
        
        payload = {
            "model": self.model,
            "messages": formatted_messages,
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens)
        }
        
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        # 40 minutes timeout for complex LLM workflows
        response = requests.post(url, json=payload, headers=headers, timeout=2400)
        response.raise_for_status()
        
        data = response.json()
        
        return LLMResponse(
            content=data["choices"][0]["message"]["content"],
            model=data["model"],
            usage=data.get("usage"),
            finish_reason=data["choices"][0].get("finish_reason")
        )
    
    def _generate_generic(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Generic local LLM generation (OpenAI-compatible API)"""
        url = f"{self.base_url}/v1/chat/completions"
        formatted_messages = [
            {"role": msg.role, "content": msg.content}
            for msg in messages
        ]
        
        payload = {
            "model": self.model,
            "messages": formatted_messages,
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens)
        }
        
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        # 40 minutes timeout for complex LLM workflows
        response = requests.post(url, json=payload, headers=headers, timeout=2400)
        response.raise_for_status()
        
        data = response.json()
        
        return LLMResponse(
            content=data["choices"][0]["message"]["content"],
            model=data["model"],
            usage=data.get("usage"),
            finish_reason=data["choices"][0].get("finish_reason")
        )
    
    async def agenerate(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Async generate response"""
        import asyncio
        return await asyncio.to_thread(self.generate, messages, **kwargs)
    
    async def stream(self, messages: List[LLMMessage], **kwargs) -> AsyncIterator[str]:
        """Stream responses from local LLM"""
        if self.provider_type == "ollama":
            async for chunk in self._stream_ollama(messages, **kwargs):
                yield chunk
        else:
            # For OpenAI-compatible APIs
            async for chunk in self._stream_generic(messages, **kwargs):
                yield chunk
    
    async def _stream_ollama(self, messages: List[LLMMessage], **kwargs) -> AsyncIterator[str]:
        """Stream from Ollama"""
        import aiohttp
        
        prompt = self._format_messages_for_prompt(messages)
        url = f"{self.base_url}/api/generate"
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": True,
            "options": {
                "temperature": kwargs.get("temperature", self.temperature),
                "num_predict": kwargs.get("max_tokens", self.max_tokens)
            }
        }
        
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers) as response:
                async for line in response.content:
                    if line:
                        import json
                        data = json.loads(line)
                        if "response" in data:
                            yield data["response"]
    
    async def _stream_generic(self, messages: List[LLMMessage], **kwargs) -> AsyncIterator[str]:
        """Stream from OpenAI-compatible API"""
        import aiohttp
        
        url = f"{self.base_url}/v1/chat/completions"
        formatted_messages = [
            {"role": msg.role, "content": msg.content}
            for msg in messages
        ]
        
        payload = {
            "model": self.model,
            "messages": formatted_messages,
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
            "stream": True
        }
        
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers) as response:
                async for line in response.content:
                    if line:
                        import json
                        line_str = line.decode('utf-8')
                        if line_str.startswith('data: '):
                            data_str = line_str[6:].strip()
                            if data_str == '[DONE]':
                                break
                            try:
                                data = json.loads(data_str)
                                if "choices" in data and len(data["choices"]) > 0:
                                    delta = data["choices"][0].get("delta", {})
                                    if "content" in delta:
                                        yield delta["content"]
                            except json.JSONDecodeError:
                                continue
    
    def _format_messages_for_prompt(self, messages: List[LLMMessage]) -> str:
        """Format messages as a single prompt (for models that don't support chat)"""
        formatted = []
        for msg in messages:
            if msg.role == "system":
                formatted.append(f"System: {msg.content}")
            elif msg.role == "user":
                formatted.append(f"User: {msg.content}")
            elif msg.role == "assistant":
                formatted.append(f"Assistant: {msg.content}")
        return "\n\n".join(formatted)
    
    def validate_config(self) -> bool:
        """Validate local LLM configuration"""
        return bool(self.base_url and self.model)

