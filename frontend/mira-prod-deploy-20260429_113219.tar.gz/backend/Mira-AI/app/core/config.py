"""Application configuration"""
from typing import List, Optional, Union
from pydantic_settings import BaseSettings
from pydantic import field_validator


class Settings(BaseSettings):
    """Application settings"""
    
    # App
    APP_NAME: str = "Mira AI"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # API
    API_V1_PREFIX: str = "/api/v1"
    
    # Security
    SECRET_KEY: str = "dev-secret-key-change-in-production-min-32-chars"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # Password Reset & Email Verification
    PASSWORD_RESET_TOKEN_EXPIRE_HOURS: int = 24
    EMAIL_VERIFICATION_TOKEN_EXPIRE_HOURS: int = 48
    
    # Email Configuration
    MAIL_USERNAME: Optional[str] = None
    MAIL_PASSWORD: Optional[str] = None
    MAIL_FROM: Optional[str] = None
    MAIL_PORT: int = 587
    MAIL_SERVER: Optional[str] = None
    MAIL_FROM_NAME: str = "Mira AI"
    MAIL_TLS: bool = True
    MAIL_SSL: bool = False
    
    # Frontend URL (for email verification links)
    FRONTEND_URL: str = "https://mira.codsy.ai"
    BACKEND_URL: str = "https://mira.codsy.ai"
    # Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = 60
    LOGIN_RATE_LIMIT: str = "5/minute"  # 5 login attempts per minute
    SIGNUP_RATE_LIMIT: str = "3/minute"  # 3 signup attempts per minute
    PASSWORD_RESET_RATE_LIMIT: str = "3/hour"  # 3 password reset requests per hour
    
    # CORS
    # Note: For Netlify, add your specific Netlify URL (e.g., https://your-app.netlify.app)
    # You can set BACKEND_CORS_ORIGINS via environment variable as comma-separated values
    BACKEND_CORS_ORIGINS: Union[List[str], str] = [
        "https://mira.codsy.ai",
        "https://sonarqube.codsy.ai",
        "https://mira-ai-f.netlify.app",
        "http://localhost:3000",
        "http://localhost:5173",
        "http://localhost:8000",
        "http://localhost:8080",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:8000",
        "http://127.0.0.1:8080",
    ]
    
    @field_validator("BACKEND_CORS_ORIGINS", mode="before")
    @classmethod
    def assemble_cors_origins(cls, v):
        if v is None or v == "":
            return [
                "http://localhost:3000",
                "http://localhost:5173",
                "http://localhost:8000",
                "http://localhost:8080",
                "http://127.0.0.1:3000",
                "http://127.0.0.1:5173",
                "http://127.0.0.1:8000",
                "http://127.0.0.1:8080",
            ]
        if isinstance(v, str):
            return [i.strip() for i in v.split(",") if i.strip()]
        return v
    
    # Database
    # DATABASE_URL removed - using MongoDB only
    
    # MongoDB
    MONGO_DB_URL: Optional[str] = None  # MongoDB Atlas connection string
    MONGODB_DATABASE: str = "mira_ai"  # Database name
    
    # Redis/Celery
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/0"
    
    # File Storage
    UPLOAD_DIR: str = "uploads"
    MAX_UPLOAD_SIZE: int = 100 * 1024 * 1024  # 100MB
    
    # VM-Based Workspace Storage (Optional - for local caching/temp files only)
    # Note: Primary storage is on user VMs via SSH
    WORKSPACE_ROOT: str = "miraai-workspace"  # Optional: Local temp/cache storage
    MAX_PROJECT_SIZE_GB: int = 3  # Optional: Max size for local temp storage
    STORAGE_RETENTION_DAYS: int = 30  # Optional: Auto-cleanup for local temp files
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FILE: Optional[str] = "app.log"
    
    # Admin User
    ADMIN_SUPERUSER_EMAIL: Optional[str] = None
    ADMIN_SUPERUSER_PASSWORD: Optional[str] = None
    
    # LangGraph & LLM Configuration
    LLM_PROVIDER: str = "openai"  # openai, groq, anthropic, google, local, ollama, llama, vllm
    OPENAI_API_KEY: Optional[str] = None
    GROQ_API_KEY: Optional[str] = None
    # Reduce HTTP 429 from Groq during many back-to-back agent calls (modernization, digests, etc.)
    GROQ_MIN_REQUEST_INTERVAL_SECONDS: float = 0.55
    GROQ_API_MAX_RETRIES: int = 10
    GROQ_API_BASE_RETRY_DELAY_SECONDS: float = 2.0
    ANTHROPIC_API_KEY: Optional[str] = None
    GOOGLE_API_KEY: Optional[str] = None
    
    # Local/On-premises LLM Configuration
    LOCAL_LLM_BASE_URL: str = "http://localhost:11434"  # Default Ollama URL
    LOCAL_LLM_API_KEY: Optional[str] = None  # Optional API key for local LLM
    LOCAL_LLM_PROVIDER_TYPE: str = "ollama"  # ollama, vllm, or generic OpenAI-compatible
    
    LLM_MODEL: str = "gpt-4-turbo-preview"  # Default model (change to "llama2" for local)
    LLM_TEMPERATURE: float = 0.7
    
    # Agent Configuration
    AGENT_MAX_ITERATIONS: int = 50
    AGENT_TIMEOUT_SECONDS: int = 2400  # 40 minutes (for complex LLM workflows analyzing large codebases)
    
    # SonarQube Configuration
    SONAR_HOST_URL: str = "https://sonarqube.codsy.ai"  # SonarQube server URL
    SONAR_TOKEN: Optional[str] = None  # SonarQube authentication token
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "ignore"  # Allow extra env vars


settings = Settings()
