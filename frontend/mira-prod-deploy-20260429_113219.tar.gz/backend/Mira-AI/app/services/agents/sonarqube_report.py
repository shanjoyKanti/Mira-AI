#!/usr/bin/env python3
"""
SonarQube Report Downloader - SIMPLE VERSION

When used from the API (run-modernization pipeline / upgrade analysis agent), the project
name is always passed from the API; run_download_workflow(project_name) is called with
the request's project_name. No fallback project name is used.

CLI usage (project name required):
    python sonarqube_report.py <project_name>
    PROJECT_NAME=my_project python sonarqube_report.py
"""

import os
import shutil
import sys
import time
import requests
from pathlib import Path
from typing import Optional, Tuple, Union
from datetime import datetime


# Project name: from API when run_download_workflow() is called by upgrade agent; from CLI arg or PROJECT_NAME env when run as script. No fallback.

# API Configuration
API_BASE_URL = "http://localhost:8000"
API_TIMEOUT = 900  # seconds (increased to 15 mins for large projects)

# Login Credentials
LOGIN_EMAIL = "admin@mira-ai.com"
LOGIN_PASSWORD = "Admin123!@#"

# SSH Configuration
SSH_HOSTNAME = "10.240.92.1"
SSH_PORT = 2224
SSH_USERNAME = "usama"
SSH_PASSWORD = os.environ.get("SSH_PASSWORD", "TempPassUsama2026!") # Added env fallback
SSH_BASE_PATH = "/home/usama"  # Base path on remote server
# Note: Full path will be constructed as: {SSH_BASE_PATH}/{project_name}
# Example: /home/usama/php-task-manager for project "php-task-manager"

# SonarQube Configuration
SONAR_TOKEN = os.environ.get("SONAR_TOKEN", "squ_cc0635a5221eb49f8074136b5090f64c3950a1a2")
SONAR_HOST_URL = os.environ.get("SONAR_HOST_URL", "http://10.240.92.129:9000")

# Report Settings
# Valid values: "generic_security", "owasp_top_10", "pci_dss", "iso_27001"
VALID_REPORT_TYPES = {"generic_security", "owasp_top_10", "pci_dss", "iso_27001"}
DEFAULT_REPORT_TYPE = "generic_security"
REPORT_TYPES = [DEFAULT_REPORT_TYPE]  # Default; overridden at runtime via run_download_workflow(report_type=...)
# All formats supported by /api/v1/analyze/reports/{report_id}/download (excluding pdf)
REPORT_FORMATS = ["html", "docx", "md"]
OUTPUT_DIRECTORY = "./reports"

# Optional Settings
SKIP_SSH_TEST = False  # Set to True to skip SSH connection test



class Colors:
    """Terminal colors"""
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    END = '\033[0m'


def print_step(step_num, message):
    """Print step header"""
    print(f"\n{Colors.CYAN}{'═' * 80}{Colors.END}")
    print(f"{Colors.BOLD}STEP {step_num}: {message}{Colors.END}")
    print(f"{Colors.CYAN}{'═' * 80}{Colors.END}")


def print_success(message):
    """Print success message"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{Colors.GREEN}[{timestamp}] ✓ {message}{Colors.END}")


def print_error(message):
    """Print error message"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{Colors.RED}[{timestamp}] ✗ {message}{Colors.END}")


def print_info(message):
    """Print info message"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{Colors.BLUE}[{timestamp}] ℹ {message}{Colors.END}")


def login():
    """Step 1: Login and get access token"""
    print_step(1, "Authenticating")
    
    try:
        url = f"{API_BASE_URL}/api/v1/accounts/login"
        payload = {
            "email": LOGIN_EMAIL,
            "password": LOGIN_PASSWORD
        }
        
        print_info(f"Logging in as {LOGIN_EMAIL}...")
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            access_token = data.get("access_token")
            
            if access_token:
                print_success("Login successful! Access token obtained.")
                return access_token
            else:
                print_error("Login response missing access_token")
                return None
        else:
            print_error(f"Login failed: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        print_error(f"Login failed: {e}")
        return None


def test_ssh(
    access_token,
    project_name,
    source_path_override: Optional[str] = None,
    ssh_credentials: Optional[dict] = None,
):
    """Step 2: Test SSH connection. If ``source_path_override`` is set, verify that path; otherwise ``{SSH_BASE_PATH}/{project_name}``. Optional ``ssh_credentials`` overrides module defaults (same shape as analyze/test/ssh body)."""
    print_step(2, "Testing SSH Connection")
    
    if SKIP_SSH_TEST:
        print_info("SSH test skipped (SKIP_SSH_TEST = True)")
        return True
    
    override = (source_path_override or "").strip()
    if override:
        source_path = override
        project_folder = Path(source_path).name
    else:
        # Convert project name to lowercase and replace spaces with hyphens
        project_folder = project_name.lower().replace(' ', '-')
        source_path = f"{SSH_BASE_PATH}/{project_folder}"
    
    try:
        url = f"{API_BASE_URL}/api/v1/analyze/test/ssh"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        if ssh_credentials:
            creds_payload = {k: v for k, v in ssh_credentials.items() if v is not None}
        else:
            creds_payload = {
                "hostname": SSH_HOSTNAME,
                "port": SSH_PORT,
                "username": SSH_USERNAME,
                "password": SSH_PASSWORD,
            }
        payload = {
            "ssh_credentials": creds_payload,
            "source_path": source_path
        }
        
        print_info(f"Testing connection to {creds_payload.get('username')}@{creds_payload.get('hostname')}:{creds_payload.get('port')}")
        print_info(f"Project folder: {project_folder}")
        print_info(f"Verifying source path: {source_path}")
        
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        
        if response.status_code == 200:
            data = response.json()

            if data.get("success"):
                print_success("SSH connection successful!")

                if data.get("source_path_verified", True):
                    print_success(f"Source path verified: {source_path}")
                    return True
                else:
                    print_error(f"Source path could not be verified: {source_path}")
                    return False
            else:
                print_error(f"SSH connection failed: {data.get('message', 'Unknown error')}")
                return False
        else:
            print_error(f"SSH test failed: {response.status_code}")
            return False
            
    except Exception as e:
        print_error(f"SSH test failed: {e}")
        return False


def analyze_code(
    access_token,
    project_name,
    sonar_token=None,
    sonar_host_url=None,
    source_path: Optional[str] = None,
    ssh_credentials: Optional[dict] = None,
    report_type: Optional[str] = None,
):
    """Step 3: Trigger code analysis (POST /api/v1/analyze/scan).

    Args:
        report_type: One of "generic_security", "owasp_top_10", "pci_dss", "iso_27001".
                     Passed to the scan API so the correct SonarQube quality profile is used.
    """
    effective_type = (report_type or DEFAULT_REPORT_TYPE).strip().lower()
    if effective_type not in VALID_REPORT_TYPES:
        effective_type = DEFAULT_REPORT_TYPE
    print_step(3, f"Analyzing Code [{effective_type.upper()}]")

    try:
        url = f"{API_BASE_URL}/api/v1/analyze/scan"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        payload = {
            "project_name": project_name,
            "report_types": [effective_type],
        }
        sp = (source_path or "").strip()
        if sp:
            payload["source_path"] = sp
        if ssh_credentials:
            payload["ssh_credentials"] = {k: v for k, v in ssh_credentials.items() if v is not None}
        # Use same credentials as the API: request body takes precedence, then module-level config, then env
        token = sonar_token or SONAR_TOKEN
        host_url = sonar_host_url or SONAR_HOST_URL
        if token:
            payload["sonar_token"] = token
        if host_url:
            payload["sonar_host_url"] = host_url
        
        print_info(f"Project: {project_name}")
        print_info(f"Report type: {effective_type}")
        print_info("Starting code analysis... (this may take a few minutes)")
        
        response = requests.post(url, json=payload, headers=headers, timeout=API_TIMEOUT)
        
        if response.status_code in [200, 201]:
            data = response.json()
            
            # Try multiple locations for report_id and extract file paths
            report_id = data.get("report_id")
            report_paths = {}  # format -> absolute path (use when running on same server as API)
            
            if data.get("report") and data["report"].get("security_reports"):
                sec = data["report"]["security_reports"]
                for report_type, report_data in sec.items():
                    if report_data.get("report_id"):
                        report_id = report_id or report_data["report_id"]
                    # Extract file paths from formats (avoid broken download endpoint when paths exist locally)
                    for fmt, info in (report_data.get("formats") or {}).items():
                        if isinstance(info, dict) and info.get("file"):
                            report_paths[fmt.lower()] = info["file"]
                    if report_id and report_paths:
                        break
            
            if report_id:
                print_success(f"Analysis completed!")
                print_success(f"Report ID: {report_id}")
                return (report_id, report_paths)
            else:
                print_error("Analysis response missing report_id")
                print_info(f"Response keys: {list(data.keys())}")
                if data.get("report"):
                    print_info(f"Report keys: {list(data['report'].keys())}")
                return (None, {})
        else:
            print_error(f"Analysis failed: {response.status_code} - {response.text}")
            return (None, {})
            
    except requests.exceptions.Timeout:
        print_error("Analysis request timed out")
        print_info("Large projects may take longer. Check server logs.")
        return (None, {})
    except Exception as e:
        print_error(f"Analysis failed: {e}")
        return (None, {})


def download_report(access_token, report_id, project_name=None, output_directory=None, report_paths=None):
    """Step 4: Download report in all formats (html, pdf, docx, md). When report_paths is provided and paths exist locally (same server as API), copy from disk to avoid the download API; otherwise use HTTP. If project_name given, HTML is also saved as {project_name}_sonarqube_report_{timestamp}.html for API discovery."""
    print_step(4, "Downloading Report (all formats)")
    
    url = f"{API_BASE_URL}/api/v1/analyze/reports/{report_id}/download"
    headers = {"Authorization": f"Bearer {access_token}"}
    output_dir = Path(output_directory) if output_directory else Path(OUTPUT_DIRECTORY)
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    downloaded = 0
    html_path_for_rename = None
    report_paths = report_paths or {}

    try:
        print_info(f"Report ID: {report_id}")
        print_info(f"Formats: {', '.join(f.upper() for f in REPORT_FORMATS)}")

        for fmt in REPORT_FORMATS:
            src_path = report_paths.get(fmt.lower())
            if src_path and os.path.exists(src_path):
                try:
                    filename = os.path.basename(src_path)
                    output_path = output_dir / filename
                    if os.path.abspath(src_path) != os.path.abspath(output_path):
                        shutil.copy2(src_path, output_path)
                    if fmt.lower() == "html":
                        html_path_for_rename = output_path
                    file_size = output_path.stat().st_size
                    print_success(f"{fmt.upper()}: {output_path.name} ({file_size:,} bytes, from disk)")
                    downloaded += 1
                    continue
                except Exception as e:
                    print_error(f"Copy failed for {fmt.upper()}: {e}")
            params = {"format": fmt}
            try:
                response = requests.get(
                    url,
                    params=params,
                    headers=headers,
                    stream=False,
                    timeout=90
                )
                if response.status_code != 200:
                    print_error(f"Download failed for {fmt.upper()}: {response.status_code}")
                    continue
                filename = None
                if "Content-Disposition" in response.headers:
                    content_disp = response.headers["Content-Disposition"]
                    if "filename=" in content_disp:
                        filename = content_disp.split("filename=")[1].strip('"')
                if not filename:
                    filename = f"sonarqube_report_{report_id}_{timestamp}.{fmt}"
                output_path = output_dir / filename
                content = getattr(response, "content", None) or b""
                if content:
                    with open(output_path, "wb") as f:
                        f.write(content)
                    if fmt.lower() == "html":
                        html_path_for_rename = output_path
                    file_size = output_path.stat().st_size
                    print_success(f"{fmt.upper()}: {output_path.name} ({file_size:,} bytes)")
                    downloaded += 1
                else:
                    print_error(f"Download failed for {fmt.upper()}: empty response body")
            except Exception as e:
                print_error(f"Download failed for {fmt.upper()}: {e}")

        if downloaded > 0 and project_name and html_path_for_rename and html_path_for_rename.exists():
            try:
                named_path = output_dir / f"{project_name.replace(' ', '_')}_sonarqube_report_{timestamp}.html"
                if named_path != html_path_for_rename:
                    html_path_for_rename.rename(named_path)
                    print_success(f"HTML report named for API: {named_path.name}")
            except Exception as e:
                print_error(f"Rename for project name failed: {e}")

        if downloaded > 0:
            print_success(f"Downloaded {downloaded} format(s) to {output_dir.absolute()}")
            return True
        print_error("No format could be downloaded")
        return False

    except Exception as e:
        print_error(f"Download failed: {e}")
        return False


def get_project_name():
    """Project name: first CLI arg, then PROJECT_NAME env. Returns None if neither is set (no fallback)."""
    if len(sys.argv) > 1 and sys.argv[1].strip():
        return sys.argv[1].strip()
    return (os.environ.get("PROJECT_NAME", "").strip() or None)


def run_download_workflow(
    project_name: str,
    output_directory: Optional[Union[str, Path]] = None,
    skip_ssh_test: Optional[bool] = None,
    sonar_token: Optional[str] = None,
    sonar_host_url: Optional[str] = None,
    remote_source_path: Optional[str] = None,
    ssh_credentials: Optional[dict] = None,
    report_type: Optional[str] = None,
) -> bool:
    """
    Run the full SonarQube report download workflow (login → test SSH → analyze code → download report).

    Args:
        project_name:        Name of the project to scan.
        output_directory:    Local directory to save the downloaded report.
        skip_ssh_test:       Skip SSH connectivity test when True.
        sonar_token:         SonarQube auth token (overrides module-level SONAR_TOKEN).
        sonar_host_url:      SonarQube server URL (overrides module-level SONAR_HOST_URL).
        remote_source_path:  Path on the client SSH server to scan (overrides SSH_BASE_PATH/{project_name}).
        ssh_credentials:     Dict with hostname/port/username/password/private_key for SSH.
        report_type:         One of "generic_security" (default), "owasp_top_10", "pci_dss", "iso_27001".
                             Determines which SonarQube quality profile / rule set is activated.

    Returns True if the report was downloaded successfully, False otherwise.
    """
    # Validate and normalise report_type
    effective_report_type = (report_type or DEFAULT_REPORT_TYPE).strip().lower()
    if effective_report_type not in VALID_REPORT_TYPES:
        import logging as _logging
        _logging.getLogger(__name__).warning(
            "Unknown report_type '%s'; falling back to '%s'. Valid: %s",
            effective_report_type, DEFAULT_REPORT_TYPE, sorted(VALID_REPORT_TYPES),
        )
        effective_report_type = DEFAULT_REPORT_TYPE

    access_token = login()
    if not access_token:
        return False
    if skip_ssh_test if skip_ssh_test is not None else SKIP_SSH_TEST:
        pass
    elif not test_ssh(
        access_token,
        project_name,
        source_path_override=remote_source_path,
        ssh_credentials=ssh_credentials,
    ):
        return False
    result = analyze_code(
        access_token,
        project_name,
        sonar_token=sonar_token,
        sonar_host_url=sonar_host_url,
        source_path=remote_source_path,
        ssh_credentials=ssh_credentials,
        report_type=effective_report_type,
    )
    if not result:
        return False
    report_id, report_paths = result
    if not report_id:
        return False
    if not download_report(
        access_token,
        report_id,
        project_name=project_name,
        output_directory=output_directory,
        report_paths=report_paths,
    ):
        return False
    return True


def main():
    """Main workflow: uses run_download_workflow (same function called by upgrade analysis agent). Project name required (CLI arg or PROJECT_NAME env)."""
    project_name = get_project_name()
    if not project_name:
        print_error("Project name is required. Pass it as the first argument or set PROJECT_NAME environment variable.")
        sys.exit(1)
    print(f"\n{Colors.BOLD}{Colors.CYAN}{'═' * 80}")
    print(f"           SonarQube Report Downloader - Automated Workflow")
    print(f"{'═' * 80}{Colors.END}\n")
    print(f"{Colors.BOLD}Project:{Colors.END} {project_name}")
    print(f"{Colors.BOLD}API Server:{Colors.END} {API_BASE_URL}")
    print(f"{Colors.BOLD}Output Directory:{Colors.END} {OUTPUT_DIRECTORY}")
    print(f"{Colors.BOLD}Report Formats:{Colors.END} {', '.join(f.upper() for f in REPORT_FORMATS)}")
    start_time = time.time()
    try:
        success = run_download_workflow(project_name)
        elapsed_time = time.time() - start_time
        if success:
            print(f"\n{Colors.CYAN}{'═' * 80}{Colors.END}")
            print(f"{Colors.BOLD}{Colors.GREEN}✨ SUCCESS! Workflow completed in {elapsed_time:.1f} seconds{Colors.END}")
            print(f"{Colors.BOLD}{Colors.GREEN}Report downloaded and ready to use!{Colors.END}")
            print(f"{Colors.CYAN}{'═' * 80}{Colors.END}\n")
            sys.exit(0)
        print_error("\n❌ Workflow failed")
        sys.exit(1)
    except KeyboardInterrupt:
        print(f"\n\n{Colors.YELLOW}⚠ Workflow interrupted by user{Colors.END}\n")
        sys.exit(1)
    except Exception as e:
        print_error(f"\n❌ Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()