"""Service for fetching reports from SonarQube server"""
import requests
from typing import Optional, Dict, Any, List
from app.core.logging import get_logger
from app.core.config import settings

logger = get_logger(__name__)


class SonarQubeReportFetcher:
    """Service for fetching reports and data from SonarQube server"""
    
    def __init__(self, sonar_host_url: str = "https://sonarqube.codsy.ai", sonar_token: Optional[str] = None):
        """
        Initialize SonarQube report fetcher
        
        Args:
            sonar_host_url: SonarQube server URL
            sonar_token: SonarQube authentication token (optional for public endpoints)
        """
        self.sonar_host_url = sonar_host_url.rstrip('/')
        self.sonar_token = sonar_token
        self.session = requests.Session()
        if sonar_token:
            # SonarQube uses HTTP Basic Auth with token as username and empty password
            self.session.auth = (sonar_token, '')
    
    def _make_request(self, endpoint: str, params: Optional[Dict] = None) -> Optional[Dict[str, Any]]:
        """Make HTTP request to SonarQube API"""
        try:
            url = f"{self.sonar_host_url}{endpoint}"
            headers = {}
            
            # Headers for API requests
            
            response = self.session.get(url, params=params, headers=headers, timeout=30)
            
            # Verify response is JSON, not HTML
            if response.status_code == 200 and "<!doctype html>" in response.text.lower():
                logger.warning("Received HTML instead of JSON API response. The request may have been blocked.")
                return None
            
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 403:
                logger.error(
                    f"403 Forbidden accessing {endpoint}. "
                    f"This usually means the token doesn't have permission for this endpoint. "
                    f"Token: {'Set' if self.sonar_token else 'Not set'}"
                )
            else:
                logger.error(f"HTTP error fetching from SonarQube API: {e}")
            return None
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch from SonarQube API: {e}")
            return None
    
    def get_project_measures(self, project_key: str, metric_keys: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Get project measures/metrics
        
        Args:
            project_key: SonarQube project key
            metric_keys: List of metric keys to fetch (default: common metrics)
        """
        if metric_keys is None:
            metric_keys = [
                "bugs", "vulnerabilities", "code_smells",
                "coverage", "duplicated_lines_density",
                "ncloc", "sqale_index", "reliability_rating",
                "security_rating", "sqale_rating"
            ]
        
        params = {
            "component": project_key,
            "metricKeys": ",".join(metric_keys)
        }
        
        result = self._make_request("/api/measures/component", params)
        if result:
            return {
                "success": True,
                "project_key": project_key,
                "measures": result.get("component", {}).get("measures", []),
                "data": result
            }
        return {"success": False, "error": "Failed to fetch project measures"}
    
    def get_project_issues(self, project_key: str, severities: Optional[List[str]] = None,
                          types: Optional[List[str]] = None, limit: int = 100) -> Dict[str, Any]:
        """
        Get project issues
        
        Args:
            project_key: SonarQube project key
            severities: Filter by severity (BLOCKER, CRITICAL, MAJOR, MINOR, INFO)
            types: Filter by type (BUG, VULNERABILITY, CODE_SMELL)
            limit: Maximum number of issues to return
        """
        params = {
            "componentKeys": project_key,
            "ps": limit
        }
        
        if severities:
            params["severities"] = ",".join(severities)
        if types:
            params["types"] = ",".join(types)
        
        result = self._make_request("/api/issues/search", params)
        if result:
            return {
                "success": True,
                "project_key": project_key,
                "total": result.get("total", 0),
                "issues": result.get("issues", []),
                "data": result
            }
        return {"success": False, "error": "Failed to fetch project issues"}
    
    def get_project_status(self, project_key: str) -> Dict[str, Any]:
        """
        Get project quality gate status
        
        Args:
            project_key: SonarQube project key
        """
        params = {"projectKey": project_key}
        result = self._make_request("/api/qualitygates/project_status", params)
        if result:
            return {
                "success": True,
                "project_key": project_key,
                "status": result.get("projectStatus", {}).get("status", "UNKNOWN"),
                "conditions": result.get("projectStatus", {}).get("conditions", []),
                "data": result
            }
        return {"success": False, "error": "Failed to fetch project status"}
    
    def get_project_info(self, project_key: str) -> Dict[str, Any]:
        """
        Get project information
        
        Args:
            project_key: SonarQube project key
        """
        params = {"projects": project_key}
        result = self._make_request("/api/projects/search", params)
        if result:
            projects = result.get("components", [])
            if projects:
                return {
                    "success": True,
                    "project_key": project_key,
                    "project": projects[0],
                    "data": result
                }
        return {"success": False, "error": "Project not found"}
    
    def get_full_report(self, project_key: str) -> Dict[str, Any]:
        """
        Get comprehensive report including measures, issues, and status
        
        Args:
            project_key: SonarQube project key
        """
        try:
            measures = self.get_project_measures(project_key)
            issues = self.get_project_issues(project_key, limit=500)
            status = self.get_project_status(project_key)
            info = self.get_project_info(project_key)
            
            return {
                "success": True,
                "project_key": project_key,
                "measures": measures.get("measures", []) if measures.get("success") else [],
                "issues": {
                    "total": issues.get("total", 0) if issues.get("success") else 0,
                    "items": issues.get("issues", []) if issues.get("success") else []
                },
                "quality_gate": {
                    "status": status.get("status", "UNKNOWN") if status.get("success") else "UNKNOWN",
                    "conditions": status.get("conditions", []) if status.get("success") else []
                },
                "project_info": info.get("project", {}) if info.get("success") else {}
            }
        except Exception as e:
            logger.error(f"Failed to generate full report: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e)
            }

