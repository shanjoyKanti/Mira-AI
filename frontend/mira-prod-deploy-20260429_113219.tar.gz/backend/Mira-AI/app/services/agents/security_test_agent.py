"""
Security Test Agent for MIRA-AI

Post-modernization verification agent that cross-checks the modernized codebase
against BOTH the SonarQube analysis report AND the PHP upgrade guide (the same
reports used by the code modernization agent) to identify which issues have been
resolved during modernization and which remain.

Flow:
1. Load the SonarQube analysis report from app/data/upgrade-guide/
2. Load the PHP upgrade guide from app/data/upgrade-guide/
3. Parse issues from both reports
4. Load the modernized/upgraded PHP code files via SSH
5. For each file, ask the LLM to verify which issues are resolved vs remaining
6. Aggregate and return a combined verification report
"""

import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime

from app.services.agents.base_agent import BaseAgent, AgentState, GroqClient
from app.core.logging import get_logger

logger = get_logger(__name__)

# Default location for reports
UPGRADE_GUIDE_DIR = Path("app/data/upgrade-guide")


class SecurityTestAgent(BaseAgent):
    """Verifies modernized code against SonarQube analysis + PHP upgrade guide"""

    def __init__(self, groq_client: Optional[GroqClient] = None):
        super().__init__(
            name="security_test_agent",
            description="Cross-checks modernized code against SonarQube analysis and PHP upgrade guide",
            groq_client=groq_client,
        )
        self.sonarqube_report_content: Optional[str] = None
        self.php_guide_content: Optional[str] = None
        self.sonarqube_issues: List[Dict] = []
        self.php_guide_items: List[Dict] = []
        self.modernized_files: Dict[str, str] = {}  # rel_path -> code

    # =========================================================================
    # STEP 1: LOAD REPORTS
    # =========================================================================

    def load_sonarqube_report(
        self, project_name: str, report_path: Optional[str] = None
    ) -> bool:
        """Load the SonarQube analysis report for the project."""
        if report_path:
            path = Path(report_path)
        else:
            candidates = sorted(
                UPGRADE_GUIDE_DIR.glob(f"{project_name}_sonarqube_analysis_*.txt"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if not candidates:
                logger.error(
                    "No SonarQube analysis report found for project '%s' in %s",
                    project_name, UPGRADE_GUIDE_DIR,
                )
                return False
            path = candidates[0]

        if not path.exists():
            logger.error("SonarQube analysis report not found: %s", path)
            return False

        with open(path, "r", encoding="utf-8") as f:
            self.sonarqube_report_content = f.read()

        logger.info("Loaded SonarQube report: %s (%s chars)", path, len(self.sonarqube_report_content))
        return True

    def load_php_upgrade_guide(
        self, project_name: str, guide_path: Optional[str] = None
    ) -> bool:
        """Load the PHP upgrade guide for the project."""
        if guide_path:
            path = Path(guide_path)
        else:
            candidates = sorted(
                UPGRADE_GUIDE_DIR.glob(f"{project_name}_php_upgrade_guide_*.txt"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if not candidates:
                logger.warning(
                    "No PHP upgrade guide found for project '%s' in %s",
                    project_name, UPGRADE_GUIDE_DIR,
                )
                return False
            path = candidates[0]

        if not path.exists():
            logger.warning("PHP upgrade guide not found: %s", path)
            return False

        with open(path, "r", encoding="utf-8") as f:
            self.php_guide_content = f.read()

        logger.info("Loaded PHP upgrade guide: %s (%s chars)", path, len(self.php_guide_content))
        return True

    # =========================================================================
    # STEP 2: PARSE ISSUES FROM BOTH REPORTS
    # =========================================================================

    def parse_sonarqube_issues(self) -> List[Dict]:
        """Parse issues from the SonarQube analysis report."""
        if not self.sonarqube_report_content:
            return []

        issues: List[Dict] = []
        report = self.sonarqube_report_content

        issues_section = self._extract_section(report, "## ISSUES BY FILE")
        if not issues_section:
            logger.warning("No '## ISSUES BY FILE' section found in SonarQube report")
            return []

        # Split by file headings (### filename.php)
        file_blocks = re.split(r"^### (.+?)\s*$", issues_section, flags=re.MULTILINE)

        i = 1
        while i < len(file_blocks) - 1:
            current_file = file_blocks[i].strip()
            issue_block = file_blocks[i + 1]
            i += 2

            issue_entries = re.split(r"^- \*\*Line ", issue_block, flags=re.MULTILINE)

            for entry in issue_entries:
                entry = entry.strip()
                if not entry:
                    continue

                entry = "**Line " + entry

                header_match = re.match(
                    r"\*\*Line\s+(.+?)\*\*\s*\[(\w+)\]\s*\*\*Rule:\*\*\s*(\S+)\s*[—–-]\s*(.+?)(?:\s{2,}|\n|$)",
                    entry,
                )
                if not header_match:
                    continue

                line_val = header_match.group(1).strip()
                severity = header_match.group(2).strip()
                rule_type = header_match.group(3).strip()
                message = header_match.group(4).strip()

                code_match = re.search(
                    r"\*\*Code:\*\*\s*(?:```(?:php)?\s*(.*?)```|(.*?)(?=\*\*Remediation|\Z))",
                    entry, re.DOTALL,
                )
                original_code = ""
                if code_match:
                    original_code = (code_match.group(1) or code_match.group(2) or "").strip()

                remediation_match = re.search(
                    r"\*\*Remediation:\*\*\s*(.*?)(?=\n- \*\*Line|\Z)",
                    entry, re.DOTALL,
                )
                remediation = ""
                if remediation_match:
                    remediation = remediation_match.group(1).strip()

                issues.append({
                    "source": "sonarqube_analysis",
                    "file": current_file,
                    "line": line_val,
                    "severity": severity,
                    "rule": rule_type,
                    "message": message,
                    "original_code": original_code,
                    "remediation": remediation,
                })

        self.sonarqube_issues = issues
        logger.info("Parsed %d SonarQube issues", len(issues))
        return issues

    def parse_php_guide_items(self) -> List[Dict]:
        """
        Parse actionable items from the PHP upgrade guide.

        Extracts items from QUICK REFERENCE table and individual
        code change entries (Old Code → New Code).
        """
        if not self.php_guide_content:
            return []

        items: List[Dict] = []
        guide = self.php_guide_content

        # Extract upgrade path
        upgrade_match = re.search(r"\*\*Upgrade path:\*\*\s*(.+)", guide)
        upgrade_path = upgrade_match.group(1).strip() if upgrade_match else "unknown"

        # Parse individual code change entries across all sections
        # Pattern: - **Description**\n  - **Old Code:**\n```php\n...\n```\n  - **New Code:**\n```php\n...\n```
        sections_to_parse = [
            "## BREAKING CHANGES",
            "## DEPRECATED AND REMOVED FUNCTIONS",
            "## SYNTAX AND TYPE UPDATES",
        ]

        for section_heading in sections_to_parse:
            section = self._extract_section(guide, section_heading)
            if not section:
                continue

            # Find PHP version sub-headings and their items (handle optional bolding/whitespaces)
            version_blocks = re.split(r"^###[\s\*]*(PHP [\d.]+)[\s\*]*", section, flags=re.MULTILINE | re.IGNORECASE)

            vi = 1
            while vi < len(version_blocks) - 1:
                php_version = version_blocks[vi].strip()
                block = version_blocks[vi + 1]
                vi += 2

                # Find individual items (start with - **description** or 1. **description**)
                item_entries = re.split(r"^(?:-|\d+\.) \*\*", block, flags=re.MULTILINE)

                for entry in item_entries:
                    entry = entry.strip()
                    if not entry:
                        continue

                    entry = "**" + entry

                    # Extract description
                    desc_match = re.match(r"\*\*(.+?)\*\*", entry)
                    if not desc_match:
                        continue
                    description = desc_match.group(1).strip()

                    # Extract Old Code
                    old_code_match = re.search(
                        r"\*\*Old Code[^\`]*```(?:php)?\s*(.*?)```",
                        entry, re.IGNORECASE | re.DOTALL,
                    )
                    old_code = old_code_match.group(1).strip() if old_code_match else ""

                    # Extract New Code
                    new_code_match = re.search(
                        r"\*\*New Code[^\`]*```(?:php)?\s*(.*?)```",
                        entry, re.IGNORECASE | re.DOTALL,
                    )
                    new_code = new_code_match.group(1).strip() if new_code_match else ""
                    
                    # If specific sections not found, just grab any code block
                    if not old_code and not new_code:
                        any_code_match = re.search(
                            r"```(?:php)?\s*(.*?)```",
                            entry, re.IGNORECASE | re.DOTALL,
                        )
                        if any_code_match:
                            old_code = any_code_match.group(1).strip()

                    if old_code or new_code:
                        items.append({
                            "source": "php_upgrade_guide",
                            "section": section_heading.replace("## ", ""),
                            "php_version": php_version,
                            "description": description,
                            "old_code": old_code,
                            "new_code": new_code,
                            "upgrade_path": upgrade_path,
                        })

        self.php_guide_items = items
        logger.info("Parsed %d PHP upgrade guide items", len(items))
        return items

    # =========================================================================
    # STEP 3: LOAD MODERNIZED CODE
    # =========================================================================

    def load_modernized_code(self, upgraded_code_path: str) -> bool:
        """Load modernized PHP files from the upgraded code directory."""
        code_dir = Path(upgraded_code_path)
        if not code_dir.exists():
            logger.error("Upgraded code path not found: %s", upgraded_code_path)
            return False

        php_files = list(code_dir.rglob("*.php"))
        excluded = ["vendor", "node_modules", ".git", "cache"]
        php_files = [
            f for f in php_files if not any(ex in f.parts for ex in excluded)
        ]

        for php_file in php_files:
            try:
                with open(php_file, "r", encoding="utf-8", errors="ignore") as f:
                    code = f.read()
                rel_path = str(php_file.relative_to(code_dir))
                self.modernized_files[rel_path] = code
            except Exception as e:
                logger.warning("Could not read %s: %s", php_file, e)

        logger.info("Loaded %d modernized PHP files from %s", len(self.modernized_files), upgraded_code_path)
        return len(self.modernized_files) > 0

    # =========================================================================
    # STEP 4: VERIFY SONARQUBE ISSUES
    # =========================================================================

    def verify_sonarqube_issues(self) -> Dict:
        """Verify SonarQube issues against the modernized code."""
        if not self.sonarqube_issues:
            return self._build_empty_sonarqube_result()

        issues_by_file: Dict[str, List[Dict]] = {}
        for issue in self.sonarqube_issues:
            file_path = issue.get("file", "").strip()
            issues_by_file.setdefault(file_path, []).append(issue)

        resolved: List[Dict] = []
        remaining: List[Dict] = []

        for file_path, file_issues in issues_by_file.items():
            modernized_code = self._find_modernized_code(file_path)
            if modernized_code is None:
                for issue in file_issues:
                    issue["verification_note"] = "File not found in modernized codebase"
                remaining.extend(file_issues)
                continue

            file_resolved, file_remaining = self._verify_sonarqube_file(
                file_path, modernized_code, file_issues
            )
            resolved.extend(file_resolved)
            remaining.extend(file_remaining)

        total = len(self.sonarqube_issues)
        resolved_count = len(resolved)
        remaining_count = len(remaining)
        pct = round((resolved_count / total) * 100, 1) if total > 0 else 0.0

        return {
            "total_issues": total,
            "resolved_count": resolved_count,
            "remaining_count": remaining_count,
            "resolution_percentage": pct,
            "resolved_issues": resolved,
            "remaining_issues": remaining,
            "summary": (
                f"{resolved_count}/{total} SonarQube issues resolved ({pct}%). "
                f"{remaining_count} issue(s) still remain."
            ),
        }

    # =========================================================================
    # STEP 5: VERIFY PHP UPGRADE GUIDE
    # =========================================================================

    def verify_php_guide(self) -> Dict:
        """Verify PHP upgrade guide items against the modernized code."""
        if not self.php_guide_items:
            return self._build_empty_php_result()

        if not self.modernized_files:
            return self._build_empty_php_result()

        # Combine all modernized code for analysis
        code_snippets: List[str] = []
        for path, code in list(self.modernized_files.items())[:30]:
            truncated = code[:3000] if len(code) > 3000 else code
            code_snippets.append(f"--- {path} ---\n{truncated}")
        all_code = "\n\n".join(code_snippets)

        # Build the items text for the LLM
        items_text = ""
        for i, item in enumerate(self.php_guide_items):
            items_text += f"  {i+1}. [{item['php_version']}] [{item['section']}] {item['description']}\n"
            if item.get("old_code"):
                items_text += f"     Old pattern: {item['old_code'][:200]}\n"
            if item.get("new_code"):
                items_text += f"     New pattern: {item['new_code'][:200]}\n"
            items_text += "\n"

        prompt = f"""You are a PHP code reviewer verifying whether a codebase has been properly modernized according to a PHP upgrade guide.

MODERNIZED CODE:
{all_code}

PHP UPGRADE GUIDE ITEMS to verify:
{items_text}

For EACH numbered item, analyze the modernized code and determine ONE of these statuses:

- APPLIED: The new/modern PHP pattern from the guide IS used in the modernized code.
- NOT_APPLIED: The code COULD use this modern pattern but it was NOT added during modernization.
- NOT_APPLICABLE: The code has absolutely NO place where this feature could be used.

CRITICAL RULES FOR CORRECT CLASSIFICATION:

1. DEPRECATED/REMOVED FUNCTIONS (mysql_*, ereg_*, each(), mcrypt, etc.):
   - If the old function does NOT appear anywhere in the code → NOT_APPLICABLE
   - If the old function is still used → NOT_APPLIED
   - If replaced with the new function → APPLIED

2. SYNTAX AND TYPE UPDATES — THESE REQUIRE SPECIAL ATTENTION:
   - "Scalar type declarations" → If ANY function exists with untyped parameters, this IS applicable.
     A function like `function foo($a, $b)` WITHOUT type hints means scalar types were NOT_APPLIED.
     Only mark NOT_APPLICABLE if there are literally NO functions in the code.
   - "Union types" → If ANY function can return multiple different types (e.g., returns a number OR a string),
     this IS applicable. No return type declaration means it was NOT_APPLIED.
     Only mark NOT_APPLICABLE if every function returns exactly one type.
   - "Arrow functions" → Only applicable if code uses anonymous functions / closures.
     If no anonymous functions exist → NOT_APPLICABLE.
   - "Match expressions" → Only applicable if code uses switch statements.
     If no switch statements → NOT_APPLICABLE.
   - "Nullsafe operator" → Only applicable if code has null-check-then-access patterns.
     If none → NOT_APPLICABLE.
   - "Constructor property promotion" → Only applicable if code has classes with constructors.
     If no classes → NOT_APPLICABLE.
   - "str_contains/str_starts_with" → Only applicable if code uses strpos().
     If no strpos → NOT_APPLICABLE.

3. GENERAL RULE: If a PHP 8.3 feature COULD improve the code but was NOT added,
   that is NOT_APPLIED — NEVER mark it as NOT_APPLICABLE.
   NOT_APPLICABLE means the code has ZERO opportunity for that feature.

Respond in EXACTLY this format (one line per item):
1. APPLIED - brief explanation
2. NOT_APPLICABLE - brief explanation
3. NOT_APPLIED - brief explanation"""

        response = self.groq_client.generate(
            system_prompt="You are a strict PHP version compatibility reviewer. For EACH item: if the code COULD use the feature but doesn't, mark NOT_APPLIED. Only mark NOT_APPLICABLE if the code has absolutely NO place for that feature. Output one line per item: number, APPLIED or NOT_APPLICABLE or NOT_APPLIED, then a brief factual explanation.",
            user_content=prompt,
            temperature=0.7,
        )

        return self._parse_php_guide_response(response, self.php_guide_items)

    # =========================================================================
    # LLM VERIFICATION HELPERS
    # =========================================================================

    def _verify_sonarqube_file(
        self, file_path: str, code: str, issues: List[Dict]
    ) -> Tuple[List[Dict], List[Dict]]:
        """Use LLM to verify SonarQube issues for a single file."""

        issues_text = ""
        for i, iss in enumerate(issues):
            issues_text += f"  {i+1}. [Line {iss['line']}] [{iss['severity']}] {iss['rule']} — {iss['message']}\n"
            if iss.get("original_code"):
                issues_text += f"     Original problematic code: {iss['original_code']}\n"
            if iss.get("remediation"):
                rem = iss["remediation"][:300]
                issues_text += f"     Expected remediation: {rem}\n"
            issues_text += "\n"

        prompt = f"""You are a strict code reviewer verifying whether SonarQube issues have been resolved after code modernization.

MODERNIZED CODE for file "{file_path}":
```php
{code}
```

SONARQUBE ISSUES that the modernization agent was supposed to fix:
{issues_text}

For EACH numbered issue, carefully analyze the MODERNIZED CODE and determine:
- RESOLVED: The specific problem has been fixed as described in the remediation.
- REMAINING: The problematic pattern is still present in the modernized code.

VERIFICATION RULES:
- Check the ACTUAL code, not comments about fixes.
- "Add a new line at the end of this file" → the file must end with an actual trailing newline, not just a comment about it.
- "Move curly brace to next line" → check if the opening curly brace of the function/class is on its own separate line (PSR-12 style).
- "Immediately return this expression instead of assigning it to temporary variable X" → check if the SPECIFIC variable X mentioned in the issue has been eliminated. If the issue says remove "$total" and "$total" no longer exists in the code, it is RESOLVED — even if OTHER intermediate variables (like "$taxAmount") still exist. Focus ONLY on the specific variable named in the issue.
- Always compare against the SPECIFIC problem described in the "Original problematic code" field. If that exact pattern is gone, the issue is RESOLVED.
- Be precise and factual.

Respond in EXACTLY this format (one line per issue, same numbering):
1. RESOLVED - brief explanation of how it was fixed
2. REMAINING - brief explanation of why it still exists"""

        response = self.groq_client.generate(
            system_prompt="You are a strict code reviewer. Verify EACH SonarQube issue against the provided modernized code. Output exactly one line per issue: number, RESOLVED or REMAINING, then a brief factual explanation. Do not guess.",
            user_content=prompt,
            temperature=0.7,
        )

        return self._parse_verification_response(response, issues)

    def _parse_verification_response(
        self, response: str, issues: List[Dict]
    ) -> Tuple[List[Dict], List[Dict]]:
        """Parse LLM verification response into resolved/remaining lists."""
        resolved: List[Dict] = []
        remaining: List[Dict] = []

        lines = response.strip().split("\n")
        for i, issue in enumerate(issues):
            issue_copy = dict(issue)
            matched = False
            for line in lines:
                match = re.match(
                    rf"^\s*{i+1}[\.\)]\s*(RESOLVED|REMAINING)\s*[-–—:]\s*(.*)$",
                    line, re.IGNORECASE,
                )
                if match:
                    status_val = match.group(1).upper()
                    explanation = match.group(2).strip()
                    issue_copy["verification_note"] = explanation
                    if status_val == "RESOLVED":
                        resolved.append(issue_copy)
                    else:
                        remaining.append(issue_copy)
                    matched = True
                    break

            if not matched:
                issue_copy["verification_note"] = "Could not determine status from LLM response"
                remaining.append(issue_copy)

        return resolved, remaining

    def _parse_php_guide_response(self, response: str, items: List[Dict]) -> Dict:
        """Parse LLM PHP guide verification response."""
        applied: List[Dict] = []
        not_applicable: List[Dict] = []
        not_applied: List[Dict] = []

        lines = response.strip().split("\n")
        for i, item in enumerate(items):
            item_copy = dict(item)
            matched = False
            for line in lines:
                match = re.match(
                    rf"^\s*{i+1}[\.\)]\s*(APPLIED|NOT_APPLICABLE|NOT_APPLIED)\s*[-–—:]\s*(.*)$",
                    line, re.IGNORECASE,
                )
                if match:
                    status_val = match.group(1).upper()
                    explanation = match.group(2).strip()
                    item_copy["verification_note"] = explanation
                    if status_val == "APPLIED":
                        applied.append(item_copy)
                    elif status_val == "NOT_APPLICABLE":
                        not_applicable.append(item_copy)
                    else:
                        not_applied.append(item_copy)
                    matched = True
                    break

            if not matched:
                item_copy["verification_note"] = "Could not determine status from LLM response"
                not_applied.append(item_copy)

        total = len(items)
        applied_count = len(applied)
        not_applicable_count = len(not_applicable)
        not_applied_count = len(not_applied)
        # Percentage based on applicable items only
        applicable = total - not_applicable_count
        pct = round((applied_count / applicable) * 100, 1) if applicable > 0 else 100.0

        return {
            "total_items": total,
            "applied_count": applied_count,
            "not_applicable_count": not_applicable_count,
            "not_applied_count": not_applied_count,
            "compliance_percentage": pct,
            "applied_items": applied,
            "not_applicable_items": not_applicable,
            "not_applied_items": not_applied,
            "summary": (
                f"{applied_count}/{applicable} applicable PHP guide items applied ({pct}%). "
                f"{not_applied_count} item(s) not applied. "
                f"{not_applicable_count} item(s) not applicable to this codebase."
            ),
        }

    # =========================================================================
    # UTILITY HELPERS
    # =========================================================================

    def _find_modernized_code(self, file_path: str) -> Optional[str]:
        """Find modernized code for a file path (flexible matching)."""
        if file_path in self.modernized_files:
            return self.modernized_files[file_path]

        basename = Path(file_path).name
        for mod_path, code in self.modernized_files.items():
            if Path(mod_path).name == basename:
                return code

        for mod_path, code in self.modernized_files.items():
            if mod_path.endswith(file_path) or file_path.endswith(mod_path):
                return code

        return None

    @staticmethod
    def _extract_section(report: str, heading: str) -> Optional[str]:
        """Extract content under a specific ## heading until the next ## heading."""
        base_heading = heading.replace("## ", "")
        pattern = r"##[ \t#\*]*" + re.escape(base_heading) + r"[ \t\*]*(.*?(?=\n## |\Z))"
        match = re.search(pattern, report, re.IGNORECASE | re.DOTALL)
        return match.group(1).strip() if match else None

    @staticmethod
    def _build_empty_sonarqube_result() -> Dict:
        return {
            "total_issues": 0, "resolved_count": 0, "remaining_count": 0,
            "resolution_percentage": 0.0,
            "resolved_issues": [], "remaining_issues": [],
            "summary": "No SonarQube issues found to verify.",
        }

    @staticmethod
    def _build_empty_php_result() -> Dict:
        return {
            "total_items": 0, "applied_count": 0, "not_applicable_count": 0,
            "not_applied_count": 0, "compliance_percentage": 0.0,
            "applied_items": [], "not_applicable_items": [], "not_applied_items": [],
            "summary": "No PHP upgrade guide items found to verify.",
        }

    # =========================================================================
    # MAIN EXECUTION
    # =========================================================================

    def execute(self, state: AgentState) -> AgentState:
        """
        Execute the combined security test verification workflow.

        Expected state parameters:
        - project_name: Base project name (required)
        - upgraded_code_path: Path to modernized code directory (required)
        - sonarqube_report_path: Optional path to SonarQube analysis report
        - php_guide_path: Optional path to PHP upgrade guide
        """
        try:
            project_name = state.context.get("project_name")
            upgraded_code_path = state.context.get("upgraded_code_path")
            sonarqube_report_path = state.context.get("sonarqube_report_path")
            php_guide_path = state.context.get("php_guide_path")

            if not project_name:
                state.add_error("project_name is required")
                return state

            if not upgraded_code_path:
                state.add_error("upgraded_code_path is required")
                return state

            # Step 1: Load both reports
            sonarqube_loaded = self.load_sonarqube_report(project_name, sonarqube_report_path)
            php_guide_loaded = self.load_php_upgrade_guide(project_name, php_guide_path)

            if not sonarqube_loaded and not php_guide_loaded:
                state.add_error(
                    f"Failed to load both SonarQube analysis and PHP upgrade guide for '{project_name}'"
                )
                return state

            # Step 2: Parse issues from both reports
            sonarqube_issues = self.parse_sonarqube_issues() if sonarqube_loaded else []
            php_guide_items = self.parse_php_guide_items() if php_guide_loaded else []

            if not sonarqube_issues and not php_guide_items:
                state.add_result("sonarqube_verification", self._build_empty_sonarqube_result())
                state.add_result("php_guide_verification", self._build_empty_php_result())
                return state

            # Step 3: Load modernized code
            if not self.load_modernized_code(upgraded_code_path):
                state.add_error(
                    f"Failed to load modernized code from '{upgraded_code_path}'"
                )
                return state

            # Step 4: Verify SonarQube issues
            sonarqube_result = self.verify_sonarqube_issues() if sonarqube_issues else self._build_empty_sonarqube_result()
            state.add_result("sonarqube_verification", sonarqube_result)

            # Step 5: Verify PHP upgrade guide
            php_result = self.verify_php_guide() if php_guide_items else self._build_empty_php_result()
            state.add_result("php_guide_verification", php_result)

            logger.info(
                "Security test completed — SonarQube: %s/%s resolved (%.1f%%), PHP Guide: %s/%s applied (%.1f%%)",
                sonarqube_result["resolved_count"],
                sonarqube_result["total_issues"],
                sonarqube_result["resolution_percentage"],
                php_result["applied_count"],
                php_result["total_items"],
                php_result["compliance_percentage"],
            )
            return state

        except Exception as e:
            state.add_error(f"Security test failed: {str(e)}")
            return state
