"""LLM report generator functions, report type registries, and workflow helpers."""
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any, Optional

from app.services.llm.llm_service import get_llm_service
from app.core.logging import get_logger
from app.api.v1.analyze.utils import _parse_llm_json_response

logger = get_logger(__name__)


# Used by generate_project_analysis_report. JSON braces are doubled so .format()
# emits single braces; substitution fields use single braces.
_PROJECT_ANALYSIS_PROMPT_TEMPLATE = """You are a Principal Software Architect with 20+ years of experience in system design and codebase auditing.
Perform an exhaustive, deeply technical Codebase Analysis for this project. This report is for developers, technical leads, and architects who need to deeply understand this codebase.

**Project Info:**
- Name: {project_name}
- Key: {project_key}
- Source Path: {source_path}

**Complete File/Directory Structure:**
{file_tree}
{source_section}
**Code Quality Metrics (if available):**
- Total Issues: {total_issues}
- Metrics: {metrics}

**Key Issues Found:**
{top_issues}

**INSTRUCTIONS:**
Analyze ALL of the following 10 aspects thoroughly. You MUST base your analysis on the ACTUAL SOURCE CODE provided above — reference specific files, functions, classes, imports, and code patterns you observe. Do NOT guess or provide generic advice.

1. **Directory Structure** - Module layout, organization quality, naming conventions, separation of concerns
2. **Entry Points** - Main functions, scripts, API entry points, scheduled jobs
3. **External Interfaces** - APIs consumed or exposed, webhooks, message queues, file/socket protocols
4. **Architectural Styles** - Layered, Microservices, Monolith, Event-driven, CQRS, MVC/MVVM
5. **Software Design Patterns** - Singleton, Factory, Observer, Strategy, Repository, Service Layer, custom/hybrid patterns
6. **Anti-Patterns & Code Smells** - God classes, tight coupling, dead code, unused functions, duplicate logic, hard-coded configurations
7. **Configuration & Environment** - Environment-specific settings, hard-coded paths or secrets, logging setup
8. **Modules & Components** - Logical grouping of code, classes, functions, packages, external libraries vs internal modules
9. **Dependency Graphs** - Module-to-module dependencies, third-party library usage, cyclic dependencies, version mismatches
10. **Execution Flow** - Call hierarchy, event/request flow, threading/concurrency paths, error handling paths

Generate the report in this JSON format. **CRITICAL: Ensure the response is VALID JSON. All newlines within string values MUST be escaped as \\\\n. No literal newlines are allowed inside JSON strings.**
{{
    "report_title": "Comprehensive Project Analysis",
    "executive_summary": "A comprehensive 5-8 paragraph overview of the project's architecture, code organization, strengths, weaknesses, technical debt, and overall code health. Discuss the maturity of the codebase and its readiness for scaling.",
    "analysis_score": 0-100,
    "overall_health": "Excellent|Good|Fair|Poor",
    "directory_structure": {{
        "organization_style": "Describe the overall folder organization approach (e.g., feature-based, layer-based, hybrid)",
        "top_level_layout": "Description of top-level directory layout and purpose of each major directory",
        "modules_identified": [
            {{"name": "Module/folder name", "purpose": "What this module does", "files_estimate": 0, "health": "Good|Fair|Poor"}}
        ],
        "naming_conventions": "Assessment of naming consistency and quality",
        "separation_of_concerns": "How well the code separates different concerns (presentation, business logic, data access)",
        "assessment": "Overall assessment of directory organization quality",
        "recommendations": ["Specific improvement recommendation 1", "Specific improvement recommendation 2"]
    }},
    "entry_points": {{
        "main_entry": "Primary entry point file and description",
        "identified_entries": [
            {{"type": "API|Script|Main|ScheduledJob|CLI", "file": "file path", "description": "What this entry point does"}}
        ],
        "assessment": "Overall assessment of entry point organization"
    }},
    "external_interfaces": {{
        "apis_exposed": [{{"endpoint_pattern": "e.g. /api/v1/...", "description": "What it does"}}],
        "apis_consumed": [{{"service": "External service name", "description": "How it's used"}}],
        "webhooks": ["Description of any webhook integrations"],
        "message_queues": ["Description of any message queue usage (RabbitMQ, Redis, Kafka, etc.)"],
        "protocols": ["HTTP/REST, WebSocket, gRPC, etc."],
        "assessment": "Overall assessment of external interface design"
    }},
    "architectural_style": {{
        "primary_style": "MVC|Microservices|Monolith|Layered|Event-driven|CQRS|MVVM|Hybrid",
        "description": "Detailed explanation of the identified architectural style and why",
        "secondary_patterns": ["Additional architectural patterns identified"],
        "layer_analysis": [
            {{"layer": "Layer name (e.g., Presentation, Business Logic, Data Access)", "purpose": "What this layer does", "key_files": ["Key files in this layer"]}}
        ],
        "strengths": ["Architectural strength 1 with explanation", "Architectural strength 2"],
        "weaknesses": ["Architectural weakness 1 with explanation", "Architectural weakness 2"]
    }},
    "design_patterns": {{
        "patterns_detected": [
            {{"pattern": "Pattern name (e.g., Repository, Factory, Singleton, Observer)", "evidence": "What in the codebase suggests this pattern", "files": ["Files where this pattern is used"], "assessment": "How well it's implemented"}}
        ],
        "custom_patterns": ["Any custom or hybrid patterns identified"],
        "assessment": "Overall assessment of design pattern usage and consistency"
    }},
    "anti_patterns": {{
        "issues_found": [
            {{"type": "God Class|Tight Coupling|Dead Code|Duplicate Logic|Hard-coded Config|Missing Abstraction|Circular Dependency", "severity": "Critical|High|Medium|Low", "location": "File or module where this was found", "description": "Detailed description of the anti-pattern and its impact", "fix": "Specific recommended fix"}}
        ],
        "code_health_score": 0-100,
        "assessment": "Overall assessment of code smell prevalence"
    }},
    "configuration_environment": {{
        "env_handling": "How environment variables and configuration are managed",
        "config_files_identified": ["List of configuration files found"],
        "hardcoded_secrets_risk": "Critical|High|Medium|Low|None",
        "hardcoded_issues": ["Any hard-coded paths, URLs, or secrets identified"],
        "logging_setup": "Assessment of logging configuration and practices",
        "recommendations": ["Configuration improvement recommendation 1"]
    }},
    "modules_components": {{
        "total_modules": 0,
        "modules": [
            {{"name": "Module name", "purpose": "What this module does", "type": "internal|external_library", "key_files": ["Important files"], "dependencies": ["What it depends on"], "health": "Good|Fair|Poor"}}
        ],
        "external_libraries_count": 0,
        "internal_vs_external_ratio": "Assessment of reliance on external vs internal code",
        "assessment": "Overall assessment of modular organization"
    }},
    "dependency_analysis": {{
        "internal_dependencies": [
            {{"from_module": "Source module", "to_module": "Target module", "coupling_level": "Tight|Moderate|Loose", "description": "Nature of dependency"}}
        ],
        "external_libraries": [
            {{"name": "Library name", "purpose": "Why it's used", "risk_level": "High|Medium|Low", "notes": "Any concerns"}}
        ],
        "cyclic_dependencies": ["Description of any identified circular dependencies"],
        "version_concerns": ["Any version mismatch or outdated library concerns"],
        "recommendations": ["Dependency improvement recommendation 1"]
    }},
    "execution_flow": {{
        "primary_flows": [
            {{"name": "Flow name (e.g., User Login, API Request Processing)", "path": ["Step 1 -> file", "Step 2 -> file"], "description": "How this flow works end-to-end"}}
        ],
        "concurrency_model": "Description of threading, async, or concurrency approach",
        "error_handling_assessment": "How errors are handled across the codebase",
        "recommendations": ["Execution flow improvement recommendation 1"]
    }},
    "critical_findings": ["Most critical finding 1 with detailed explanation", "Most critical finding 2"],
    "recommendations_summary": [
        {{
            "priority": "High|Medium|Low",
            "recommendation": "Detailed actionable recommendation",
            "effort": "Low|Medium|High",
            "impact": "Expected improvement if implemented"
        }}
    ]
}}"""


def generate_generic_security_report(report: Dict[str, Any], file_structure: str, project_info: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate a Generic Security Analysis report using the LLM.
    Comprehensive security assessment covering common vulnerabilities and best practices.
    """
    try:
        llm_service = get_llm_service()
        measures = report.get("measures", [])
        issues = report.get("issues", {})
        quality_gate = report.get("quality_gate", {})
        top_issues = issues.get("items", [])[:20]

        metrics_summary = {m.get("metric", ""): m.get("value", "") for m in measures}

        prompt = f"""You are a Senior Principal Security Architect. Perform an exhaustive and deeply technical Generic Security Analysis for this project.
Your goal is to provide a high-value, professional assessment suitable for review by executive leadership and senior engineering teams.

**Project Info:**
- Name: {project_info.get('project_name', 'N/A')}
- Key: {project_info.get('project_key', 'N/A')}
- Source Path: {project_info.get('source_path', 'N/A')}

**Architecture Overview (File Structure):**
{file_structure[:4000]}

**Technical Context (SonarQube Data):**
- Quality Gate: {quality_gate.get('status', 'UNKNOWN')}
- Total Issues: {issues.get('total', 0)}
- Metrics: {json.dumps(metrics_summary, indent=2)}

**Critical Vulnerabilities Identified:**
{chr(10).join([f"- [{issue.get('severity', 'N/A')}] {issue.get('type', 'N/A')}: {issue.get('message', 'N/A')} (File: {issue.get('component', 'N/A')})" for issue in top_issues])}

**Instructions for Detailed Reporting:**
1. **Executive Summary**: Provide a **comprehensive 5-8 paragraph analysis**. Discuss the overall security posture, architectural strengths/weaknesses discovered from the file structure, and the strategic implications of the SonarQube findings.
2. **Technical Depth**: For every category and finding, explain the secondary and tertiary impacts. Don't just say what is wrong; explain *why* it matters in a modern production environment.
3. **Strategic Roadmap**: Provide actionable, prioritized remediation steps that consider both short-term "quick wins" and long-term architectural improvements.

Generate the report in this JSON format. **CRITICAL: Ensure the response is VALID JSON. All newlines within string values MUST be escaped as \\\\n. No literal newlines are allowed inside JSON strings.**
{{
    "report_title": "Comprehensive Generic Security Analysis & Risk Assessment",
    "executive_summary": "A comprehensive 5-8 paragraph overview of the security posture, architectural strengths/weaknesses, and strategic implications of findings.",
    "overall_risk_level": "Critical|High|Medium|Low",
    "security_score": 0-100,
    "vulnerability_categories": [
        {{
            "category": "Category name (e.g., Authentication, Input Validation, etc.)",
            "severity": "Critical|High|Medium|Low",
            "findings_count": 0,
            "description": "Exhaustive technical description of findings in this category, including root cause analysis and why it matters in a modern production environment.",
            "findings": ["Detailed finding 1 with its secondary and tertiary impacts", "Detailed finding 2 with its secondary and tertiary impacts"],
            "recommendations": ["Technical recommendation 1 with actionable steps", "Strategic recommendation 2 for long-term improvement"]
        }}
    ],
    "best_practices_assessment": [
        {{
            "practice": "Best practice name",
            "status": "Compliant|Partially Compliant|Non-Compliant",
            "details": "Detailed assessment of implementation versus industry standards, including observed gaps and their implications."
        }}
    ],
    "critical_findings": ["Most critical finding 1 with detailed impact analysis and why it needs immediate attention", "Most critical finding 2 with detailed impact analysis"],
    "recommendations_summary": [
        {{
            "priority": "High|Medium|Low",
            "recommendation": "Detailed actionable steps for remediation, considering short-term and long-term goals.",
            "effort": "Low|Medium|High",
            "impact": "Quantifiable impact analysis if addressed, including security posture improvement and risk reduction."
        }}
    ],
    "remediation_roadmap": [
        {{
            "phase": "Phase 1 - Immediate (0-30 days)",
            "actions": ["Action with clear outcome 1 and technical steps", "Action with clear outcome 2 and technical steps"]
        }}
    ]
}}"""

        response = llm_service.generate(
            prompt=prompt,
            system_prompt="You are a world-class security architect. Provide extremely detailed, professional, and technical analysis. Return ONLY valid JSON.",
            temperature=0.0,
            max_tokens=8000
        )
        return _parse_llm_json_response(response)
    except Exception as e:
        logger.error(f"Failed to generate generic security report: {e}", exc_info=True)
        return {"error": str(e), "report_type": "generic_security"}


def generate_owasp_report(report: Dict[str, Any], file_structure: str, project_info: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate an OWASP Top 10 Assessment report using the LLM.
    Evaluation against the OWASP Top 10 most critical security risks for web applications.
    """
    try:
        llm_service = get_llm_service()
        measures = report.get("measures", [])
        issues = report.get("issues", {})
        quality_gate = report.get("quality_gate", {})
        top_issues = issues.get("items", [])[:20]

        metrics_summary = {m.get("metric", ""): m.get("value", "") for m in measures}

        prompt = f"""You are a Lead OWASP Security Auditor. Perform an exhaustive and deeply technical OWASP Top 10 (2021) Assessment for this project.

**Project Domain:** {project_info.get('project_name', 'N/A')}
**Technical Context (File Structure):**
{file_structure[:4000]}

**SonarQube Data:**
- Quality Gate: {quality_gate.get('status', 'UNKNOWN')}
- Metrics: {json.dumps(metrics_summary, indent=2)}
- Key Issues: {chr(10).join([f"- [{iss.get('severity')}] {iss.get('message')}" for iss in top_issues])}

**Detailed Instructions:**
1. **Executive Summary**: Provide a **detailed 5-8 paragraph strategic overview**. Analyze the project's adherence to secure coding principles based on the architecture seen in the file structure and the issues reported. Discuss systemic risks and trends.
2. **Category Deep-Dive**: For EVERY one of the 10 OWASP categories, provide a detailed assessment. If a category is not vulnerable, explain the protective measures identified in the architecture that contribute to this security. If vulnerable, provide deep technical evidence, root cause analysis, and multi-layered remediation steps.
3. **Remediation Strategy**: Order remediation by risk impact and implementation complexity.

Return ONLY valid JSON. **CRITICAL: Ensure all newlines within string values are escaped as \\\\n.**
{{
    "report_title": "Advanced OWASP Top 10 Technical Assessment",
    "executive_summary": "A detailed 5-8 paragraph strategic overview of the project's adherence to secure coding principles, systemic risks, and trends.",
    "overall_compliance_level": "Critical Risk|High Risk|Medium Risk|Low Risk|Compliant",
    "owasp_score": 0-100,
    "owasp_categories": [
        {{
            "id": "A01:2021",
            "name": "Broken Access Control",
            "risk_level": "Critical|High|Medium|Low|Not Applicable",
            "status": "Vulnerable|Partially Vulnerable|Secure|Not Assessed",
            "findings": ["Detailed technical finding 1 with impact explanation and root cause analysis"],
            "evidence": "Deep-crawl evidence from project structure and SonarQube data, explaining how it supports the finding.",
            "recommendations": ["Multi-stage remediation recommendation 1 with technical steps", "Multi-stage remediation recommendation 2"]
        }},
        {{
            "id": "A02:2021",
            "name": "Cryptographic Failures",
            "risk_level": "Critical|High|Medium|Low|Not Applicable",
            "status": "Vulnerable|Partially Vulnerable|Secure|Not Assessed",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "id": "A03:2021",
            "name": "Injection",
            "risk_level": "...",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "id": "A04:2021",
            "name": "Insecure Design",
            "risk_level": "...",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "id": "A05:2021",
            "name": "Security Misconfiguration",
            "risk_level": "...",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "id": "A06:2021",
            "name": "Vulnerable and Outdated Components",
            "risk_level": "...",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "id": "A07:2021",
            "name": "Identification and Authentication Failures",
            "risk_level": "...",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "id": "A08:2021",
            "name": "Software and Data Integrity Failures",
            "risk_level": "...",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "id": "A09:2021",
            "name": "Security Logging and Monitoring Failures",
            "risk_level": "...",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "id": "A10:2021",
            "name": "Server-Side Request Forgery (SSRF)",
            "risk_level": "...",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }}
    ],
    "critical_vulnerabilities": ["Critical OWASP-related finding 1 with architectural impact analysis and detailed explanation"],
    "remediation_priority": [
        {{
            "owasp_category": "A01:2021 - Broken Access Control",
            "priority": "Immediate|Short-term|Long-term",
            "actions": ["Architectural fix with technical steps", "Code fix with specific examples", "Process improvement for prevention"]
        }}
    ]
}}"""

        response = llm_service.generate(
            prompt=prompt,
            system_prompt="You are an OWASP security expert. Provide exhaustive, technical, and professional analysis. Return ONLY valid JSON.",
            temperature=0.0,
            max_tokens=8000
        )
        return _parse_llm_json_response(response)
    except Exception as e:
        logger.error(f"Failed to generate OWASP report: {e}", exc_info=True)
        return {"error": str(e), "report_type": "owasp_top_10"}


def generate_pci_dss_report(report: Dict[str, Any], file_structure: str, project_info: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate a PCI DSS Compliance Assessment report using the LLM.
    Payment Card Industry Data Security Standard compliance assessment.
    """
    try:
        llm_service = get_llm_service()
        measures = report.get("measures", [])
        issues = report.get("issues", {})
        quality_gate = report.get("quality_gate", {})
        top_issues = issues.get("items", [])[:20]

        metrics_summary = {m.get("metric", ""): m.get("value", "") for m in measures}

        prompt = f"""You are a Lead Payment Security Auditor (QSA). Perform an exhaustive PCI DSS v4.0 Technical Assessment for this system.

**Environment Context:** {project_info.get('project_name', 'N/A')}
**Architectural Footprint:**
{file_structure[:4000]}

**Technical Audit Data (SonarQube):**
- Compliance Indicators: {json.dumps(metrics_summary, indent=2)}
- Observed Vulnerabilities: {chr(10).join([f"- [{iss.get('severity')}] {iss.get('message')}" for iss in top_issues])}

**Comprehensive Reporting Instructions:**
1. **Executive Summary**: Provide a **detailed 5-8 paragraph compliance analysis**. Evaluate the project's capability to protect Cardholder Data (CHD) based on the observed technical Stack and directory structure. Discuss systemic compliance gaps and risks to the CDE.
2. **Technical Controls**: For all 12 PCI requirements, provide deep analysis. Explain how specific code patterns or architectural decisions impact compliance. Provide actionable evidence-based findings.
3. **Strategic Remediation**: Outline a technical roadmap for achieving and maintaining formal PCI v4.0 compliance.

Return ONLY valid JSON. **CRITICAL: Ensure all newlines within string values are escaped as \\\\n.**
{{
    "report_title": "Exhaustive PCI DSS v4.0 Compliance Audit Report",
    "executive_summary": "A detailed 5-8 paragraph compliance analysis evaluating the project's capability to protect Cardholder Data (CHD), discussing systemic compliance gaps and risks to the CDE.",
    "overall_compliance_status": "Compliant|Partially Compliant|Non-Compliant",
    "compliance_score": 0-100,
    "requirements_assessment": [
        {{
            "requirement_id": "Req 1",
            "requirement_name": "Install and Maintain Network Security Controls",
            "status": "Compliant|Partially Compliant|Non-Compliant|Not Applicable",
            "findings": ["Detailed technical finding 1 with impact on PCI compliance and root cause"],
            "evidence": "Verification evidence from code artifacts and technical metrics, explaining how it relates to the requirement.",
            "recommendations": ["Specific technical control recommendation 1 with implementation steps"]
        }},
        {{
            "requirement_id": "Req 2",
            "requirement_name": "Apply Secure Configurations to All System Components",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 3",
            "requirement_name": "Protect Stored Account Data",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 4",
            "requirement_name": "Protect Cardholder Data with Strong Cryptography During Transmission",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 5",
            "requirement_name": "Protect All Systems and Networks from Malicious Software",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 6",
            "requirement_name": "Develop and Maintain Secure Systems and Software",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 7",
            "requirement_name": "Restrict Access to System Components and Cardholder Data",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 8",
            "requirement_name": "Identify Users and Authenticate Access",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 9",
            "requirement_name": "Restrict Physical Access to Cardholder Data",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 10",
            "requirement_name": "Log and Monitor All Access to System Components and Cardholder Data",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 11",
            "requirement_name": "Test Security of Systems and Networks Regularly",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }},
        {{
            "requirement_id": "Req 12",
            "requirement_name": "Support Information Security with Organizational Policies and Programs",
            "status": "...",
            "findings": [],
            "evidence": "",
            "recommendations": []
        }}
    ],
    "high_risk_areas": ["Compromise vector or significant compliance gap with detailed explanation of its impact on CHD security."],
    "remediation_plan": [
        {{
            "requirement": "Req X",
            "priority": "Critical|High|Medium|Low",
            "action": "Exhaustive technical remediation steps with specific configurations or code changes.",
            "timeline": "Immediate|30 days|90 days"
        }}
    ]
}}"""

        response = llm_service.generate(
            prompt=prompt,
            system_prompt="You are a PCI DSS v4.0 expert auditor. Provide exhaustive technical and compliance analysis. Return ONLY valid JSON.",
            temperature=0.0,
            max_tokens=8000
        )
        return _parse_llm_json_response(response)
    except Exception as e:
        logger.error(f"Failed to generate PCI DSS report: {e}", exc_info=True)
        return {"error": str(e), "report_type": "pci_dss"}


def generate_iso_27001_report(report: Dict[str, Any], file_structure: str, project_info: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate an ISO/IEC 27001 Audit report using the LLM.
    Information security management system audit based on ISO 27001 standards.
    """
    try:
        llm_service = get_llm_service()
        measures = report.get("measures", [])
        issues = report.get("issues", {})
        quality_gate = report.get("quality_gate", {})
        top_issues = issues.get("items", [])[:20]

        metrics_summary = {m.get("metric", ""): m.get("value", "") for m in measures}

        prompt = f"""You are a Senior ISO/IEC 27001 Lead Auditor. Perform a deep-dive ISMS Audit for this project.

**Project Context:** {project_info.get('project_name', 'N/A')}
**System Architecture:** {file_structure[:4000]}

**Audit Evidence (SonarQube):**
- Indicators: {json.dumps(metrics_summary, indent=2)}
- Non-conformity traces: {chr(10).join([f"- [{iss.get('severity')}] {iss.get('message')}" for iss in top_issues])}

**Exhaustive Audit Instructions:**
1. **Executive Summary**: Provide a **comprehensive 5-8 paragraph ISMS analysis**. Evaluate the maturity of the Information Security Management System based on the technical controls observed. Discuss the alignment of the technical Stack with ISO 27001:2022 principles of Confidentiality, Integrity, and Availability.
2. **Control Assessment**: For Annex A control domains, provide deep technical and organizational analysis. Explain how the code architecture supports or hinders control implementation.
3. **Continuous Improvement**: Provide a strategic roadmap for continual improvement of the project's security maturity.

Return ONLY valid JSON. **CRITICAL: Ensure all newlines within string values are escaped as \\\\n.**
{{
    "report_title": "Exhaustive ISO/IEC 27001 ISMS Technical Audit Report",
    "executive_summary": "A comprehensive 5-8 paragraph ISMS analysis evaluating the maturity of the Information Security Management System and its alignment with ISO 27001:2022 principles.",
    "overall_conformity_level": "Conforming|Partially Conforming|Non-Conforming",
    "maturity_score": 0-100,
    "annex_a_controls": [
        {{
            "control_domain": "A.5 - Organizational Controls",
            "conformity_status": "Conforming|Partially Conforming|Non-Conforming|Not Assessed",
            "findings": ["Detailed finding 1 with reference to ISO 27001 controls and its impact on ISMS."],
            "observations": "Deep technical audit observation explaining how the code architecture supports or hinders control implementation.",
            "recommendations": ["Comprehensive control improvement recommendation 1 with strategic and technical steps"]
        }},
        {{
            "control_domain": "A.6 - People Controls",
            "conformity_status": "...",
            "findings": [],
            "observations": "",
            "recommendations": []
        }},
        {{
            "control_domain": "A.7 - Physical Controls",
            "conformity_status": "...",
            "findings": [],
            "observations": "",
            "recommendations": []
        }},
        {{
            "control_domain": "A.8 - Technological Controls",
            "conformity_status": "...",
            "findings": [],
            "observations": "",
            "recommendations": []
        }}
    ],
    "risk_assessment": [
        {{
            "risk_area": "Risk area description",
            "likelihood": "High|Medium|Low",
            "impact": "High|Medium|Low",
            "risk_level": "Critical|High|Medium|Low",
            "mitigation": "Exhaustive mitigation strategy with technical and procedural controls."
        }}
    ],
    "non_conformities": [
        {{
            "id": "NC-001",
            "type": "Major|Minor|Observation",
            "control_reference": "A.X.X",
            "description": "Deep-dive description of non-conformity, including its root cause and implications for ISMS.",
            "corrective_action": "Technical and process corrective action with specific steps and expected outcomes."
        }}
    ],
    "continual_improvement_opportunities": ["Detailed opportunity for security maturity growth, including strategic and tactical recommendations."]
}}"""

        response = llm_service.generate(
            prompt=prompt,
            system_prompt="You are a Senior ISO 27001 Lead Auditor. Provide exhaustive, technical, and professional analysis. Return ONLY valid JSON.",
            temperature=0.0,
            max_tokens=8000
        )
        return _parse_llm_json_response(response)
    except Exception as e:
        logger.error(f"Failed to generate ISO 27001 report: {e}", exc_info=True)
        return {"error": str(e), "report_type": "iso_27001"}


_FILE_MARKER_RE = __import__("re").compile(r"^=== FILE: (.+?) ===$", __import__("re").MULTILINE)


def _extract_file_paths_from_chunk(chunk_text: str) -> list:
    """Return every `=== FILE: path ===` marker found in the chunk. Deterministic,
    free, and 100% accurate — don't ask the LLM to list files it saw when we can
    parse it ourselves."""
    return _FILE_MARKER_RE.findall(chunk_text or "")


def _split_source_into_chunks(source_code: str, chunk_size: int) -> list:
    """
    Split the source text (formatted as `=== FILE: path ===\\ncontent\\n=== FILE: ... ===`)
    into chunks of roughly chunk_size bytes, without breaking file boundaries when possible.
    A file larger than chunk_size becomes its own chunk (may exceed the cap).
    Returns a list of strings.
    """
    if not source_code:
        return []
    parts = source_code.split("=== FILE: ")
    # parts[0] is whatever preceded the first marker; skip if empty
    file_blocks = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        file_blocks.append("=== FILE: " + p)

    if not file_blocks:
        # Fallback: no markers found — emit raw slices of chunk_size
        return [source_code[i:i + chunk_size] for i in range(0, len(source_code), chunk_size)]

    chunks = []
    current = []
    current_size = 0
    for block in file_blocks:
        # Giant single file: emit anything buffered, then put this file as its own chunk.
        if len(block) >= chunk_size:
            if current:
                chunks.append("\n".join(current))
                current, current_size = [], 0
            chunks.append(block)
            continue
        if current_size + len(block) > chunk_size and current:
            chunks.append("\n".join(current))
            current, current_size = [], 0
        current.append(block)
        current_size += len(block) + 1
    if current:
        chunks.append("\n".join(current))
    return chunks


_CHUNK_EXTRACT_PROMPT = """You are analyzing ONE slice of a larger codebase. Extract concrete, specific findings from this slice only. Return ONLY valid JSON.

**Project:** {project_name}
**Slice {chunk_index} of {chunk_total}**

**Files in this slice (you MUST examine EVERY one of these):**
{file_list}

**Source code slice:**
{chunk_text}

**CRITICAL INSTRUCTIONS:**
1. The "files_seen" array below will be auto-populated by the system — you do NOT need to list them.
2. For EVERY file in the list above, you MUST include at least one observation about it in
   the appropriate category (entry_points, anti_patterns, notable_functions, internal_dependencies,
   or key_issues). A file's absence from the findings means "I missed it", not "nothing to say".
3. Never invent files, functions, or patterns not present in the source.
4. If a file is a simple config/data file, mention it in config_files_seen with a one-line purpose.

Return this JSON exactly:
{{
  "entry_points": [{{"file": "path", "type": "API|Script|Main|CLI|ScheduledJob", "description": "brief"}}],
  "apis_exposed": [{{"endpoint": "pattern or route", "file": "path", "description": "brief"}}],
  "apis_consumed": [{{"service": "name or URL", "file": "path", "description": "brief"}}],
  "design_patterns": [{{"pattern": "name", "file": "path", "evidence": "what you saw"}}],
  "anti_patterns": [{{"type": "God Class|Tight Coupling|Dead Code|Duplicate Logic|Hard-coded Config|Missing Abstraction|Circular Dependency|SQL Injection|XSS|Insecure Auth", "severity": "Critical|High|Medium|Low", "file": "path", "description": "what you saw", "fix": "concrete fix"}}],
  "hardcoded_secrets": [{{"file": "path", "what": "database credential|api key|token|url", "snippet": "short snippet"}}],
  "config_files_seen": [{{"file": "path", "purpose": "brief"}}],
  "internal_dependencies": [{{"from_file": "path", "to_file_or_module": "path/name", "how": "include|require|import|use"}}],
  "external_libraries_seen": ["library name or package"],
  "notable_functions": [{{"file": "path", "function": "name", "purpose": "brief"}}],
  "key_issues": [{{"file": "path", "issue": "short description of anything significant not captured above"}}]
}}"""


_SYNTHESIS_PROMPT_TEMPLATE = """You are a Principal Software Architect writing a final Codebase Analysis report. You have been given structured findings already extracted from EVERY slice of the codebase by a prior pass. Do NOT ask for more source — use ONLY the findings and the file tree below.

**Project:** {project_name} (key: {project_key}) at {source_path}

**Complete File/Directory Structure:**
{file_tree}

**SonarQube metrics:** {metrics}
**SonarQube total issues:** {total_issues}
**Top SonarQube issues:**
{top_issues}

**AGGREGATED FINDINGS FROM ALL SLICES (JSON):**
{aggregated_findings}

**Instructions:** Produce a comprehensive report. Populate every array with as many specific entries as the findings support — list every distinct file, anti-pattern, and dependency that appears in the findings. The report must reflect the ENTIRE codebase, not just part of it.

Return ONLY this JSON (no markdown, no prose outside the JSON). Use \\\\n for any newlines inside string values.
{{
    "report_title": "Comprehensive Project Analysis",
    "executive_summary": "5-8 paragraph overview of architecture, code organization, strengths, weaknesses, technical debt, and overall code health.",
    "analysis_score": 0-100,
    "overall_health": "Excellent|Good|Fair|Poor",
    "directory_structure": {{
        "organization_style": "string",
        "top_level_layout": "string",
        "modules_identified": [{{"name": "string", "purpose": "string", "files_estimate": 0, "health": "Good|Fair|Poor"}}],
        "naming_conventions": "string",
        "separation_of_concerns": "string",
        "assessment": "string",
        "recommendations": ["string"]
    }},
    "entry_points": {{
        "main_entry": "string",
        "identified_entries": [{{"type": "API|Script|Main|ScheduledJob|CLI", "file": "string", "description": "string"}}],
        "assessment": "string"
    }},
    "external_interfaces": {{
        "apis_exposed": [{{"endpoint_pattern": "string", "description": "string"}}],
        "apis_consumed": [{{"service": "string", "description": "string"}}],
        "webhooks": ["string"],
        "message_queues": ["string"],
        "protocols": ["string"],
        "assessment": "string"
    }},
    "architectural_style": {{
        "primary_style": "string",
        "description": "string",
        "secondary_patterns": ["string"],
        "layer_analysis": [{{"layer": "string", "purpose": "string", "key_files": ["string"]}}],
        "strengths": ["string"],
        "weaknesses": ["string"]
    }},
    "design_patterns": {{
        "patterns_detected": [{{"pattern": "string", "evidence": "string", "files": ["string"], "assessment": "string"}}],
        "custom_patterns": ["string"],
        "assessment": "string"
    }},
    "anti_patterns": {{
        "issues_found": [{{"type": "string", "severity": "Critical|High|Medium|Low", "location": "string", "description": "string", "fix": "string"}}],
        "code_health_score": 0-100,
        "assessment": "string"
    }},
    "configuration_environment": {{
        "env_handling": "string",
        "config_files_identified": ["string"],
        "hardcoded_secrets_risk": "Critical|High|Medium|Low|None",
        "hardcoded_issues": ["string"],
        "logging_setup": "string",
        "recommendations": ["string"]
    }},
    "modules_components": {{
        "total_modules": 0,
        "modules": [{{"name": "string", "purpose": "string", "type": "internal|external_library", "key_files": ["string"], "dependencies": ["string"], "health": "Good|Fair|Poor"}}],
        "external_libraries_count": 0,
        "internal_vs_external_ratio": "string",
        "assessment": "string"
    }},
    "dependency_analysis": {{
        "internal_dependencies": [{{"from_module": "string", "to_module": "string", "coupling_level": "Tight|Moderate|Loose", "description": "string"}}],
        "external_libraries": [{{"name": "string", "purpose": "string", "risk_level": "High|Medium|Low", "notes": "string"}}],
        "cyclic_dependencies": ["string"],
        "version_concerns": ["string"],
        "recommendations": ["string"]
    }},
    "execution_flow": {{
        "primary_flows": [{{"name": "string", "path": ["string"], "description": "string"}}],
        "concurrency_model": "string",
        "error_handling_assessment": "string",
        "recommendations": ["string"]
    }},
    "critical_findings": ["string"],
    "recommendations_summary": [{{"priority": "High|Medium|Low", "recommendation": "string", "effort": "Low|Medium|High", "impact": "string"}}]
}}"""


_VALID_SEVERITIES = {"Critical", "High", "Medium", "Low"}


def _normalize_severity(raw: Any) -> str:
    """Coerce LLM-returned severity values to one of Critical|High|Medium|Low.
    '?' / missing / unknown values default to 'Low' so the UI never renders a
    question-mark severity chip."""
    if not isinstance(raw, str):
        return "Low"
    s = raw.strip().title()
    if s in _VALID_SEVERITIES:
        return s
    # Common aliases
    alias = {
        "Crit": "Critical", "Fatal": "Critical", "Blocker": "Critical",
        "Major": "High", "Sev1": "Critical", "Sev2": "High",
        "Warning": "Medium", "Minor": "Medium", "Info": "Low", "Trivial": "Low",
        "": "Low", "?": "Low", "N/A": "Low", "Unknown": "Low",
    }
    return alias.get(s, "Low")


def _normalize_anti_pattern(ap: Dict[str, Any]) -> Dict[str, Any]:
    """Fill blank 'fix' and 'severity' fields with sensible defaults so the UI
    doesn't render empty cells or question marks."""
    if not isinstance(ap, dict):
        return {}
    out = dict(ap)
    out["severity"] = _normalize_severity(out.get("severity"))
    if not (out.get("fix") or "").strip():
        # Generate a minimal suggestion from the anti-pattern type so the UI column isn't empty
        ap_type = (out.get("type") or "").lower()
        fix_defaults = {
            "sql injection": "Replace string interpolation with prepared statements (PDO/MySQLi)",
            "xss": "Escape all user-controlled output with htmlspecialchars() or equivalent",
            "hard-coded config": "Move the value to environment variables or a secure config store",
            "hardcoded": "Move the value to environment variables or a secure config store",
            "tight coupling": "Extract the dependency behind an interface and inject it",
            "dead code": "Remove the unused code or document why it's kept",
            "duplicate logic": "Extract the shared logic into a helper/utility function",
            "missing abstraction": "Introduce an interface or base class to unify the callers",
            "circular dependency": "Break the cycle by inverting or extracting the shared part",
            "insecure auth": "Use password_hash()/password_verify() (bcrypt or Argon2)",
            "insecure password storage": "Use password_hash()/password_verify() (bcrypt or Argon2)",
            "insecure direct object reference": "Validate access rights + whitelist allowed identifiers",
        }
        for key, suggestion in fix_defaults.items():
            if key in ap_type:
                out["fix"] = suggestion
                break
        else:
            out["fix"] = "Review and refactor as appropriate for your framework"
    # File/location fallback
    if not (out.get("file") or out.get("location") or "").strip():
        out["file"] = "unknown"
    return out


def _merge_chunk_findings(chunk_results: list) -> Dict[str, Any]:
    """Merge per-chunk JSON findings into a single aggregated dict, de-duplicating
    files/libraries and concatenating issue lists. Severity/fix fields are
    normalized so the UI never shows '?' values.

    Note: `files_seen` is deterministic (injected by the map worker from chunk
    markers, not supplied by the LLM). Other fields may be missing or in
    slightly different shapes depending on which prompt version produced them.
    """
    merged: Dict[str, Any] = {
        "files_seen": set(),
        "entry_points": [],
        "apis_exposed": [],
        "apis_consumed": [],
        "design_patterns": [],
        "anti_patterns": [],
        "hardcoded_secrets": [],
        "config_files_seen": [],
        "internal_dependencies": [],
        "external_libraries_seen": set(),
        "notable_functions": [],
        "key_issues": [],
    }

    seen_config_files: set = set()

    for cr in chunk_results:
        if not isinstance(cr, dict):
            continue

        # files_seen + external_libraries_seen: simple string sets
        for v in cr.get("files_seen", []) or []:
            if isinstance(v, str) and v.strip():
                merged["files_seen"].add(v.strip())
        for v in cr.get("external_libraries_seen", []) or []:
            if isinstance(v, str) and v.strip():
                merged["external_libraries_seen"].add(v.strip())

        # config_files_seen: accept both legacy list-of-str and new list-of-dict
        for v in cr.get("config_files_seen", []) or []:
            if isinstance(v, str) and v.strip():
                if v.strip() not in seen_config_files:
                    seen_config_files.add(v.strip())
                    merged["config_files_seen"].append({"file": v.strip(), "purpose": ""})
            elif isinstance(v, dict):
                f = (v.get("file") or "").strip()
                if f and f not in seen_config_files:
                    seen_config_files.add(f)
                    merged["config_files_seen"].append({"file": f, "purpose": v.get("purpose", "")})

        # Anti-patterns get per-item normalization
        for ap in cr.get("anti_patterns", []) or []:
            norm = _normalize_anti_pattern(ap)
            if norm:
                merged["anti_patterns"].append(norm)

        # key_issues: accept list-of-str (legacy) or list-of-dict (new)
        for k in cr.get("key_issues", []) or []:
            if isinstance(k, str):
                merged["key_issues"].append({"file": "", "issue": k})
            elif isinstance(k, dict):
                merged["key_issues"].append({
                    "file": k.get("file", ""),
                    "issue": k.get("issue") or k.get("description") or "",
                })

        # Other list-of-dict fields pass through
        for k in ("entry_points", "apis_exposed", "apis_consumed", "design_patterns",
                 "hardcoded_secrets", "internal_dependencies", "notable_functions"):
            items = cr.get(k, []) or []
            if isinstance(items, list):
                merged[k].extend(items)

    merged["files_seen"] = sorted(merged["files_seen"])
    merged["external_libraries_seen"] = sorted(merged["external_libraries_seen"])

    _sev_rank = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    merged["anti_patterns"].sort(
        key=lambda ap: (_sev_rank.get(ap.get("severity", "Low"), 3), ap.get("file", ""))
    )
    return merged


def generate_project_analysis_report(report: Dict[str, Any], file_structure: str, project_info: Dict[str, Any], source_code: str = "") -> Dict[str, Any]:
    """
    Map-reduce project analysis:
      1) Split source into chunks that each fit in the LLM context.
      2) Map: run a findings-extraction prompt on each chunk.
      3) Reduce: run a synthesis prompt over the aggregated findings + file tree
         to produce the final structured report.
    Falls back to single-shot analysis if the source is small enough.
    """
    try:
        llm_service = get_llm_service()
        measures = report.get("measures", [])
        issues = report.get("issues", {})
        top_issues = issues.get("items", [])[:20]
        metrics_summary = {m.get("metric", ""): m.get("value", "") for m in measures}

        # Tuned against Qwen3-32B on Groq: 131K input+output window, 40K max output.
        # 400 KB chunk ≈ 100K input tokens, leaves ~16K output + ~15K safety margin.
        chunk_size = int(os.environ.get("MIRA_ANALYZE_CHUNK_CHARS", 400_000))
        tree_cap = int(os.environ.get("MIRA_ANALYZE_LLM_TREE_CHARS", 20_000))
        map_max_tokens = int(os.environ.get("MIRA_ANALYZE_MAP_MAX_TOKENS", 6_000))
        reduce_max_tokens = int(os.environ.get("MIRA_ANALYZE_LLM_MAX_TOKENS", 20_000))
        # At 400 KB/chunk, 200 chunks = 80 MB of code. Real projects after skip-filtering
        # rarely exceed this; hard cap exists only to bound cost on pathological inputs.
        max_chunks = int(os.environ.get("MIRA_ANALYZE_MAX_CHUNKS", 200))

        top_issues_text = chr(10).join([
            f"- [{i.get('severity', 'N/A')}] {i.get('type', 'N/A')}: {i.get('message', 'N/A')} (File: {i.get('component', 'N/A')})"
            for i in top_issues
        ]) or "(none)"

        # ---- MAP PHASE (parallel) ----
        chunks = _split_source_into_chunks(source_code, chunk_size)
        if len(chunks) > max_chunks:
            logger.warning(f"Project has {len(chunks)} chunks; capping to {max_chunks} to bound cost")
            chunks = chunks[:max_chunks]

        map_concurrency = max(1, int(os.environ.get("MIRA_ANALYZE_MAP_CONCURRENCY", 8)))
        logger.info(
            f"Map-reduce analysis: {len(chunks)} chunk(s) @ ~{chunk_size} chars each, "
            f"total_src={len(source_code)} chars, concurrency={map_concurrency}"
        )

        # Parse a Groq 429 message and pull the "try again in Xs" hint if present
        import re as _re
        _retry_after_re = _re.compile(r"try again in\s+([\d.]+)s", _re.IGNORECASE)

        def _run_one_chunk(idx_chunk_pair):
            idx, chunk_text = idx_chunk_pair
            # Deterministic: extract every file path the chunk contains from its
            # `=== FILE: path ===` markers. We pass the list into the prompt so the
            # LLM knows exactly which files it must address, and we use this list
            # (not the LLM's output) as the ground truth for files_seen.
            chunk_file_paths = _extract_file_paths_from_chunk(chunk_text)
            file_list_for_prompt = "\n".join(f"  - {p}" for p in chunk_file_paths) or "  (none)"
            extract_prompt = _CHUNK_EXTRACT_PROMPT.format(
                project_name=project_info.get('project_name', 'N/A'),
                chunk_index=idx,
                chunk_total=len(chunks),
                file_list=file_list_for_prompt,
                chunk_text=chunk_text,
            )
            max_attempts = int(os.environ.get("MIRA_ANALYZE_MAP_MAX_ATTEMPTS", 5))
            base_backoff = float(os.environ.get("MIRA_ANALYZE_MAP_BASE_BACKOFF", 2.0))
            t0 = time.time()
            last_err: Optional[Exception] = None
            for attempt in range(1, max_attempts + 1):
                try:
                    resp = llm_service.generate(
                        prompt=extract_prompt,
                        system_prompt=(
                            "You are a precise static-analysis assistant. Return ONLY valid JSON with "
                            "concrete findings grounded in the slice. Never invent files or functions."
                        ),
                        temperature=0.0,
                        max_tokens=map_max_tokens,
                    )
                    parsed = _parse_llm_json_response(resp)
                    dt = time.time() - t0
                    # Inject the deterministic file list — this is ground truth,
                    # not whatever the LLM chose to acknowledge.
                    if isinstance(parsed, dict):
                        parsed["files_seen"] = chunk_file_paths
                    logger.info(
                        f"  map {idx}/{len(chunks)} ok ({len(chunk_text)} chars, "
                        f"{len(chunk_file_paths)} files, {dt:.1f}s, attempt {attempt})"
                    )
                    return idx, parsed if isinstance(parsed, dict) else None, None
                except Exception as chunk_err:
                    last_err = chunk_err
                    msg = str(chunk_err)
                    # Only retry on rate-limit / transient errors; give up immediately on other errors
                    transient = (
                        "429" in msg
                        or "rate_limit" in msg.lower()
                        or "rate limit" in msg.lower()
                        or "tokens per minute" in msg.lower()
                        or "service_unavailable" in msg.lower()
                        or "timeout" in msg.lower()
                    )
                    if not transient or attempt >= max_attempts:
                        dt = time.time() - t0
                        logger.warning(
                            f"  map {idx}/{len(chunks)} failed after {dt:.1f}s (attempt {attempt}/{max_attempts}): {chunk_err}"
                        )
                        return idx, None, chunk_err
                    # Honor the Retry-After hint if Groq gave one; else exponential backoff
                    retry_hint_match = _retry_after_re.search(msg)
                    if retry_hint_match:
                        wait_s = float(retry_hint_match.group(1)) + 1.0  # add 1s buffer
                    else:
                        wait_s = base_backoff * (2 ** (attempt - 1))
                    # Cap wait at 90s so a truly stuck chunk doesn't hold the pool forever
                    wait_s = min(wait_s, 90.0)
                    logger.info(
                        f"  map {idx}/{len(chunks)} hit rate limit on attempt {attempt}/{max_attempts}; "
                        f"sleeping {wait_s:.1f}s then retrying"
                    )
                    time.sleep(wait_s)
            # Shouldn't reach here, but guard anyway
            return idx, None, last_err

        chunk_findings: list = []
        map_failures = 0
        t_map_start = time.time()
        with ThreadPoolExecutor(max_workers=map_concurrency, thread_name_prefix="mira-map") as pool:
            futures = [pool.submit(_run_one_chunk, (i + 1, c)) for i, c in enumerate(chunks)]
            for fut in as_completed(futures):
                idx, result, err = fut.result()
                if result is not None:
                    chunk_findings.append(result)
                else:
                    map_failures += 1

        map_elapsed = time.time() - t_map_start
        logger.info(
            f"Map phase finished: {len(chunk_findings)} ok / {map_failures} failed in {map_elapsed:.1f}s"
        )

        if not chunk_findings:
            logger.error("All map chunks failed; cannot synthesize")
            return {
                "report_title": "Comprehensive Project Analysis",
                "error": "All per-chunk analyses failed",
                "executive_summary": "Analysis could not be completed — every source chunk failed during extraction.",
                "report_type": "project_analysis",
            }

        aggregated = _merge_chunk_findings(chunk_findings)
        logger.info(
            f"Map phase complete: files_seen={len(aggregated['files_seen'])}, "
            f"anti_patterns={len(aggregated['anti_patterns'])}, "
            f"internal_deps={len(aggregated['internal_dependencies'])}, "
            f"external_libs={len(aggregated['external_libraries_seen'])}"
        )

        # ---- REDUCE PHASE ----
        aggregated_json = json.dumps(aggregated, indent=2)
        # Keep aggregated findings under a sensible cap so reduce prompt fits
        # Aggregated findings cap for reduce phase. Leaves ~30K tokens for response at 400 KB.
        max_agg = int(os.environ.get("MIRA_ANALYZE_AGG_CHARS", 300_000))
        if len(aggregated_json) > max_agg:
            logger.warning(f"Aggregated findings {len(aggregated_json)} > {max_agg}; truncating")
            aggregated_json = aggregated_json[:max_agg] + "\n... [truncated]"

        synthesis_prompt = _SYNTHESIS_PROMPT_TEMPLATE.format(
            project_name=project_info.get('project_name', 'N/A'),
            project_key=project_info.get('project_key', 'N/A'),
            source_path=project_info.get('source_path', 'N/A'),
            file_tree=file_structure[:tree_cap],
            metrics=json.dumps(metrics_summary, indent=2),
            total_issues=issues.get('total', 0),
            top_issues=top_issues_text,
            aggregated_findings=aggregated_json,
        )
        logger.info(
            f"Reduce phase: synthesis_prompt_chars={len(synthesis_prompt)}, "
            f"max_response_tokens={reduce_max_tokens}"
        )
        response = llm_service.generate(
            prompt=synthesis_prompt,
            system_prompt=(
                "You are a world-class software architect synthesizing findings from every slice "
                "of a codebase into one comprehensive structured report. Use ONLY the provided "
                "findings — do not invent evidence. List every distinct file and issue that the "
                "findings mention. Return ONLY valid JSON."
            ),
            temperature=0.0,
            max_tokens=reduce_max_tokens,
        )
        result = _parse_llm_json_response(response)

        # Attach run metadata + raw aggregated findings so the frontend can render a
        # full per-file breakdown (coverage badges + detailed findings panel).
        if isinstance(result, dict):
            result["_analysis_metadata"] = {
                "chunks_analyzed": len(chunk_findings),
                "chunks_total": len(chunks),
                "chunks_failed": len(chunks) - len(chunk_findings),
                "source_bytes": len(source_code),
                "files_seen_in_findings": len(aggregated["files_seen"]),
                "anti_patterns_found": len(aggregated["anti_patterns"]),
                "internal_deps_found": len(aggregated["internal_dependencies"]),
                "external_libs_found": len(aggregated["external_libraries_seen"]),
                "config_files_found": len(aggregated["config_files_seen"]),
                "entry_points_found": len(aggregated.get("entry_points", [])),
            }
            # Raw aggregated findings for the UI — separate from the synthesized report
            # so the frontend can show "all 149 files the LLM actually looked at"
            # regardless of whether the LLM named them in the executive summary.
            result["_aggregated_findings"] = {
                "files_seen": aggregated["files_seen"],
                "config_files_seen": aggregated["config_files_seen"],
                "external_libraries_seen": aggregated["external_libraries_seen"],
                "entry_points": aggregated.get("entry_points", []),
                "apis_exposed": aggregated.get("apis_exposed", []),
                "apis_consumed": aggregated.get("apis_consumed", []),
                "design_patterns": aggregated.get("design_patterns", []),
                "anti_patterns": aggregated.get("anti_patterns", []),
                "hardcoded_secrets": aggregated.get("hardcoded_secrets", []),
                "internal_dependencies": aggregated.get("internal_dependencies", []),
                "notable_functions": aggregated.get("notable_functions", []),
                "key_issues": aggregated.get("key_issues", []),
            }
        return result

    except Exception as e:
        logger.error(f"Failed to generate project analysis report: {e}", exc_info=True)
        return {"error": str(e), "report_type": "project_analysis"}


# Maps report type string to its generator function
REPORT_GENERATORS = {
    "project_analysis": generate_project_analysis_report,
    "generic_security": generate_generic_security_report,
    "owasp_top_10": generate_owasp_report,
    "pci_dss": generate_pci_dss_report,
    "iso_27001": generate_iso_27001_report,
}

REPORT_TYPE_LABELS = {
    "project_analysis": "Comprehensive Project Analysis",
    "generic_security": "Generic Security Analysis",
    "owasp_top_10": "OWASP Top 10 Assessment",
    "pci_dss": "PCI DSS Compliance",
    "iso_27001": "ISO/IEC 27001 Audit",
    "sonarqube_original": "SonarQube Original Report",
}

REPORT_CATEGORIES = {
    "analyse_project": ["project_analysis"],
    "compliance_reports": ["generic_security", "owasp_top_10", "pci_dss", "iso_27001"]
}


_OWASP_2021_CATEGORIES = [
    ("A01:2021", "Broken Access Control"),
    ("A02:2021", "Cryptographic Failures"),
    ("A03:2021", "Injection"),
    ("A04:2021", "Insecure Design"),
    ("A05:2021", "Security Misconfiguration"),
    ("A06:2021", "Vulnerable and Outdated Components"),
    ("A07:2021", "Identification and Authentication Failures"),
    ("A08:2021", "Software and Data Integrity Failures"),
    ("A09:2021", "Security Logging and Monitoring Failures"),
    ("A10:2021", "Server-Side Request Forgery"),
]

_PCI_DSS_REQUIREMENTS = [
    ("1", "Install and maintain network security controls"),
    ("2", "Apply secure configurations to all system components"),
    ("3", "Protect stored account data"),
    ("4", "Protect cardholder data with strong cryptography during transmission"),
    ("5", "Protect all systems and networks from malicious software"),
    ("6", "Develop and maintain secure systems and software"),
    ("7", "Restrict access to system components and cardholder data"),
    ("8", "Identify users and authenticate access to system components"),
    ("9", "Restrict physical access to cardholder data"),
    ("10", "Log and monitor all access to system components and cardholder data"),
    ("11", "Test security of systems and networks regularly"),
    ("12", "Support information security with organizational policies and programs"),
]

_ISO_27001_DOMAINS = [
    "A.5 Information security policies",
    "A.6 Organization of information security",
    "A.7 Human resource security",
    "A.8 Asset management",
    "A.9 Access control",
    "A.10 Cryptography",
    "A.12 Operations security",
    "A.13 Communications security",
    "A.14 System acquisition, development and maintenance",
    "A.16 Information security incident management",
]


def _classify_owasp_for_issue(iss: Dict[str, Any]) -> str:
    """Heuristic mapping of a SonarQube issue to an OWASP 2021 category id."""
    text = " ".join(str(iss.get(k, "")) for k in ("message", "rule", "type", "tags")).lower()
    tags = iss.get("tags", []) or []
    tags_text = " ".join(str(t).lower() for t in tags) if isinstance(tags, list) else str(tags).lower()
    blob = f"{text} {tags_text}"
    if any(k in blob for k in ("sql injection", "xss", "command-injection", "ldap-injection", "sqli", "injection")):
        return "A03:2021"
    if any(k in blob for k in ("access control", "authorization", "idor", "privilege")):
        return "A01:2021"
    if any(k in blob for k in ("crypto", "cipher", "md5", "sha1", "tls", "ssl", "hash")):
        return "A02:2021"
    if any(k in blob for k in ("auth", "password", "session", "jwt", "token")):
        return "A07:2021"
    if any(k in blob for k in ("deserialization", "integrity", "unsigned")):
        return "A08:2021"
    if any(k in blob for k in ("log", "monitor")):
        return "A09:2021"
    if any(k in blob for k in ("ssrf", "url", "redirect")):
        return "A10:2021"
    if any(k in blob for k in ("dependency", "outdated", "cve")):
        return "A06:2021"
    if iss.get("type") == "VULNERABILITY":
        return "A04:2021"
    return "A05:2021"


def build_report_from_sonarqube_only(
    report: Dict[str, Any],
    project_info: Dict[str, Any],
    report_type: str = "sonarqube_original",
) -> Dict[str, Any]:
    """
    Build report content from raw SonarQube data only (no LLM enhancement).
    Frames the same SonarQube data against the requested compliance framework
    (generic_security, owasp_top_10, pci_dss, iso_27001) so that selecting
    multiple report types produces distinct, usable reports without an LLM.
    Returns a dict compatible with HTML/PDF/DOCX generators.
    """
    measures = report.get("measures", [])
    issues = report.get("issues", {})
    quality_gate = report.get("quality_gate", {})
    issue_items = issues.get("items", []) or []
    total = issues.get("total", 0)
    qg_status = quality_gate.get("status", "UNKNOWN")

    metrics_dict = {m.get("metric", ""): m.get("value", "") for m in measures}
    bugs = int(metrics_dict.get("bugs", 0) or 0)
    vulns = int(metrics_dict.get("vulnerabilities", 0) or 0)
    code_smells = int(metrics_dict.get("code_smells", 0) or 0)
    coverage = metrics_dict.get("coverage", "N/A")
    duplications = metrics_dict.get("duplicated_lines_density", "N/A")

    risk_level = "Low" if qg_status == "OK" else "High" if qg_status == "ERROR" else "Medium"
    security_score = 100 if qg_status == "OK" else 50 if qg_status == "WARN" else 0

    by_severity: Dict[str, list] = {}
    for iss in issue_items:
        sev = iss.get("severity", "UNKNOWN")
        by_severity.setdefault(sev, []).append(iss)

    vuln_categories = []
    for sev in ["BLOCKER", "CRITICAL", "MAJOR", "MINOR", "INFO"]:
        items = by_severity.get(sev) or []
        if not items:
            continue
        findings = [
            f"{i.get('message', '')} (File: {i.get('component', '').split(':')[-1]}, Line: {i.get('line', 'N/A')})"
            for i in items[:10]
        ]
        vuln_categories.append({
            "category": f"{sev} Issues",
            "severity": sev,
            "findings_count": len(items),
            "description": f"SonarQube identified {len(items)} {sev}-level issue(s).",
            "findings": findings,
            "recommendations": [f"Address the {sev} findings reported by SonarQube."],
        })

    critical_findings = [
        f"[{iss.get('severity')}] {iss.get('message', '')} - {iss.get('component', '').split(':')[-1]}:{iss.get('line', 'N/A')}"
        for iss in issue_items[:50]
        if iss.get("severity") in ("BLOCKER", "CRITICAL")
    ]

    remediation = []
    if critical_findings:
        remediation.append({"phase": "Immediate (0-30 days)", "priority": "Critical", "actions": ["Address all BLOCKER and CRITICAL issues"]})
    if total > 0:
        remediation.append({"phase": "Short-term (30-90 days)", "priority": "High", "actions": [f"Review and fix remaining {total} issues"]})

    base_summary = (
        f"This report contains the raw SonarQube analysis for project {project_info.get('project_name', 'N/A')}.\n\n"
        f"Quality Gate status: {qg_status}. Total issues: {total} "
        f"(Bugs: {bugs}, Vulnerabilities: {vulns}, Code Smells: {code_smells}). "
        f"Coverage: {coverage}, Duplicated lines: {duplications}.\n\n"
        "This report is generated directly from SonarQube telemetry without LLM enhancement. "
        "Enable the AI-Enhanced option for strategic recommendations and deeper contextual analysis."
    )

    content: Dict[str, Any] = {
        "executive_summary": base_summary,
        "overall_risk_level": risk_level,
        "security_score": security_score,
        "vulnerability_categories": vuln_categories,
        "critical_findings": critical_findings,
        "remediation_roadmap": remediation,
    }

    if report_type == "owasp_top_10":
        owasp_groups: Dict[str, list] = {cid: [] for cid, _ in _OWASP_2021_CATEGORIES}
        for iss in issue_items:
            cid = _classify_owasp_for_issue(iss)
            owasp_groups.setdefault(cid, []).append(iss)
        owasp_categories = []
        for cid, cname in _OWASP_2021_CATEGORIES:
            matched = owasp_groups.get(cid, [])
            if matched:
                sev_rank = {"BLOCKER": 4, "CRITICAL": 4, "MAJOR": 3, "MINOR": 2, "INFO": 1}
                top_sev = max((sev_rank.get(i.get("severity", ""), 1) for i in matched), default=1)
                risk = "Critical" if top_sev == 4 else "Medium" if top_sev == 3 else "Low"
                status = "Vulnerable" if top_sev >= 3 else "Partially Vulnerable"
                findings = [
                    f"{i.get('message', '')} ({i.get('component', '').split(':')[-1]}:{i.get('line', 'N/A')})"
                    for i in matched[:5]
                ]
            else:
                risk = "Low"
                status = "Not Assessed"
                findings = []
            owasp_categories.append({
                "id": cid,
                "name": cname,
                "risk_level": risk,
                "status": status,
                "findings": findings,
                "evidence": f"Derived from {len(matched)} matching SonarQube finding(s).",
                "recommendations": [f"Review {cname} controls and remediate the listed findings."] if matched else [],
            })
        content["report_title"] = "OWASP Top 10 Assessment (SonarQube Only)"
        content["owasp_score"] = security_score
        content["overall_compliance_level"] = (
            "Compliant" if qg_status == "OK" else "High Risk" if qg_status == "ERROR" else "Medium Risk"
        )
        content["owasp_categories"] = owasp_categories
        return content

    if report_type == "pci_dss":
        requirements = []
        for rid, rname in _PCI_DSS_REQUIREMENTS:
            status = "Compliant" if qg_status == "OK" else "Non-Compliant" if qg_status == "ERROR" else "Partially Compliant"
            requirements.append({
                "requirement_id": rid,
                "requirement_name": rname,
                "status": status,
                "findings": [f"SonarQube Quality Gate: {qg_status}. Issues: {total}."] if total else [],
            })
        content["report_title"] = "PCI DSS Compliance Assessment (SonarQube Only)"
        content["compliance_score"] = security_score
        content["overall_compliance_status"] = (
            "Compliant" if qg_status == "OK" else "Non-Compliant" if qg_status == "ERROR" else "Partial"
        )
        content["requirements_assessment"] = requirements
        return content

    if report_type == "iso_27001":
        controls = []
        for domain in _ISO_27001_DOMAINS:
            status = "Conforming" if qg_status == "OK" else "Non-Conforming" if qg_status == "ERROR" else "Partially Conforming"
            controls.append({
                "control_domain": domain,
                "conformity_status": status,
                "observations": f"SonarQube Quality Gate: {qg_status}. {total} issue(s) identified.",
            })
        content["report_title"] = "ISO/IEC 27001 Audit (SonarQube Only)"
        content["maturity_score"] = security_score
        content["overall_conformity_level"] = (
            "Conforming" if qg_status == "OK" else "Non-Conforming" if qg_status == "ERROR" else "Partial"
        )
        content["annex_a_controls"] = controls
        return content

    # generic_security / sonarqube_original / project_analysis fallback
    content["report_title"] = (
        "Generic Security Analysis (SonarQube Only)" if report_type == "generic_security"
        else "SonarQube Original Report (No LLM Enhancement)"
    )
    return content


def enhance_report_with_llm(report: Dict[str, Any]) -> Dict[str, Any]:
    """
    Enhance SonarQube report with LLM analysis
    
    Args:
        report: SonarQube report dictionary
        
    Returns:
        Enhanced report with LLM analysis
    """
    try:
        llm_service = get_llm_service()
        
        # Extract key metrics
        measures = report.get("measures", [])
        issues = report.get("issues", {})
        quality_gate = report.get("quality_gate", {})
        
        # Build summary for LLM
        metrics_summary = {}
        for measure in measures:
            metric = measure.get("metric", "")
            value = measure.get("value", "")
            metrics_summary[metric] = value
        
        issues_summary = {
            "total": issues.get("total", 0),
            "items_count": len(issues.get("items", []))
        }
        
        # Get top issues
        top_issues = issues.get("items", [])[:10]  # Top 10 issues
        
        # Build prompt for LLM
        prompt = f"""Exhaustively analyze this SonarQube technical report and provide a deep technical analysis suitable for senior architects and CISOs.

**Data for Analysis:**
- Project Identity: {report.get('project_key', 'N/A')}
- Current Quality Status: {quality_gate.get('status', 'UNKNOWN')}
- Quantitative Metrics: {metrics_summary}
- Critical Technical Findings:
{chr(10).join([f"- {iss.get('type')}: {iss.get('message')} (Severity: {iss.get('severity')})" for iss in top_issues])}

**In-Depth Reporting Requirements:**
1. **Executive Summary**: Provide a **comprehensive 5-8 paragraph strategic analysis**. Do not just summarize the numbers; explain the technical risk profile of the project, the maturity of the engineering practices suggested by the metrics, and the potential business impact of the identified technical debt.
2. **Technical Deep-Dive**: For key findings and quality assessments, provide exhaustive reasoning. Connect different metrics to explain systemic issues (e.g., how low coverage and high complexity are causing a specific bug trend).
3. **Actionable Roadmap**: Provide strategic, high-impact recommendations that address the root causes of the identified issues.

Generate a comprehensive professional analysis in JSON format. **CRITICAL: All newlines within string values MUST be escaped as \\\\n. Return ONLY valid JSON.**:
{{
    "executive_summary": "A comprehensive 5-8 paragraph strategic analysis explaining the technical risk profile, engineering practice maturity, and potential business impact of technical debt.",
    "key_findings": ["Top finding with detailed risk and impact analysis, explaining its root cause and implications.", "Second finding with detailed analysis, connecting it to systemic issues."],
    "quality_assessment": {{
        "rating": "Excellent|Good|Fair|Poor",
        "reasoning": "Technical deep-dive justifying the rating based on all metrics, explaining interdependencies and systemic issues."
    }},
    "security_concerns": ["Security vulnerability with detailed exploitability and impact analysis, including potential attack vectors and business consequences."],
    "recommendations": ["Strategic architectural or process recommendation with detailed implementation steps and expected outcomes.", "Tactical code-level recommendation with specific examples and best practices."],
    "priority_actions": [
        {{"action": "Exhaustive technical fix steps with clear objectives and methods", "priority": "High|Medium|Low", "impact": "Quantifiable analysis of improvement if addressed, including risk reduction and efficiency gains."}},
        ...
    ]
}}"""

        # Generate LLM response
        response = llm_service.generate(
            prompt=prompt,
            system_prompt="You are an elite code quality architect and security analyst. Provide deeply technical and exhaustive insights.",
            temperature=0.3,
            max_tokens=4000
        )
        
        # Parse LLM response (handle JSON in markdown code blocks)
        llm_content = response.content.strip()
        if llm_content.startswith("```"):
            lines = llm_content.split('\n')
            lines = lines[1:-1] if lines[-1].strip() == "```" else lines[1:]
            llm_content = '\n'.join(lines)
        
        # Try to parse as JSON, if fails return as text
        try:
            llm_analysis = json.loads(llm_content)
        except:
            llm_analysis = {
                "raw_analysis": llm_content,
                "format": "text"
            }
        
        return {
            "llm_enhanced": True,
            "llm_analysis": llm_analysis,
            "llm_model": response.model,
            "llm_usage": response.usage
        }
        
    except Exception as e:
        logger.error(f"Failed to enhance report with LLM: {e}", exc_info=True)
        return {
            "llm_enhanced": False,
            "llm_error": str(e)
        }
