"""Base agent class for MIRA-AI using Groq with Qwen model"""
import re
import time
from typing import Dict, Any, List, Optional
from abc import ABC, abstractmethod
from datetime import datetime
from groq import Groq
from app.core.logging import get_logger
from app.core.config import settings

logger = get_logger(__name__)


class AgentState:
    """State object for agent workflows"""
    
    def __init__(self, **kwargs):
        self.context: Dict[str, Any] = kwargs.get('context', {})
        self.results: Dict[str, Any] = kwargs.get('results', {})
        self.errors: List[str] = kwargs.get('errors', [])
        self.project_id: Optional[str] = kwargs.get('project_id')
        self.user_id: Optional[str] = kwargs.get('user_id')
        self.phase: Optional[str] = kwargs.get('phase')
        self.timestamp: str = datetime.now().isoformat()
        
        # MIRA-AI specific fields
        self.project_path: Optional[str] = kwargs.get('project_path')
        self.project_name: Optional[str] = kwargs.get('project_name')
        self.analysis_type: Optional[str] = kwargs.get('analysis_type')
        self.output_dir: Optional[str] = kwargs.get('output_dir')
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert state to dictionary"""
        return {
            'context': self.context,
            'results': self.results,
            'errors': self.errors,
            'project_id': self.project_id,
            'user_id': self.user_id,
            'phase': self.phase,
            'timestamp': self.timestamp,
            'project_path': self.project_path,
            'project_name': self.project_name,
            'analysis_type': self.analysis_type,
            'output_dir': self.output_dir
        }
    
    def add_error(self, error: str):
        """Add an error to the state"""
        self.errors.append(f"[{datetime.now().isoformat()}] {error}")
        logger.error(f"Agent Error: {error}")
    
    def add_result(self, key: str, value: Any):
        """Add a result to the state"""
        self.results[key] = value
        logger.info(f"Agent Result: {key} = {type(value).__name__}")


class GroqClient:
    """LLM client for MIRA-AI agents (Groq API with Qwen model)."""
    
    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        """
        Initialize Groq client for agents.

        Args:
            api_key: Groq API key (uses settings.GROQ_API_KEY if not provided)
            model: Model name (uses settings.LLM_MODEL or default Qwen model if not provided)
        """
        self.api_key = api_key or settings.GROQ_API_KEY
        if not self.api_key:
            raise ValueError("Groq API key not provided. Set GROQ_API_KEY in settings or pass api_key parameter.")
        self.model = model or getattr(settings, "LLM_MODEL", None) or "qwen/qwen3-32b"
        self.client = Groq(api_key=self.api_key)
        self.max_tokens = 16384
        self.temperature = 0.7
        self.retry_attempts = 3
        self.retry_delay = 2
        self.min_request_interval = float(
            getattr(settings, "GROQ_MIN_REQUEST_INTERVAL_SECONDS", 0.55) or 0.0
        )
        self.api_max_retries = int(getattr(settings, "GROQ_API_MAX_RETRIES", 10) or 10)
        self.api_base_retry_delay = float(
            getattr(settings, "GROQ_API_BASE_RETRY_DELAY_SECONDS", 2.0) or 2.0
        )
        self._last_llm_request_monotonic: float = 0.0
        # Cumulative token usage across this client's lifetime. Updated on every
        # successful LLM response. Each pipeline can snapshot + diff this to
        # attribute token spend to a specific job.
        import threading as _threading
        self._token_lock = _threading.Lock()
        self.token_usage: Dict[str, int] = {"prompt": 0, "completion": 0, "total": 0}
        logger.info("Agent LLM client (Groq) initialized with model %s", self.model)

    def snapshot_token_usage(self) -> Dict[str, int]:
        """Return a copy of cumulative token usage — safe for concurrent readers."""
        with self._token_lock:
            return dict(self.token_usage)

    def _record_token_usage(self, response: Any) -> None:
        """Extract token counts from a Groq response.usage and accumulate."""
        try:
            usage = getattr(response, "usage", None)
            if usage is None:
                return
            p = int(getattr(usage, "prompt_tokens", 0) or 0)
            c = int(getattr(usage, "completion_tokens", 0) or 0)
            t = int(getattr(usage, "total_tokens", p + c) or 0)
            with self._token_lock:
                self.token_usage["prompt"] += p
                self.token_usage["completion"] += c
                self.token_usage["total"] += t
            # Also emit to Prometheus so /metrics reflects live spend.
            try:
                from app.core.metrics import mira_llm_tokens_total
                mira_llm_tokens_total.labels(kind="prompt").inc(p)
                mira_llm_tokens_total.labels(kind="completion").inc(c)
                mira_llm_tokens_total.labels(kind="total").inc(t)
            except Exception:
                pass
        except Exception:
            # Never let accounting errors break an LLM call
            pass

    def generate(
        self,
        system_prompt: str,
        user_content: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        """
        Generate response using Groq (Qwen model).

        Args:
            system_prompt: System prompt
            user_content: User content/query
            temperature: Optional temperature override
            max_tokens: Optional completion token budget (defaults to ``self.max_tokens``)

        Returns:
            Generated text response
        """
        temp = temperature if temperature is not None else self.temperature
        mt = max_tokens if max_tokens is not None else self.max_tokens
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
        self._throttle_before_groq_request()
        _t_llm_start = time.monotonic()
        try:
            response = self._retry_request(
                self.client.chat.completions.create,
                model=self.model,
                messages=messages,
                max_tokens=mt,
                temperature=temp,
            )
            self._record_token_usage(response)
            text = self._extract_response_text(response)
            return self._strip_think_blocks(text)
        finally:
            self._last_llm_request_monotonic = time.monotonic()
            try:
                from app.core.metrics import mira_llm_call_seconds
                mira_llm_call_seconds.observe(time.monotonic() - _t_llm_start)
            except Exception:
                pass

    def _throttle_before_groq_request(self) -> None:
        """Space out requests to stay under Groq rate limits (complements SDK retries on 429)."""
        if self.min_request_interval <= 0:
            return
        now = time.monotonic()
        wait = self.min_request_interval - (now - self._last_llm_request_monotonic)
        if wait > 0:
            time.sleep(wait)

    @staticmethod
    def _is_groq_rate_limit_error(exc: BaseException) -> bool:
        if getattr(exc, "status_code", None) == 429:
            return True
        msg = str(exc).lower()
        return "429" in msg or "too many requests" in msg

    @staticmethod
    def _retry_after_seconds(exc: BaseException) -> Optional[float]:
        resp = getattr(exc, "response", None)
        if resp is None:
            return None
        headers = getattr(resp, "headers", None)
        if not headers:
            return None
        ra = headers.get("retry-after") or headers.get("Retry-After")
        if ra is None:
            return None
        try:
            return float(ra)
        except (TypeError, ValueError):
            return None

    def _retry_request(self, func, *args, **kwargs):
        """Retry with short backoff for generic errors; longer exponential backoff for HTTP 429."""
        last_exception: Optional[BaseException] = None
        max_rounds = max(self.api_max_retries, self.retry_attempts)
        for attempt in range(max_rounds):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                rate_limited = self._is_groq_rate_limit_error(e)
                if rate_limited:
                    if attempt >= self.api_max_retries - 1:
                        raise last_exception
                    delay = self._retry_after_seconds(e)
                    if delay is None:
                        delay = self.api_base_retry_delay * (2 ** min(attempt, 6))
                    delay = float(min(max(delay, 2.0), 120.0))
                    logger.warning(
                        "Groq rate limit (429): sleeping %.1fs then retry %s/%s — %s",
                        delay,
                        attempt + 1,
                        self.api_max_retries,
                        e,
                    )
                else:
                    if attempt >= self.retry_attempts - 1:
                        raise last_exception
                    delay = self.retry_delay * (attempt + 1)
                    logger.warning(
                        "LLM request failed (attempt %s/%s): %s",
                        attempt + 1,
                        self.retry_attempts,
                        e,
                    )
                time.sleep(delay)
        if last_exception:
            raise last_exception
        raise RuntimeError("Groq retry loop exited unexpectedly")
    
    @staticmethod
    def _extract_response_text(response: Any) -> str:
        """Extract text from Groq chat completion response"""
        try:
            return (response.choices[0].message.content or "").strip()
        except (IndexError, AttributeError):
            return ""

    @staticmethod
    def _strip_think_blocks(text: str) -> str:
        """Remove think/reasoning blocks from model output so all agents get clean responses."""
        if not text or "<think>" not in text:
            return text
        return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE).strip()


class BaseAgent(ABC):
    """Base class for all MIRA-AI agents (LLM via Groq Qwen)."""
    
    def __init__(self, name: str, description: str, groq_client: Optional[GroqClient] = None):
        """
        Initialize base agent

        Args:
            name: Agent name
            description: Agent description
            groq_client: Optional Groq LLM client instance
        """
        self.name = name
        self.description = description
        self.groq_client = groq_client or GroqClient()
        self.stats = {
            'executions': 0,
            'successes': 0,
            'failures': 0,
            'total_runtime': 0
        }
        
        logger.info(f"Initialized agent: {self.name}")
    
    @abstractmethod
    def execute(self, state: AgentState) -> AgentState:
        """Execute the agent's main logic"""
        pass
    
    def run(self, **kwargs) -> Dict[str, Any]:
        """
        Run the agent with provided parameters
        
        Args:
            **kwargs: Parameters for the agent
            
        Returns:
            Dictionary with execution results
        """
        start_time = time.time()
        self.stats['executions'] += 1
        
        try:
            # Create initial state
            state = AgentState(**kwargs)
            state.phase = f"{self.name}_started"
            
            logger.info(f"Starting agent: {self.name}")
            
            # Execute agent logic
            result_state = self.execute(state)
            result_state.phase = f"{self.name}_completed"
            
            # Update stats
            execution_time = time.time() - start_time
            self.stats['successes'] += 1
            self.stats['total_runtime'] += execution_time
            
            logger.info(f"Agent {self.name} completed successfully in {execution_time:.2f}s")
            
            return {
                "success": True,
                "agent": self.name,
                "execution_time": execution_time,
                "results": result_state.results,
                "context": result_state.context,
                "phase": result_state.phase,
                "errors": result_state.errors
            }
            
        except Exception as e:
            execution_time = time.time() - start_time
            self.stats['failures'] += 1
            self.stats['total_runtime'] += execution_time
            
            error_msg = f"Agent {self.name} failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            
            return {
                "success": False,
                "agent": self.name,
                "execution_time": execution_time,
                "error": error_msg,
                "results": {},
                "context": {},
                "errors": [error_msg]
            }
    
    async def arun(self, **kwargs) -> Dict[str, Any]:
        """Async version of run method"""
        # For now, just call the sync version
        # Can be overridden by subclasses for true async support
        return self.run(**kwargs)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get agent execution statistics"""
        avg_runtime = (self.stats['total_runtime'] / self.stats['executions'] 
                      if self.stats['executions'] > 0 else 0)
        
        return {
            **self.stats,
            'average_runtime': avg_runtime,
            'success_rate': (self.stats['successes'] / self.stats['executions'] 
                           if self.stats['executions'] > 0 else 0)
        }

