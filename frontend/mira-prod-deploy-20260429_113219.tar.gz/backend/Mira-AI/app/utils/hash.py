"""Hashing utilities"""
import hashlib
from pathlib import Path
from typing import Union
from app.core.logging import get_logger

logger = get_logger(__name__)


def hash_string(data: str, algorithm: str = "sha256") -> str:
    """
    Hash a string using specified algorithm
    
    Args:
        data: String to hash
        algorithm: Hash algorithm (md5, sha1, sha256, sha512)
        
    Returns:
        Hex digest of hash
    """
    hash_obj = hashlib.new(algorithm)
    hash_obj.update(data.encode('utf-8'))
    return hash_obj.hexdigest()


def hash_file(file_path: Path, algorithm: str = "sha256", chunk_size: int = 8192) -> str:
    """
    Hash a file using specified algorithm
    
    Args:
        file_path: Path to file
        algorithm: Hash algorithm (md5, sha1, sha256, sha512)
        chunk_size: Size of chunks to read (default 8KB)
        
    Returns:
        Hex digest of hash
    """
    try:
        hash_obj = hashlib.new(algorithm)
        
        with open(file_path, 'rb') as f:
            while chunk := f.read(chunk_size):
                hash_obj.update(chunk)
        
        return hash_obj.hexdigest()
    except Exception as e:
        logger.error(f"Failed to hash file {file_path}: {str(e)}")
        raise


def verify_file_hash(file_path: Path, expected_hash: str, algorithm: str = "sha256") -> bool:
    """
    Verify file hash matches expected hash
    
    Args:
        file_path: Path to file
        expected_hash: Expected hash value
        algorithm: Hash algorithm
        
    Returns:
        True if hash matches, False otherwise
    """
    try:
        actual_hash = hash_file(file_path, algorithm)
        return actual_hash == expected_hash
    except Exception as e:
        logger.error(f"Failed to verify hash for {file_path}: {str(e)}")
        return False


def generate_file_signature(file_path: Path) -> str:
    """
    Generate a unique signature for a file (SHA256 hash)
    
    Args:
        file_path: Path to file
        
    Returns:
        File signature (SHA256 hex digest)
    """
    return hash_file(file_path, algorithm="sha256")
