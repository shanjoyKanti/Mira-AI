"""
RAG Adapter for Mira AI.

Bridges the Mira agent system (planning_agent, new_version_upgradation_agent)
with the UniversalMigrationTool RAG system located in rag/.

Responsibilities:
  - Translate per-version PHP/Laravel migration requests into RAG calls
  - Handle Qdrant cache hits and misses transparently
  - Enforce scrape → embed → store on cache miss before returning content
  - Map RAG results back into the MigrationStage.combined_documentation format
  - Use the version ladder to resolve which Laravel guide corresponds to each
    PHP migration step

All LLM calls use Groq exclusively (configured via GROQ_API_KEY env var).
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import List, NamedTuple, Optional, Tuple

from app.core.logging import get_logger
from app.services.rag.version_ladder import (
    PHP_VERSION_LADDER,
    VersionLadderError,
    get_version_steps,
)

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class RagFetchError(Exception):
    """Raised when RAG cannot supply content after exhausting scrape retries."""


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


class RagStageDoc(NamedTuple):
    """Migration documentation for one version step, returned by the adapter."""
    from_version: str
    to_version: str
    content: str        # Full migration text — maps to MigrationStage.combined_documentation
    source_url: str     # URL that was scraped or the Qdrant retrieval key
    source: str         # "qdrant" | "fetched"


# ---------------------------------------------------------------------------
# Path resolution helpers
# ---------------------------------------------------------------------------

def _rag_root() -> Path:
    """Absolute path to the rag/ directory adjacent to the Mira app root."""
    # app/services/rag/rag_adapter.py → parents[3] = Mira-AI root
    return Path(__file__).resolve().parents[3] / "rag"


def _ensure_rag_in_sys_path() -> None:
    """Add rag/ and rag/Search_tool/ to sys.path so RAG imports work."""
    rag_dir = str(_rag_root())
    search_tool_dir = str(_rag_root() / "Search_tool")
    for p in (rag_dir, search_tool_dir):
        if p not in sys.path:
            sys.path.insert(0, p)


# ---------------------------------------------------------------------------
# Laravel PHP → Laravel version mapping (mirrors planning_agent logic)
# ---------------------------------------------------------------------------

# Highest Laravel major whose minimum PHP floor is <= target_php.
# Duplicated here to avoid circular import with planning_agent.
_LARAVEL_LINE_MIN_PHP = {
    "4.2": "5.4",
    "5.0": "5.5",  "5.1": "5.5",  "5.2": "5.5",
    "5.3": "5.6",  "5.4": "5.6",
    "5.5": "7.0",  "5.6": "7.1",  "5.7": "7.1",  "5.8": "7.1",
    "6": "7.2",    "7": "7.2",
    "8": "7.3",    "9": "8.0",
    "10": "8.1",   "11": "8.2",   "12": "8.3",
}

_LARAVEL_DESCENDING = [12, 11, 10, 9, 8, 7, 6]


def _laravel_version_for_php_target(target_php: str) -> Optional[str]:
    """
    Return the highest Laravel major (as string) whose minimum PHP requirement
    is satisfied by target_php. E.g. target_php="8.0" → "9" (Laravel 9 requires PHP 8.0+).
    Returns None if no match.
    """
    def _php_tuple(v: str):
        parts = v.strip().replace(".x", "").split(".")
        major = int(parts[0]) if parts and parts[0].isdigit() else 0
        minor = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
        return (major, minor)

    t = _php_tuple(target_php)
    for maj in _LARAVEL_DESCENDING:
        min_php = _LARAVEL_LINE_MIN_PHP.get(str(maj))
        if min_php and _php_tuple(min_php) <= t:
            return str(maj)
    return None


# ---------------------------------------------------------------------------
# RagAdapter
# ---------------------------------------------------------------------------


class RagAdapter:
    """
    Adapter that wraps UniversalMigrationTool for use by Mira agents.

    Usage:
        adapter = RagAdapter()
        docs = adapter.fetch_php_migration_docs("7.4", "8.2")
        # → [RagStageDoc("7.4","8.0",...), RagStageDoc("8.0","8.1",...),
        #    RagStageDoc("8.1","8.2",...)]

        laravel_guide = adapter.fetch_laravel_docs("8.0")
        # → "Laravel 9 upgrade guide text..."
    """

    _SCRAPE_RETRY_DELAY_SEC = 5
    _SCRAPE_MAX_RETRIES = 2

    def __init__(self) -> None:
        _ensure_rag_in_sys_path()
        self._tool = self._init_tool()

    def _init_tool(self):
        """Lazily import and initialise UniversalMigrationTool."""
        try:
            from php_migrator.core.migration_tool import UniversalMigrationTool  # type: ignore
            tool = UniversalMigrationTool()
            logger.info("RagAdapter: UniversalMigrationTool initialised")
            return tool
        except Exception as e:
            logger.error("RagAdapter: failed to initialise UniversalMigrationTool: %s", e)
            raise RuntimeError(
                f"RagAdapter could not initialise UniversalMigrationTool: {e}. "
                "Ensure rag/ dependencies are installed (pip install -r rag/requirements.txt)."
            ) from e

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _fetch_with_retry(
        self,
        language: str,
        version: str,
        framework: Optional[str] = None,
        force_refresh: bool = False,
    ) -> dict:
        """
        Call UniversalMigrationTool.fetch_migration() with retry on empty content.
        Returns the result dict. Raises RagFetchError if content is still empty
        after all retries.
        """
        label = f"{language}/{framework} {version}" if framework else f"{language} {version}"

        for attempt in range(self._SCRAPE_MAX_RETRIES):
            try:
                result = self._tool.fetch_migration(
                    language=language,
                    version=version,
                    framework=framework,
                    force_refresh=force_refresh,
                )
            except Exception as e:
                logger.error("RagAdapter: fetch_migration raised exception for %s: %s", label, e)
                if attempt < self._SCRAPE_MAX_RETRIES - 1:
                    logger.info("RagAdapter: retrying %s in %ss (attempt %d)", label, self._SCRAPE_RETRY_DELAY_SEC, attempt + 2)
                    time.sleep(self._SCRAPE_RETRY_DELAY_SEC)
                    continue
                raise RagFetchError(
                    f"RAG fetch raised exception for {label} after {self._SCRAPE_MAX_RETRIES} attempt(s): {e}"
                ) from e

            if result and result.get("success") and result.get("content", "").strip():
                logger.info(
                    "RagAdapter: fetched %s (source=%s, %d chars)",
                    label, result.get("source", "?"), len(result["content"]),
                )
                return result

            # Content empty — log and maybe retry
            error_msg = result.get("error") if result else "no result returned"
            logger.warning(
                "RagAdapter: empty content for %s (attempt %d/%d) — %s",
                label, attempt + 1, self._SCRAPE_MAX_RETRIES, error_msg,
            )
            if attempt < self._SCRAPE_MAX_RETRIES - 1:
                logger.info("RagAdapter: retrying %s in %ss", label, self._SCRAPE_RETRY_DELAY_SEC)
                time.sleep(self._SCRAPE_RETRY_DELAY_SEC)

        raise RagFetchError(
            f"RAG returned empty content for {label} after {self._SCRAPE_MAX_RETRIES} attempt(s). "
            f"Check network connectivity and official docs URL."
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fetch_php_migration_docs(
        self,
        from_version: str,
        to_version: str,
    ) -> List[RagStageDoc]:
        """
        Return ordered RAG docs for each PHP migration step from
        *from_version* to *to_version*.

        Each returned RagStageDoc corresponds to one step in the PHP version
        ladder and its .content maps directly to MigrationStage.combined_documentation.

        Raises:
            VersionLadderError: if versions are invalid or out of order.
            RagFetchError: if content cannot be retrieved for any step.
        """
        steps = get_version_steps("php", None, from_version, to_version)
        if not steps:
            logger.info("RagAdapter.fetch_php_migration_docs: no steps (%s == %s)", from_version, to_version)
            return []

        docs: List[RagStageDoc] = []
        prev = from_version
        for step_to in steps:
            result = self._fetch_with_retry("php", step_to)
            docs.append(RagStageDoc(
                from_version=prev,
                to_version=step_to,
                content=result["content"],
                source_url=result.get("url", ""),
                source=result.get("source", "fetched"),
            ))
            prev = step_to

        logger.info(
            "RagAdapter.fetch_php_migration_docs: PHP %s → %s — %d stage doc(s) ready",
            from_version, to_version, len(docs),
        )
        return docs

    def fetch_laravel_docs(
        self,
        target_php_version: str,
        from_laravel: Optional[str] = None,
    ) -> str:
        """
        Return the Laravel upgrade guide text relevant to a PHP migration stage
        whose target PHP version is *target_php_version*.

        The highest Laravel major whose PHP floor is <= target_php_version is
        selected (same logic as the former planning_agent file-based approach).

        Args:
            target_php_version: The PHP version being migrated TO in this stage
                                 (e.g. "8.0" for the 7.4→8.0 step).
            from_laravel: Current Laravel version string from language analysis
                          (used only for logging/context).

        Returns:
            Full Laravel upgrade guide text, or "" if no matching guide exists.

        Raises:
            RagFetchError: if guide content cannot be fetched after retries.
        """
        laravel_version = _laravel_version_for_php_target(target_php_version)
        if not laravel_version:
            logger.info(
                "RagAdapter.fetch_laravel_docs: no Laravel version maps to PHP %s — returning empty",
                target_php_version,
            )
            return ""

        logger.info(
            "RagAdapter.fetch_laravel_docs: PHP target=%s → Laravel guide version=%s (app from_laravel=%r)",
            target_php_version, laravel_version, from_laravel,
        )

        try:
            result = self._fetch_with_retry("php", laravel_version, framework="laravel")
        except RagFetchError as e:
            logger.warning("RagAdapter.fetch_laravel_docs: could not fetch Laravel %s guide: %s", laravel_version, e)
            return ""

        content = result.get("content", "")
        if content:
            return f"--- Laravel {laravel_version} Upgrade Guide ---\n{content}"
        return ""

    def fetch_migration_docs(
        self,
        language: str,
        framework: Optional[str],
        from_version: str,
        to_version: str,
    ) -> List[RagStageDoc]:
        """
        Generic multi-step migration doc fetcher for any supported language/framework.
        Returns one RagStageDoc per version step. Enforces the version ladder.

        Applies per-chunk dedup BETWEEN consecutive step docs (window = 1):
        if step N+1 repeats a paragraph from step N, the duplicate is dropped.
        We deliberately do NOT dedup across all earlier steps — a paragraph
        re-stated 3 versions later is usually re-stated for a reason (e.g. a
        feature deprecated in 7.3 was finally REMOVED in 8.0). The narrow window
        cuts the most wasteful repetition without losing version-relevant context.

        Raises:
            VersionLadderError: for invalid versions or downgrade attempts.
            RagFetchError: if content cannot be retrieved for any step.
        """
        steps = get_version_steps(language, framework, from_version, to_version)
        if not steps:
            logger.info(
                "RagAdapter.fetch_migration_docs: no steps for %s%s %s → %s",
                language, f"/{framework}" if framework else "", from_version, to_version,
            )
            return []

        docs: List[RagStageDoc] = []
        prev = from_version
        prev_chunks: set = set()      # hashes from the IMMEDIATELY PRIOR step only
        total_raw = 0
        total_deduped = 0
        for step_to in steps:
            result = self._fetch_with_retry(language, step_to, framework=framework)
            raw_content = result["content"]
            # Window of 1: dedup only against the previous step's paragraphs.
            current_chunks: set = set()
            deduped_content, kept, dropped = self._dedup_content(
                raw_content, prev_chunks, emit_hashes=current_chunks,
            )
            total_raw += kept + dropped
            total_deduped += dropped
            docs.append(RagStageDoc(
                from_version=prev,
                to_version=step_to,
                content=deduped_content,
                source_url=result.get("url", ""),
                source=result.get("source", "fetched"),
            ))
            prev = step_to
            prev_chunks = current_chunks  # slide the window forward by one step

        logger.info(
            "RagAdapter.fetch_migration_docs: %s%s %s → %s — %d doc(s) ready (deduped %d/%d chunks)",
            language, f"/{framework}" if framework else "",
            from_version, to_version, len(docs), total_deduped, total_raw,
        )
        return docs

    @staticmethod
    def _dedup_content(
        content: str,
        seen: set,
        *,
        emit_hashes: Optional[set] = None,
    ) -> Tuple[str, int, int]:
        """
        Split ``content`` into paragraphs and drop those whose normalized hash
        is already in ``seen``. Returns (deduped_content, kept_chunks, dropped_chunks).

        Args:
            content: Raw doc text to dedup.
            seen: Hashes from previous step(s); paragraphs with hashes in this set are dropped.
                Read-only — not mutated. (Kept for backward compatibility, callers may still pass
                a set they want to grow themselves.)
            emit_hashes: If provided, every kept paragraph's hash is added to this set.
                Use this with a per-step set to support a sliding window.

        Paragraphs are split on blank lines. Very short paragraphs (<40 chars)
        are always kept — they're usually headers, and hashing them would make
        consecutive section boundaries collapse.
        """
        import hashlib
        if not content or not content.strip():
            return content, 0, 0
        paragraphs = [p for p in content.split("\n\n") if p.strip()]
        kept_paragraphs: List[str] = []
        kept = 0
        dropped = 0
        for p in paragraphs:
            stripped = p.strip()
            if len(stripped) < 40:
                kept_paragraphs.append(p)
                kept += 1
                continue
            normalized = " ".join(stripped.split()).lower()
            h = hashlib.md5(normalized.encode("utf-8", errors="replace")).hexdigest()
            if h in seen:
                dropped += 1
                continue
            # Track for the sliding-window callers (and legacy single-set callers).
            if emit_hashes is not None:
                emit_hashes.add(h)
            else:
                seen.add(h)
            kept_paragraphs.append(p)
            kept += 1
        return "\n\n".join(kept_paragraphs), kept, dropped
