"""Logging configuration"""
import logging
import logging.handlers
import os
import sys
from pathlib import Path
from app.core.config import settings


def setup_logging():
    """Configure application logging"""
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(logging.Formatter(log_format))

    handlers = [console_handler]

    # File handler (if configured) — uses RotatingFileHandler so the log file
    # cannot grow unbounded on a long-running deployment. On high volume
    # (100K-file migrations) a plain FileHandler can fill disk in days.
    if settings.LOG_FILE:
        log_path = Path(settings.LOG_FILE)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        max_bytes = int(os.environ.get("MIRA_LOG_MAX_BYTES", str(100 * 1024 * 1024)))  # 100 MB
        backup_count = int(os.environ.get("MIRA_LOG_BACKUP_COUNT", "5"))
        file_handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
        file_handler.setFormatter(logging.Formatter(log_format))
        handlers.append(file_handler)
    
    # Configure root logger
    logging.basicConfig(
        level=getattr(logging, settings.LOG_LEVEL),
        format=log_format,
        handlers=handlers
    )
    
    # Suppress noisy loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance"""
    return logging.getLogger(name)
