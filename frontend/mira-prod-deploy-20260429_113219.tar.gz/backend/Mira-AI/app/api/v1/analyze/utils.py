"""Shared utility functions for report generation and text processing."""
import os
import re
import json
from typing import Optional, Dict, Any, List

from app.core.logging import get_logger

logger = get_logger(__name__)


REPORTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', '..', 'reports')
os.makedirs(REPORTS_DIR, exist_ok=True)


def gather_file_structure(ssh_conn, source_path: str) -> str:
    """
    Gather file/directory structure from the remote server via SSH.
    Returns a string representation of the tree structure.
    """
    try:
        # Build the find excludes from the shared SKIP_DIRS set so we stay consistent.
        skip_args = " ".join(f"-not -path '*/{d}/*'" for d in sorted(SKIP_DIRS))
        result = ssh_conn.execute_command(
            f"find {source_path} -maxdepth 10 -type f -not -path '*/\\.*' {skip_args} 2>/dev/null | head -50000"
        )
        if result.get("success") and result.get("stdout", "").strip():
            return result["stdout"].strip()
        
        # Fallback to ls -laR
        result = ssh_conn.execute_command(f"ls -laR {source_path} 2>/dev/null | head -300")
        if result.get("success"):
            return result["stdout"].strip()
        return f"Could not retrieve file structure from {source_path}"
    except Exception as e:
        logger.warning(f"Failed to gather file structure: {e}")
        return f"Error gathering file structure: {str(e)}"


# Extensions for source code files worth reading
SOURCE_EXTENSIONS = {
    '.py', '.php', '.js', '.ts', '.jsx', '.tsx', '.java', '.go', '.rb', '.rs',
    '.cs', '.c', '.cpp', '.h', '.hpp', '.vue', '.svelte', '.swift', '.kt',
    '.scala', '.sh', '.bash', '.pl', '.pm', '.lua', '.r', '.m',
}

# Config/manifest files to always prioritize (read first)
CONFIG_FILES = {
    'composer.json', 'package.json', 'requirements.txt', 'pyproject.toml',
    'setup.py', 'setup.cfg', 'Pipfile', 'Gemfile', 'pom.xml', 'build.gradle',
    'Cargo.toml', 'go.mod', 'go.sum', 'Makefile', 'CMakeLists.txt',
    'docker-compose.yml', 'docker-compose.yaml', 'Dockerfile',
    '.env.example', '.env.sample', 'config.yaml', 'config.yml', 'config.json',
    'tsconfig.json', 'webpack.config.js', 'vite.config.ts', 'vite.config.js',
    '.eslintrc.js', '.eslintrc.json', 'nginx.conf', 'apache.conf',
    'sonar-project.properties', 'tox.ini', 'pytest.ini',
}

# Directories to always skip — vendored, generated, build, IDE, cache
SKIP_DIRS = {
    'node_modules', 'vendor', '.git', '__pycache__', '.venv', 'venv',
    'env', '.env', 'dist', 'build', '.next', '.nuxt', 'target',
    'bin', 'obj', '.idea', '.vscode', 'coverage', '.tox',
    # additional: cache/lock/generated output
    '.pytest_cache', '.mypy_cache', '.ruff_cache', '.cache', '.parcel-cache',
    '.yarn', 'bower_components', '.gradle', '.m2', '.terraform',
    'out', 'output', 'generated', 'gen', '__generated__',
    '.docusaurus', '.serverless', '.svelte-kit', '.turbo',
    'cmake-build-debug', 'cmake-build-release', 'CMakeFiles',
    'storage', 'bootstrap_cache',  # laravel runtime dirs
    'migrations_cache',
}

# Files/patterns to always skip (minified, generated, binaries, lockfiles)
# Checked against basename, and "contains" for patterns like '.min.'
SKIP_BASENAMES = {
    'package-lock.json', 'yarn.lock', 'pnpm-lock.yaml', 'composer.lock',
    'Gemfile.lock', 'Cargo.lock', 'poetry.lock', 'bun.lockb',
    'go.sum',  # large checksum file; go.mod is in CONFIG_FILES
    '.DS_Store', 'Thumbs.db',
}

# Substrings in the filename (lowercased) that mean "skip"
SKIP_NAME_SUBSTRINGS = (
    '.min.',        # foo.min.js, bar.min.css
    '.bundle.',     # webpack bundles
    '.chunk.',      # code-split chunks
    '-min.',        # foo-min.js
    '.compiled.',   # foo.compiled.js
)

# File extensions that are NEVER source (binaries, media, archives, compiled)
SKIP_EXTENSIONS = {
    # images
    '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico', '.webp', '.svg',
    '.tiff', '.tif', '.psd', '.ai', '.heic',
    # fonts
    '.ttf', '.otf', '.woff', '.woff2', '.eot',
    # video / audio
    '.mp4', '.mov', '.avi', '.mkv', '.webm', '.mp3', '.wav', '.ogg', '.flac',
    # archives
    '.zip', '.tar', '.gz', '.tgz', '.bz2', '.xz', '.7z', '.rar', '.jar', '.war',
    # binaries / compiled
    '.exe', '.dll', '.so', '.dylib', '.o', '.a', '.class', '.pyc', '.pyo',
    '.phar',  # PHP archives
    # documents
    '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
    # data dumps (often huge, not useful to LLM)
    '.sql', '.db', '.sqlite', '.sqlite3', '.dump', '.bak',
    # large data formats
    '.csv', '.tsv',  # often data, not source; can re-enable per-project if needed
    # compiled sourcemaps (large, machine-generated)
    '.map',
}

MAX_FILE_SIZE = int(os.environ.get("MIRA_ANALYZE_MAX_FILE_BYTES", 300_000))            # 300 KB per file
MAX_TOTAL_SIZE = int(os.environ.get("MIRA_ANALYZE_MAX_TOTAL_BYTES", 50_000_000))       # 50 MB total (analyze flow)
MAX_LINES_PER_FILE = int(os.environ.get("MIRA_ANALYZE_MAX_LINES_PER_FILE", 10_000))    # cap head -N per file
# Heuristic: files whose average line length exceeds this are treated as minified/generated
MINIFIED_AVG_LINE_LEN = int(os.environ.get("MIRA_ANALYZE_MINIFIED_AVG_LINE_LEN", 400))


def should_skip_path(path: str) -> tuple:
    """
    Decide whether a path should be skipped BEFORE any LLM cost is incurred.
    Returns (skip: bool, reason: str).

    Applies to: analyze flow, migration pipeline file selection, fix-sonar filtering.
    This is the single source of truth for "is this worth sending to the LLM".
    """
    if not path:
        return True, "empty path"
    norm = path.replace('\\', '/')
    parts = norm.split('/')
    basename = parts[-1]
    basename_lower = basename.lower()

    # Directory-level skip
    for part in parts[:-1]:
        if part in SKIP_DIRS:
            return True, f"inside skip dir: {part}"

    # Explicit lockfile / known-skip basename
    if basename in SKIP_BASENAMES:
        return True, f"skip basename: {basename}"

    # Name pattern (minified, bundle, chunk)
    for sub in SKIP_NAME_SUBSTRINGS:
        if sub in basename_lower:
            return True, f"name contains {sub!r}"

    # Binary / media / archive / compiled extensions
    _, ext = os.path.splitext(basename_lower)
    if ext in SKIP_EXTENSIONS:
        return True, f"skip extension: {ext}"

    return False, ""


def looks_minified(content: str) -> bool:
    """
    Content-level heuristic: if the file's average non-empty line length
    exceeds the threshold, it's probably minified/generated. Cheap check.
    """
    if not content:
        return False
    lines = [ln for ln in content.split('\n') if ln.strip()]
    if len(lines) < 3:
        # Single-line files: if they're long, almost certainly minified
        return len(content) > 2 * MINIFIED_AVG_LINE_LEN
    avg = len(content) / len(lines)
    return avg > MINIFIED_AVG_LINE_LEN


def gather_source_code(ssh_conn, source_path: str, file_list: str) -> str:
    """
    Read actual source code files from the remote server via SSH.
    Prioritizes config/manifest files, then source code by extension.
    
    Args:
        ssh_conn: Active SSH connection
        source_path: Root path of the project
        file_list: Output from gather_file_structure (newline-separated file paths)
    
    Returns:
        Concatenated source code with file headers, ready for LLM analysis.
    """
    try:
        # Parse file list into individual paths
        all_paths = [p.strip() for p in file_list.split('\n') if p.strip()]
        
        config_files = []
        source_files = []
        skipped_by_reason: Dict[str, int] = {}

        for path in all_paths:
            if path.endswith('/'):
                continue

            # Unified skip filter — identical to what the migration pipeline will use
            skip, reason = should_skip_path(path)
            if skip:
                skipped_by_reason[reason] = skipped_by_reason.get(reason, 0) + 1
                continue

            basename = os.path.basename(path)
            _, ext = os.path.splitext(basename)

            if basename in CONFIG_FILES:
                config_files.append(path)
            elif ext.lower() in SOURCE_EXTENSIONS:
                source_files.append(path)

        files_to_read = config_files + source_files

        if skipped_by_reason:
            top_reasons = sorted(skipped_by_reason.items(), key=lambda x: -x[1])[:5]
            logger.info(
                "Skip filter dropped %d paths before LLM cost; top reasons: %s",
                sum(skipped_by_reason.values()),
                ", ".join(f"{r}={n}" for r, n in top_reasons),
            )

        if not files_to_read:
            logger.warning("No readable source files found in project")
            return ""

        logger.info(f"Reading {len(files_to_read)} source files ({len(config_files)} config, {len(source_files)} source)")

        collected = []
        total_size = 0
        files_read = 0
        skipped_minified = 0

        for filepath in files_to_read:
            if total_size >= MAX_TOTAL_SIZE:
                logger.info(f"Reached total size cap ({MAX_TOTAL_SIZE} bytes) after {files_read} files")
                break

            try:
                result = ssh_conn.execute_command(f"cat '{filepath}' 2>/dev/null | head -{MAX_LINES_PER_FILE}")
                if not result.get("success") or not result.get("stdout", "").strip():
                    continue

                content = result["stdout"].strip()

                # Content-level skip: the file passed path filters but reads like minified code.
                if looks_minified(content):
                    skipped_minified += 1
                    continue

                if len(content) > MAX_FILE_SIZE:
                    content = content[:MAX_FILE_SIZE] + "\n... [truncated]"

                rel_path = filepath
                if filepath.startswith(source_path):
                    rel_path = filepath[len(source_path):].lstrip('/')

                file_block = f"=== FILE: {rel_path} ===\n{content}\n"
                collected.append(file_block)
                total_size += len(file_block)
                files_read += 1

            except Exception as file_err:
                logger.debug(f"Could not read {filepath}: {file_err}")
                continue

        if skipped_minified:
            logger.info(f"Skipped {skipped_minified} minified/generated-looking file(s) based on line-length heuristic")

        logger.info(
            f"Collected {files_read} of {len(files_to_read)} candidate files "
            f"({len(config_files)} config + {len(source_files)} source), {total_size} bytes of source code "
            f"[caps: per_file={MAX_FILE_SIZE}, total={MAX_TOTAL_SIZE}, lines={MAX_LINES_PER_FILE}]"
        )
        return "\n".join(collected)
        
    except Exception as e:
        logger.error(f"Failed to gather source code: {e}", exc_info=True)
        return ""


def _normalize_text_for_display(text: Any) -> str:
    """
    Normalize text for human-readable display in reports.
    Converts escaped newlines to real newlines, strips markdown formatting,
    and cleans up JSON artifacts.
    """
    if not isinstance(text, str):
        text = str(text) if text is not None else ""
    # Convert escaped newlines to actual newlines
    text = text.replace('\\n', '\n').replace('\\r', '\r')
    # Strip markdown bold/italic
    text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
    text = re.sub(r'\*(.+?)\*', r'\1', text)
    text = re.sub(r'__(.+?)__', r'\1', text)
    text = re.sub(r'_(.+?)_', r'\1', text)
    # Remove code block markers
    text = re.sub(r'^```\w*\s*', '', text)
    text = re.sub(r'\s*```$', '', text)
    return text.strip()


def _sanitize_for_xml(text: Any) -> str:
    """
    Ultra-strict sanitization for XML 1.0 / HTML.
    Removes control characters, surrogates, replaces special chars,
    and escapes XML entities for safe embedding in HTML/PDF/DOCX.
    """
    if not isinstance(text, str):
        text = str(text) if text is not None else ""
    
    # First normalize for display (escaped newlines, markdown)
    text = _normalize_text_for_display(text)
    
    # Replace em-dashes and other problematic chars with safe versions
    text = text.replace('\u2014', '-').replace('\u2013', '-').replace('\u2026', '...')
    
    # Escape XML/HTML entities
    text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#39;')
    
    def is_valid_xml_char(c):
        cp = ord(c)
        return (
            cp == 0x9 or cp == 0xA or cp == 0xD or
            (0x20 <= cp <= 0xD7FF) or
            (0xE000 <= cp <= 0xFFFD)
        )
    
    return "".join(c for c in text if is_valid_xml_char(c))


def _safe_set_style(obj, style_name: str, is_table=False):
    """
    Safely set a style on a Paragraph or Table.
    For tables, never fall back to 'Normal' (which is a paragraph style).
    """
    try:
        obj.style = style_name
    except:
        if not is_table:
            try:
                obj.style = 'Normal'
            except:
                pass


def _set_cell_text(cell, text):
    """
    Safely set text for a table cell by creating a clean paragraph.
    Handles internal newlines by creating multiple paragraphs to avoid XML breakage.
    """
    # Clear existing content
    for p in cell.paragraphs:
        p.text = ""
    
    lines = str(text).split('\n')
    for i, line in enumerate(lines):
        if i == 0:
            p = cell.paragraphs[0]
            p.text = _sanitize_for_xml(line.strip())
        else:
            p = cell.add_paragraph(_sanitize_for_xml(line.strip()))


def _extract_json_from_text(content: str) -> Optional[str]:
    """Extract JSON object from text using brace matching (handles nested braces)."""
    start = content.find('{')
    if start == -1:
        return None
    depth = 0
    in_string = False
    escape = False
    quote_char = None
    for i, c in enumerate(content[start:], start):
        if escape:
            escape = False
            continue
        if c == '\\' and in_string:
            escape = True
            continue
        if not in_string:
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    return content[start:i + 1]
            elif c in ('"', "'"):
                in_string = True
                quote_char = c
        else:
            if c == quote_char:
                in_string = False
    return None


def _parse_llm_json_response(response) -> Dict[str, Any]:
    """
    Parse LLM response content as JSON, handling markdown code blocks,
    escaped newlines, and extra non-JSON text.
    """
    if hasattr(response, 'content'):
        llm_content = response.content.strip()
    else:
        llm_content = str(response).strip()
    
    # Pre-processing: Handle escaped newlines that LLM often injects incorrectly
    processed_content = llm_content.replace("\\n\\", "\\n").replace("\\\n", "\\n")
    
    # Remove <think>...</think> blocks if present
    processed_content = re.sub(r'<think>.*?</think>', '', processed_content, flags=re.DOTALL).strip()
    
    # Helper to try parsing with fallback for unescaped backslashes
    def _try_parse(json_string):
        try:
            return json.loads(json_string, strict=False)
        except json.JSONDecodeError:
            try:
                # Fix unescaped backslashes like App\Exceptions\Handler -> App\\Exceptions\\Handler
                # Match \ that is not followed by a valid JSON escape character
                fixed_json = re.sub(r'\\(?!["\\/bfnrtu])', r'\\\\', json_string)
                return json.loads(fixed_json, strict=False)
            except json.JSONDecodeError:
                return None

    # Try direct parse first
    parsed = _try_parse(processed_content)
    if parsed is not None:
        return parsed
        
    # Handle markdown code blocks - extract JSON using brace matching
    if "```" in processed_content:
        # Find content between ``` markers
        parts = processed_content.split('```')
        for i, part in enumerate(parts):
            if i % 2 == 1:  # Content inside backticks
                json_str = _extract_json_from_text(part)
                if json_str:
                    parsed = _try_parse(json_str)
                    if parsed is not None:
                        return parsed

    # Look for JSON object using brace matching on the whole text
    json_str = _extract_json_from_text(processed_content)
    if json_str:
        parsed = _try_parse(json_str)
        if parsed is not None:
            return parsed

    return {"raw_analysis": llm_content, "format": "text"}


def _escape_md_cell(text: Any) -> str:
    """Escape pipe chars for markdown table cells."""
    s = str(text) if text is not None else ""
    return s.replace("|", "\\|").replace("\n", " ")
