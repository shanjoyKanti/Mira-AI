"""Account business logic service layer - MongoDB/Beanie"""
from typing import Optional
from datetime import datetime, timedelta
from fastapi import HTTPException, status
import secrets

from app.api.v1.accounts import schemas
from app.db.mongodb_models import User, RefreshToken, UserRole
from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_refresh_token,
    decode_token
)
from app.core.config import settings
from app.core.email import email_service


# Account lockout settings
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_DURATION_MINUTES = 15


async def get_user_by_id(user_id: str) -> Optional[User]:
    """Get user by ID"""
    return await User.get(user_id)


async def get_user_by_email(email: str) -> Optional[User]:
    """Get user by email"""
    return await User.find_one(User.email == email)


async def get_user_by_verification_token(token: str) -> Optional[User]:
    """Get user by email verification token"""
    return await User.find_one(User.email_verification_token == token)


async def get_user_by_reset_token(token: str) -> Optional[User]:
    """Get user by password reset token"""
    return await User.find_one(User.password_reset_token == token)


def is_account_locked(user: User) -> bool:
    """Check if user account is locked due to failed login attempts"""
    if user.locked_until and user.locked_until > datetime.utcnow():
        return True
    return False


async def reset_failed_attempts(user: User):
    """Reset failed login attempts"""
    user.failed_login_attempts = 0
    user.locked_until = None
    await user.save()


async def increment_failed_attempts(user: User):
    """Increment failed login attempts and lock account if necessary"""
    user.failed_login_attempts += 1
    
    if user.failed_login_attempts >= MAX_FAILED_ATTEMPTS:
        user.locked_until = datetime.utcnow() + timedelta(minutes=LOCKOUT_DURATION_MINUTES)
    
    await user.save()


async def create_user(user_data: schemas.UserCreate) -> User:
    """Create a new user"""
    hashed_password = get_password_hash(user_data.password)
    
    # Generate email verification token
    verification_token = secrets.token_urlsafe(32)
    
    db_user = User(
        email=user_data.email,
        username=user_data.username,
        hashed_password=hashed_password,
        email_verification_token=verification_token,
        email_verification_sent_at=datetime.utcnow(),
        role=UserRole.USER,
        is_active=True,
        is_email_verified=False,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow()
    )
    
    await db_user.insert()
    
    # Send verification email
    try:
        await email_service.send_verification_email(
            email=db_user.email,
            token=verification_token,
            username=db_user.username
        )
    except Exception as e:
        # Log error but don't fail user creation
        from app.core.logging import get_logger
        logger = get_logger(__name__)
        logger.warning(f"Failed to send verification email: {str(e)}")
    
    return db_user


async def authenticate_user(email: str, password: str) -> Optional[User]:
    """Authenticate user with email and password"""
    user = await get_user_by_email(email)
    if not user:
        return None
    
    # Check if account is locked
    if is_account_locked(user):
        raise HTTPException(
            status_code=status.HTTP_423_LOCKED,
            detail=f"Account is locked due to too many failed login attempts. Try again after {user.locked_until.strftime('%Y-%m-%d %H:%M:%S UTC')}"
        )
    
    # Check if account is active
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is inactive. Please contact support."
        )
    
    # Verify password
    if not verify_password(password, user.hashed_password):
        await increment_failed_attempts(user)
        return None
    
    # Reset failed attempts and update last login
    await reset_failed_attempts(user)
    user.last_login_at = datetime.utcnow()
    await user.save()
    
    return user


async def create_user_tokens(user: User) -> schemas.TokenResponse:
    """Create access and refresh tokens for user"""
    access_token = create_access_token(data={"sub": str(user.id), "role": user.role.value})
    refresh_token = create_refresh_token(data={"sub": str(user.id)})
    
    # Store refresh token in database
    expires_at = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    db_refresh_token = RefreshToken(
        user_id=str(user.id),  # MongoDB ObjectId as string
        token=refresh_token,
        expires_at=expires_at
    )
    await db_refresh_token.insert()
    
    return schemas.TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )


async def refresh_user_tokens(refresh_token: str) -> schemas.TokenResponse:
    """Refresh access token using refresh token"""
    # Check if token exists and is not revoked
    db_token = await RefreshToken.find_one(
        RefreshToken.token == refresh_token,
        RefreshToken.is_revoked == False
    )
    
    if not db_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or revoked refresh token"
        )
    
    # Check if token is expired
    if db_token.expires_at < datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token has expired"
        )
    
    # Decode token
    payload = decode_token(refresh_token)
    
    if payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type"
        )
    
    user_id = payload.get("sub")
    user = await get_user_by_id(user_id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    
    # Revoke old refresh token
    db_token.is_revoked = True
    await db_token.save()
    
    return await create_user_tokens(user)


async def revoke_refresh_token(refresh_token: str):
    """Revoke a refresh token (logout)"""
    db_token = await RefreshToken.find_one(RefreshToken.token == refresh_token)
    
    if db_token:
        db_token.is_revoked = True
        await db_token.save()


async def verify_email(token: str) -> User:
    """Verify user email with token"""
    user = await get_user_by_verification_token(token)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid verification token"
        )
    
    # Check if token is expired
    if user.email_verification_sent_at:
        token_age = datetime.utcnow() - user.email_verification_sent_at
        if token_age > timedelta(hours=settings.EMAIL_VERIFICATION_TOKEN_EXPIRE_HOURS):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Verification token has expired"
            )
    
    # Mark email as verified
    user.is_email_verified = True
    user.email_verification_token = None
    user.email_verification_sent_at = None
    await user.save()
    
    return user


async def resend_verification_email(email: str):
    """Resend verification email"""
    user = await get_user_by_email(email)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    if user.is_email_verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email is already verified"
        )
    
    # Generate new verification token
    verification_token = secrets.token_urlsafe(32)
    user.email_verification_token = verification_token
    user.email_verification_sent_at = datetime.utcnow()
    await user.save()
    
    # Send verification email
    await email_service.send_verification_email(
        email=user.email,
        token=verification_token,
        username=user.username
    )


async def request_password_reset(email: str):
    """Request password reset"""
    user = await get_user_by_email(email)
    
    if not user:
        # Don't reveal that user doesn't exist
        return
    
    # Generate password reset token
    reset_token = secrets.token_urlsafe(32)
    user.password_reset_token = reset_token
    user.password_reset_sent_at = datetime.utcnow()
    await user.save()
    
    # Send password reset email
    await email_service.send_password_reset_email(
        email=user.email,
        token=reset_token,
        username=user.username
    )


async def reset_password(token: str, new_password: str) -> User:
    """Reset password with token"""
    user = await get_user_by_reset_token(token)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid reset token"
        )
    
    # Check if token is expired
    if user.password_reset_sent_at:
        token_age = datetime.utcnow() - user.password_reset_sent_at
        if token_age > timedelta(hours=settings.PASSWORD_RESET_TOKEN_EXPIRE_HOURS):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Reset token has expired"
            )
    
    # Update password
    user.hashed_password = get_password_hash(new_password)
    user.password_reset_token = None
    user.password_reset_sent_at = None
    
    # Reset failed login attempts
    user.failed_login_attempts = 0
    user.locked_until = None
    
    await user.save()
    
    # Send password changed confirmation email
    await email_service.send_password_changed_email(
        email=user.email,
        username=user.username
    )
    
    # Revoke all refresh tokens for this user
    user_id_str = str(user.id)
    tokens = await RefreshToken.find(RefreshToken.user_id == user_id_str, RefreshToken.is_revoked == False).to_list()
    for token in tokens:
        token.is_revoked = True
        await token.save()
    
    return user


async def change_password(
    user: User,
    current_password: str,
    new_password: str
) -> User:
    """Change user password"""
    # Verify current password
    if not verify_password(current_password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect"
        )
    
    # Update password
    user.hashed_password = get_password_hash(new_password)
    user.updated_at = datetime.utcnow()
    await user.save()
    
    # Send password changed confirmation email
    await email_service.send_password_changed_email(
        email=user.email,
        username=user.username
    )
    
    # Revoke all refresh tokens for this user
    user_id_str = str(user.id)
    tokens = await RefreshToken.find(RefreshToken.user_id == user_id_str, RefreshToken.is_revoked == False).to_list()
    for token in tokens:
        token.is_revoked = True
        await token.save()
    
    return user


async def update_user(user_id: str, user_update: schemas.UserUpdate) -> User:
    """Update user information"""
    user = await get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    update_data = user_update.model_dump(exclude_unset=True)
    
    for field, value in update_data.items():
        setattr(user, field, value)
    
    user.updated_at = datetime.utcnow()
    await user.save()
    return user


async def delete_user(user_id: str) -> None:
    """Delete user"""
    user = await get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    await user.delete()
