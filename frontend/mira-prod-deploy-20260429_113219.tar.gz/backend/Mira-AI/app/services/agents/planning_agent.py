"""
Planning agent: resolves PHP migration stages from current → target version and fetches
official migration documentation via the RAG system (Qdrant vector DB + web scraper).

Static documentation folders have been removed. All migration content is now sourced
dynamically from app/services/rag/rag_adapter.py (UniversalMigrationTool + Qdrant).
"""

from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from app.services.agents.base_agent import AgentState, BaseAgent, GroqClient
from app.core.logging import get_logger

logger = get_logger(__name__)

# Project root: app/services/agents -> parents[2] = app
_APP_DIR = Path(__file__).resolve().parent.parent.parent
_REPO_ROOT = _APP_DIR.parent
_REPORTS_DIR = _REPO_ROOT / "reports"
_STAGE_UPGRADE_GUIDE_DIR = _REPO_ROOT / "app" / "data" / "upgrade-guide"

# ---------------------------------------------------------------------------
# Lazy RAG adapter (imported here to avoid circular imports at module load)
# ---------------------------------------------------------------------------
_rag_adapter = None


def _get_rag_adapter():
    """Return a module-level singleton RagAdapter, initialised on first call."""
    global _rag_adapter
    if _rag_adapter is None:
        from app.services.rag.rag_adapter import RagAdapter
        _rag_adapter = RagAdapter()
    return _rag_adapter

# Ordered chain matching php.net migration guides (folder NN = migrationNN.php).
# Each row: (folder_num, from_version, to_version) as dotted minors.
# Covers the full PHP history from 4.x onwards so any legacy project can be migrated.
PHP_MIGRATION_CHAIN: List[tuple[int, str, str]] = [
    (40,  "4.0",  "4.1"),
    (41,  "4.1",  "4.2"),
    (42,  "4.2",  "4.3"),
    (43,  "4.3",  "4.4"),
    (50,  "4.4",  "5.0"),
    (51,  "5.0",  "5.1"),
    (52,  "5.1",  "5.2"),
    (53,  "5.2",  "5.3"),
    (54,  "5.3",  "5.4"),
    (55,  "5.4",  "5.5"),
    (56,  "5.5",  "5.6"),
    (70,  "5.6",  "7.0"),
    (71,  "7.0",  "7.1"),
    (72,  "7.1",  "7.2"),
    (73,  "7.2",  "7.3"),
    (74,  "7.3",  "7.4"),
    (80,  "7.4",  "8.0"),
    (81,  "8.0",  "8.1"),
    (82,  "8.1",  "8.2"),
    (83,  "8.2",  "8.3"),
    (84,  "8.3",  "8.4"),
    (85,  "8.4",  "8.5"),
]

_BEFORE_LIST = [row[1] for row in PHP_MIGRATION_CHAIN]
_AFTER_LIST = [row[2] for row in PHP_MIGRATION_CHAIN]
_FOLDER_LIST = [row[0] for row in PHP_MIGRATION_CHAIN]


def normalize_php_version(version: str) -> str:
    """Normalize user/language-agent version strings to 'major.minor'."""
    if version is None:
        return ""
    v = version.strip().lower().replace(".x", "").rstrip(".")
    if not v:
        return ""
    parts = v.split(".")
    major = parts[0]
    minor = parts[1] if len(parts) > 1 else "0"
    return f"{major}.{minor}"


@dataclass
class MigrationStage:
    """One step in the staged migration plan."""

    stage_index: int
    folder_num: int
    folder_name: str
    from_version: str
    to_version: str
    label_from: str
    label_to: str
    doc_dir: Path
    doc_paths: List[Path] = field(default_factory=list)
    combined_documentation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "stage_index": self.stage_index,
            "folder_num": self.folder_num,
            "folder_name": self.folder_name,
            "from_version": self.from_version,
            "to_version": self.to_version,
            "label_from": self.label_from,
            "label_to": self.label_to,
            "doc_dir": str(self.doc_dir),
            "doc_file_count": len(self.doc_paths),
            "documentation_chars": len(self.combined_documentation),
        }


def compute_migration_stages(
    from_version: str,
    to_version: str,
    docs_txt_root: Optional[Path] = None,
    load_file_contents: bool = True,
    max_chars_per_stage: Optional[int] = None,
) -> List[MigrationStage]:
    """
    Build the ordered list of migration stages from `from_version` to `to_version`.

    Migration documentation is now sourced dynamically via the RAG system
    (Qdrant vector DB with web-scraper fallback) instead of static .txt files.

    Args:
        from_version: Current PHP version (e.g. from language analysis).
        to_version: Target PHP version.
        docs_txt_root: Ignored — kept for API compatibility. RAG is always used.
        load_file_contents: If True (default), fetch RAG documentation for each stage.
                            If False, stages are returned with empty combined_documentation.
        max_chars_per_stage: If set, truncate combined_documentation to this many chars.

    Returns:
        Non-empty list of MigrationStage, or empty if from_version == to_version or invalid.

    Raises:
        ValueError: if versions are unsupported or out of order.
    """
    from_v = normalize_php_version(from_version)
    to_v = normalize_php_version(to_version)

    if not from_v or not to_v:
        raise ValueError("from_version and to_version must be non-empty")

    if from_v == to_v:
        logger.info(
            "[planning_agent] compute_migration_stages: from == to (%s); no stages.",
            from_v,
        )
        return []

    logger.info(
        "[planning_agent] compute_migration_stages: start PHP %s → %s (RAG mode)",
        from_v,
        to_v,
    )

    try:
        start_idx = _BEFORE_LIST.index(from_v)
    except ValueError as e:
        raise ValueError(
            f"Unsupported or unknown from_version '{from_version}' (normalized '{from_v}'). "
            f"Supported starts: {sorted(set(_BEFORE_LIST))}"
        ) from e

    try:
        end_idx = _AFTER_LIST.index(to_v)
    except ValueError as e:
        raise ValueError(
            f"Unsupported or unknown to_version '{to_version}' (normalized '{to_v}'). "
            f"Supported targets: {sorted(set(_AFTER_LIST))}"
        ) from e

    if end_idx < start_idx:
        raise ValueError(
            f"to_version {to_v} is before the first migration after {from_v} in the official chain."
        )

    # Fetch RAG docs for all steps at once if content loading is requested
    rag_docs_by_to_version: Dict[str, str] = {}
    rag_urls_by_to_version: Dict[str, str] = {}
    if load_file_contents:
        try:
            adapter = _get_rag_adapter()
            rag_docs = adapter.fetch_php_migration_docs(from_v, to_v)
            for doc in rag_docs:
                rag_docs_by_to_version[doc.to_version] = doc.content
                rag_urls_by_to_version[doc.to_version] = doc.source_url
            logger.info(
                "[planning_agent] compute_migration_stages: RAG returned %d doc(s) for PHP %s → %s",
                len(rag_docs), from_v, to_v,
            )
        except Exception as e:
            logger.error(
                "[planning_agent] compute_migration_stages: RAG fetch failed — %s. "
                "Stages will have empty combined_documentation.",
                e,
            )

    stages: List[MigrationStage] = []
    for i, chain_idx in enumerate(range(start_idx, end_idx + 1), start=1):
        folder_num = _FOLDER_LIST[chain_idx]
        fv = _BEFORE_LIST[chain_idx]
        tv = _AFTER_LIST[chain_idx]
        folder_name = f"php_migration_{folder_num}_txt"

        combined = rag_docs_by_to_version.get(tv, "")
        source_url = rag_urls_by_to_version.get(tv, "")

        if combined:
            logger.info(
                "[planning_agent] compute_migration_stages: stage %d PHP %s→%s — %d chars (from RAG, url=%s)",
                i, fv, tv, len(combined), source_url or "n/a",
            )
        else:
            if load_file_contents:
                logger.warning(
                    "[planning_agent] compute_migration_stages: stage %d PHP %s→%s — no RAG content",
                    i, fv, tv,
                )

        if max_chars_per_stage is not None and len(combined) > max_chars_per_stage:
            logger.warning(
                "Stage %s (%s): truncating documentation from %s to %s chars",
                i, folder_name, len(combined), max_chars_per_stage,
            )
            combined = combined[:max_chars_per_stage]

        stages.append(
            MigrationStage(
                stage_index=i,
                folder_num=folder_num,
                folder_name=folder_name,
                from_version=fv,
                to_version=tv,
                label_from=f"{fv}.x",
                label_to=f"{tv}.x",
                doc_dir=Path(f"rag://{folder_name}"),  # synthetic — no longer a real path
                doc_paths=[],                           # not used; content is in combined_documentation
                combined_documentation=combined,
            )
        )

    logger.info(
        "[planning_agent] compute_migration_stages: done — %s stage(s) PHP %s → %s (folder nums %s)",
        len(stages), from_v, to_v, [s.folder_num for s in stages],
    )
    return stages


def _php_tuple(version: str) -> Tuple[int, int]:
    v = normalize_php_version(version)
    parts = v.split(".")
    major = int(parts[0]) if parts and parts[0].isdigit() else 0
    minor = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
    return major, minor


def laravel_doc_covers_target_php(doc_text: str, target_php: str) -> bool:
    """
    True if this Laravel .txt document mentions PHP >= target (version requirement / support).
    Used only in legacy fallback when ``from_laravel`` is not provided.
    """
    t = _php_tuple(target_php)
    for m in re.finditer(
        r"(?:PHP|php)\s*(?:version\s*)?(?:>=|≥|>|:\s*)?\s*(\d+)\.(\d+)(?:\.(\d+))?",
        doc_text,
        re.IGNORECASE,
    ):
        maj, mn = int(m.group(1)), int(m.group(2))
        if (maj, mn) >= t:
            return True
    if re.search(rf"\bPHP\s+{re.escape(target_php)}\b", doc_text, re.IGNORECASE):
        return True
    return False


# Official PHP runtimes per Laravel line (minimum first, then other supported minors where relevant).
# ``_php_tuple`` uses only ``supported[0]`` for floor checks against ``target_php``.
_LARAVEL_LINE_SUPPORTED_PHP: Dict[str, Tuple[str, ...]] = {
    "4.2": ("5.4",),
    "5.0": ("5.5",),
    "5.1": ("5.5",),
    "5.2": ("5.5",),
    "5.3": ("5.6.4",),  # or higher on 5.6.x
    "5.4": ("5.6",),
    "5.5": ("7.0.0",),
    "5.6": ("7.1.3",),
    "5.7": ("7.1",),
    "5.8": ("7.1",),
    "6": ("7.2",),
    "7": ("7.2.5", "7.3", "7.4"),
    "8": ("7.3.0", "7.4"),
    "9": ("8.0",),
    "10": ("8.1.0",),
    "11": ("8.2.0",),
    "12": ("8.3", "8.4", "8.5"),
}

_LARAVEL_LINE_MIN_PHP: Dict[str, str] = {
    k: versions[0] for k, versions in _LARAVEL_LINE_SUPPORTED_PHP.items()
}

# Laravel majors 12→6 (descending) for ``laravel_guide_major_for_target_php`` scanning.
_LARAVEL_GUIDE_MAJOR_DESCENDING: Tuple[int, ...] = (12, 11, 10, 9, 8, 7, 6)


def laravel_guide_major_for_target_php(target_php: str) -> Optional[int]:
    """
    Highest Laravel major in **6.x–12.x** whose minimum PHP requirement is satisfied by
    ``target_php`` (e.g. target 7.3 → 8 because Laravel 8 requires PHP 7.3+; target 8.3 → 12).

    Aligns with packaged ``laravel_upgrade_N.x.txt``; floors come from
    ``_LARAVEL_LINE_SUPPORTED_PHP`` / ``_LARAVEL_LINE_MIN_PHP``.
    """
    t = _php_tuple(target_php)
    for maj in _LARAVEL_GUIDE_MAJOR_DESCENDING:
        min_p = _LARAVEL_LINE_MIN_PHP.get(str(maj))
        if min_p and _php_tuple(min_p) <= t:
            return maj
    return None


_LARAVEL_UPGRADE_FILENAME_RE = re.compile(
    r"^laravel_upgrade_(\d+)(?:\.(x|\d+))?\.txt$", re.IGNORECASE
)


def _laravel_doc_path_sort_key(path: Path) -> Tuple[int, int]:
    """Sort upgrade docs in real version order (avoids ``10.x`` sorting before ``5.x``)."""
    m = _LARAVEL_UPGRADE_FILENAME_RE.match(path.name)
    if not m:
        return (99_999, 99_999)
    maj = int(m.group(1))
    sub = (m.group(2) or "").lower()
    if sub == "x":
        return (maj, 999)
    if sub.isdigit():
        return (maj, int(sub))
    return (maj, 0)


def _parse_single_laravel_version_branch(branch: str) -> Optional[Tuple[int, Optional[int]]]:
    """
    Parse one composer-style branch (no ``|``) into ``(major, minor)``.
    ``minor`` is set only for Laravel 5.0–5.8 lines.
    """
    s = (branch or "").strip()
    if not s:
        return None
    s = re.sub(r"^laravel[\s/-]*", "", s, flags=re.IGNORECASE)
    s = re.sub(r"^[\^~>=\s]+", "", s).lstrip("vV")
    nums = [int(x) for x in re.findall(r"\d+", s)]
    if not nums:
        return None
    major = nums[0]
    if major >= 6:
        return (major, None)
    if major == 5 and len(nums) >= 2:
        return (5, min(8, max(0, nums[1])))
    if major == 5:
        return (5, 8)
    if major == 4:
        return (4, 2)
    return (major, None)


def _laravel_tuple_sort_key(t: Tuple[int, Optional[int]]) -> Tuple[int, int]:
    """Order Laravel lines for ``max()`` (6+ has no 5.x-style minor)."""
    maj, mn = t
    if maj >= 6:
        return (maj, 0)
    if maj == 5:
        return (5, mn if mn is not None else 0)
    if maj == 4:
        return (4, mn if mn is not None else 2)
    return (maj, mn or 0)


def _parse_laravel_version_from_language(from_laravel: str) -> Optional[Tuple[int, Optional[int]]]:
    """
    Parse language-agent strings (``10.48.0``, ``v8``, ``^6.20|^8.0``, ``Laravel 5.7``).

    Composer **OR** constraints are split on ``|`` and the **highest** Laravel line is kept,
    so ``^6.20|^8.0`` resolves to **8.x** (avoids picking ``laravel_upgrade_6.x.txt`` when the
    app is on Laravel 8 with a widened composer constraint).
    """
    raw = (from_laravel or "").strip()
    if not raw:
        return None
    branches = [b.strip() for b in re.split(r"\s*\|\s*", raw) if b.strip()]
    if not branches:
        return None
    parsed_list: List[Tuple[int, Optional[int]]] = []
    for br in branches:
        p = _parse_single_laravel_version_branch(br)
        if p:
            parsed_list.append(p)
    if not parsed_list:
        return None
    return max(parsed_list, key=_laravel_tuple_sort_key)


def laravel_upgrade_txt_filename_for_detected_version(from_laravel: str) -> Optional[str]:
    """
    Map a Laravel **major** string (e.g. ``"8"``, ``"12"``) to a single ``laravel_upgrade_*.txt``.
    Used for doc selection together with ``laravel_guide_major_for_target_php``.
    """
    parsed = _parse_laravel_version_from_language(from_laravel)
    if not parsed:
        return None
    major, minor = parsed
    if major >= 12:
        return "laravel_upgrade_12.x.txt"
    if major == 11:
        return "laravel_upgrade_11.x.txt"
    if major == 10:
        return "laravel_upgrade_10.x.txt"
    if major == 9:
        return "laravel_upgrade_9.x.txt"
    if major == 8:
        return "laravel_upgrade_8.x.txt"
    if major == 7:
        return "laravel_upgrade_7.x.txt"
    if major == 6:
        return "laravel_upgrade_6.x.txt"
    if major == 5 and minor is not None:
        return f"laravel_upgrade_5.{minor}.txt"
    if major == 5:
        return "laravel_upgrade_5.8.txt"
    if major == 4:
        return "laravel_upgrade_4.2.txt"
    return None


def _laravel_min_php_for_doc_name(filename: str) -> Optional[str]:
    m = _LARAVEL_UPGRADE_FILENAME_RE.match(filename)
    if not m:
        return None
    maj = int(m.group(1))
    sub = (m.group(2) or "").lower()
    if maj >= 6 and sub == "x":
        key = str(maj)
        return _LARAVEL_LINE_MIN_PHP.get(key)
    if maj == 5 and sub.isdigit():
        return _LARAVEL_LINE_MIN_PHP.get(f"5.{sub}")
    if maj == 4 and sub == "2":
        return _LARAVEL_LINE_MIN_PHP.get("4.2")
    return None


def collect_laravel_docs_until_php_target(
    target_php: str,
    from_laravel: Optional[str] = None,
    laravel_docs_path: Optional[Path] = None,
    max_total_chars: int = 150_000,
) -> str:
    """
    Return the Laravel upgrade guide text relevant to a PHP migration step whose
    target PHP version is *target_php*.

    Documentation is now sourced dynamically via the RAG system (Qdrant vector DB
    with web-scraper fallback). The *laravel_docs_path* parameter is ignored.

    Args:
        target_php: The PHP version being migrated TO in this stage (e.g. "8.0").
        from_laravel: Current Laravel version from language analysis (context only).
        laravel_docs_path: Ignored — kept for API compatibility.
        max_total_chars: Truncate returned content to this many chars.

    Returns:
        Laravel upgrade guide text, or "" if no guide is available.
    """
    target_norm = normalize_php_version(target_php)
    guide_major = laravel_guide_major_for_target_php(target_norm)

    logger.info(
        "[planning_agent] collect_laravel_docs_until_php_target: target_php=%s "
        "guide_laravel_major=%s app_from_laravel=%r (RAG mode)",
        target_norm,
        guide_major,
        (from_laravel or "").strip() or None,
    )

    try:
        adapter = _get_rag_adapter()
        content = adapter.fetch_laravel_docs(
            target_php_version=target_norm,
            from_laravel=from_laravel,
        )
    except Exception as e:
        logger.error(
            "[planning_agent] collect_laravel_docs_until_php_target: RAG fetch failed — %s",
            e,
        )
        return ""

    if not content:
        logger.info(
            "[planning_agent] collect_laravel_docs_until_php_target: no content for PHP %s (guide_major=%s)",
            target_norm, guide_major,
        )
        return ""

    if len(content) > max_total_chars:
        logger.warning(
            "[planning_agent] collect_laravel_docs_until_php_target: truncating content (%d → %d chars)",
            len(content), max_total_chars,
        )
        content = content[:max_total_chars]

    logger.info(
        "[planning_agent] collect_laravel_docs_until_php_target: returning %d chars for PHP %s (guide_major=%s)",
        len(content), target_norm, guide_major,
    )
    return content


def _gather_php_tree_for_llm(project_root: Path, max_chars: int = 95_000) -> str:
    """Concatenate project PHP sources for LLM-based Sonar-equivalent pass."""
    chunks: List[str] = []
    n = 0
    root = project_root.resolve()
    for fp in sorted(root.rglob("*.php")):
        if any(x in fp.parts for x in ("vendor", "node_modules", ".git", "cache")):
            continue
        try:
            body = fp.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        rel = fp.relative_to(root).as_posix()
        block = f"=== FILE: {rel} ===\n{body}\n"
        if n + len(block) > max_chars:
            break
        chunks.append(block)
        n += len(block)
    logger.info(
        "[planning_agent] _gather_php_tree_for_llm: bundled %s file(s), ~%s chars from %s",
        len(chunks),
        n,
        project_root,
    )
    return "\n".join(chunks)


def _llm_sonar_equivalent_report(
    groq_client: GroqClient,
    project_name: str,
    stage: MigrationStage,
    source_bundle: str,
) -> str:
    """When no Sonar server report is available, emit the same structural report the modernization agent expects."""
    user = f"""Migration **stage {stage.stage_index}**: PHP **{stage.from_version}** → **{stage.to_version}**.

You perform a static quality review of the PHP sources below (no live SonarQube). A **separate LLM** will open **one file at a time**, read your report, and **must edit source code** wherever your findings apply. Vague or generic Remediation lines cause the upgrader to skip edits — be **exhaustive and concrete**.

**Before writing:** Read the **entire** SOURCE BUNDLE from first `=== FILE:` to last line. Do not stop after the first few files. Every header `=== FILE: path ===` must be considered.

REQUIRED OUTPUT STRUCTURE (markdown):

1) **## ISSUES BY FILE**
   For each file path from the source headers, under:
   ### <exact relative path from === FILE: ... ===>
   List concrete issues: security (SQL injection, XSS, weak crypto), deprecated PHP {stage.from_version} patterns that affect moving to {stage.to_version}, bugs, and maintainability. Use bullets:
   - **Line N/A** [SEVERITY] **Rule:** <short id> — <message>
     **Code:** <short snippet **copied from that file's bundle** or the exact pattern in that file>
     **Remediation:** <exact fix with **copy-pastable PHP** or precise steps — never "fix the issue" or "refactor" alone>

2) **## SUMMARY** — counts by severity and files affected.

3) **## REMEDIATION REFERENCE** — cross-cutting patterns (PDO, password_hash, htmlspecialchars, etc.) with **code-shaped** examples the per-file editor can apply.

Rules: Only use files present in the bundle. Do not invent paths. If a file truly has no issues after a full read, you may omit its ### section. Be strict about PHP {stage.to_version} compatibility where relevant. **Goal:** The downstream tool must be able to produce **different file contents** when issues exist — your Remediation must mandate specific code edits.

SOURCE BUNDLE:
{source_bundle}
"""
    logger.info(
        "[planning_agent] _llm_sonar_equivalent_report: calling LLM (bundle ~%s chars, PHP %s→%s)",
        len(source_bundle),
        stage.from_version,
        stage.to_version,
    )
    out = groq_client.generate(
        system_prompt=(
            "You are a senior PHP reviewer. You read the **full** source bundle before writing. "
            "Output only the structured markdown report requested; no preamble. Match headings exactly "
            "so downstream tools can parse ## ISSUES BY FILE. Every issue must include **Code** tied to "
            "the real file and **Remediation** with explicit PHP (or exact edit steps). The next LLM "
            "is required to apply these remediations in source files — avoid non-actionable text."
        ),
        user_content=user,
        temperature=0.7,
    )
    logger.info(
        "[planning_agent] _llm_sonar_equivalent_report: LLM returned ~%s chars",
        len(out or ""),
    )
    return out


def regenerate_sonar_once_for_staged_pipeline(
    groq_client: GroqClient,
    project_name: str,
    stages: List[MigrationStage],
    project_root: Path,
    reports_dir: Optional[Path] = None,
) -> Optional[Path]:
    """
    Run SonarQube download + LLM analysis **once** before any migration stage, and save a single
    upgrade-guide text under ``app/data/upgrade-guide/{project}_staged_pipeline_sonarqube_analysis_{ts}.txt``.

    The same report is intended to be reused for every PHP migration stage (no re-download, no re-analysis
    per stage). If no downloadable Sonar report exists, builds one LLM **Sonar-equivalent** pass from the
    initial on-disk PHP tree under ``project_root``.
    """
    if not stages:
        return None
    from app.services.agents.upgrade_analysis_agent import (  # local import: heavy module
        PHPUpgradeAnalyzer,
        _find_latest_sonarqube_report,
        _run_sonarqube_download,
    )

    first, last = stages[0], stages[-1]
    logger.info(
        "[planning_agent] regenerate_sonar_once_for_staged_pipeline: start project=%s "
        "stages=%s PHP %s→%s tree=%s",
        project_name,
        len(stages),
        first.from_version,
        last.to_version,
        project_root,
    )
    rd = Path(reports_dir) if reports_dir else _REPORTS_DIR
    try:
        _STAGE_UPGRADE_GUIDE_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as _e:
        logger.error(
            "[planning_agent] regenerate_sonar_once_for_staged_pipeline: cannot create upgrade-guide dir %s — %s",
            _STAGE_UPGRADE_GUIDE_DIR, _e,
        )
        return None
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = _STAGE_UPGRADE_GUIDE_DIR / (
        f"{project_name}_staged_pipeline_sonarqube_analysis_{ts}.txt"
    )
    reqs = (
        f"Staged PHP migration pipeline: {len(stages)} step(s), PHP {first.from_version} → {last.to_version}. "
        "Extract **every** actionable issue from the Sonar report. This analysis will be **reused for all stages** — "
        "include deprecations, security, and quality findings relevant across the full upgrade path where the "
        "report shows them; do not scope to a single minor step only. "
        "For each finding: preserve file paths, and ensure **Remediation** is concrete (code or exact steps) so a "
        "per-file LLM can **modify source files** — not summaries like 'address the vulnerability'. "
        "Read across **all** chunks of the report; do not drop issues from later sections."
    )

    # Synthetic stage for LLM fallback prompts (full pipeline span)
    pipeline_stage = MigrationStage(
        stage_index=0,
        folder_num=first.folder_num,
        folder_name="staged_pipeline",
        from_version=first.from_version,
        to_version=last.to_version,
        label_from=first.label_from,
        label_to=last.label_to,
        doc_dir=first.doc_dir,
        doc_paths=[],
        combined_documentation="",
    )

    logger.info(
        "[planning_agent] regenerate_sonar_once_for_staged_pipeline: step 1/3 Sonar download → %s",
        rd,
    )
    _run_sonarqube_download(project_name, reports_dir=rd)
    report_path = _find_latest_sonarqube_report(project_name, rd)
    logger.info(
        "[planning_agent] regenerate_sonar_once_for_staged_pipeline: step 2/3 latest report=%s",
        report_path or "(none)",
    )

    if report_path and Path(report_path).exists():
        logger.info(
            "[planning_agent] regenerate_sonar_once_for_staged_pipeline: step 3/3 LLM analyze_sonarqube_report → %s",
            dest.name,
        )
        analyzer = PHPUpgradeAnalyzer(groq_client)
        analyzed = analyzer.analyze_sonarqube_report(
            report_path, project_name, report_requirements=reqs
        )
        if not analyzed:
            logger.error(
                "[planning_agent] regenerate_sonar_once_for_staged_pipeline: analyze_sonarqube_report failed",
            )
            return None
        shutil.copy2(Path(analyzed), dest)
        extra = (
            f"\n\n---\n**Pipeline note:** Single SonarQube analysis for PHP {first.from_version} → {last.to_version} "
            f"({len(stages)} stage(s)); **reused for every stage** without re-download or regeneration.\n"
        )
        dest.write_text(dest.read_text(encoding="utf-8", errors="replace") + extra, encoding="utf-8")
        logger.info(
            "[planning_agent] regenerate_sonar_once_for_staged_pipeline: saved pipeline Sonar txt %s",
            dest,
        )
        return dest

    logger.warning(
        "[planning_agent] regenerate_sonar_once_for_staged_pipeline: no Sonar download; "
        "fallback LLM pass on %s",
        project_root,
    )
    bundle = _gather_php_tree_for_llm(project_root)
    if not bundle.strip():
        logger.error(
            "[planning_agent] regenerate_sonar_once_for_staged_pipeline: no PHP sources for fallback",
        )
        return None
    body = _llm_sonar_equivalent_report(groq_client, project_name, pipeline_stage, bundle)
    header = (
        f"# SonarQube Analysis Report (LLM static pass, pipeline)\n\n"
        f"**Project:** {project_name}\n"
        f"**Pipeline:** PHP {first.from_version} → {last.to_version} ({len(stages)} stage(s); one report for all)\n"
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n---\n\n"
    )
    dest.write_text(header + body, encoding="utf-8")
    logger.info(
        "[planning_agent] regenerate_sonar_once_for_staged_pipeline: saved LLM Sonar-equivalent %s",
        dest,
    )
    return dest


def _sanitize_stage_name_for_filename(folder_name: str) -> str:
    """Safe segment for upgrade-guide filenames (matches php_migration_NN_txt style)."""
    s = (folder_name or "stage").strip().replace(" ", "_")
    s = re.sub(r"[^\w\-.]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "stage"


def synthesize_laravel_guide_for_stage(
    groq_client: GroqClient,
    project_name: str,
    stage: MigrationStage,
    from_laravel: Optional[str],
    laravel_docs_slice: str,
) -> Optional[Path]:
    """
    One Laravel upgrade guide scoped to **this** PHP minor hop (``stage.from_version`` → ``stage.to_version``),
    using only ``laravel_docs_slice`` (single ``laravel_upgrade_*.txt`` chosen from **stage target PHP** via
    ``collect_laravel_docs_until_php_target``, then truncated). ``from_laravel`` is only app context in the header.
    """
    if not (laravel_docs_slice or "").strip():
        return None
    logger.info(
        "[planning_agent] synthesize_laravel_guide_for_stage: start project=%s stage=%s %s PHP %s→%s "
        "doc_slice_chars=%s",
        project_name,
        stage.stage_index,
        stage.folder_name,
        stage.from_version,
        stage.to_version,
        len(laravel_docs_slice),
    )
    try:
        _STAGE_UPGRADE_GUIDE_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as _e:
        logger.error(
            "[planning_agent] synthesize_laravel_guide_for_stage: cannot create upgrade-guide dir %s — %s",
            _STAGE_UPGRADE_GUIDE_DIR, _e,
        )
        return None
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    stage_slug = _sanitize_stage_name_for_filename(stage.folder_name)
    dest = _STAGE_UPGRADE_GUIDE_DIR / (
        f"{project_name}_stage{stage.stage_index:02d}_{stage_slug}_laravel_upgrade_guide_{ts}.txt"
    )
    chunk_cap = 48_000
    if len(laravel_docs_slice) <= chunk_cap:
        doc_input = laravel_docs_slice
    else:
        doc_input = laravel_docs_slice[:chunk_cap] + "\n\n[... documentation truncated for this synthesis call ...]"

    prompt = f"""You are producing a **Laravel framework upgrade guide** for **one PHP migration step only**.

A downstream LLM will read this guide **together with each PHP file** and must **change source code** when the guide applies. Read the **entire** excerpt below **before** writing (top to bottom). Do not summarize away breaking changes that appear late in the text.

**Scope (strict):**
- **Stage name (php.net migration folder):** `{stage.folder_name}` (stage index {stage.stage_index})
- Current PHP for this step: **{stage.from_version}** → target after this step: **{stage.to_version}**.
- Current Laravel (from project analysis): **{from_laravel or "unknown"}**.
- Use **only** the Laravel official documentation excerpt below. Do not assume later PHP versions than **{stage.to_version}**.

**Output:** Markdown with these sections:
1. **## PHP AND LARAVEL VERSION REQUIREMENTS** — which Laravel majors/minors align with PHP **{stage.to_version}** per the excerpt (cite doc lines or filenames when possible).
2. **## BREAKING CHANGES FOR THIS STEP** — only Laravel/framework changes that apply when the runtime moves from PHP {stage.from_version} to **{stage.to_version}**. Prefer **current** framework patterns described in the excerpt (e.g. application bootstrap in `bootstrap/app.php`, `casts()` on models vs legacy `$casts` only if the doc says so, middleware registration, route/controller signatures, queue and validation APIs). For each item: name the **symbol or file pattern** to search for and the **exact replacement pattern** where the excerpt allows.
3. **## DEPRECATED / REMOVED** — removed classes, facades, helpers, config keys; each with replacement and **before/after code** snippets when the excerpt provides them.
4. **## CONFIG AND DEPENDENCIES** — `composer.json` constraints, `config/*.php`, `.env` keys for this step only; be specific enough that editors can edit those files.
5. **## STEP-BY-STEP (THIS STAGE ONLY)** — numbered actions the per-file code editor **must implement when the file matches** (e.g. "If the file imports X, replace with Y"). Avoid steps that say "review" or "consider" without a concrete edit.

When the excerpt discusses **recent** Laravel lines (10.x / 11.x / 12.x or newer), explicitly call out upgrades that teams commonly need: typed properties in requests, `enum` bindings, model casts API, streamlined exception/middleware registration, and any renamed `Illuminate\\` namespaces — **only** if the excerpt supports them.

If the excerpt does not mention Laravel changes for this PHP hop, write **## NOTE** that no Laravel-specific changes are documented for this step and that PHP-only migration applies.

Laravel documentation excerpt:
{doc_input}
"""
    logger.info(
        "[planning_agent] synthesize_laravel_guide_for_stage: calling LLM (prompt input ~%s chars → %s)",
        len(doc_input),
        dest.name,
    )
    body = groq_client.generate(
        system_prompt=(
            f"You write concise, **actionable** Laravel upgrade notes aligned with **current** Laravel documentation in the excerpt, "
            f"for migration stage `{stage.folder_name}` (PHP {stage.from_version} → {stage.to_version}). "
            f"You have read the **full** excerpt; downstream LLMs will apply your steps as **mandatory code edits** when symbols match. "
            f"Do not invent upgrades not grounded in the excerpt. Prefer imperative, file-level instructions over vague advice. "
            f"End with no preamble outside the requested sections."
        ),
        user_content=prompt,
        temperature=0.7,
    )
    logger.info(
        "[planning_agent] synthesize_laravel_guide_for_stage: LLM done (~%s chars body)",
        len((body or "").strip()),
    )
    header = (
        f"# Laravel Upgrade Guide (staged)\n\n"
        f"**Project:** {project_name}\n"
        f"**Stage index:** {stage.stage_index}\n"
        f"**Stage name:** `{stage.folder_name}` (php.net migration bundle for this hop)\n"
        f"**PHP step:** {stage.from_version} → {stage.to_version}\n"
        f"**From Laravel:** {from_laravel or 'unknown'}\n"
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n---\n\n"
    )
    dest.write_text(header + (body or "").strip(), encoding="utf-8")
    logger.info(
        "[planning_agent] synthesize_laravel_guide_for_stage: wrote %s (total file ~%s chars)",
        dest,
        len(header) + len((body or "").strip()),
    )
    return dest


class PlanningAgent(BaseAgent):
    """
    Computes which `php_migration_*_txt` folders apply between two PHP versions
    and optionally loads all `.txt` content for downstream modernization.
    """

    def __init__(self, groq_client=None):
        super().__init__(
            name="planning_agent",
            description="Plans PHP migration stages using official php.net migration guide folders",
            groq_client=groq_client,
        )

    def execute(self, state: AgentState) -> AgentState:
        """
        Context keys:
            from_version (str): current PHP version
            to_version (str): target PHP version
            laravel_version (str, optional): current Laravel major — stored for future use / reporting
            docs_txt_root (str | Path, optional): ignored — kept for API compatibility (RAG is always used)
            load_file_contents (bool, optional): default True
            max_chars_per_stage (int, optional): cap text per stage
        """
        ctx = state.context
        from_v = ctx.get("from_version")
        to_v = ctx.get("to_version")
        if not from_v or not to_v:
            state.add_error("from_version and to_version are required in context")
            return state

        logger.info(
            "[planning_agent] execute: start PHP %s → %s (load_file_contents=%s, RAG mode)",
            from_v,
            to_v,
            ctx.get("load_file_contents", True),
        )
        load_files = ctx.get("load_file_contents", True)
        max_chars = ctx.get("max_chars_per_stage")

        try:
            stages = compute_migration_stages(
                str(from_v),
                str(to_v),
                load_file_contents=bool(load_files),
                max_chars_per_stage=max_chars if isinstance(max_chars, int) else None,
            )
        except ValueError as e:
            logger.error("[planning_agent] execute: failed — %s", e)
            state.add_error(str(e))
            return state

        laravel = ctx.get("laravel_version")
        logger.info(
            "[planning_agent] execute: success — %s stage(s) laravel_version=%s",
            len(stages),
            laravel or "n/a",
        )
        plan_summary = {
            "from_version": normalize_php_version(str(from_v)),
            "to_version": normalize_php_version(str(to_v)),
            "laravel_version": laravel,
            "stage_count": len(stages),
            "stages": [s.to_dict() for s in stages],
        }
        state.results["migration_plan"] = plan_summary
        state.results["migration_stages"] = stages
        return state


if __name__ == "__main__":
    import argparse
    import json
    import sys

    _parser = argparse.ArgumentParser(
        description="Test planning_agent: list migration stages and optional doc loading.",
    )
    _parser.add_argument(
        "--from",
        dest="from_v",
        default="7.0",
        metavar="VER",
        help="Current PHP version (default: 7.0)",
    )
    _parser.add_argument(
        "--to",
        dest="to_v",
        default="8.3",
        metavar="VER",
        help="Target PHP version (default: 8.3)",
    )
    _parser.add_argument(
        "--load",
        action="store_true",
        help="Read every .txt under each php_migration_*_txt folder into combined_documentation",
    )
    _parser.add_argument(
        "--docs-root",
        type=str,
        default=None,
        metavar="DIR",
        help="Ignored — kept for CLI compatibility. RAG is always used.",
    )
    _parser.add_argument(
        "--max-chars",
        type=int,
        default=None,
        metavar="N",
        help="Optional per-stage char cap when using --load",
    )
    _parser.add_argument(
        "--via-agent",
        action="store_true",
        help="Call PlanningAgent.execute (needs GROQ_API_KEY in env)",
    )
    _args = _parser.parse_args()
    _docs = Path(_args.docs_root) if _args.docs_root else None

    if _args.via_agent:
        agent = PlanningAgent()
        _st = AgentState(
            context={
                "from_version": _args.from_v,
                "to_version": _args.to_v,
                "load_file_contents": _args.load,
                "docs_txt_root": str(_docs) if _docs else None,
                "max_chars_per_stage": _args.max_chars,
            }
        )
        _out = agent.execute(_st)
        _payload = {
            "errors": _out.errors,
            "migration_plan": _out.results.get("migration_plan"),
            "migration_stages": [
                s.to_dict() for s in _out.results.get("migration_stages", [])
            ],
        }
        json.dump(_payload, sys.stdout, indent=2, default=str)
        sys.stdout.write("\n")
        sys.exit(0 if not _out.errors else 1)

    try:
        _stages = compute_migration_stages(
            _args.from_v,
            _args.to_v,
            docs_txt_root=_docs,
            load_file_contents=_args.load,
            max_chars_per_stage=_args.max_chars,
        )
    except ValueError as _e:
        print(str(_e), file=sys.stderr)
        sys.exit(2)
    json.dump([s.to_dict() for s in _stages], sys.stdout, indent=2, default=str)
    sys.stdout.write("\n")
