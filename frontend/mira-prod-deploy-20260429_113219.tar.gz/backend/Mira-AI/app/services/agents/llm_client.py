"""
Shared LLM client for project modules (Groq with Qwen model).
"""

import os
import re
import time
import logging
from typing import Any

from dotenv import load_dotenv
from groq import Groq

load_dotenv()
logger = logging.getLogger(__name__)


class LLMConfig:
    """Configuration for project-level LLM analysis (Groq)."""

    MODEL: str = "qwen/qwen3-32b"
    MAX_TOKENS: int = 16384
    TEMPERATURE: float = 0.7

    RETRY_ATTEMPTS: int = 3
    RETRY_DELAY: int = 2  # seconds

    @staticmethod
    def get_api_key() -> str:
        api_key = os.getenv("GROQ_API_KEY", "")
        if not api_key:
            raise ValueError("GROQ_API_KEY environment variable is required for LLM analysis")
        return api_key


class ProjectLLMClient:
    """
    Thin wrapper around Groq client for project LLM modules (Qwen model).
    Uses GROQ_API_KEY only.
    """

    def __init__(self):
        self.api_key = LLMConfig.get_api_key()
        self.client = Groq(api_key=self.api_key)
        self.model = LLMConfig.MODEL
        self.max_tokens = LLMConfig.MAX_TOKENS
        self.temperature = LLMConfig.TEMPERATURE
        self.retry_attempts = LLMConfig.RETRY_ATTEMPTS
        self.retry_delay = LLMConfig.RETRY_DELAY
        logger.info("ProjectLLMClient (Groq) initialized with model %s", self.model)

    def generate(
        self,
        system_prompt: str,
        user_content: str,
    ) -> str:
        """Call Groq with system + user message and return text content."""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
        response = self._retry_request(
            self.client.chat.completions.create,
            model=self.model,
            messages=messages,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
        )
        text = self._extract_response_text(response)
        return self._strip_think_blocks(text)

    def _retry_request(self, func, *args, **kwargs):
        last_exception = None
        for attempt in range(self.retry_attempts):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                logger.warning(
                    "LLM request failed (attempt %d/%d): %s",
                    attempt + 1,
                    self.retry_attempts,
                    str(e),
                )
                if attempt < self.retry_attempts - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                else:
                    raise last_exception
        raise last_exception

    @staticmethod
    def _extract_response_text(response: Any) -> str:
        try:
            return (response.choices[0].message.content or "").strip()
        except (IndexError, AttributeError):
            return ""

    @staticmethod
    def _strip_think_blocks(text: str) -> str:
        """Remove think/reasoning blocks from model output."""
        if not text or "<think>" not in text:
            return text
        return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE).strip()
