"""LLM Service - High-level interface for LLM operations"""
from typing import List, Dict, Any, Optional, AsyncIterator
from app.services.llm.base_provider import BaseLLMProvider, LLMMessage, LLMResponse
from app.services.llm.llm_factory import LLMFactory
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class LLMService:
    """Service for LLM operations with provider abstraction"""
    
    def __init__(self, provider_type: Optional[str] = None, config: Optional[Dict[str, Any]] = None):
        """
        Initialize LLM service
        
        Args:
            provider_type: LLM provider type (defaults to settings.LLM_PROVIDER)
            config: Provider configuration (defaults to settings)
        """
        self.provider_type = provider_type or settings.LLM_PROVIDER
        self.config = config or self._get_default_config()
        self._provider: Optional[BaseLLMProvider] = None
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration from settings"""
        config = {
            "model": settings.LLM_MODEL,
            "temperature": settings.LLM_TEMPERATURE,
        }
        
        # Add provider-specific config
        if self.provider_type == "openai":
            config["api_key"] = settings.OPENAI_API_KEY
        elif self.provider_type == "groq":
            config["api_key"] = settings.GROQ_API_KEY
        elif self.provider_type == "anthropic":
            config["api_key"] = settings.ANTHROPIC_API_KEY
        elif self.provider_type == "google":
            config["api_key"] = settings.GOOGLE_API_KEY
        elif self.provider_type in ["local", "ollama", "llama", "vllm"]:
            # Local LLM configuration
            config["base_url"] = getattr(settings, "LOCAL_LLM_BASE_URL", "http://localhost:11434")
            config["api_key"] = getattr(settings, "LOCAL_LLM_API_KEY", None)
            config["provider_type"] = self.provider_type if self.provider_type != "local" else "ollama"
        
        return config
    
    @property
    def provider(self) -> BaseLLMProvider:
        """Get or create LLM provider"""
        if self._provider is None:
            self._provider = LLMFactory.create_provider(self.provider_type, self.config)
        return self._provider
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None, **kwargs) -> LLMResponse:
        """
        Generate a response from LLM
        
        Args:
            prompt: User prompt
            system_prompt: Optional system prompt
            **kwargs: Additional parameters (temperature, max_tokens, etc.)
            
        Returns:
            LLMResponse with generated content
        """
        messages = []
        if system_prompt:
            messages.append(LLMMessage(role="system", content=system_prompt))
        messages.append(LLMMessage(role="user", content=prompt))
        
        return self.provider.generate(messages, **kwargs)
    
    async def agenerate(self, prompt: str, system_prompt: Optional[str] = None, **kwargs) -> LLMResponse:
        """Async generate a response"""
        messages = []
        if system_prompt:
            messages.append(LLMMessage(role="system", content=system_prompt))
        messages.append(LLMMessage(role="user", content=prompt))
        
        return await self.provider.agenerate(messages, **kwargs)
    
    def chat(self, messages: List[Dict[str, str]], **kwargs) -> LLMResponse:
        """
        Chat with LLM using conversation history
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            **kwargs: Additional parameters
            
        Returns:
            LLMResponse with generated content
        """
        llm_messages = [
            LLMMessage(role=msg["role"], content=msg["content"])
            for msg in messages
        ]
        return self.provider.generate(llm_messages, **kwargs)
    
    async def stream(self, prompt: str, system_prompt: Optional[str] = None, **kwargs) -> AsyncIterator[str]:
        """Stream responses from LLM"""
        messages = []
        if system_prompt:
            messages.append(LLMMessage(role="system", content=system_prompt))
        messages.append(LLMMessage(role="user", content=prompt))
        
        async for chunk in self.provider.stream(messages, **kwargs):
            yield chunk
    
    def switch_provider(self, provider_type: str, config: Optional[Dict[str, Any]] = None):
        """
        Switch to a different LLM provider
        
        Args:
            provider_type: New provider type
            config: Provider configuration
        """
        self.provider_type = provider_type
        self.config = config or self._get_default_config()
        self._provider = None  # Reset provider to force recreation
        logger.info(f"Switched LLM provider to: {provider_type}")


# Global LLM service instance (singleton pattern)
_llm_service: Optional[LLMService] = None


def get_llm_service(provider_type: Optional[str] = None, config: Optional[Dict[str, Any]] = None) -> LLMService:
    """
    Get global LLM service instance
    
    Args:
        provider_type: Optional provider type override
        config: Optional configuration override
        
    Returns:
        LLMService instance
    """
    global _llm_service
    
    if _llm_service is None or provider_type or config:
        _llm_service = LLMService(provider_type=provider_type, config=config)
    
    return _llm_service

