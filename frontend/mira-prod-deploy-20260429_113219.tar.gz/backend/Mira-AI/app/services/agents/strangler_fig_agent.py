"""
Strangler Fig Proxy — config generator (deployment is operator-controlled).

What this is:
    A small generator that emits nginx configuration so the customer can
    place a thin routing proxy in front of both their LEGACY backend and
    the NEW migrated backend. The proxy routes each API call to whichever
    backend currently owns that route, letting the team migrate route by
    route instead of cutting everything over at once.

Solves doc Issue I-05:
    "Without a clear sequencing strategy and rollback checkpoints, partial
    migration states can leave the system in an unrecoverable broken state.
    [...] Frontend always calls the proxy — it never needs to know which
    backend is serving a given route."

What this is NOT:
    A live deployed proxy. We deliberately do not push config to the
    customer's VM and reload nginx — that's a production change that must
    be operator-approved. Instead we generate a ready-to-deploy nginx.conf
    + a runbook, and the customer applies it during their maintenance
    window.

Output:
    {VALIDATION_DIR}/<project>/strangler/
        nginx.conf            ← the routing config
        DEPLOY.md             ← step-by-step deploy + rollback instructions
        routes.json           ← machine-readable route assignment table
"""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


_DEFAULT_OUT_DIR = Path(
    os.environ.get("MIRA_STRANGLER_FIG_DIR", "/app/app/data/contracts")
)


def out_dir_for(project_name: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", project_name or "unknown")
    return _DEFAULT_OUT_DIR / safe / "strangler"


@dataclass
class RouteAssignment:
    path: str
    method: str
    target: str  # "legacy" | "new"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def generate_proxy_config(
    project_name: str,
    contract_registry: Dict[str, Any],
    *,
    legacy_upstream: str = "http://legacy-backend:8080",
    new_upstream: str = "http://new-backend:8080",
    migrated_routes: Optional[List[Dict[str, str]]] = None,
    save: bool = True,
) -> Dict[str, Any]:
    """
    Build an nginx Strangler Fig proxy config from the Contract Registry.

    Args:
        project_name: Used for output path.
        contract_registry: An OpenAPI 3.0 dict (e.g. from Contract Extraction Agent).
        legacy_upstream: URL of the legacy backend (default uses Docker service name).
        new_upstream:    URL of the new migrated backend.
        migrated_routes: Optional list of ``{"path": ..., "method": ...}`` entries
            indicating which routes should be sent to ``new_upstream``. Anything
            not on this list is sent to ``legacy_upstream`` (default safe state:
            everything still on legacy until the operator opts each route in).

    Returns:
        ``{"nginx_conf_path": str, "deploy_md_path": str, "routes_json_path": str,
           "assignments": [...], "totals": {"legacy": int, "new": int}}``
    """
    migrated_set = set(
        (r.get("path", ""), r.get("method", "").upper())
        for r in (migrated_routes or [])
    )

    assignments: List[RouteAssignment] = []
    for path, ops in (contract_registry.get("paths") or {}).items():
        if not isinstance(ops, dict):
            continue
        for method in ops.keys():
            m = method.upper()
            if m not in ("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"):
                continue
            target = "new" if (path, m) in migrated_set else "legacy"
            assignments.append(RouteAssignment(path=path, method=m, target=target))

    nginx_conf = _render_nginx_conf(
        project_name, assignments, legacy_upstream=legacy_upstream, new_upstream=new_upstream
    )
    deploy_md = _render_deploy_md(
        project_name, assignments, legacy_upstream=legacy_upstream, new_upstream=new_upstream
    )

    paths: Dict[str, str] = {}
    if save:
        out_dir = out_dir_for(project_name)
        out_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        nginx_path = out_dir / f"nginx-{ts}.conf"
        nginx_path.write_text(nginx_conf, encoding="utf-8")
        (out_dir / "nginx.conf").write_text(nginx_conf, encoding="utf-8")  # stable name
        deploy_path = out_dir / f"DEPLOY-{ts}.md"
        deploy_path.write_text(deploy_md, encoding="utf-8")
        (out_dir / "DEPLOY.md").write_text(deploy_md, encoding="utf-8")
        routes_path = out_dir / f"routes-{ts}.json"
        routes_path.write_text(
            json.dumps([a.to_dict() for a in assignments], indent=2), encoding="utf-8"
        )
        (out_dir / "routes.json").write_text(
            json.dumps([a.to_dict() for a in assignments], indent=2), encoding="utf-8"
        )
        paths = {
            "nginx_conf_path": str(nginx_path),
            "deploy_md_path": str(deploy_path),
            "routes_json_path": str(routes_path),
        }
        logger.info(
            "Strangler Fig: project=%s legacy=%d new=%d → %s",
            project_name,
            sum(1 for a in assignments if a.target == "legacy"),
            sum(1 for a in assignments if a.target == "new"),
            nginx_path,
        )

    return {
        **paths,
        "assignments": [a.to_dict() for a in assignments],
        "totals": {
            "legacy": sum(1 for a in assignments if a.target == "legacy"),
            "new": sum(1 for a in assignments if a.target == "new"),
            "total": len(assignments),
        },
    }


def _render_nginx_conf(
    project_name: str,
    assignments: List[RouteAssignment],
    *,
    legacy_upstream: str,
    new_upstream: str,
) -> str:
    # Group routes by target so we can use one location block per backend.
    new_routes = [a for a in assignments if a.target == "new"]
    # Build location blocks for the migrated routes. Order matters: more
    # specific paths must come first. nginx matches the longest prefix, so
    # sort descending by path length.
    new_routes.sort(key=lambda a: (-len(a.path), a.path, a.method))

    location_blocks: List[str] = []
    for a in new_routes:
        # nginx doesn't filter by method natively in `location` — we use a
        # `limit_except` trick to send only matching methods to new, falling
        # back to legacy for the rest (safest default).
        location_blocks.append(
            f"""    # {a.method} {a.path} → migrated backend
    location = {a.path} {{
        limit_except {a.method} {{ proxy_pass {legacy_upstream}; }}
        proxy_pass {new_upstream};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}"""
        )

    blocks_str = "\n\n".join(location_blocks) if location_blocks else "    # (no migrated routes yet — everything still on legacy)"

    return f"""# nginx Strangler Fig config — generated by Mira AI
# Project: {project_name}
# Generated: {datetime.utcnow().isoformat()}Z
#
# WHAT THIS DOES
#   - Routes specific (path, method) pairs to the NEW migrated backend.
#   - Routes everything else to the LEGACY backend (default safe state).
#   - Frontend always calls the proxy on a single hostname; it never needs
#     to know which backend is serving a given request.
#
# DEPLOY
#   See DEPLOY.md alongside this file.
#
# ROLLBACK
#   To send a problematic migrated route back to legacy:
#       comment out its `location` block below and run `nginx -s reload`.
#       The path immediately falls through to the legacy `location /` block.

upstream legacy_backend {{
    server {legacy_upstream.replace('http://', '').replace('https://', '')};
}}

upstream new_backend {{
    server {new_upstream.replace('http://', '').replace('https://', '')};
}}

server {{
    listen 80;
    server_name _;

    client_max_body_size 50m;
    proxy_read_timeout 300;
    proxy_connect_timeout 30;

    # ── Migrated routes (new backend) ──────────────────────────────────
{blocks_str}

    # ── Default fallback: legacy backend ───────────────────────────────
    location / {{
        proxy_pass {legacy_upstream};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}
}}
"""


def _render_deploy_md(
    project_name: str,
    assignments: List[RouteAssignment],
    *,
    legacy_upstream: str,
    new_upstream: str,
) -> str:
    n_legacy = sum(1 for a in assignments if a.target == "legacy")
    n_new = sum(1 for a in assignments if a.target == "new")
    return f"""# Strangler Fig Deployment Runbook — {project_name}

_Generated by Mira AI on {datetime.utcnow().isoformat()}Z_

## What this gives you

A thin nginx proxy that sits between your frontend and your backends.
Each `(path, method)` pair is sent to either:

- **legacy backend** — `{legacy_upstream}`  (current production)
- **new backend** — `{new_upstream}`  (migrated code)

Initial split for this generation:
- Legacy backend: **{n_legacy}** routes
- New backend: **{n_new}** routes

The frontend never needs to be aware of this — it talks to the proxy
hostname only.

## Deploy steps

1. SSH to the VM where the proxy will run.
2. Copy `nginx.conf` to `/etc/nginx/conf.d/{project_name}.conf`.
3. Validate the config (this will not reload anything yet):
   ```bash
   sudo nginx -t
   ```
4. If `-t` reports OK, reload nginx with zero downtime:
   ```bash
   sudo nginx -s reload
   ```
5. Smoke-test 1–2 known routes through the proxy hostname before
   pointing the frontend at it.

## Promoting a route from legacy → new

When a route has been migrated and verified end-to-end:

1. Re-run the contract validator and confirm zero breaking changes.
2. Re-generate this proxy config with the new route added to
   `migrated_routes`.
3. `nginx -s reload`.
4. Watch error rates for ~10 minutes before promoting the next route.

## Rolling back a route from new → legacy

If a migrated route is misbehaving in production:

1. Open `/etc/nginx/conf.d/{project_name}.conf`.
2. Comment out the `location` block for that route.
3. `nginx -t && nginx -s reload`.
4. The path immediately falls through to the default `location /` block,
   which forwards to legacy.

This rollback is **instant** and does not require any frontend deploy.
"""


def load_latest_assignments(project_name: str) -> Optional[List[Dict[str, str]]]:
    p = out_dir_for(project_name) / "routes.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("Failed to load Strangler routes %s: %s", p, e)
        return None
