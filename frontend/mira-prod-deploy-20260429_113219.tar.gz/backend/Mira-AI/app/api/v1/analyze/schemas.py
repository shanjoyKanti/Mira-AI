"""Request/response schemas for the analyze endpoints."""
from typing import Optional, List
from pydantic import BaseModel, Field


class SSHCredentialsInput(BaseModel):
    """SSH credentials for remote server"""
    hostname: str = Field(..., description="Server hostname or IP address")
    port: int = Field(22, description="SSH port")
    username: str = Field(..., description="SSH username")
    password: Optional[str] = Field(None, description="SSH password")
    private_key: Optional[str] = Field(None, description="SSH private key content", json_schema_extra={"exclude_from_schema": True})
    private_key_password: Optional[str] = Field(None, description="Private key password if encrypted", json_schema_extra={"exclude_from_schema": True})

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "hostname": "10.240.92.1",
                "port": 2224,
                "username": "usama",
                "password": "your-password"
            }]
        }
    }


class CodeAnalysisRequest(BaseModel):
    """Request for complete code analysis workflow"""
    project_name: str = Field(..., description="Project display name")
    source_path: Optional[str] = Field(
        None,
        description="Override: absolute path on the remote server to scan (e.g. staged migration folder). If omitted, uses the user's saved ssh_source_path.",
    )
    ssh_credentials: Optional[SSHCredentialsInput] = Field(
        None,
        description="When set, this scan uses these SSH credentials to connect to the server (instead of the JWT account's saved SSH profile).",
    )
    report_types: List[str] = Field(
        default=["generic_security"],
        description="Report types to generate: project_analysis (comprehensive codebase analysis), generic_security, owasp_top_10, pci_dss, iso_27001"
    )
    exclusions: Optional[str] = Field(None, description="File exclusion patterns (e.g., **/__pycache__/**,**/tests/**)")
    sonar_host_url: Optional[str] = Field(None, description="SonarQube server URL (default: from settings)")
    sonar_token: Optional[str] = Field(None, description="SonarQube token (default: from settings)")
    auto_install: bool = Field(True, description="Automatically install Docker or SonarScanner CLI if not available")
    prefer_docker: bool = Field(True, description="Prefer Docker over SonarScanner CLI")

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "project_name": "PHP Task Manager",
                "report_types": ["generic_security", "owasp_top_10"]
            }]
        }
    }


class ProjectCreateRequest(BaseModel):
    """Request for creating a new project"""
    project_name: str = Field(..., description="Project display name (required)")
    organization_name: Optional[str] = Field(None, description="Organization name")
    project_description: Optional[str] = Field(None, description="Project description")
    source_path: Optional[str] = Field(None, description="Path to source code on remote server (when code exists on server)")
    project_type: Optional[str] = Field("web", description="Project type (web, mobile, desktop, api, etc.)")
    legacy_technology: Optional[List[str]] = Field(default_factory=list, description="Legacy technologies used (e.g. COBOL, Java EE, Classic ASP)")
    frameworks: Optional[List[str]] = Field(default_factory=list, description="Frameworks used")
    # Industry
    industry: Optional[str] = Field(None, description="Industry: healthcare, finance, ecommerce, technology, education, government, manufacturing, other")
    # Traffic Information
    deployment_regions: Optional[List[str]] = Field(default_factory=list, description="Deployment regions: north_america, south_america, europe, middle_east, south_asia, east_asia, africa, oceania, other")
    monthly_traffic: Optional[str] = Field(None, description="Monthly traffic: low, medium, high, enterprise")
    peak_concurrent_users: Optional[int] = Field(None, description="Estimated peak concurrent users")
    # Conversion Environment
    conversion_environment: Optional[str] = Field("on_premises_server", description="Conversion environment: miraai_hosted_vm or on_premises_server")
    # Code Source Configuration
    code_source_type: Optional[str] = Field("exists_on_server", description="Code source type: exists_on_server or needs_upload")
    git_repo_url: Optional[str] = Field(None, description="Git repository URL (required when code_source_type is needs_upload)")
    git_access_token: Optional[str] = Field(None, description="Git access token for private repositories")
    additional_files: Optional[List[str]] = Field(default_factory=list, description="Additional config file names uploaded (.env, config files, etc.) — only when code_source_type is needs_upload")
    # LLM Option
    llm_option: Optional[str] = Field("miraai_hosted", description="LLM option: on_premises, miraai_hosted, or commercial")


class ProjectUpdateRequest(BaseModel):
    """Request for updating an existing project (all fields optional for partial update)"""
    project_name: Optional[str] = Field(None, description="Project display name")
    organization_name: Optional[str] = Field(None, description="Organization name")
    project_description: Optional[str] = Field(None, description="Project description")
    source_path: Optional[str] = Field(None, description="Path to source code on remote server")
    project_type: Optional[str] = Field(None, description="Project type (web, mobile, desktop, api, etc.)")
    legacy_technology: Optional[List[str]] = Field(None, description="Legacy technologies used")
    frameworks: Optional[List[str]] = Field(None, description="Frameworks used")
    industry: Optional[str] = Field(None, description="Industry: healthcare, finance, ecommerce, technology, education, government, manufacturing, other")
    deployment_regions: Optional[List[str]] = Field(None, description="Deployment regions")
    monthly_traffic: Optional[str] = Field(None, description="Monthly traffic: low, medium, high, enterprise")
    peak_concurrent_users: Optional[int] = Field(None, description="Estimated peak concurrent users")
    conversion_environment: Optional[str] = Field(None, description="Conversion environment: miraai_hosted_vm or on_premises_server")
    code_source_type: Optional[str] = Field(None, description="Code source type: exists_on_server or needs_upload")
    git_repo_url: Optional[str] = Field(None, description="Git repository URL")
    git_access_token: Optional[str] = Field(None, description="Git access token for private repositories")
    additional_files: Optional[List[str]] = Field(None, description="Additional config file names")
    llm_option: Optional[str] = Field(None, description="LLM option: on_premises, miraai_hosted, or commercial")


class SSHTestRequest(BaseModel):
    """
    Test an SSH connection and save credentials to your account.

    On success, the API stores the SSH hostname, username, password/key, and source_path
    against your user profile. All pipeline steps (1–4) then use these saved credentials
    automatically — you only need to provide `project_name` in subsequent calls.
    """
    ssh_credentials: SSHCredentialsInput = Field(..., description="SSH credentials for connecting to the remote server")
    source_path: str = Field(
        ...,
        description=(
            "Absolute path to the project **parent** directory on the remote server "
            "(e.g. `/home/ubuntu/projects`). This is saved as `ssh_source_path` and used "
            "as the base for all subsequent pipeline calls."
        ),
        examples=["/home/ubuntu/projects"],
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "ssh_credentials": {"hostname": "10.240.92.4", "port": 22, "username": "ubuntu", "password": "yourpass"},
                "source_path": "/home/ubuntu/projects"
            }]
        }
    }


class ProjectAnalysisRequest(BaseModel):
    """Request for standalone project analysis (no SonarQube, no report_types)"""
    project_name: str = Field(..., description="Project display name")

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "project_name": "My E-Commerce App"
            }]
        }
    }
