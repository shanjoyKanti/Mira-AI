"""Agent API routes"""
from app.api.v1.agents.routes import router

__all__ = ["router"]

