"""File management utilities"""
import os
import shutil
from pathlib import Path
from typing import List, Optional
from fastapi import UploadFile
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


def ensure_upload_dir():
    """Ensure upload directory exists"""
    upload_path = Path(settings.UPLOAD_DIR)
    upload_path.mkdir(parents=True, exist_ok=True)
    return upload_path


async def save_upload_file(upload_file: UploadFile, destination: Path) -> Path:
    """
    Save uploaded file to destination
    
    Args:
        upload_file: FastAPI UploadFile object
        destination: Destination path
        
    Returns:
        Path to saved file
    """
    try:
        with destination.open("wb") as buffer:
            shutil.copyfileobj(upload_file.file, buffer)
        logger.info(f"File saved: {destination}")
        return destination
    except Exception as e:
        logger.error(f"Failed to save file {destination}: {str(e)}")
        raise
    finally:
        upload_file.file.close()


def get_file_extension(filename: str) -> str:
    """Get file extension"""
    return Path(filename).suffix.lower()


def is_allowed_file(filename: str, allowed_extensions: set) -> bool:
    """Check if file extension is allowed"""
    return get_file_extension(filename) in allowed_extensions


def get_file_size(file_path: Path) -> int:
    """Get file size in bytes"""
    return file_path.stat().st_size


def delete_file(file_path: Path) -> bool:
    """Delete a file"""
    try:
        if file_path.exists():
            file_path.unlink()
            logger.info(f"File deleted: {file_path}")
            return True
        return False
    except Exception as e:
        logger.error(f"Failed to delete file {file_path}: {str(e)}")
        return False


def list_files(directory: Path, pattern: str = "*") -> List[Path]:
    """List files in directory matching pattern"""
    return list(directory.glob(pattern))


def create_project_directory(project_id: int) -> Path:
    """Create directory for project files"""
    project_dir = Path(settings.UPLOAD_DIR) / f"project_{project_id}"
    project_dir.mkdir(parents=True, exist_ok=True)
    return project_dir


def cleanup_project_files(project_id: int) -> bool:
    """Delete all files for a project"""
    project_dir = Path(settings.UPLOAD_DIR) / f"project_{project_id}"
    try:
        if project_dir.exists():
            shutil.rmtree(project_dir)
            logger.info(f"Project directory cleaned: {project_dir}")
            return True
        return False
    except Exception as e:
        logger.error(f"Failed to cleanup project {project_id}: {str(e)}")
        return False
