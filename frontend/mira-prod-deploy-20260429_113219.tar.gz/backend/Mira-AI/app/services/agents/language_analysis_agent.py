"""
Framework & Language Analyzer for MIRA-AI (Groq/Qwen)

Input: project folder path + project name
Output: detected programming languages and frameworks used in the project
"""

import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from app.services.agents.base_agent import BaseAgent, AgentState, GroqClient
from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Version-ladder maps for RAG-based verification
# ---------------------------------------------------------------------------
_PHP_LADDER = [
    "4.0","4.1","4.2","4.3","4.4",
    "5.0","5.1","5.2","5.3","5.4","5.5","5.6",
    "7.0","7.1","7.2","7.3","7.4",
    "8.0","8.1","8.2","8.3","8.4","8.5",
]
_LARAVEL_LADDER = ["4.2","5.0","5.1","5.2","5.3","5.4","5.5","5.6","5.7","5.8","6","7","8","9","10","11","12","13"]
_SYMFONY_LADDER = ["4.4","5.0","5.4","6.0","6.4","7.0","7.2","7.4","8.0"]
_PYTHON_LADDER = ["3.5","3.6","3.7","3.8","3.9","3.10","3.11","3.12","3.13","3.14"]
_DJANGO_LADDER = ["3.0","3.1","3.2","4.0","4.1","4.2","5.0","5.1","5.2","6.0"]
_NODE_LADDER = ["12","14","16","18","20","21","22"]
_REACT_LADDER = ["15","16","17","18","19"]
_ANGULAR_LADDER = ["12","13","14","15","16","17","18","19","20","21"]
_VUE_LADDER = ["2","3","3.1","3.2","3.3","3.4"]
_NEXTJS_LADDER = ["11","12","13","14","15"]
_NESTJS_LADDER = ["8","9","10","11"]
_TYPESCRIPT_LADDER = [
    "3.8","3.9",
    "4.0","4.1","4.2","4.3","4.4","4.5","4.6","4.7","4.8","4.9",
    "5.0","5.1","5.2","5.3","5.4","5.5","5.6","5.7",
]
_JAVA_LADDER = ["11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26"]
_SPRINGBOOT_LADDER = ["2.5","2.6","2.7","3.0","3.1","3.2","3.3","3.4","3.5","4.0"]
_DOTNET_LADDER = ["4.7.2","4.8","5.0","6.0","7.0","8.0","9.0","10.0"]
_CSHARP_LADDER = ["9.0","10.0","11.0","12.0","13.0","14.0"]
_GO_LADDER = ["1.17","1.18","1.19","1.20","1.21","1.22","1.23","1.24","1.25","1.26"]
_KOTLIN_LADDER = ["1.5","1.6","1.7","1.8","1.9","2.0","2.1"]
_RUST_LADDER = [
    "1.50","1.55","1.60","1.65","1.70","1.71","1.72","1.73","1.74",
    "1.75","1.76","1.77","1.78","1.79","1.80","1.81","1.82","1.83",
    "1.84","1.85","1.86","1.87","1.88",
]
_SCALA_LADDER = ["2.11","2.12","2.13","3.0","3.1","3.2","3.3","3.4"]
_SWIFT_LADDER = ["5.0","5.1","5.2","5.3","5.4","5.5","5.6","5.7","5.8","5.9","6.0"]
_DART_LADDER = ["2.0","2.5","2.10","2.15","2.17","2.18","2.19","3.0","3.1","3.2","3.3","3.4"]
_ELIXIR_LADDER = ["1.10","1.11","1.12","1.13","1.14","1.15","1.16"]
_HASKELL_LADDER = ["8.8","8.10","9.0","9.2","9.4","9.6","9.8","9.10"]
_R_LADDER = ["3.6","4.0","4.1","4.2","4.3","4.4"]
_JULIA_LADDER = ["1.0","1.1","1.2","1.3","1.4","1.5","1.6","1.7","1.8","1.9","1.10"]

_LADDER_MAP: Dict[str, List[str]] = {
    # PHP
    "php": _PHP_LADDER,
    "laravel": _LARAVEL_LADDER,
    "symfony": _SYMFONY_LADDER,
    # Python
    "python": _PYTHON_LADDER,
    "django": _DJANGO_LADDER,
    # JavaScript / Node
    "node": _NODE_LADDER,
    "nodejs": _NODE_LADDER,
    "javascript": _NODE_LADDER,
    "react": _REACT_LADDER,
    "angular": _ANGULAR_LADDER,
    "vue": _VUE_LADDER,
    "nextjs": _NEXTJS_LADDER,
    "next.js": _NEXTJS_LADDER,
    "nestjs": _NESTJS_LADDER,
    # TypeScript
    "typescript": _TYPESCRIPT_LADDER,
    # Java
    "java": _JAVA_LADDER,
    "springboot": _SPRINGBOOT_LADDER,
    "spring boot": _SPRINGBOOT_LADDER,
    # .NET / C#
    "dotnet": _DOTNET_LADDER,
    ".net": _DOTNET_LADDER,
    "csharp": _CSHARP_LADDER,
    "c#": _CSHARP_LADDER,
    # Go
    "go": _GO_LADDER,
    "golang": _GO_LADDER,
    # Kotlin
    "kotlin": _KOTLIN_LADDER,
    # Rust
    "rust": _RUST_LADDER,
    # Scala
    "scala": _SCALA_LADDER,
    # Swift
    "swift": _SWIFT_LADDER,
    # Dart / Flutter
    "dart": _DART_LADDER,
    "flutter": _DART_LADDER,
    # Elixir
    "elixir": _ELIXIR_LADDER,
    # Haskell
    "haskell": _HASKELL_LADDER,
    # R
    "r": _R_LADDER,
    # Julia
    "julia": _JULIA_LADDER,
}

# Patterns for "deprecated / removed" sections in migration docs.
# We scan the RAG content for these sections to extract function/API names.
_DEPRECATED_SECTION_RE = re.compile(
    r"(?:deprecated|removed|backward.incompatible|breaking|no longer|dropped)\b",
    re.IGNORECASE,
)

# PHP function names that are strong signals of a version ceiling
_PHP_REMOVED_FUNCTIONS: Dict[str, List[str]] = {
    "7.0": ["mysql_query","mysql_connect","mysql_fetch","ereg","eregi","split","call_user_method","set_socket_blocking"],
    "7.2": ["create_function","each","__autoload","png2wbmp","jpeg2wbmp"],
    "8.0": ["create_function","each","__autoload"],
    "8.1": ["mhash","mhash_count","mhash_get_hash_name","mhash_keygen_s2k"],
}


def _strip_php_line_comments(code_text: str) -> str:
    """Remove // single-line comments so feature regexes don't fire on comment text."""
    return re.sub(r'//[^\n]*', '', code_text)


def _php_version_from_composer_json(project_root: "Path") -> Optional[str]:
    """
    Read composer.json and return the PHP version declared in require.php.

    The constraint format is normalised to major.minor:
      ^7.0   → "7.0"
      ~7.2.5 → "7.2"
      >=8.0  → "8.0"
      7.4.*  → "7.4"

    Returns None if composer.json is absent or has no php constraint.
    This is the most reliable source — it reflects what the developer
    deliberately declared, not what code patterns imply.
    """
    composer = project_root / "composer.json"
    if not composer.exists():
        return None
    try:
        import json as _json
        data = _json.loads(composer.read_text(encoding="utf-8", errors="ignore"))
        constraint = (data.get("require") or {}).get("php") or ""
        if not constraint:
            return None
        # Strip operators: ^, ~, >=, >, =, spaces, v prefix
        cleaned = re.sub(r"[^0-9.]", "", constraint.split("||")[0].split(",")[0].strip())
        parts = cleaned.split(".")
        if not parts or not parts[0].isdigit():
            return None
        major = parts[0]
        minor = parts[1] if len(parts) > 1 and parts[1].isdigit() else "0"
        version = f"{major}.{minor}"
        ladder = _LADDER_MAP.get("php", [])
        return version if version in ladder else None
    except Exception:
        return None


def _php_version_from_code_patterns(code_text: str) -> Optional[str]:
    """
    Scan raw PHP code text for removed/deprecated function calls.
    Returns the MAXIMUM version the code is still compatible with —
    i.e. the last PHP version before those functions were removed.

    This is a CEILING only; it is NOT the current version of the code.
    Returns None if no hard-blocking patterns are found.
    """
    code_text = _strip_php_line_comments(code_text)
    lower = code_text.lower()

    # PHP 4.x-only constructs (removed or fundamentally changed in PHP 5)
    # old-style constructors (class Foo { function Foo() {} }) are a 4.x ceiling signal
    # but too common in 5.x as well — skip. Use PHP 4-only functions instead.
    if re.search(r'\b(?:call_user_method|call_user_method_array)\s*\(', lower):
        return "4.4"  # removed in PHP 5.0
    if re.search(r'\b(?:define_syslog_variables|magic_quotes_runtime|set_magic_quotes_runtime)\s*\(', lower):
        return "5.3"  # removed in 5.4
    if re.search(r'\b(?:session_register|session_unregister|session_is_registered)\s*\(', lower):
        return "5.3"  # removed in 5.4
    if re.search(r'\b(?:import_request_variables)\s*\(', lower):
        return "5.3"  # removed in 5.4

    # PHP 5.2-era functions removed in 5.3
    if re.search(r'\b(?:ereg|eregi|ereg_replace|eregi_replace|split|spliti|sql_regcase)\s*\(', lower):
        return "5.2"  # removed in 5.3 (POSIX regex)

    # mysql_* removed in PHP 7.0 — code is max PHP 5.6
    if re.search(r'\bmysql_(?:query|connect|fetch_array|fetch_assoc|fetch_row|select_db|num_rows|result|error|escape_string|real_escape_string|insert_id|affected_rows|close)\s*\(', lower):
        return "5.6"

    # create_function / each / __autoload removed in PHP 8.0 — code is max PHP 7.4
    if re.search(r'\bcreate_function\s*\(', lower):
        return "7.4"
    if re.search(r'\beach\s*\(', lower):
        return "7.4"
    if re.search(r'\bfunction\s+__autoload\s*\(', lower):
        return "7.4"

    return None


def _php_min_version_from_features(code_text: str) -> Optional[str]:
    """
    Scan raw PHP code for MODERN features to establish the MINIMUM version required.
    Returns the lowest PHP version needed to run this code.
    """
    code_text = _strip_php_line_comments(code_text)
    # PHP 8.1+ enum keyword
    if re.search(r'\benum\s+\w+', code_text):
        return "8.1"
    # PHP 8.0+ match expression / union types / constructor promotion / named args
    if re.search(r'\bmatch\s*\(', code_text) or re.search(r'function\s+\w+\s*\([^)]*\w+\|\w+', code_text):
        return "8.0"
    # PHP 7.4+ arrow functions / typed properties (type token required before $var — not plain `private $x`)
    if re.search(r'\bfn\s*\(', code_text) or re.search(r'(private|public|protected)\s+(?:static\s+)?(?:\??\w+)\s+\$\w+\s*[;=]', code_text):
        return "7.4"
    # PHP 7.0+ null coalescing / return types
    if re.search(r'\?\?', code_text) or re.search(r'\)\s*:\s*(?:int|string|float|bool|array|void|self|static)\b', code_text):
        return "7.0"
    return None


FRAMEWORK_LANGUAGE_SYSTEM_PROMPT = """You are a precise project analyzer. Your output drives automated code modernization, so accuracy is critical.

TASK: Identify every programming language (with version) and every framework used in the project. Use only evidence from the provided file inventory and file contents. Do not assume or guess.

OUTPUT: Return ONLY valid JSON. No markdown fences, no commentary, no extra keys. Schema:
{
  "languages": ["php", "javascript"],
  "frameworks": ["Laravel", "React"],
  "language_versions": {
     "php": "7.2",
     "laravel": "6",
     "to_laravel": "8",
     "python": "3.11",
     "node": "20",
     "java": "17",
     "go": "1.22",
     "typescript": "5.4",
     "ruby": "3.3",
     "rust": "1.78"
  }
}
Include ONLY the keys that are actually present/detected. Omit keys with unknown or absent versions.
The "to_laravel" key is only included when the project uses Laravel AND TARGET_PHP_FOR_UPGRADE is provided.

- `language_versions["laravel"]` = **current** Laravel **major** the application is written for (from composer.lock / laravel/framework constraint). This is **from_laravel** — the framework version already on the project.
- `language_versions["to_laravel"]` = Laravel **major** whose packaged upgrade guide applies to the **TARGET_PHP_FOR_UPGRADE** in the user message. It is **not** the app’s current Laravel. If TARGET_PHP_FOR_UPGRADE is omitted, omit `to_laravel` unless the user message defines a target PHP.
- Use major only as a string: "5", "6", "8", "12", etc. (for 5.x lines use the minor series if needed: the pipeline normalizes majors 6–12 for guide selection; still output the best-matching major for 5.x apps, e.g. "5" with context from composer.)

OFFICIAL LARAVEL RELEASE LINE → MINIMUM PHP (use this table to set `to_laravel` from TARGET_PHP_FOR_UPGRADE: pick the **highest** Laravel line below whose minimum PHP is **≤** TARGET_PHP_FOR_UPGRADE when comparing major.minor versions):

- Laravel **5.3** requires **PHP 5.6.4** or higher on **5.6.x**
- Laravel **5.5** requires **PHP 7.0.0** or higher
- Laravel **5.6** requires **PHP 7.1.3** or higher
- Laravel **6.x** requires **PHP 7.2**
- Laravel **7.x** requires **PHP 7.2.5** or higher
- Laravel **8.x** requires **PHP 7.3.0** and **7.4.x** (i.e. minimum PHP **7.3**; runs on 7.3–7.4 series)
- Laravel **9.x** requires **PHP 8.0** / **8.0.x**
- Laravel **10.x** requires **PHP 8.1.0** or greater
- Laravel **11.x** requires **PHP 8.2.0** or greater
- Laravel **12.x** requires **PHP 8.3**, **PHP 8.4**, and **PHP 8.5** (i.e. minimum PHP **8.3** for that line; compatible with 8.3+)

Examples (compare TARGET_PHP_FOR_UPGRADE as major.minor, e.g. 7.3, 8.1, 8.3):
- TARGET **7.2** → Laravel **6** (Laravel 7.x requires PHP **7.2.5+**, stricter than plain 7.2)
- TARGET **7.3** → Laravel **8**
- TARGET **8.0** → Laravel **9**
- TARGET **8.1** → Laravel **10**
- TARGET **8.2** → Laravel **11**
- TARGET **8.3**, **8.4**, or **8.5** → Laravel **12**

- Be exhaustive: include every language and framework indicated by the file inventory and content samples.

LARAVEL DETECTION (use strong evidence from file contents; do not rely on file names alone):

1) PRIMARY EVIDENCE (use these to both detect Laravel and determine **current** laravel major):
   - composer.json: In "require" or "require-dev", look for "laravel/framework" with a version constraint (e.g. "^8.0", "~9.0", "^10.0", "^11.0"). The constraint indicates the Laravel major version: ^8.0 or 8.* or ~8 → 8; ^9.0 → 9; ^10.0 → 10; ^11.0 → 11. Set `language_versions["laravel"]` to that major (e.g. "8", "9", "10", "11"). Do not put package versions from `laravel/ui`, `laravel/tinker`, etc. into `laravel`.
   - composer.lock: In "packages" or "packages-dev", find the object with "name": "laravel/framework". Its "version" field (e.g. "v8.83.0", "v10.0.0") is the resolved Laravel version. Use the major part as language_versions["laravel"] (e.g. "8", "10"). If laravel/framework is not in the lock, look for "illuminate/support" or "illuminate/contracts" — their resolved version aligns with Laravel (e.g. v8.x → Laravel 8).

2) CONFIRMING EVIDENCE (Laravel is present when combined with primary evidence):
   - illuminate/* packages in composer.json or composer.lock (illuminate/support, illuminate/contracts, illuminate/http, illuminate/routing, etc.) — these are Laravel's core; their version constraints or resolved versions indicate Laravel version.
   - bootstrap/app.php or bootstrap/app.php content: Laravel 11+ uses Application::configure(); older versions use $app = new Illuminate\\Application. Use this to cross-check major version.
   - config/app.php: "name" => "Laravel", or "providers" containing Laravel service providers, or "env" => "production" — confirms Laravel app.
   - artisan file at project root: contains Laravel console bootstrap; confirms Laravel.
   - app/Http/Kernel.php, app/Console/Kernel.php, app/Providers/*: Laravel-specific structure; confirms framework.

3) VERSION INFERENCE RULES (no hardcoding):
   - Prefer composer.lock resolved version for "laravel/framework" or "illuminate/support" over composer.json constraint (lock is exact).
   - From composer.json constraint only: ^X.Y or ~X.Y or X.* → major version X. Use the number you see (8, 9, 10, 11).
   - If you have both lock and json, lock takes precedence for version.
   - If you find only illuminate/* (e.g. illuminate/support ^8.0) and no laravel/framework, treat as Laravel and infer version from illuminate constraint or lock.
   - Do not assume a version from directory structure (e.g. app/Http) alone; you must have at least composer.json with laravel/framework or illuminate/*, or composer.lock with those packages, or unambiguous Laravel bootstrap/config content stating version or package.

4) WHEN TO REPORT LARAVEL:
   - Report "Laravel" in frameworks and set language_versions["laravel"] only when you have primary evidence (composer.json or composer.lock or clear bootstrap/config content showing Laravel/Illuminate). Do not report Laravel solely because paths like app/Http or routes/ exist.
   - If Laravel is not present (no laravel/framework, no illuminate/*, no Laravel bootstrap), omit "laravel" from language_versions and do not include "Laravel" in frameworks.

CRITICAL - Language Version Detection Rules:

FOR PHP - Determine the ACTUAL version the code was WRITTEN FOR (not the highest it could theoretically run on).
The system supports migration from PHP 4.0 through 8.5. Do NOT default to 7.4 or 8.x for old code.

**RULE 0 — HIGHEST PRIORITY: composer.json "require": {"php": "^X.Y"}**
If composer.json is provided and contains a `require.php` constraint, that IS the PHP version. Use it exactly.
- "^4.0" → "4.0"  "^5.0" → "5.0"  "^7.0" → "7.0"  ">=7.4" → "7.4"  "^8.1" → "8.1"
NEVER override composer.json with code pattern analysis.

**RULE 1 — Removed/deprecated functions set the CEILING (max), NOT the actual version.**
Example: `create_function()` existed in PHP 4, 5.x, 7.0, 7.1, 7.2, 7.3, 7.4 — all of them.
Its presence only tells you the code CANNOT be PHP 8.0+. It does NOT mean the code IS PHP 7.4.
If the only evidence is deprecated functions and no modern features, report the LOWEST plausible version.

STEP 1 — composer.json (highest priority, use if present):
- `"require": {"php": "^X.Y"}` → PHP "X.Y" — always use this, never override with code patterns.

STEP 2 — Look for version-BLOCKING patterns (these set a MAX ceiling only):
- call_user_method(), call_user_method_array()                → MAX PHP 4.4 (removed in PHP 5)
- define_syslog_variables(), magic_quotes_runtime()           → MAX PHP 5.3 (removed in 5.4)
- session_register(), session_unregister(), import_request_variables() → MAX PHP 5.3 (removed in 5.4)
- ereg(), eregi(), split(), spliti(), sql_regcase()           → MAX PHP 5.2 (removed in 5.3 — POSIX regex)
- mysql_query(), mysql_connect(), mysql_fetch_array(), etc.   → MAX PHP 5.6 (removed in 7.0)
- create_function(), each(), __autoload()                     → MAX PHP 7.4 (removed in 8.0)

STEP 3 — Look for version-FLOOR patterns (features that require a MINIMUM version):
PHP 4.x (no type hints, no exceptions in 4.0, no interfaces in 4.0):
- Object model with `extends` but no interfaces = PHP 4.x possible
- `new ClassName` syntax without type hints, no abstract classes = PHP 4.0–4.4
- Interfaces (`interface Foo {}`) introduced in PHP 5.0
- Abstract classes (`abstract class`) introduced in PHP 5.0
- try/catch exceptions introduced in PHP 5.0
- Access modifiers (public/protected/private) introduced in PHP 5.0

PHP 5.0+ FEATURES (require minimum 5.0):
- Interfaces, abstract classes, access modifiers, exceptions, PDO, SimpleXML

PHP 5.3+ FEATURES (require minimum 5.3):
- Namespaces (`namespace Foo\Bar;`) = Requires 5.3+
- Anonymous functions / closures (`function() {}`) = Requires 5.3+
- Late static binding (`static::`) = Requires 5.3+
- `const` in class scope = Requires 5.3+
- Heredoc/Nowdoc in class const = Requires 5.3+

PHP 5.4+ FEATURES (require minimum 5.4):
- Traits (`trait Foo {}`) = Requires 5.4+
- Short array syntax `[]` = Requires 5.4+
- `$this` in closures = Requires 5.4+

PHP 5.5+ FEATURES (require minimum 5.5):
- Generators (`yield`) = Requires 5.5+
- `finally` block = Requires 5.5+
- `::class` constant = Requires 5.5+
- `list()` in foreach = Requires 5.5+

PHP 5.6+ FEATURES (require minimum 5.6):
- Variadic functions `...args` = Requires 5.6+
- Argument unpacking `func(...$args)` = Requires 5.6+
- `use const` / `use function` in imports = Requires 5.6+
- `**` exponentiation operator = Requires 5.6+

PHP 7.0+ FEATURES (require minimum 7.0):
- Null coalescing `??` = Requires 7.0+
- Spaceship `<=>` = Requires 7.0+
- Return type declarations `function foo(): int` = Requires 7.0+
- Scalar type hints `function foo(int $x)` = Requires 7.0+
- Anonymous classes `new class {}` = Requires 7.0+

PHP 7.1+ FEATURES:
- Nullable types `?int` = Requires 7.1+
- `void` return type = Requires 7.1+
- Multi-catch `catch (A|B $e)` = Requires 7.1+

PHP 7.4+ FEATURES:
- Arrow functions `fn() =>` = Requires 7.4+
- Typed class properties `private int $x` = Requires 7.4+
- Null coalescing assignment `??=` = Requires 7.4+

PHP 8.0+ FEATURES:
- `match` expressions = Requires 8.0+
- Union types `string|int` = Requires 8.0+
- Named arguments = Requires 8.0+
- Constructor property promotion = Requires 8.0+
- Nullsafe operator `?->` = Requires 8.0+
- Attributes `#[Attribute]` = Requires 8.0+

PHP 8.1+ FEATURES:
- `enum` keyword = Requires 8.1+
- `readonly` properties = Requires 8.1+
- Intersection types `A&B` = Requires 8.1+

PHP 8.2+ FEATURES:
- `readonly` classes = Requires 8.2+
- `true`/`false`/`null` standalone types = Requires 8.2+

PHP 8.3+ FEATURES:
- Typed class constants `const string NAME` = Requires 8.3+
- `#[Override]` attribute = Requires 8.3+

PHP 8.4+ FEATURES:
- Property hooks = Requires 8.4+
- Asymmetric visibility `public private(set)` = Requires 8.4+

PHP 8.5+:
- New API/syntax in 8.5 release notes = Requires 8.5+

STEP 4 — DETERMINE ACTUAL VERSION (combine all evidence):
1. composer.json `require.php` → authoritative, always use (RULE 0)
2. If no composer.json: find the HIGHEST floor feature present in the code
3. Cross-check that the floor version does not exceed the ceiling from STEP 2
4. Decision matrix (when no composer.json — use the LOWEST version consistent with floor features):
   - No OOP / only procedural / `call_user_method` present    → PHP 4.0–4.4
   - OOP with interfaces/exceptions but no namespaces          → PHP 5.0–5.2
   - Namespaces but no traits or short array                   → PHP 5.3
   - Traits or short array `[]` present                        → PHP 5.4–5.6
   - `??` or scalar type hints but no arrow functions          → PHP 7.0–7.3
   - Arrow functions `fn()` but no `match`/union types         → PHP 7.4
   - `match` / union types / named args                        → PHP 8.0+
   - `enum` / `readonly`                                       → PHP 8.1+
   - `readonly` class                                          → PHP 8.2+
   - Typed class constants                                     → PHP 8.3+
   - Property hooks / asymmetric visibility                    → PHP 8.4+
5. When uncertain between two adjacent versions, pick the LOWER one.
   DO NOT assume modern versions for old code just because deprecated functions are present.

FOR PYTHON:
- Check pyproject.toml `[tool.poetry.dependencies] python = "^3.11"` or `[project] requires-python = ">=3.11"` → version "3.11"
- Check runtime.txt (Heroku): `python-3.10.12` → "3.10"
- Check setup.py `python_requires=">=3.9"` → "3.9"
- Check Pipfile `[requires] python_version = "3.12"` → "3.12"
- Check Dockerfile `FROM python:3.11-slim` → "3.11"
- Check .tool-versions `python 3.12.0` → "3.12"
- If no manifest: look at f-strings (3.6+), walrus operator := (3.8+), match statement (3.10+), type hints with | (3.10+), tomllib (3.11+)
- Default if no evidence: "3.9"

FOR NODE.JS / JAVASCRIPT:
- Check package.json `"engines": {"node": ">=18.0.0"}` → version "18"
- Check .nvmrc or .node-version file content (e.g. "20.11.0") → "20"
- Check Dockerfile `FROM node:20-alpine` → "20"
- Check .tool-versions `nodejs 20.0.0` → "20"
- For framework version: check package.json `"dependencies": {"react": "^18.0.0"}` → react "18"
- Default if no evidence: "18"

FOR TYPESCRIPT:
- Check package.json `"devDependencies": {"typescript": "^5.4.0"}` → "5.4"
- Check tsconfig.json `"target": "ES2022"` (informational, not version)
- Default: "5"

FOR JAVA:
- Check pom.xml `<java.version>17</java.version>` or `<maven.compiler.source>17</maven.compiler.source>` → "17"
- Check build.gradle `sourceCompatibility = JavaVersion.VERSION_17` or `java { toolchain { languageVersion = JavaLanguageVersion.of(21) } }` → "21"
- Check .java-version file
- Check Dockerfile `FROM eclipse-temurin:21-jre` → "21"
- Default: "17"

FOR GO:
- Check go.mod `go 1.22` → "1.22"
- Check .tool-versions `golang 1.21.0` → "1.21"
- Default: "1.21"

FOR RUST:
- Check rust-toolchain.toml or rust-toolchain file
- Default: "1.78"

FOR RUBY:
- Check Gemfile `ruby '3.3.0'` → "3.3"
- Check .ruby-version file
- Default: "3.3"

For all other languages:
- Prefer manifest files, lockfiles, and Dockerfiles for version. Then code syntax.
- If version cannot be determined from evidence, use "unknown".

STRICT OUTPUT RULES:
- JSON only. Keys: "languages" (array of strings), "frameworks" (array of strings), "language_versions" (object: language or framework name → version string).
- PHP: Report the MINIMUM version required by the project (composer "php" constraint or highest feature used). Use one of: 4.0, 4.1, 4.2, 4.3, 4.4, 5.0, 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 7.0, 7.1, 7.2, 7.3, 7.4, 8.0, 8.1, 8.2, 8.3, 8.4, 8.5. Do not invent; cite evidence (e.g. "composer.json require.php ^8.0" → "8.0"). For very old code with no namespaces/OOP features, report 4.x or 5.x — do NOT default to 7.4.
- Laravel: Only include when you have primary evidence (composer laravel/framework or illuminate/*, or lock file). `language_versions["laravel"]` = current major only (e.g. "8", "10").
- `to_laravel` (when TARGET_PHP_FOR_UPGRADE is in the user message): set using **OFFICIAL LARAVEL RELEASE LINE → MINIMUM PHP** above — largest Laravel major whose minimum PHP requirement is **≤** TARGET_PHP_FOR_UPGRADE. Do not use the app’s current `laravel` value for this.
- Be exhaustive: if the project uses multiple languages or frameworks, list every one indicated by the files. Omit nothing that is clearly present.

FINAL CHECK (before returning):
- Did I cite composer.json or composer.lock or code content for every version I reported?
- Did I avoid reporting Laravel based only on folder names?
- Is my output valid JSON with no trailing commas or comments?
"""


@dataclass
class FrameworkLanguageResult:
    languages: List[str]
    frameworks: List[str]
    language_versions: Dict[str, str]
    
    def to_dict(self) -> dict:
        """Convert result to dictionary"""
        return {
            "languages": self.languages,
            "frameworks": self.frameworks,
            "language_versions": self.language_versions
        }


class FrameworkLanguageAnalyzer(BaseAgent):
    """Analyzes project frameworks and languages using Groq (Qwen)."""

    def __init__(
        self,
        groq_client: Optional[GroqClient] = None,
        target_php_for_upgrade: Optional[str] = None,
    ):
        """Initialize framework/language analyzer."""
        super().__init__(
            name="framework_language_analyzer",
            description="Analyzes programming languages and frameworks in projects",
            groq_client=groq_client
        )
        self.target_php_for_upgrade = (target_php_for_upgrade or "").strip() or None
        # Minimal ignore list (avoid obvious noise / huge environments).
        # We still want to consider "all" languages/frameworks in the project itself.
        self.ignore_patterns = [".git", "__pycache__", "venv", ".venv"]
    
    def execute(self, state: AgentState) -> AgentState:
        """
        Execute framework and language analysis
        
        Args:
            state: Agent state containing project_path and project_name
            
        Returns:
            Updated agent state with analysis results
        """
        try:
            project_path = state.project_path
            project_name = state.project_name
            
            if not project_path:
                state.add_error("project_path is required")
                return state
                
            if not project_name:
                project_name = Path(project_path).name
                state.project_name = project_name
            
            folder_path = Path(project_path)
            if not folder_path.exists():
                state.add_error(f"Project path does not exist: {project_path}")
                return state
                
            logger.info(f"Analyzing frameworks and languages: {project_name}")
            
            # Build context and analyze
            context = self._build_context(folder_path, project_name)
            raw = self.groq_client.generate(
                system_prompt=FRAMEWORK_LANGUAGE_SYSTEM_PROMPT,
                user_content=context,
                temperature=0.7,
            )

            # Parse results
            data = self._parse_json(raw)
            result = self._create_result(data)
            result = self._apply_to_laravel_from_target_php(result)

            # RAG-based version verification: cross-check detected versions against
            # RAG migration docs and code pattern analysis for ground-truth confidence.
            result = self._rag_verify_and_correct_versions(result, folder_path)

            # Store results
            state.add_result("frameworks_languages", result.to_dict())
            state.add_result("detected_languages", result.languages)
            state.add_result("detected_frameworks", result.frameworks)
            state.add_result("language_versions", result.language_versions)
            state.context["framework_analysis_completed"] = True

            logger.info(f"Framework/language analysis completed for {project_name}")
            logger.info(f"Found languages: {', '.join(result.languages)}")
            logger.info(f"Found frameworks: {', '.join(result.frameworks)}")

            return state
            
        except Exception as e:
            state.add_error(f"Framework/language analysis failed: {str(e)}")
            logger.error(f"Framework/language analysis failed: {e}", exc_info=True)
            return state

    def analyze(self, folder_path: Path, folder_name: str) -> FrameworkLanguageResult:
        """
        Legacy method for backward compatibility
        
        Args:
            folder_path: Path to project folder
            folder_name: Name of the project folder
            
        Returns:
            FrameworkLanguageResult with detected languages and frameworks
        """
        result = self.run(project_path=str(folder_path), project_name=folder_name)
        if result["success"]:
            data = result["results"].get("frameworks_languages", {})
            return FrameworkLanguageResult(
                languages=data.get("languages", []),
                frameworks=data.get("frameworks", []),
                language_versions=data.get("language_versions", {})
            )
        else:
            raise Exception(result.get("error", "Unknown error"))
    
    def _create_result(self, data: dict) -> FrameworkLanguageResult:
        """Create FrameworkLanguageResult from parsed data"""
        languages = sorted({s.strip() for s in (data.get("languages") or []) 
                           if isinstance(s, str) and s.strip()})
        frameworks = sorted({s.strip() for s in (data.get("frameworks") or []) 
                            if isinstance(s, str) and s.strip()})
        language_versions = data.get("language_versions") or {}
        
        # Ensure it's a dict with string values
        if isinstance(language_versions, dict):
            language_versions = {k: str(v) for k, v in language_versions.items() if k and v}
        else:
            language_versions = {}
            
        return FrameworkLanguageResult(
            languages=languages, 
            frameworks=frameworks, 
            language_versions=language_versions
        )

    def _apply_to_laravel_from_target_php(
        self, result: FrameworkLanguageResult
    ) -> FrameworkLanguageResult:
        """Set ``language_versions[\"to_laravel\"]`` from TARGET_PHP using planning_agent table."""
        if not self.target_php_for_upgrade:
            return result
        try:
            from app.services.agents.planning_agent import laravel_guide_major_for_target_php
        except Exception as ex:
            logger.warning("Could not import laravel_guide_major_for_target_php: %s", ex)
            return result
        maj = laravel_guide_major_for_target_php(self.target_php_for_upgrade)
        if maj is None:
            logger.info(
                "target_php_for_upgrade=%s did not map to Laravel 6–12 guide major; omitting to_laravel",
                self.target_php_for_upgrade,
            )
            return result
        lv = dict(result.language_versions)
        lv["to_laravel"] = str(maj)
        return FrameworkLanguageResult(
            languages=result.languages,
            frameworks=result.frameworks,
            language_versions=lv,
        )

    # ------------------------------------------------------------------
    # RAG-based version ground-truth verification
    # ------------------------------------------------------------------

    def _collect_code_text(self, project_root: Path, language: str, max_chars: int = 200_000) -> str:
        """Collect raw source code from the project for pattern scanning."""
        ext_map = {
            "php": [".php"],
            "python": [".py"],
            "javascript": [".js", ".mjs", ".cjs"],
            "typescript": [".ts", ".tsx"],
            "java": [".java"],
            "go": [".go"],
            "ruby": [".rb"],
            "rust": [".rs"],
            "csharp": [".cs"],
        }
        exts = set(ext_map.get(language.lower(), []))
        if not exts:
            return ""
        ignore = {".git", "__pycache__", "venv", ".venv", "vendor", "node_modules"}
        chunks: List[str] = []
        total = 0
        for root, dirnames, filenames in os.walk(project_root):
            dirnames[:] = [d for d in dirnames if d not in ignore]
            for fn in filenames:
                if Path(fn).suffix.lower() not in exts:
                    continue
                fp = Path(root) / fn
                try:
                    chunk = fp.read_text(encoding="utf-8", errors="ignore")[:20_000]
                    chunks.append(chunk)
                    total += len(chunk)
                    if total >= max_chars:
                        break
                except Exception:
                    pass
            if total >= max_chars:
                break
        return "\n".join(chunks)

    def _rag_verify_and_correct_versions(
        self, result: FrameworkLanguageResult, project_root: Path
    ) -> FrameworkLanguageResult:
        """
        Cross-check LLM-detected versions against:
        1. Removed/deprecated API patterns found directly in the project's code.
        2. RAG migration docs — fetch version step docs and compare against code.

        For PHP: scan for removed functions (mysql_*, create_function, etc.) to
        establish a hard ceiling, and scan for modern syntax to establish a floor.
        The intersection gives a confident version range.

        Returns a corrected FrameworkLanguageResult.
        """
        lv = dict(result.language_versions)
        corrected = False

        # ── PHP verification ──────────────────────────────────────────────
        if "php" in result.languages:
            llm_php = lv.get("php", "")
            code_text = self._collect_code_text(project_root, "php")

            # Priority 1: composer.json require.php — developer's explicit declaration
            # This is authoritative: a project requiring ^7.0 IS a PHP 7.0 project even
            # if it uses create_function (which was legal through 7.4).
            composer_version = _php_version_from_composer_json(project_root)

            # 2. Hard ceiling: removed functions (safety cap only — not the actual version)
            ceiling = _php_version_from_code_patterns(code_text)
            # 3. Hard floor: modern features (minimum required version)
            floor = _php_min_version_from_features(code_text)

            ladder = _LADDER_MAP["php"]

            ceiling_idx = ladder.index(ceiling) if ceiling in ladder else len(ladder) - 1
            floor_idx = ladder.index(floor) if floor in ladder else 0

            # Sanity: floor should be ≤ ceiling
            if floor_idx > ceiling_idx:
                # Contradictory evidence — trust ceiling (deprecated code is a hard constraint)
                floor_idx = ceiling_idx

            llm_idx = ladder.index(llm_php) if llm_php in ladder else None

            if composer_version and composer_version in ladder:
                # composer.json is the ground truth — use it directly
                composer_idx = ladder.index(composer_version)
                # Only override if it differs from what LLM said
                if llm_php != composer_version:
                    old = lv.get("php", "unknown")
                    lv["php"] = composer_version
                    logger.info(
                        "RAG version verify: PHP set to %s from composer.json require.php "
                        "(LLM said %s; composer is authoritative)", composer_version, old
                    )
                    corrected = True
                    llm_idx = composer_idx
                else:
                    logger.info(
                        "RAG version verify: PHP=%s confirmed by composer.json (ceiling=%s, floor=%s)",
                        composer_version, ceiling, floor
                    )
                # Still enforce ceiling as a safety cap (code can't exceed ceiling)
                if ceiling and llm_idx is not None and llm_idx > ceiling_idx:
                    old = lv.get("php", "unknown")
                    lv["php"] = ceiling
                    logger.info(
                        "RAG version verify: PHP capped %s → %s "
                        "(composer version exceeds removed-function ceiling=%s)", old, ceiling, ceiling
                    )
                    corrected = True
            else:
                # No composer.json or no php constraint — fall back to pattern analysis
                if ceiling:
                    # Code uses removed functions → cannot be above ceiling
                    if llm_idx is None or llm_idx > ceiling_idx:
                        old = lv.get("php", "unknown")
                        lv["php"] = ceiling
                        logger.info(
                            "RAG version verify: PHP corrected %s → %s "
                            "(removed functions found: ceiling=%s)", old, ceiling, ceiling
                        )
                        corrected = True

                if floor and not ceiling:
                    # Modern syntax found, no removed functions.
                    if llm_idx is None or llm_idx < floor_idx:
                        old = lv.get("php", "unknown")
                        lv["php"] = floor
                        logger.info(
                            "RAG version verify: PHP corrected %s → %s "
                            "(modern features require min=%s)", old, floor, floor
                        )
                        corrected = True
                    elif llm_idx > floor_idx:
                        # LLM guessed higher than pattern analysis can confirm — cap it
                        old = lv.get("php", "unknown")
                        lv["php"] = floor
                        logger.info(
                            "RAG version verify: PHP capped %s → %s "
                            "(LLM exceeded pattern-confirmed floor=%s; ceiling absent)",
                            old, floor, floor
                        )
                        corrected = True

                if not ceiling and not floor:
                    logger.info(
                        "RAG version verify: PHP=%s — no strong signals found; "
                        "trusting LLM/manifest detection", lv.get("php")
                    )

        # ── RAG content-based verification (for any language with RAG support) ──
        # We fetch the migration doc for the version ABOVE the detected one.
        # If the doc says "feature X was added in this version" and the code uses X,
        # we know the project must be at least this version.
        # This step runs only when RAG is available and the language is supported.
        try:
            rag_verified = self._rag_fetch_and_compare_versions(result.languages, lv, project_root)
            if rag_verified:
                for k, v in rag_verified.items():
                    if v != lv.get(k):
                        logger.info(
                            "RAG doc comparison: %s version corrected %s → %s",
                            k, lv.get(k, "unknown"), v
                        )
                        lv[k] = v
                        corrected = True
        except Exception as exc:
            logger.debug("RAG version comparison skipped: %s", exc)

        if not corrected:
            return result
        return FrameworkLanguageResult(
            languages=result.languages,
            frameworks=result.frameworks,
            language_versions=lv,
        )

    def _rag_fetch_and_compare_versions(
        self,
        languages: List[str],
        language_versions: Dict[str, str],
        project_root: Path,
    ) -> Dict[str, str]:
        """
        Fetch migration docs via RAG for each detected language/framework.
        Compare the DEPRECATED/REMOVED section of each version's migration guide
        against the project's code to pin-point the current version more accurately.

        Returns a dict of {lang_key: corrected_version} for keys that were corrected.
        """
        # Try to import UniversalMigrationTool from the rag directory.
        # /app/rag is the parent that contains the `php_migrator` package folder,
        # so we add /app/rag (not /app/rag/php_migrator) to sys.path.
        rag_root = Path(__file__).parent.parent.parent.parent / "rag"
        rag_root_str = str(rag_root)
        if rag_root_str not in sys.path:
            sys.path.insert(0, rag_root_str)
        search_tool_path = str(rag_root / "Search_tool")
        if search_tool_path not in sys.path:
            sys.path.insert(0, search_tool_path)

        try:
            from php_migrator.core.migration_tool import UniversalMigrationTool
        except ImportError:
            logger.debug("UniversalMigrationTool not importable; skipping RAG version compare")
            return {}

        tool = UniversalMigrationTool()
        corrections: Dict[str, str] = {}

        for lang in languages:
            lang_lower = lang.lower()
            if lang_lower not in _LADDER_MAP:
                continue
            ladder = _LADDER_MAP[lang_lower]
            current_v = language_versions.get(lang_lower, "")
            if not current_v or current_v not in ladder:
                continue

            # Collect code text for this language
            code_text = self._collect_code_text(project_root, lang_lower)
            if not code_text.strip():
                continue

            current_idx = ladder.index(current_v)
            # Check the version ABOVE detected to see if code already needs it
            # (verifying "current" is not already out of date)
            # Also check the version BELOW to see if code only needs older APIs.

            # Strategy: fetch docs for each candidate version and look for
            # "deprecated/removed" items that appear in the code.
            # If code uses items removed in version X, max version = X-1.

            confirmed_max = current_idx  # start from what LLM said

            # Only scan 3 versions below and 1 above the detected version to avoid
            # fetching irrelevant ancient versions (e.g. PHP 4.x when project is 7.x).
            _check_start = min(current_idx + 1, len(ladder) - 1)
            _check_stop = max(current_idx - 3, 0)
            for check_idx in range(_check_start, _check_stop - 1, -1):
                check_v = ladder[check_idx]
                try:
                    doc_result = tool.fetch_migration(lang_lower, check_v, framework=None, force_refresh=False)
                    if not doc_result.get("success") or not doc_result.get("content"):
                        continue
                    content = doc_result["content"]
                    # Find the "removed/deprecated" sections
                    if not _DEPRECATED_SECTION_RE.search(content):
                        continue
                    # Extract function/method names mentioned near deprecated sections
                    # Look for patterns like: `function_name()`, `ClassName::method()`, etc.
                    mentioned_funcs = re.findall(r'`(\w+(?:::\w+)?)\(\)`|`(\w+(?:::\w+)?)`', content)
                    flat_funcs = [f for pair in mentioned_funcs for f in pair if f]
                    # Check if any of these appear in the code
                    for fn in flat_funcs:
                        if re.search(r'\b' + re.escape(fn) + r'\s*(?:\(|::)', code_text, re.IGNORECASE):
                            # Code uses something deprecated/removed in check_v
                            # So code is at most check_v - 1
                            if check_idx > 0:
                                confirmed_max = check_idx - 1
                                logger.info(
                                    "RAG doc: code uses '%s' which was deprecated/removed in %s %s → "
                                    "capping version at %s",
                                    fn, lang_lower, check_v, ladder[confirmed_max],
                                )
                            break
                except Exception:
                    continue

            # Only report a correction if we found a lower ceiling than LLM said
            if confirmed_max < current_idx:
                corrections[lang_lower] = ladder[confirmed_max]

        return corrections

    def _build_context(self, project_root: Path, project_name: str) -> str:
        """
        Build a compact context (no full file contents) to avoid token limits:
        - file extension counts + a few example paths
        - small sample of file contents selected by size (truncated)
        """
        ext_counts: Dict[str, int] = {}
        ext_examples: Dict[str, List[str]] = {}
        sampled_contents: List[Tuple[str, str]] = []

        def should_ignore_dir(name: str) -> bool:
            return any(p == name or p in name for p in self.ignore_patterns)

        def should_ignore_file(name: str) -> bool:
            return any(p in name for p in self.ignore_patterns)

        # Walk project and collect extensions (full inventory)
        for root, dirnames, filenames in os.walk(project_root):
            dirnames[:] = [d for d in dirnames if not should_ignore_dir(d)]
            for filename in filenames:
                if should_ignore_file(filename):
                    continue
                file_path = Path(root) / filename
                rel_path = os.path.relpath(file_path, project_root)
                ext = file_path.suffix.lower() or "(no_ext)"
                ext_counts[ext] = ext_counts.get(ext, 0) + 1
                if len(ext_examples.get(ext, [])) < 5:
                    ext_examples.setdefault(ext, []).append(rel_path)

        # High-value files for framework/language detection across all languages.
        # PHP/Laravel, Python, Node.js, Java, Go, Rust, Ruby, C#, etc.
        priority_paths = [
            # PHP / Laravel
            "composer.json",
            "composer.lock",
            "bootstrap/app.php",
            "config/app.php",
            "artisan",
            # Python
            "requirements.txt",
            "pyproject.toml",
            "setup.py",
            "setup.cfg",
            "Pipfile",
            "runtime.txt",          # Heroku Python runtime version
            # JavaScript / TypeScript / Node
            "package.json",
            "package-lock.json",
            ".nvmrc",
            ".node-version",
            "tsconfig.json",
            # Java / Kotlin
            "pom.xml",
            "build.gradle",
            "build.gradle.kts",
            "gradle/wrapper/gradle-wrapper.properties",
            ".java-version",
            # Go
            "go.mod",
            "go.sum",
            # Rust
            "Cargo.toml",
            "Cargo.lock",
            # Ruby
            "Gemfile",
            "Gemfile.lock",
            ".ruby-version",
            # C# / .NET
            "*.csproj",
            "global.json",
            # Misc
            "Dockerfile",
            ".tool-versions",       # asdf version manager
        ]
        max_total_chars = 120_000
        max_file_chars = 20_000
        max_priority_chars = 50_000  # total budget for priority files
        used_chars = 0
        sampled_paths: set[str] = set()

        for rel in priority_paths:
            p = project_root / rel
            if not p.exists() or not p.is_file() or rel in sampled_paths:
                continue
            try:
                raw = p.read_bytes()
            except Exception:
                continue
            if b"\x00" in raw[:2048]:
                continue
            try:
                content = raw.decode("utf-8", errors="ignore")
            except Exception:
                continue
            if used_chars + len(content) > max_priority_chars:
                content = content[: max_priority_chars - used_chars]
            used_chars += len(content)
            content = content[:max_file_chars]
            sampled_contents.append((rel, content))
            sampled_paths.add(rel)

        max_files = 40
        candidates: List[Tuple[int, str, str, Path]] = []
        for root, dirnames, filenames in os.walk(project_root):
            dirnames[:] = [d for d in dirnames if not should_ignore_dir(d)]
            for filename in filenames:
                if should_ignore_file(filename):
                    continue
                p = Path(root) / filename
                rel_path = os.path.relpath(p, project_root)
                if rel_path in sampled_paths:
                    continue
                try:
                    size = p.stat().st_size
                except Exception:
                    continue
                if 0 < size <= 200_000:
                    ext = p.suffix.lower() or "(no_ext)"
                    candidates.append((size, ext, rel_path, p))

        candidates.sort(key=lambda t: t[0])
        picked: List[Tuple[int, str, str, Path]] = []
        seen_ext: set[str] = set()
        for item in candidates:
            _, ext, _, _ = item
            if ext in seen_ext:
                continue
            seen_ext.add(ext)
            picked.append(item)
            if len(picked) >= max_files:
                break
        if len(picked) < max_files:
            for item in candidates:
                if item in picked:
                    continue
                picked.append(item)
                if len(picked) >= max_files:
                    break

        for size, ext, rel_path, p in picked:
            if len(sampled_contents) >= max_files or used_chars >= max_total_chars:
                break
            try:
                raw = p.read_bytes()
            except Exception:
                continue
            # Skip likely-binary files (very basic check, no keyword rules)
            if b"\x00" in raw[:2048]:
                continue
            try:
                content = raw.decode("utf-8", errors="ignore")
            except Exception:
                continue
            content = content[:max_file_chars]
            if used_chars + len(content) > max_total_chars:
                remaining = max_total_chars - used_chars
                if remaining <= 0:
                    break
                content = content[:remaining]
            used_chars += len(content)
            sampled_contents.append((rel_path, content))

        lines: List[str] = []
        lines.append(f"Project name: {project_name}")
        lines.append(f"Project root: {project_root}")
        if self.target_php_for_upgrade:
            lines.append(
                f"TARGET_PHP_FOR_UPGRADE: {self.target_php_for_upgrade} "
                "(use this to set language_versions[\"to_laravel\"] per system prompt mapping)"
            )
        lines.append("=" * 80)
        lines.append("FILE EXTENSION COUNTS (with a few examples)")
        lines.append("=" * 80)
        for ext in sorted(ext_counts.keys()):
            examples = ", ".join(ext_examples.get(ext, []))
            lines.append(f"{ext}: {ext_counts[ext]} | examples: {examples}")

        lines.append("")
        lines.append("=" * 80)
        lines.append("SAMPLED FILE CONTENTS (TRUNCATED)")
        lines.append("=" * 80)
        if not sampled_contents:
            lines.append("[no text files sampled]")
        else:
            for rel_path, content in sampled_contents:
                lines.append("")
                lines.append(f"FILE: {rel_path}")
                lines.append("```")
                lines.append(content)
                lines.append("```")

        return "\n".join(lines)

    @staticmethod
    def _parse_json(text: str) -> Dict:
        """
        Parse strict JSON. If the model accidentally wraps extra text, extract the
        first JSON object block.
        """
        text = text.strip()
        try:
            return json.loads(text)
        except Exception:
            # attempt to extract first {...} block
            start = text.find("{")
            end = text.rfind("}")
            if start != -1 and end != -1 and end > start:
                try:
                    return json.loads(text[start : end + 1])
                except Exception:
                    pass
        raise ValueError("LLM did not return valid JSON for languages/frameworks")


def analyze_frameworks_languages(folder_path: str, folder_name: str) -> FrameworkLanguageResult:
    analyzer = FrameworkLanguageAnalyzer()
    return analyzer.analyze(Path(folder_path), folder_name)

