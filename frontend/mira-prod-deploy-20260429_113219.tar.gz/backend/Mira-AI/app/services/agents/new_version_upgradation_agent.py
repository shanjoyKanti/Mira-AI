"""
Staged (recursive) PHP version upgradation agent.

Standalone module: does **not** import or subclass `PHPModernizationAgent`.

Runs one LLM pass per official PHP migration step (e.g. 7.0→7.1 via
`php_migration_71_txt`), reusing the on-disk tree between stages. Each pass uses
this stage's php.net migration text and (when the tree is Laravel) per-stage
Laravel documentation — **no SonarQube** download, report, or scanner-driven edits.

All `*.php` paths are scanned, including `*.blade.php` templates (HTML/Blade +
embedded PHP).

SSH uploads: see `push_local_tree_to_remote`.
"""

from __future__ import annotations

import json
import os
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from app.services.agents.base_agent import AgentState, BaseAgent, GroqClient
from app.services.agents.planning_agent import (
    MigrationStage,
    collect_laravel_docs_until_php_target,
    compute_migration_stages,
    synthesize_laravel_guide_for_stage,
)
from app.core.logging import get_logger

logger = get_logger(__name__)

# When combined migration text fits, skip digest LLM pipeline (prompt still uses labeled PARTs if text exceeds part size).
_FULL_MIGRATION_INLINE_MAX_CHARS = 100_000
# Larger guides: pack ``--- FILE:`` blocks into digest LLM inputs.
_MIGRATION_LLM_CHUNK_INPUT_CHARS = 48_000
# Labeled PART size for php.net / Laravel / Phase-1 analysis in prompts — **split only, never truncate**.
_MIGRATION_IN_FILE_PROMPT_MAX_CHARS = 55_000
_DOC_CONTEXT_CHUNK_MAX_CHARS = 55_000
# Phase 1: map (per source chunk) → tree-merge → final formatter token budgets.
_STAGE_DOC_ANALYSIS_MAX_TOKENS = 16_384
_STAGE_DOC_CHUNK_EXTRACT_MAX_TOKENS = 12_288
_STAGE_DOC_MERGE_PAIR_MAX_TOKENS = 16_384
# Per-file version upgradation + structured synthesis: allow long MIRA_PHP + JSON (default client max_tokens is often 16k).
_MODERNIZE_FILE_MAX_TOKENS = 32_768
_STRUCTURED_SYNTHESIS_MAX_TOKENS = 32_768
# Checklist pipeline: (1) JSON task list per file (php.net + Laravel scoped to CURRENT CODE), (2) batched MIRA apply.
_MODERNIZE_CHECKLIST_PIPELINE = True
_MODERNIZE_CHECKLIST_GUIDE_MAX = 55_000
_MODERNIZE_CHECKLIST_LARAVEL_MAX = 45_000
_MODERNIZE_CHECKLIST_PHASE1_MAX = 25_000
_MODERNIZE_CHECKLIST_MAX_TOKENS = 16_384
_MODERNIZE_CHECKLIST_BATCH_SIZE = 7
_MODERNIZE_CHECKLIST_APPLY_MAX_TOKENS = 32_768
# Primary upgradation should emit these markers so notes + PHP are parsed from one string (no CHANGES vs fence drift).
_MIRA_NOTES_JSON_START = "<<<BEGIN_MIRA_NOTES_JSON>>>"
_MIRA_NOTES_JSON_END = "<<<END_MIRA_NOTES_JSON>>>"
_MIRA_PHP_START = "<<<BEGIN_MIRA_PHP>>>"
_MIRA_PHP_END = "<<<END_MIRA_PHP>>>"
_SUBSTANTIVE_MODERNIZE_NA = re.compile(
    r"^\s*[-*]?\s*\[(?:PHP|Laravel)\]\s*(?:N/A|n/a)\b",
    re.IGNORECASE,
)


def _normalize_php_text(s: str) -> str:
    return s.replace("\r\n", "\n")


def _has_substantive_modernize_change_bullets(changes: List[str]) -> bool:
    """True if ### CHANGES: claims real work (not only explicit N/A lines)."""
    for raw in changes:
        line = raw.strip()
        if not line:
            continue
        if _SUBSTANTIVE_MODERNIZE_NA.match(line):
            continue
        low = line.lower()
        if "no migration items applied" in low:
            continue
        if "no constructs from the guide" in low:
            continue
        if "no issues for this path" in low:
            continue
        return True
    return False


def _extract_json_object(text: str) -> Optional[Dict[str, Any]]:
    """Parse the first top-level JSON object from model output (tolerates leading/trailing prose)."""
    s = (text or "").strip()
    if not s:
        return None
    start = s.find("{")
    if start == -1:
        return None
    decoder = json.JSONDecoder()
    try:
        obj, _ = decoder.raw_decode(s[start:])
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj, dict) else None


def _normalize_modernization_tasks(raw: Any) -> List[Dict[str, Any]]:
    if not isinstance(raw, list):
        return []
    out: List[Dict[str, Any]] = []
    for i, t in enumerate(raw):
        if not isinstance(t, dict):
            continue
        pillar = str(t.get("pillar", "")).lower().strip()
        if pillar not in ("php", "laravel"):
            continue
        item = {
            "id": str(t.get("id") or f"{pillar}_{i}"),
            "pillar": pillar,
            "summary": str(t.get("summary") or "")[:2_000],
            "remediation": str(t.get("remediation") or t.get("action") or "")[:4_000],
        }
        out.append(item)
    return out


def _parse_mira_tagged_response(response: str, fallback_code: str) -> Optional[Tuple[str, List[str]]]:
    """If MIRA markers are present, return (php_body, notes). Otherwise None."""
    text = response or ""
    if _MIRA_PHP_START not in text or _MIRA_PHP_END not in text:
        return None
    try:
        i0 = text.index(_MIRA_PHP_START) + len(_MIRA_PHP_START)
        i1 = text.index(_MIRA_PHP_END, i0)
    except ValueError:
        return None
    php_body = text[i0:i1].strip()
    if not php_body:
        return None
    if not php_body.startswith("<?php"):
        php_body = "<?php\n" + php_body
    notes: List[str] = []
    if _MIRA_NOTES_JSON_START in text and _MIRA_NOTES_JSON_END in text:
        try:
            n0 = text.index(_MIRA_NOTES_JSON_START) + len(_MIRA_NOTES_JSON_START)
            n1 = text.index(_MIRA_NOTES_JSON_END, n0)
            raw = text[n0:n1].strip()
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                notes = [str(x) for x in parsed]
        except (ValueError, json.JSONDecodeError, TypeError):
            pass
    return php_body, notes


def _parse_modernize_response_unified(
    response: str, fallback_code: str
) -> Tuple[str, List[str], str]:
    """Return (php_body, change_notes, parse_mode) with parse_mode ``mira`` or ``legacy``."""
    mira = _parse_mira_tagged_response(response, fallback_code)
    if mira is not None:
        return mira[0], mira[1], "mira"
    legacy = _parse_modernize_llm_response(response, fallback_code)
    return legacy[0], legacy[1], "legacy"


def _parse_modernize_llm_response(response: str, fallback_code: str) -> Tuple[str, List[str], bool]:
    """
    Parse model reply: upgraded PHP body, change bullets, whether a php code fence was found.
    """
    text = response or ""
    changes: List[str] = []
    changes_match = re.search(
        r"###\s*CHANGES:\s*(.*?)(?=###\s*UPGRADED\s*CODE:|```)",
        text,
        re.DOTALL | re.IGNORECASE,
    )
    if changes_match:
        changes_text = changes_match.group(1).strip()
        if "no changes needed" not in changes_text.lower():
            changes = [c.strip() for c in re.findall(r"[-*]\s*(.+)", changes_text)]

    upgraded_code = fallback_code
    had_fence = False
    code_match = re.search(r"```\s*php\s*(.*?)\s*```", text, re.DOTALL | re.IGNORECASE)
    if code_match:
        had_fence = True
        upgraded_code = code_match.group(1).strip()
    else:
        # Some models use a bare ``` fence without the php tag
        generic = re.search(r"```\s*\n(.*?)```", text, re.DOTALL)
        if generic:
            had_fence = True
            upgraded_code = generic.group(1).strip()
            if upgraded_code.lstrip().startswith("<?php"):
                pass
            elif "function " in upgraded_code or "namespace " in upgraded_code:
                pass

    if had_fence and upgraded_code and not upgraded_code.startswith("<?php"):
        upgraded_code = "<?php\n" + upgraded_code

    return upgraded_code, changes, had_fence


def _php_modernization_directives(target_php: str) -> str:
    """Per-version proactive modernization rules — new syntax to ADOPT even when not strictly required."""
    rules = {
        "7.1": [
            "Replace `list()` destructuring with short `[]` syntax: `[$a, $b] = $arr;`",
            "Add nullable types `?Type` where a parameter or return can be null",
            "Add `void` return type to functions that return nothing",
            "Replace single-type `catch (TypeA $e) {...} catch (TypeB $e) {...}` blocks with multi-catch `catch (TypeA | TypeB $e)` when the body is identical",
            "Add `public`/`protected`/`private` visibility to class constants",
        ],
        "7.2": [
            "Replace `object` type-hint workarounds with the `object` scalar type where applicable",
            "Remove `each()` calls — replace with `foreach` or `key()`/`current()`/`next()`",
        ],
        "7.3": [
            "Use trailing commas in function/method call argument lists where they improve readability",
            "Replace `is_array($x) && count($x) === 0` style checks with direct empty checks",
        ],
        "7.4": [
            "Convert anonymous functions `function($x) { return $x * 2; }` to arrow functions `fn($x) => $x * 2` where they only reference outer scope by value",
            "Add typed property declarations to class properties that have a clear type (e.g. `private string $name;` instead of `private $name;`)",
            "Replace `$x = $x ?? $default;` patterns with null coalescing assignment `$x ??= $default;`",
            "Use spread operator `...$arr` in array literals where applicable",
        ],
        "8.0": [
            "Replace `switch/case` blocks with `match` expressions where the matched value maps to return values (not side effects)",
            "Add `#[Attribute]` annotations where docblock `@` tags existed for type/validation hints",
            "Replace `isset($obj) ? $obj->method() : null` chains with nullsafe operator `$obj?->method()`",
            "Add union types `int|string` to function parameters and return types that accept multiple types",
            "Convert constructor property assignments (`$this->x = $x`) to constructor property promotion `public function __construct(private string $x)` where the property has no other logic",
            "Replace named positional-only calls with named arguments where it improves readability: `array_slice(array: $arr, offset: 2)`",
            "Use `str_contains()`, `str_starts_with()`, `str_ends_with()` instead of `strpos()`/`substr()` checks",
        ],
        "8.1": [
            "Replace string/int constants used as pseudo-enums with actual `enum` declarations",
            "Add `readonly` modifier to properties that are set only in the constructor and never mutated",
            "Use first-class callable syntax `strlen(...)` instead of `'strlen'` or `Closure::fromCallable('strlen')`",
            "Replace multi-return array patterns with named `readonly` value objects or enums",
            "Use `array_is_list()` instead of manual key checks where applicable",
            "Add intersection types `TypeA&TypeB` for parameters expecting objects implementing multiple interfaces",
        ],
        "8.2": [
            "Mark classes as `readonly` if all properties are readonly and no mutation occurs after construction",
            "Use `true`/`false`/`null` as standalone types in union types where applicable",
            "Add `#[SensitiveParameter]` attribute to parameters containing credentials or tokens",
        ],
        "8.3": [
            "Add types to class constants: `const string NAME = 'value';`",
            "Use `#[Override]` attribute on methods that intentionally override parent methods",
            "Use `json_validate()` instead of `json_decode()` + error check when only validity is needed",
        ],
        "8.4": [
            "Use property hooks for computed properties instead of getter/setter method pairs",
            "Add asymmetric visibility (`public private(set)`) where a property is publicly readable but should only be set internally",
        ],
    }
    directives = rules.get(target_php, [])
    if not directives:
        return ""
    lines = "\n".join(f"  - {d}" for d in directives)
    return (
        f"\n\n### Pillar 1b — Proactive modernization for PHP {target_php} (adopt new idioms)\n"
        f"Beyond fixing breaking changes, **actively modernize** the code to use PHP {target_php} idioms "
        f"where they apply to CURRENT CODE. These are **not optional** — apply each item that matches:\n"
        f"{lines}"
    )


def _llm_rubric_php_migration(target_php: str) -> str:
    modernization = _php_modernization_directives(target_php)
    return f"""### Pillar 1 — Official PHP migration documentation (php.net): analyze, then **modernize this file**
- **Goal:** TWO jobs in one pass — (A) **fix all breaking/deprecated patterns** from the migration guide, AND (B) **adopt new PHP {target_php} idioms** listed in Pillar 1b below. Both are mandatory. A file that compiles without errors but still uses only old syntax is NOT a successful upgrade.
- **Read for meaning:** Parse the **prose and lists** as technical rules (what is forbidden, what replaced what, what new errors occur). Do not treat the block as filler — every normative sentence can matter.
- **Read fully:** Read the **entire** PHP migration block below (all sections, lists, and notes) before editing. Items at the end are as important as items at the top.
- **Version scope:** Apply only what is required to move **one step** to **PHP {target_php}** for this stage. Do **not** apply changes that belong to a *later* PHP version unless this stage's text explicitly covers them.
- **Scan the guide for:** removed functions/extensions, signature changes, new TypeErrors, changed coercion, INI defaults, deprecated warnings that become errors in later minors, and any "backward incompatible changes" lists.
- **Map to code:** For each migration item AND each Pillar 1b modernization, search **CURRENT CODE** for affected patterns. If the construct appears, **you must change the code**; if it does not, skip silently.
- **Mandatory edits:** If ANY breaking change OR any Pillar 1b idiom applies to a construct in CURRENT CODE, **MIRA_PHP must reflect that change**. Do not claim `[PHP]` lines in MIRA_NOTES_JSON without the matching edits in MIRA_PHP.
- **Priority:** (1) Breaking / incompatible, (2) deprecations, (3) Pillar 1b modernizations, (4) remaining items that touch lines you already edit.
- **Conflicts:** If Laravel/Framework guidance would violate PHP {target_php} semantics, follow **PHP semantics** first, then apply framework changes in a compatible way if possible.{modernization}"""


def _llm_rubric_laravel(target_php: str) -> str:
    return f"""### Pillar 2 — Laravel framework upgrade (only when this project is Laravel): analyze, then **upgrade framework usage in this file**
- **Goal:** Where this file uses Laravel (`Illuminate\\`, facades, Eloquent, HTTP, config, etc.), apply the **staged Laravel guide** so framework APIs and patterns match the target for this PHP hop. Framework upgrades are **mandatory in code** when the guide applies to constructs in this file — not optional commentary.
- **Read fully:** Read the **entire** LARAVEL section (all headings and steps) before editing. Late steps are not optional.
- **Trust order:** The **LARAVEL** section below is the source of truth for this stage. Prefer its explicit renames, removals, and config moves over memory of older Laravel versions.
- **Mandatory edits:** If the guide names a rename, removal, or signature change that appears in **CURRENT CODE**, implement it in **MIRA_PHP**. MIRA_NOTES_JSON must match what you actually changed.
- **Scope:** Only change this file where the guide (or an obvious framework-wide rename) applies. No unrelated refactors.
- **Areas often touched in current upgrades (apply only if the guide or this file involves them):**
  - **Application bootstrap:** `bootstrap/app.php` / `Application::configure` style wiring, default middleware, route or exception handling registration (varies by Laravel major).
  - **HTTP:** `Request` / `Response` / middleware method signatures, `Route::` definitions, controller middleware attributes, invokable controllers, typed `__invoke` returns.
  - **Eloquent / models:** `$casts` vs `casts()` method, custom cast classes, `enum` / `AsEnumArrayObject` casts, `SoftDeletes`, `HasUuids`, mass-assignment / `$fillable` / guarded changes, strict mode / `Model::preventSilentlyDiscardingAttributes` when the guide says so.
  - **Validation & form requests:** rule objects, `Rule::` helpers, `prepareForValidation`, return types on `authorize` / `rules`.
  - **Facades & helpers:** renamed or removed facades, `Str::` / `Arr::` / `Http::` / `Storage::` API changes, `dispatch()` / job / queue contract changes.
  - **Config & env:** renamed keys, `config/*.php` file splits, `trustedProxies`, logging / `logging.php` channel changes when documented.
  - **Console / scheduling:** `Schedule::` fluent API, `Artisan::` command registration if this file is a command or service provider.
- **PHP coupling:** Framework calls must stay valid for **PHP {target_php}** for this stage. If the guide targets a newer PHP than this hop, apply only the subset compatible with {target_php}.
- **If the guide is split into multiple PART sections:** Read **all** parts; implement every breaking rename, namespace move, config key change, and signature change that appears in the text and touches **CURRENT CODE**."""


def _llm_rubric_plain_php_no_laravel(target_php: str) -> str:
    return f"""### Pillar 2 — Laravel: **not applicable** (plain PHP project)
- **Detection:** This tree was classified as **non-Laravel** (no `laravel/framework` in `composer.json` and no `Illuminate\\` usage in sampled sources). There is **no** Laravel framework upgrade for this stage — **Pillar 2 (Laravel) is skipped**.
- **Your upgradation is php.net-only for framework rules:** Apply **php.net PHP {target_php}** migration in code. Do **not** add or assume `Illuminate\\` imports, `Route::`, facades, Eloquent, service providers, or `artisan`-specific patterns unless they already exist in **CURRENT CODE** (they should not in a plain PHP app).
- **MIRA_NOTES_JSON:** Include one string: `[Laravel] N/A — project detected as non-Laravel; no framework upgrade applied.` (unless you already listed an equivalent note). Do not invent Laravel-only "upgradations."
- **PHP target:** Bring the file fully in line with **PHP {target_php}** using the migration section."""


def _llm_rubric_project_structure(file_path: str) -> str:
    return f"""### How to use the project structure list
- Use it to **resolve ambiguous imports**, guess correct relative namespaces, and avoid inventing paths that are not in the tree.
- **CURRENT FILE** is **`{file_path}`**; other paths are neighbors only — do not modify files you were not given."""


def _llm_rubric_analyze_php_source(file_path: str, to_version: str) -> str:
    return f"""### Analyze the **actual PHP source** in this file (required for correct upgradation)
Documentation (php.net, Laravel) is generic; **only the real code in `{file_path}`** tells you what to change.

- **Read CURRENT CODE end-to-end** before you finalize edits: every line, including `namespace`, `use`, classes, traits, enums, functions, closures, attributes, `declare`, top-level statements, and any embedded HTML/heredocs. Do not skim or assume from the path alone.
- **Inventory what is really there:** List mentally (or use for reasoning) which **APIs appear** — built-ins, extensions, deprecated/removed symbols for PHP **{to_version}**, framework calls (`Illuminate\\`, facades, helpers), SQL/HTTP/crypto patterns, error handling, and dynamic calls (`$fn()`, variable functions, `call_user_func`) that affect which migration rules apply.
- **Map docs to evidence:** For each php.net bullet or Laravel step, confirm the **matching construct exists in this file** (by name, pattern, or line context). Apply fixes **at those locations**; do not apply "typical" upgrades that this file does not contain.
- **Understand the file's role** (config, routes, model, controller, command, middleware, plain script, etc.) so edits stay coherent with how this file behaves at runtime.
- **Reconcile after reading docs:** After reading **PHP MIGRATION** / **LARAVEL**, **cross-check again against CURRENT CODE** so MIRA_PHP targets **this** body of text, not a hypothetical project."""


def _split_migration_guide_by_file_headers(combined: str) -> List[str]:
    """Split planner output on ``--- FILE:`` boundaries so each downloaded .txt stays one block."""
    t = (combined or "").strip()
    if not t:
        return []
    if "--- FILE: " not in t:
        return [t]
    parts = re.split(r"\n(?=--- FILE: )", t)
    return [p for p in parts if p.strip()]


def _pack_blocks_into_chunks(blocks: List[str], max_chunk_chars: int) -> List[str]:
    """Greedy pack file blocks into chunks <= max_chunk_chars; oversized blocks split raw."""
    chunks: List[str] = []
    current = ""
    for block in blocks:
        b = block.strip()
        if not b:
            continue
        if len(b) > max_chunk_chars:
            if current:
                chunks.append(current)
                current = ""
            chunks.extend(_chunk_text_contiguous(b, max_chunk_chars))
            continue
        sep = "\n\n" if current else ""
        if len(current) + len(sep) + len(b) <= max_chunk_chars:
            current = current + sep + b
        else:
            if current:
                chunks.append(current)
            current = b
    if current:
        chunks.append(current)
    return chunks


def _chunk_text_contiguous(text: str, max_chars: int) -> List[str]:
    """
    Split *text* into contiguous segments of at most *max_chars* characters.
    Every character is retained exactly once (no truncation). Prefer breaks at newlines.
    """
    if not text:
        return []
    if max_chars <= 0:
        return [text]
    chunks: List[str] = []
    pos = 0
    n = len(text)
    while pos < n:
        end = min(pos + max_chars, n)
        if end < n:
            window_start = pos + max(1, (max_chars * 2) // 3)
            br = text.rfind("\n\n", window_start, end)
            if br == -1:
                br = text.rfind("\n", pos + max_chars // 2, end)
            if br > pos:
                end = br + 1
        chunks.append(text[pos:end])
        pos = end
    return chunks


def _format_labeled_doc_parts(body: str, max_part_chars: int, title_base: str) -> str:
    """Split *body* into labeled PART sections for LLM consumption (full content, no truncation)."""
    t = (body or "").strip()
    if not t:
        return ""
    parts = _chunk_text_contiguous(t, max_part_chars)
    if len(parts) == 1:
        return parts[0]
    return "\n\n".join(
        f"### {title_base} — PART {i + 1} of {len(parts)}\n"
        f"**Read every part. Text is split only for size limits; nothing was omitted or cut off.**\n\n{p}"
        for i, p in enumerate(parts)
    )


def _phase1_focus_lines_for_file(analysis: str, file_path: str) -> str:
    """
    Lines from Phase 1 that mention this path or its basename — reduces copy-paste of other-file mandates.
    """
    t = (analysis or "").strip()
    if not t:
        return ""
    norm = file_path.replace("\\", "/")
    base = Path(file_path).name
    base_l = base.lower()
    norm_l = norm.lower()
    picked: List[str] = []
    for line in t.splitlines():
        ll = line.lower()
        if norm_l in ll or base_l in ll:
            picked.append(line)
    body = "\n".join(picked).strip()
    if not body:
        return (
            f"_(Phase 1 does not name `{file_path}` explicitly in any line. "
            "Do **not** treat mandates written for other paths as work items here unless the same construct exists in CURRENT CODE.)_"
        )
    return _format_labeled_doc_parts(body, _DOC_CONTEXT_CHUNK_MAX_CHARS, f"Phase 1 lines for `{file_path}`")


def push_local_tree_to_remote(
    ssh_conn,
    local_root: Path,
    remote_root: str,
    file_glob: str = "**/*",
    max_files: Optional[int] = None,
    backup: bool = True,
) -> bool:
    """
    Upload a local directory tree from the Mira Docker container to the client SSH server,
    preserving directory structure. Works for any language — not PHP-only.

    Uses SFTP write_file() — binary-safe, no heredoc, no shell-escaping corruption.

    Args:
        ssh_conn:    Active SSHConnection to the client server.
        local_root:  Directory on the Mira Docker container (e.g. /tmp/tmpXXX/project).
        remote_root: Absolute path on the client SSH server.
        file_glob:   Glob pattern relative to local_root. Default "**/*" uploads everything.
                     Pass "*.php" to restrict to PHP files only.
        max_files:   Hard cap on files uploaded (None = unlimited, override via MIRA_PHP_FILE_LIMIT).
        backup:      When True, create <file>.bak on the remote before overwriting (default True).
                     Set False only for initial uploads where no original exists yet.
    """
    try:
        local_root = Path(local_root).resolve()
        if not local_root.is_dir():
            logger.error("push_local_tree_to_remote: not a directory on container: %s", local_root)
            return False

        excluded = {"vendor", "node_modules", ".git"}
        files = [
            f for f in local_root.rglob(file_glob)
            if f.is_file() and not any(x in f.parts for x in excluded)
        ]
        files.sort()  # deterministic order

        effective_limit = max_files or int(os.environ.get("MIRA_PHP_FILE_LIMIT", "0")) or None
        if effective_limit and len(files) > effective_limit:
            logger.warning(
                "push_local_tree_to_remote: %d files found but capped at %d (MIRA_PHP_FILE_LIMIT)",
                len(files), effective_limit,
            )
            files = files[:effective_limit]

        if not files:
            logger.warning(
                "push_local_tree_to_remote: no files to upload from container path %s", local_root
            )
            return False

        # Pre-flight: check remote disk space (need at least 2× the local tree size)
        local_size_bytes = sum(f.stat().st_size for f in files)
        disk_check = ssh_conn.execute_command(
            f"df -k '{remote_root}' 2>/dev/null || df -k / 2>/dev/null | tail -1",
            timeout=ssh_conn.CMD_TIMEOUT_SHORT,
        )
        disk_out = (disk_check.get("stdout") or "").strip().splitlines()
        if len(disk_out) >= 2:
            try:
                avail_kb = int(disk_out[-1].split()[3])
                needed_kb = (local_size_bytes * 2) // 1024
                if avail_kb < needed_kb:
                    logger.error(
                        "push_local_tree_to_remote: insufficient disk space on remote — "
                        "available %dKB, needed ~%dKB", avail_kb, needed_kb,
                    )
                    return False
            except (IndexError, ValueError):
                pass  # if parsing fails, proceed anyway

        # Ensure base remote directory exists on the CLIENT server
        ssh_conn.execute_command(f"mkdir -p '{remote_root}'")

        uploaded = 0
        failed = 0
        total = len(files)
        for i, fp in enumerate(files, 1):
            rel = fp.relative_to(local_root).as_posix()
            remote_file = f"{remote_root.rstrip('/')}/{rel}"

            # Ensure full parent path exists on the CLIENT server
            remote_parent = remote_file.rsplit("/", 1)[0]
            ssh_conn.execute_command(f"mkdir -p '{remote_parent}'")

            # Read from Mira container filesystem
            try:
                body = fp.read_text(encoding="utf-8", errors="replace")
            except OSError as read_err:
                logger.warning(
                    "push_local_tree_to_remote: cannot read local file %s — %s", fp, read_err
                )
                failed += 1
                continue

            # Write to CLIENT server via SFTP — backup=True creates <file>.bak first
            ok = ssh_conn.write_file(remote_file, body, backup=backup)
            if ok:
                uploaded += 1
                if i % 50 == 0:
                    logger.info(
                        "push_local_tree_to_remote: uploaded %d/%d files to %s",
                        uploaded, total, remote_root,
                    )
            else:
                logger.warning(
                    "push_local_tree_to_remote: SFTP write failed for %s", remote_file
                )
                failed += 1

        if uploaded == 0:
            logger.error(
                "push_local_tree_to_remote: 0/%d files uploaded to %s",
                len(files), remote_root,
            )
            return False

        if failed:
            logger.warning(
                "push_local_tree_to_remote: %d/%d files uploaded, %d failed — %s",
                uploaded, len(files), failed, remote_root,
            )
        else:
            logger.info(
                "push_local_tree_to_remote: %d files uploaded to CLIENT server at %s",
                uploaded, remote_root,
            )
        return True
    except Exception as e:
        logger.error("push_local_tree_to_remote failed: %s", e, exc_info=True)
        return False


class NewVersionUpgradationAgent(BaseAgent):
    """
    Staged PHP version upgradation: sequential php.net migration folders on the same tree;
    Laravel guide slices per stage when the project is Laravel. No SonarQube integration.
    """

    def __init__(self, groq_client: Optional[GroqClient] = None):
        super().__init__(
            name="new_version_upgradation_agent",
            description="Staged PHP version upgradation using php.net migration guides (and Laravel docs when applicable)",
            groq_client=groq_client,
        )
        self.laravel_upgrade_guide: Optional[str] = None
        self.project_structure: Optional[Dict[str, Any]] = None
        self.stage_migration_guide: str = ""
        self._materialized_stage_migration_for_prompt: str = ""
        # Filled once per stage in run_staged_modernization (LLM reads docs before per-file modernization).
        self._stage_documentation_analysis: str = ""
        # Set in load_reports from composer.json / PHP heuristics (False until load_reports runs).
        self._is_laravel_project: bool = False

    def fetch_project(self, client_server_path: str, local_path: str) -> bool:
        """Copy project from a local or mounted path into ``local_path``."""
        try:
            logger.info("Fetching project from %s", client_server_path)
            if os.path.exists(client_server_path):
                shutil.copytree(client_server_path, local_path, dirs_exist_ok=True)
                logger.info("Project fetched to %s", local_path)
                return True
            logger.error("Server path not found: %s", client_server_path)
            return False
        except Exception as e:
            logger.error("Error fetching project: %s", e)
            return False

    def load_reports(
        self,
        project_name: str,
        laravel_upgrade_guide_path: Optional[str] = None,
        project_local_path: Optional[str] = None,
        skip_initial_report_requirements: bool = False,
    ) -> bool:
        """
        Initialise the staged migration agent. Laravel guide content for each stage
        is now fetched dynamically via the RAG system in run_staged_modernization().

        laravel_upgrade_guide_path: if provided AND the file exists, its content is
        pre-loaded as the initial Laravel guide (rarely needed; per-stage RAG fetch
        overrides this anyway). Static docs directories are no longer used.
        """
        logger.info(
            "[new_version_upgradation_agent] load_reports: start project_name=%s skip_initial=%s local_path=%s",
            project_name,
            skip_initial_report_requirements,
            project_local_path,
        )

        self.laravel_upgrade_guide = None

        # Accept a pre-loaded guide string only if the file path still exists
        # (e.g. a synthesised per-project guide written to upgrade-guide/).
        if laravel_upgrade_guide_path:
            lp = Path(laravel_upgrade_guide_path)
            if lp.exists():
                self.laravel_upgrade_guide = lp.read_text(encoding="utf-8", errors="replace")
                logger.info(
                    "load_reports: pre-loaded Laravel upgrade guide from %s (%s chars)",
                    lp, len(self.laravel_upgrade_guide),
                )
            else:
                logger.info(
                    "load_reports: laravel_upgrade_guide_path not found (%s) — will use RAG per stage",
                    lp,
                )

        _ = project_local_path

        if skip_initial_report_requirements:
            if self._is_laravel_project and not (self.laravel_upgrade_guide or "").strip():
                self.laravel_upgrade_guide = (
                    "# Placeholder — per-stage Laravel guide will be fetched via RAG.\n"
                )
            logger.info(
                "[new_version_upgradation_agent] load_reports: skip_initial_report_requirements=True — "
                "Laravel guide will be populated per stage via RAG.",
            )
            return True

        logger.info(
            "[new_version_upgradation_agent] load_reports: complete Laravel=%s chars is_laravel=%s",
            len(self.laravel_upgrade_guide or ""),
            self._is_laravel_project,
        )
        return True

    # =========================================================================
    # REMOTE TEST RUNNER & CYCLIC CORRECTION LOOP
    # =========================================================================

    # Maximum number of correction attempts per stage before giving up.
    MAX_STAGE_RETRIES: int = int(os.environ.get("MIRA_MAX_STAGE_RETRIES", "3"))

    @staticmethod
    def run_tests_on_remote(ssh_conn, remote_path: str, language: str = "php") -> Dict[str, Any]:
        """
        Execute syntax checks and available test suites on the client server via SSH.
        Dispatches to the appropriate runner based on *language*.
        Never copies code to Mira's server.

        Returns:
            {
                "passed": bool,
                "errors": List[str],    # error lines from failing checks
                "checks_run": List[str]
            }
        """
        errors: List[str] = []
        checks_run: List[str] = []
        lang = (language or "php").lower().strip()

        # ── PHP ──────────────────────────────────────────────────────────────
        if lang == "php":
            # 1. PHP syntax check.  Do NOT pipe through grep — grep exits 1 when it finds
            #    NO matches (= all files OK), which would be misread as a failure.
            #    Capture raw php -l output and filter parse errors in Python.
            syntax_result = ssh_conn.execute_command(
                f"find '{remote_path}' -name '*.php' -not -path '*/vendor/*' "
                f"-not -path '*/node_modules/*' -print0 | xargs -0 -r php -l 2>&1"
            )
            checks_run.append("php -l")
            syntax_out = (syntax_result.get("stdout") or "").strip()
            if syntax_out:
                parse_errors = [
                    ln for ln in syntax_out.splitlines()
                    if ln.strip()
                    and "No syntax errors" not in ln
                    and "Errors parsing" not in ln   # success summary line
                    and ln.strip().startswith(("Parse error", "Fatal error", "Syntax error"))
                ]
                errors.extend(parse_errors)

            # 2. PHPUnit (if installed) — only flag FAILURES! / ERRORS! markers
            phpunit_check = ssh_conn.execute_command(
                f"test -f '{remote_path}/vendor/bin/phpunit' && echo yes || echo no"
            )
            if "yes" in (phpunit_check.get("stdout") or ""):
                phpunit_result = ssh_conn.execute_command(
                    f"cd '{remote_path}' && vendor/bin/phpunit --no-coverage 2>&1 | tail -40"
                )
                checks_run.append("phpunit --no-coverage")
                phpunit_out = (phpunit_result.get("stdout") or "").strip()
                phpunit_exit = phpunit_result.get("exit_code") or 0
                if phpunit_exit != 0 or "FAILURES!" in phpunit_out or "ERRORS!" in phpunit_out:
                    errors.append(f"[PHPUnit] {phpunit_out[-2000:]}")

            # 3. Composer autoload — only when composer binary is present
            composer_json_check = ssh_conn.execute_command(
                f"test -f '{remote_path}/composer.json' && echo yes || echo no"
            )
            if "yes" in (composer_json_check.get("stdout") or ""):
                bin_check = ssh_conn.execute_command("which composer 2>/dev/null && echo found || echo missing")
                if "found" in (bin_check.get("stdout") or ""):
                    autoload_result = ssh_conn.execute_command(
                        f"cd '{remote_path}' && composer dump-autoload --no-dev --quiet 2>&1"
                    )
                    checks_run.append("composer dump-autoload")
                    autoload_out = (autoload_result.get("stdout") or "").strip()
                    autoload_exit = autoload_result.get("exit_code") or 0
                    if autoload_exit not in (0, 127):
                        errors.append(f"[Composer autoload] exit={autoload_exit} {autoload_out[:1000]}")
                    elif "error" in autoload_out.lower() and "autoload" in autoload_out.lower():
                        errors.append(f"[Composer autoload] {autoload_out[:1000]}")
                else:
                    logger.debug("[run_tests_on_remote] composer binary not found, skipping autoload")

            # 4. Laravel artisan sanity check
            artisan_check = ssh_conn.execute_command(
                f"test -f '{remote_path}/artisan' && echo yes || echo no"
            )
            if "yes" in (artisan_check.get("stdout") or ""):
                artisan_result = ssh_conn.execute_command(
                    f"cd '{remote_path}' && php artisan --version 2>&1"
                )
                checks_run.append("php artisan --version")
                artisan_out = (artisan_result.get("stdout") or "").strip()
                artisan_exit = artisan_result.get("exit_code") or 0
                if artisan_exit != 0:
                    errors.append(f"[Artisan] exit={artisan_exit} {artisan_out[:500]}")

        # ── Python ───────────────────────────────────────────────────────────
        elif lang == "python":
            # Syntax check with py_compile on all .py files
            syntax_result = ssh_conn.execute_command(
                f"find '{remote_path}' -name '*.py' -not -path '*/.git/*' "
                f"-not -path '*/venv/*' -not -path '*/__pycache__/*' | "
                f"xargs -r python3 -m py_compile 2>&1 || true"
            )
            checks_run.append("python3 -m py_compile")
            syntax_out = (syntax_result.get("stdout") or "").strip()
            if syntax_out:
                errors.extend([ln for ln in syntax_out.splitlines() if ln.strip()])

            # pytest if available
            pytest_check = ssh_conn.execute_command(
                f"cd '{remote_path}' && python3 -m pytest --version 2>/dev/null && echo found || echo missing"
            )
            if "found" in (pytest_check.get("stdout") or ""):
                pytest_result = ssh_conn.execute_command(
                    f"cd '{remote_path}' && python3 -m pytest --tb=short -q 2>&1 | tail -40"
                )
                checks_run.append("pytest")
                pt_out = (pytest_result.get("stdout") or "").strip()
                pt_exit = pytest_result.get("exit_code") or 0
                if pt_exit != 0 and ("failed" in pt_out.lower() or "error" in pt_out.lower()):
                    errors.append(f"[pytest] {pt_out[-2000:]}")

        # ── Java ─────────────────────────────────────────────────────────────
        elif lang == "java":
            mvn_check = ssh_conn.execute_command(
                f"test -f '{remote_path}/pom.xml' && which mvn 2>/dev/null && echo mvn || "
                f"(test -f '{remote_path}/build.gradle' && which gradle 2>/dev/null && echo gradle || echo none)"
            )
            build_tool = (mvn_check.get("stdout") or "").strip().split()[-1]
            if build_tool == "mvn":
                build_result = ssh_conn.execute_command(
                    f"cd '{remote_path}' && mvn compile -q 2>&1 | tail -40"
                )
                checks_run.append("mvn compile")
                b_out = (build_result.get("stdout") or "").strip()
                b_exit = build_result.get("exit_code") or 0
                if b_exit != 0:
                    errors.append(f"[mvn compile] exit={b_exit} {b_out[-2000:]}")
            elif build_tool == "gradle":
                build_result = ssh_conn.execute_command(
                    f"cd '{remote_path}' && gradle compileJava -q 2>&1 | tail -40"
                )
                checks_run.append("gradle compileJava")
                b_out = (build_result.get("stdout") or "").strip()
                b_exit = build_result.get("exit_code") or 0
                if b_exit != 0:
                    errors.append(f"[gradle compileJava] exit={b_exit} {b_out[-2000:]}")

        # ── JavaScript / TypeScript ───────────────────────────────────────────
        elif lang in ("javascript", "typescript"):
            npm_check = ssh_conn.execute_command(
                f"test -f '{remote_path}/package.json' && echo yes || echo no"
            )
            if "yes" in (npm_check.get("stdout") or ""):
                # Try npm test (non-interactive)
                npm_test_result = ssh_conn.execute_command(
                    f"cd '{remote_path}' && npm test --if-present 2>&1 | tail -40"
                )
                checks_run.append("npm test")
                nm_out = (npm_test_result.get("stdout") or "").strip()
                nm_exit = npm_test_result.get("exit_code") or 0
                if nm_exit != 0 and nm_out and "no test specified" not in nm_out.lower():
                    errors.append(f"[npm test] exit={nm_exit} {nm_out[-2000:]}")
                # TypeScript compile check
                if lang == "typescript":
                    tsc_check = ssh_conn.execute_command(
                        f"cd '{remote_path}' && npx tsc --noEmit 2>&1 | tail -40"
                    )
                    checks_run.append("tsc --noEmit")
                    tsc_out = (tsc_check.get("stdout") or "").strip()
                    tsc_exit = tsc_check.get("exit_code") or 0
                    if tsc_exit != 0 and tsc_out:
                        errors.append(f"[tsc] exit={tsc_exit} {tsc_out[-2000:]}")

        # ── Go ────────────────────────────────────────────────────────────────
        elif lang == "go":
            go_build = ssh_conn.execute_command(
                f"cd '{remote_path}' && go build ./... 2>&1 | tail -40"
            )
            checks_run.append("go build ./...")
            go_out = (go_build.get("stdout") or "").strip()
            go_exit = go_build.get("exit_code") or 0
            if go_exit != 0 and go_out:
                errors.append(f"[go build] exit={go_exit} {go_out[-2000:]}")

        # ── Rust ──────────────────────────────────────────────────────────────
        elif lang == "rust":
            cargo_check = ssh_conn.execute_command(
                f"cd '{remote_path}' && cargo check 2>&1 | tail -40"
            )
            checks_run.append("cargo check")
            cargo_out = (cargo_check.get("stdout") or "").strip()
            cargo_exit = cargo_check.get("exit_code") or 0
            if cargo_exit != 0 and cargo_out:
                errors.append(f"[cargo check] exit={cargo_exit} {cargo_out[-2000:]}")

        # ── Generic fallback ──────────────────────────────────────────────────
        else:
            logger.info("[run_tests_on_remote] no specific test runner for language '%s'; skipping", lang)
            checks_run.append(f"(no runner for {lang})")

        passed = len(errors) == 0
        return {"passed": passed, "errors": errors, "checks_run": checks_run}

    @staticmethod
    def _extract_deprecated_patterns(content: str, to_version: str) -> List[str]:
        """
        Extract known-deprecated symbol names from RAG migration content for
        *to_version* so they can be grepped in the migrated code as a regression check.
        """
        # Hardcoded critical patterns per version (augmented by RAG content parsing)
        version_patterns: Dict[str, List[str]] = {
            "8.0": ["each(", "create_function(", "__autoload(", "ReflectionParameter::getClass("],
            "8.1": ["Fiber::getCurrent()", "array_key_first", "array_is_list"],
            "8.2": ["utf8_encode(", "utf8_decode(", "odbc_result_all("],
            "8.3": ["mt_rand(", "str_split("],
            "7.0": ["mysql_connect(", "mysql_query(", "ereg(", "split("],
            "7.1": ["mcrypt_encrypt(", "mcrypt_decrypt("],
            "7.2": ["create_function(", "each("],
            "7.4": ["FILTER_SANITIZE_MAGIC_QUOTES", "get_magic_quotes_gpc("],
        }
        patterns = list(version_patterns.get(to_version, []))

        # Also parse RAG content for "deprecated" symbol mentions
        import re as _re
        for m in _re.finditer(
            r"`([a-zA-Z_][a-zA-Z0-9_:>-]*\(?\)?)`\s+(?:is\s+)?(?:deprecated|removed)",
            content,
            _re.IGNORECASE,
        ):
            sym = m.group(1).rstrip("()")
            if sym and sym not in patterns:
                patterns.append(sym)

        return patterns

    def _run_correction_pass(
        self,
        stage: "MigrationStage",
        local_project_path: Path,
        test_errors: List[str],
        attempt: int,
    ) -> None:
        """
        Ask the LLM to fix PHP files that caused test failures after a migration stage.
        Overwrites the failing files in-place in *local_project_path*.

        Only files mentioned in *test_errors* are re-edited (targeted correction).
        """
        if not test_errors:
            return

        # Extract file paths from error lines.
        # IMPORTANT: error paths are REMOTE paths (on the client SSH server).
        #            We must map them to LOCAL paths (on the Mira Docker container).
        # PHP -l format: "Parse error: ... in /remote/path/file.php on line N"
        # Handle both absolute (/path/file.php) and relative (app/file.php) forms.
        import re as _re
        affected_files: List[Path] = []
        seen_names: set = set()
        # Pattern handles: /absolute/path.php, relative/path.php, 'quoted/path.php'
        _err_path_re = _re.compile(
            r"in\s+['\"]?([^\s'\"\n]+\.php)['\"]?\s+on\s+line",
            _re.IGNORECASE,
        )
        for err_line in test_errors:
            m = _err_path_re.search(err_line)
            if m:
                remote_path_str = m.group(1)
                remote_candidate = Path(remote_path_str)
                filename = remote_candidate.name
                if filename in seen_names:
                    continue
                seen_names.add(filename)

                # Strategy 1: try last 2 path segments as relative path
                parts = remote_candidate.parts
                if len(parts) >= 3:
                    tail = Path(*parts[-2:])  # e.g. "controllers/HomeController.php"
                    local_match = local_project_path / tail
                    if local_match.exists():
                        affected_files.append(local_match)
                        continue
                # Strategy 2: try last 3 segments
                if len(parts) >= 4:
                    tail3 = Path(*parts[-3:])
                    local_match3 = local_project_path / tail3
                    if local_match3.exists():
                        affected_files.append(local_match3)
                        continue
                # Strategy 3: search by filename across local project tree
                matches = list(local_project_path.rglob(filename))
                matches = [f for f in matches if not any(x in f.parts for x in ("vendor", "node_modules"))]
                if matches:
                    affected_files.extend(matches[:1])
                    continue
                logger.warning(
                    "[new_version_upgradation_agent] correction pass: could not map remote path '%s' to any local file",
                    remote_path_str,
                )

        # Fallback: re-edit ALL php files if we couldn't isolate which ones failed
        if not affected_files:
            logger.warning(
                "[new_version_upgradation_agent] correction pass %d: could not isolate files from errors — "
                "re-editing all PHP files",
                attempt,
            )
            affected_files = [
                f for f in local_project_path.rglob("*.php")
                if not any(x in f.parts for x in ("vendor", "node_modules", ".git"))
            ]

        error_summary = "\n".join(test_errors[:20])
        correction_system = (
            "You are a PHP correction agent. Given PHP source code and specific parse/test errors "
            f"from migrating to PHP {stage.to_version}, output ONLY the corrected PHP source. "
            "Do not include any explanation, markdown fences, or commentary — only the raw PHP code."
        )

        for php_file in affected_files[:30]:  # cap to avoid runaway
            if not php_file.exists():
                continue
            try:
                original_code = php_file.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            correction_prompt = (
                f"These errors occurred after migrating this file to PHP {stage.to_version}:\n\n"
                f"{error_summary}\n\n"
                f"Fix the code so it is valid PHP {stage.to_version}. "
                f"Return ONLY the corrected PHP source.\n\n"
                f"FILE: {php_file.relative_to(local_project_path)}\n\n"
                f"{original_code}"
            )

            corrected = self.groq_client.generate(
                system_prompt=correction_system,
                user_content=correction_prompt,
                temperature=0.3,
            )

            if corrected and corrected.strip():
                # Strip accidental markdown fences
                if corrected.strip().startswith("```"):
                    lines = corrected.strip().splitlines()
                    corrected = "\n".join(
                        ln for ln in lines if not ln.strip().startswith("```")
                    )
                php_file.write_text(corrected, encoding="utf-8")
                logger.info(
                    "[new_version_upgradation_agent] correction pass %d: rewrote %s",
                    attempt, php_file.relative_to(local_project_path),
                )

    def _run_stage_with_correction(
        self,
        stage: "MigrationStage",
        local_project_path: Path,
        ssh_conn,
        remote_stage_dir: str,
        language: str = "php",
    ) -> Dict[str, Any]:
        """
        Run one migration stage with a cyclic correction loop.

        IMPORTANT — local vs remote:
          local_project_path  = directory on the MIRA DOCKER CONTAINER (temp staging area)
          remote_stage_dir    = directory on the CLIENT SSH SERVER (final output)

        Cycle per attempt:
            1. Upload: local (Docker container) → remote (client SSH server) via SFTP
            2. Test:   run syntax/tests on the CLIENT SSH SERVER via SSH (language-aware)
            3. If all tests pass → return success
            4. If tests fail → LLM corrects files in LOCAL (Docker container) temp dir
                               → loop back to step 1 to re-upload corrected files

        Max attempts = MAX_STAGE_RETRIES (default 3, env MIRA_MAX_STAGE_RETRIES).
        """
        for attempt in range(1, self.MAX_STAGE_RETRIES + 1):
            logger.info(
                "[new_version_upgradation_agent] _run_stage_with_correction: "
                "stage %d %s %s→%s attempt %d/%d — uploading from container:%s to client:%s",
                stage.stage_index, language.upper(), stage.from_version, stage.to_version,
                attempt, self.MAX_STAGE_RETRIES,
                local_project_path, remote_stage_dir,
            )

            # Step 1: Upload local (Docker container) → remote (client SSH server) via SFTP
            upload_ok = push_local_tree_to_remote(ssh_conn, local_project_path, remote_stage_dir)
            if not upload_ok:
                logger.error(
                    "[new_version_upgradation_agent] _run_stage_with_correction: upload failed (attempt %d)",
                    attempt,
                )
                if attempt >= self.MAX_STAGE_RETRIES:
                    return {
                        "success": False,
                        "attempts": attempt,
                        "test_results": {},
                        "error": f"SSH upload failed after {attempt} attempt(s) for stage {stage.stage_index}.",
                    }
                continue

            # Step 2: Run tests on CLIENT SSH SERVER (not on Mira container)
            test_results = self.run_tests_on_remote(ssh_conn, remote_stage_dir, language=language)
            logger.info(
                "[new_version_upgradation_agent] _run_stage_with_correction: "
                "stage %d attempt %d tests passed=%s checks=%s",
                stage.stage_index, attempt, test_results["passed"], test_results["checks_run"],
            )

            if test_results["passed"]:
                return {
                    "success": True,
                    "attempts": attempt,
                    "test_results": test_results,
                    "error": None,
                }

            # Tests failed
            logger.warning(
                "[new_version_upgradation_agent] _run_stage_with_correction: "
                "stage %d attempt %d FAILED — %d error(s): %s",
                stage.stage_index, attempt, len(test_results["errors"]),
                test_results["errors"][:3],
            )

            if attempt >= self.MAX_STAGE_RETRIES:
                return {
                    "success": False,
                    "attempts": attempt,
                    "test_results": test_results,
                    "error": (
                        f"Stage {stage.stage_index} ({language.upper()} {stage.from_version}→{stage.to_version}) "
                        f"tests failed after {attempt} correction attempt(s). "
                        f"Errors: {test_results['errors'][:5]}"
                    ),
                }

            # Step 4: LLM corrects files in LOCAL (Docker container) temp dir.
            # The corrected files will be re-uploaded at the top of the next loop iteration.
            logger.info(
                "[new_version_upgradation_agent] _run_stage_with_correction: "
                "running LLM correction on LOCAL container files (attempt %d → %d)",
                attempt, attempt + 1,
            )
            self._run_correction_pass(stage, local_project_path, test_results["errors"], attempt)
            # Next iteration will re-upload (step 1) then re-test (step 2)

        # Should not reach here but satisfy type checker
        return {
            "success": False,
            "attempts": self.MAX_STAGE_RETRIES,
            "test_results": {},
            "error": f"Exhausted {self.MAX_STAGE_RETRIES} correction attempts for stage {stage.stage_index}.",
        }

    # =========================================================================
    # END: REMOTE TEST RUNNER & CYCLIC CORRECTION LOOP
    # =========================================================================

    def _llm_digest_migration_chunk(
        self, excerpt: str, to_version: str, part_label: str
    ) -> str:
        """One LLM pass over a slice of php.net migration text so nothing is skipped by heuristics."""
        return self.groq_client.generate(
            system_prompt=(
                "You are a technical editor extracting **actionable** facts from official PHP.net migration text. "
                "Read the **meaning** of each sentence (rules, warnings, examples, backward-compatibility notes) — not a shallow pass over characters. "
                "A downstream LLM will edit PHP source one file at a time using only your output — be **exhaustive** for THIS excerpt. "
                "Read the user excerpt **completely** (start to finish); do not skip trailing sections. "
                "The editor is instructed to **apply** these facts as real code changes when symbols appear — missing facts causes skipped upgradations.\n\n"
                "Output **only** the following Markdown sections (use `— none in this excerpt` if a section has nothing):\n"
                "## BREAKING_AND_INCOMPATIBLE\n"
                "Bullets: what broke, affected symbols (functions/classes/constants/ini keys), and exact before→after if the text gives it.\n"
                "## DEPRECATED_AND_REMOVALS\n"
                "Bullets: what is deprecated or removed in this version step, replacement API, and migration note.\n"
                "## SYNTAX_AND_LANGUAGE\n"
                "Bullets: parser, keywords, types, operators, traits, exceptions — anything that changes valid PHP.\n"
                "## INI_AND_RUNTIME\n"
                "Bullets: php.ini, engine flags, default values, SAPI behavior.\n"
                "## EXTENSIONS\n"
                "Bullets: ext-* additions/removals/moved functions.\n"
                "## SEARCH_HINTS\n"
                "Comma-separated list of function names, ini keys, and error substrings a code search should look for.\n\n"
                "Rules: copy **exact** PHP identifiers from the source text; never invent version numbers beyond PHP "
                f"{to_version}; no introduction or summary paragraph."
            ),
            user_content=(
                f"{part_label}\n\n"
                f"Target version for this migration step: **PHP {to_version}**.\n"
                f"Extract every **semantically relevant** rule and fact from the prose below (what the documentation **says** must change in code or runtime).\n\n---\n{excerpt}"
            ),
            temperature=0.7,
        )

    def _materialize_migration_guide_for_file_prompts(self, to_version: str) -> str:
        """
        Build the migration section for per-file prompts: use the full combined guide when it fits;
        otherwise run the LLM once per chunk (every .txt file from the planner is represented —
        chunks are built from ``--- FILE:`` sections, not keyword search).
        """
        guide = (self.stage_migration_guide or "").strip()
        if not guide:
            return "Not available (no migration documentation loaded for this stage)."

        if len(guide) <= _FULL_MIGRATION_INLINE_MAX_CHARS:
            logger.info(
                "[new_version_upgradation_agent] materialize php.net migration PHP %s: "
                "inline full guide (%s chars)",
                to_version,
                len(guide),
            )
            text = guide
        else:
            blocks = _split_migration_guide_by_file_headers(guide)
            chunks = _pack_blocks_into_chunks(blocks, _MIGRATION_LLM_CHUNK_INPUT_CHARS)
            logger.info(
                "[new_version_upgradation_agent] materialize PHP %s: %s doc block(s) → %s LLM chunk(s)",
                to_version,
                len(blocks),
                len(chunks),
            )
            digests: List[str] = []
            for i, ch in enumerate(chunks, 1):
                label = f"[Migration documentation chunk {i}/{len(chunks)}]"
                logger.info(
                    "[new_version_upgradation_agent] materialize: digest chunk %s/%s (~%s chars)",
                    i,
                    len(chunks),
                    len(ch),
                )
                digests.append(
                    self._llm_digest_migration_chunk(ch, to_version, label).strip()
                )
            text = "\n\n".join(digests)
            logger.info(
                "[new_version_upgradation_agent] materialize: all digests merged (~%s chars)",
                len(text),
            )

        out = _format_labeled_doc_parts(text, _MIGRATION_IN_FILE_PROMPT_MAX_CHARS, "PHP MIGRATION (php.net)")
        logger.info(
            "[new_version_upgradation_agent] materialize: labeled parts ready (~%s chars total)",
            len(out),
        )
        return out

    def _get_stage_migration_context(self) -> str:
        if self._materialized_stage_migration_for_prompt:
            return self._materialized_stage_migration_for_prompt
        if self.stage_migration_guide:
            return self.stage_migration_guide
        return "Not available (no migration documentation loaded for this stage)."

    def _llm_extract_stage_source_chunk(
        self,
        stage: MigrationStage,
        source_kind: str,
        part_label: str,
        excerpt: str,
    ) -> str:
        """One LLM pass over a contiguous slice of raw php.net bundle or Laravel text."""
        ex = (excerpt or "").strip()
        if not ex:
            return ""
        return (
            self.groq_client.generate(
                system_prompt=(
                    f"You extract **every** actionable technical fact from **one** contiguous excerpt for PHP "
                    f"**{stage.from_version}** → **{stage.to_version}**. Source: **{source_kind}**. "
                    "Later steps merge many excerpts — **do not skip** facts that appear in this excerpt.\n\n"
                    "Output **only** Markdown:\n"
                    "## FACTS\n"
                    "Bullets: symbols, rule ids, paths, before→after, remediations — use **exact** identifiers from the text.\n"
                    "## PATH_OR_RULE_HINTS\n"
                    "Short lines tying facts to file paths or guide sections.\n"
                    "If nothing applies: `— none —` under FACTS."
                ),
                user_content=f"{part_label}\n\n---\n{ex}",
                temperature=0.7,
                max_tokens=_STAGE_DOC_CHUNK_EXTRACT_MAX_TOKENS,
            )
            or ""
        ).strip()

    def _llm_merge_two_stage_extracts(self, stage: MigrationStage, left: str, right: str) -> str:
        a, b = (left or "").strip(), (right or "").strip()
        if not a:
            return b
        if not b:
            return a
        return (
            self.groq_client.generate(
                system_prompt=(
                    f"Merge two Markdown fact extracts for the same PHP migration stage "
                    f"**{stage.from_version}** → **{stage.to_version}**. "
                    "Deduplicate identical bullets; **keep** all distinct technical items from both sides. "
                    "Preserve exact symbols (functions, classes, ini keys, rule keys). "
                    "Output **only** merged Markdown with headings ## FACTS and ## PATH_OR_RULE_HINTS "
                    "(same structure as inputs)."
                ),
                user_content=f"--- EXTRACT A ---\n{a}\n\n--- EXTRACT B ---\n{b}",
                temperature=0.7,
                max_tokens=_STAGE_DOC_MERGE_PAIR_MAX_TOKENS,
            )
            or ""
        ).strip()

    def _tree_merge_stage_extracts(self, stage: MigrationStage, fragments: List[str]) -> str:
        work = [f.strip() for f in fragments if f.strip()]
        if not work:
            return ""
        level = 0
        while len(work) > 1:
            level += 1
            nxt: List[str] = []
            for i in range(0, len(work), 2):
                if i + 1 < len(work):
                    logger.info(
                        "[new_version_upgradation_agent] Phase 1 merge tree level %s: combining pair into one blob",
                        level,
                    )
                    nxt.append(
                        self._llm_merge_two_stage_extracts(stage, work[i], work[i + 1])
                    )
                else:
                    nxt.append(work[i])
            work = nxt
        return work[0]

    def _llm_finalize_stage_analysis_from_facts(self, stage: MigrationStage, merged_facts: str) -> str:
        mf = (merged_facts or "").strip()
        if not mf:
            return ""
        user = f"""You are the **exhaustive documentation analysis** step for **one** PHP migration stage. Per-file code
editors run **after** you. The block below is a **merged digest** produced by reading the **entire** raw php.net bundle
for this stage and **entire** Laravel guide (when applicable) in **55k-char chunks** with no truncation — every chunk was
processed. **No SonarQube** — sources are documentation only.

**Stage:** PHP **{stage.from_version}** → **{stage.to_version}**
**php.net bundle folder:** `{stage.folder_name}/`

## MERGED_FACTS_FROM_ALL_CHUNKS (complete coverage — do not invent facts not grounded here)
{mf}

---

Output **only** Markdown using **exactly** these headings in order:

## STAGE_SUMMARY
Several paragraphs: language + framework scope of this hop, risk level, and how php.net + Laravel interact for this hop.

## PHP_NET_BREAKING_AND_INCOMPATIBLE
Exhaustive numbered list (symbol / behavior → required code/runtime action) from the merged facts.

## PHP_NET_DEPRECATED_AND_REMOVALS
Exhaustive list: deprecated/removed APIs → replacement or migration path.

## PHP_NET_SYNTAX_TYPES_AND_LANGUAGE
Parser, types, operators, attributes, exceptions, coercions.

## PHP_NET_INI_AND_RUNTIME
Every php.ini / engine / SAPI / default value change reflected in the facts.

## PHP_NET_EXTENSIONS
Extension add/remove/move/rename and affected functions.

## PHP_NET_SYMBOL_INDEX
Alphabetical or grouped quick index: `symbol` → one-line action (dedupe only true duplicates).

## LARAVEL_PHP_AND_VERSION_NOTES
From merged facts — or `N/A (non-Laravel)`.

## LARAVEL_BREAKING_AND_REMOVALS
Detailed bullets — or `N/A (non-Laravel)`.

## LARAVEL_CONFIG_COMPOSER_ENV
`composer.json`, `config/*`, `.env` — or `N/A`.

## LARAVEL_STEP_BY_STEP_FOR_CODEBASE
Numbered steps — or `N/A`.

## PATH_AND_FILE_FOCUS
Where to look first with **technical justification**.

## CROSS_SOURCE_INTERACTIONS
Overlaps/conflicts between php.net and Laravel; resolution order (PHP semantics → framework → style).

## PER_FILE_EDITOR_MANDATES
25–80 imperative bullets: concrete checks **every** per-file pass must perform, derived **only** from merged facts.

## EXHAUSTIVENESS_DECLARATION
Confirm coverage of **all** chunk-derived themes (not just the first excerpt).
"""
        return (
            self.groq_client.generate(
                system_prompt=(
                    "You produce an **exhaustive, technical** migration brief for senior engineers. "
                    "The user merged facts come from **full** sources processed in chunks — your output must reflect "
                    "**all** of that content. No high-level hand-waving; no empty sections without "
                    "`— none stated in merged facts —`. Use precise identifiers. "
                    "Output **only** the Markdown sections requested, in order; no preamble."
                ),
                user_content=user,
                temperature=0.7,
                max_tokens=_STAGE_DOC_ANALYSIS_MAX_TOKENS,
            )
            or ""
        ).strip()

    def _run_llm_stage_documentation_analysis(self, stage: MigrationStage) -> str:
        """
        Phase 1: **raw** php.net bundle + Laravel (if any), each split into 55k-char chunks.
        Each chunk → extract LLM → tree-merge → one final formatter LLM. **No truncation** of source text.
        Logged at INFO; full analysis (labeled PARTs if long) is injected into every per-file upgradation prompt.
        """
        try:
            mig_raw = (self.stage_migration_guide or "").strip()
            if not mig_raw:
                mig_raw = (self._get_stage_migration_context() or "").strip()
            laravel = (
                (self.laravel_upgrade_guide or "").strip()
                if self._is_laravel_project
                else ""
            )

            extracts: List[str] = []

            mig_chunks = _chunk_text_contiguous(mig_raw, _DOC_CONTEXT_CHUNK_MAX_CHARS)
            for i, ch in enumerate(mig_chunks):
                logger.info(
                    "[new_version_upgradation_agent] Phase 1 extract php.net bundle chunk %s/%s (~%s chars)",
                    i + 1,
                    len(mig_chunks),
                    len(ch),
                )
                extracts.append(
                    self._llm_extract_stage_source_chunk(
                        stage,
                        "PHP.net migration bundle (raw)",
                        f"PHP.net bundle part {i + 1} of {len(mig_chunks)}",
                        ch,
                    )
                )

            if laravel:
                laravel_chunks = _chunk_text_contiguous(laravel, _DOC_CONTEXT_CHUNK_MAX_CHARS)
                for i, ch in enumerate(laravel_chunks):
                    logger.info(
                        "[new_version_upgradation_agent] Phase 1 extract Laravel chunk %s/%s (~%s chars)",
                        i + 1,
                        len(laravel_chunks),
                        len(ch),
                    )
                    extracts.append(
                        self._llm_extract_stage_source_chunk(
                            stage,
                            "Laravel upgrade guide",
                            f"Laravel guide part {i + 1} of {len(laravel_chunks)}",
                            ch,
                        )
                    )

            merged = self._tree_merge_stage_extracts(stage, extracts)
            if not merged.strip():
                logger.warning(
                    "[new_version_upgradation_agent] Phase 1: no merged facts for stage %s",
                    stage.stage_index,
                )
                return ""
            out = self._llm_finalize_stage_analysis_from_facts(stage, merged)
            return (out or "").strip()
        except Exception as e:
            logger.error(
                "[new_version_upgradation_agent] _run_llm_stage_documentation_analysis: failed stage=%s — %s",
                stage.stage_index,
                e,
            )
            return ""

    def _get_laravel_guide_context(self, part_chars: int = _DOC_CONTEXT_CHUNK_MAX_CHARS) -> str:
        guide = (self.laravel_upgrade_guide or "").strip()
        if guide:
            return _format_labeled_doc_parts(guide, part_chars, "LARAVEL UPGRADE GUIDE")
        if self._is_laravel_project:
            return (
                "(Internal error: Laravel project but upgrade guide empty — load_reports should have failed.)"
            )
        return (
            "## Status: **NON-LARAVEL PROJECT** (no Laravel upgrade guide for this stage)\n\n"
            "This codebase was **not** detected as a Laravel application (`composer.json` lacks `laravel/framework` / "
            "`lumen` and sampled PHP has no `Illuminate\\` namespace). **Skip all Laravel-specific upgrade steps.**\n\n"
            "Apply **PHP MIGRATION** only for php.net rules. In MIRA_NOTES_JSON add: "
            "`[Laravel] N/A — non-Laravel project; framework section skipped.`"
        )

    def _get_project_structure_context(self, current_file_path: str) -> str:
        if not self.project_structure or not self.project_structure.get("files"):
            return "Project structure not available (single file or not yet analyzed)."
        total = self.project_structure.get("total_files", 0)
        files = self.project_structure.get("files", [])
        lines = [f"Total PHP files in project: {total}", ""]
        for f in files[:200]:
            path = f.get("path", "")
            size = f.get("size", 0)
            marker = "  <-- CURRENT FILE" if path == current_file_path else ""
            lines.append(f"  - {path} ({size:,} chars){marker}")
        if len(files) > 200:
            lines.append(f"  ... and {len(files) - 200} more files")
        return "\n".join(lines)

    def _llm_build_modernization_checklist(
        self,
        file_path: str,
        code: str,
        to_version: str,
        *,
        guide_text: str,
        laravel_text: str,
        phase1_excerpt: str,
        stage_from_version: Optional[str],
        stage_doc_folder: Optional[str],
    ) -> List[Dict[str, Any]]:
        """
        One LLM call: exhaustive **task list** for this file — php.net items whose symbols appear in CURRENT CODE,
        and Laravel items that match real usage when applicable.
        """
        hop = (
            f"PHP {stage_from_version} → **{to_version}**"
            if stage_from_version
            else f"target **PHP {to_version}**"
        )
        folder = stage_doc_folder or "(see PHP MIGRATION text)"
        user = f"""Build an **exhaustive per-file version-upgradation checklist** for **one** file.

**File:** `{file_path}`
**Stage hop:** {hop}
**php.net bundle folder (if any):** `{folder}`

Return **only** valid JSON (no markdown fences, no commentary) with this exact shape:
{{"tasks":[{{"id":"string","pillar":"php|laravel","summary":"string","remediation":"string"}}]}}

### Task rules
1. **pillar `php`**: One task per **php.net migration** item in the PHP MIGRATION text that **matches a symbol, function, ini name, or pattern present in CURRENT CODE**. Do **not** add tasks for APIs/extensions that do **not** appear in this file.
2. **pillar `laravel`**: One task per Laravel guide step that matches **actual** `Illuminate\\`, facades, or framework patterns in CURRENT CODE. If the project is plain PHP / Laravel N/A in the excerpt, add **no** laravel tasks.

### CURRENT CODE
```php
{code}
```

### PHP MIGRATION (this stage)
{guide_text}

### LARAVEL
{laravel_text}

### PHASE 1 (path-focused excerpt; may be empty)
{phase1_excerpt or "(none)"}
"""
        raw = self.groq_client.generate(
            system_prompt=(
                "You output **only** a single JSON object with key `tasks` (array of objects). "
                "Each task: id, pillar (php|laravel), summary, remediation. Be exhaustive for this file only."
            ),
            user_content=user,
            temperature=0.7,
            max_tokens=_MODERNIZE_CHECKLIST_MAX_TOKENS,
        )
        obj = _extract_json_object(raw or "")
        if not obj:
            return []
        return _normalize_modernization_tasks(obj.get("tasks"))

    def _llm_apply_modernization_task_batch(
        self,
        file_path: str,
        code: str,
        to_version: str,
        tasks: List[Dict[str, Any]],
    ) -> Tuple[str, List[str]]:
        """Apply a batch of checklist tasks to the current file body via MIRA output."""
        if not tasks:
            return code, []
        tasks_json = json.dumps(tasks, ensure_ascii=False, indent=2)
        user = f"""Apply **every** task in the JSON array to the source below. Tasks were pre-scoped to **`{file_path}`**
and **PHP {to_version}**.

### TASKS (complete this batch)
{tasks_json}

### Rules
- Output **only** {_MIRA_PHP_START} … full updated file … {_MIRA_PHP_END} then {_MIRA_NOTES_JSON_START} JSON array … {_MIRA_NOTES_JSON_END}.
- Implement **all** applicable tasks in MIRA_PHP (minimal edits are fine). If a task is already satisfied, add a note instead of a no-op claim.
- Prefix each note string with `[PHP]` or `[Laravel]` to match `pillar`.
- For `*.blade.php`, preserve valid Blade/HTML.

### CURRENT CODE
```php
{code}
```
"""
        out = self.groq_client.generate(
            system_prompt=(
                "You apply a fixed checklist batch to one file. Output **only** the two MIRA tag blocks; "
                "full file first, JSON notes second."
            ),
            user_content=user,
            temperature=0.7,
            max_tokens=_MODERNIZE_CHECKLIST_APPLY_MAX_TOKENS,
        )
        parsed = _parse_mira_tagged_response(out, code)
        if parsed is None:
            return code, [f"[Checklist batch] MIRA parse failed ({len(tasks)} task(s))"]
        return parsed[0], parsed[1]

    def _modernize_file_via_checklist(
        self,
        code: str,
        file_path: str,
        to_version: str,
        *,
        stage_from_version: Optional[str] = None,
        stage_doc_folder: Optional[str] = None,
    ) -> Tuple[str, List[str]]:
        guide_raw = self._get_stage_migration_context()
        if len(guide_raw) > _MODERNIZE_CHECKLIST_GUIDE_MAX:
            guide_raw = guide_raw[:_MODERNIZE_CHECKLIST_GUIDE_MAX] + "\n\n[... migration truncated for checklist ...]"
        laravel_raw = self._get_laravel_guide_context()
        if len(laravel_raw) > _MODERNIZE_CHECKLIST_LARAVEL_MAX:
            laravel_raw = (
                laravel_raw[:_MODERNIZE_CHECKLIST_LARAVEL_MAX]
                + "\n\n[... laravel truncated for checklist ...]"
            )
        analysis = (self._stage_documentation_analysis or "").strip()
        if analysis:
            p1 = _phase1_focus_lines_for_file(analysis, file_path)
            if len(p1) > _MODERNIZE_CHECKLIST_PHASE1_MAX:
                p1 = p1[:_MODERNIZE_CHECKLIST_PHASE1_MAX] + "\n[...]"
        else:
            p1 = ""

        tasks = self._llm_build_modernization_checklist(
            file_path,
            code,
            to_version,
            guide_text=guide_raw,
            laravel_text=laravel_raw,
            phase1_excerpt=p1,
            stage_from_version=stage_from_version,
            stage_doc_folder=stage_doc_folder,
        )
        if not tasks:
            raise ValueError("empty upgradation checklist")

        logger.info(
            "[new_version_upgradation_agent] checklist pipeline %s: %s task(s), batch_size=%s",
            file_path,
            len(tasks),
            _MODERNIZE_CHECKLIST_BATCH_SIZE,
        )
        code_curr = code
        all_notes: List[str] = []
        for i in range(0, len(tasks), _MODERNIZE_CHECKLIST_BATCH_SIZE):
            batch = tasks[i : i + _MODERNIZE_CHECKLIST_BATCH_SIZE]
            code_curr, notes = self._llm_apply_modernization_task_batch(
                file_path, code_curr, to_version, batch
            )
            if notes:
                all_notes.extend(notes)

        if not all_notes:
            all_notes = [f"[Checklist] Applied {len(tasks)} task(s) in batched passes for `{file_path}`"]

        return code_curr, all_notes

    def _structured_synthesis_emission(
        self,
        file_path: str,
        to_version: str,
        original_code: str,
        intent_notes: List[str],
        *,
        followup: bool = False,
    ) -> Tuple[str, List[str]]:
        """
        Second-stage call: original file + closed INTENT list → MIRA-tagged output.
        ``followup=True`` appends a short gentle nudge when the first pass left the body unchanged.
        On parse failure, returns ``(original_code, intent_notes)`` so notes are never discarded.
        """
        notes_json = json.dumps(intent_notes, ensure_ascii=False, indent=2)
        follow_block = ""
        if followup:
            follow_block = """

### Follow-up
The last attempt still matched ORIGINAL. Please try again: for **each** INTENT line that applies to this file, apply the
**smallest** change that satisfies it (one line, one word, or removing one commented line is enough). **Tiny edits count.**
If no INTENT applies to this file, keep ORIGINAL and use `[]` for JSON.
"""
        user = f"""## Structured emission (pipeline stage 2)

You receive **only** the original file and a JSON list of edits. Implement **every** applicable item **in the source** —
**minimal edits are welcome** (a single-line fix is a complete success).

**File:** `{file_path}`
**Target PHP:** {to_version}

### INTENT (JSON array — each applicable item → visible change in MIRA_PHP, even if minimal)
{notes_json}

### ORIGINAL
```php
{original_code}
```
{follow_block}
### Required response (copy markers exactly; **MIRA_PHP first**, then JSON — same as main modernization)

{_MIRA_PHP_START}
<?php
… full file …
{_MIRA_PHP_END}
{_MIRA_NOTES_JSON_START}
["[PHP]/[Laravel] one line per edit you applied in MIRA_PHP", "..."]
{_MIRA_NOTES_JSON_END}

Rules:
- Emit **complete** MIRA_PHP first, then JSON that **only** describes diffs you actually made in that PHP vs ORIGINAL.
- MIRA_PHP must be valid for **{to_version}** (and for `*.blade.php`, keep Blade/HTML valid alongside embedded PHP).
- If an INTENT string does not apply to this file, omit it from the JSON array; if **any** INTENT applies, MIRA_PHP **must** differ from ORIGINAL (normalized newlines) — **even a minimal diff**.
- If **no** INTENT applies, copy ORIGINAL verbatim into MIRA_PHP and use `[]` for JSON.
"""
        sys = (
            "You are a **structured emission** engine: given ORIGINAL and a fixed INTENT list, output **only** two blocks: "
            f"(1) {_MIRA_PHP_START}…{_MIRA_PHP_END} full file first, "
            f"(2) {_MIRA_NOTES_JSON_START}…{_MIRA_NOTES_JSON_END} JSON array second. "
            "Apply **every** applicable intent as **real** source changes; the smallest sufficient edit is enough. "
            "No Markdown ### headings, no ```php fences, no prose."
        )
        out = self.groq_client.generate(
            system_prompt=sys,
            user_content=user,
            temperature=0.7,
            max_tokens=_STRUCTURED_SYNTHESIS_MAX_TOKENS,
        )
        parsed = _parse_mira_tagged_response(out, original_code)
        if parsed is None:
            return original_code, list(intent_notes)
        return parsed[0], parsed[1]

    def _modernize_file(
        self,
        code: str,
        file_path: str,
        to_version: str,
        *,
        stage_index: Optional[int] = None,
        stage_doc_folder: Optional[str] = None,
        stage_from_version: Optional[str] = None,
    ) -> Tuple[str, List[str]]:
        if _MODERNIZE_CHECKLIST_PIPELINE:
            try:
                return self._modernize_file_via_checklist(
                    code,
                    file_path,
                    to_version,
                    stage_from_version=stage_from_version,
                    stage_doc_folder=stage_doc_folder,
                )
            except Exception as e:
                logger.warning(
                    "[new_version_upgradation_agent] checklist upgradation failed for %s — %s; using monolithic path",
                    file_path,
                    e,
                )
        guide_context = self._get_stage_migration_context()
        laravel_context = self._get_laravel_guide_context()
        structure_context = self._get_project_structure_context(file_path)

        guide_block = f"{_llm_rubric_php_migration(to_version)}\n\n{guide_context}"
        if self._is_laravel_project:
            laravel_rubric = _llm_rubric_laravel(to_version)
            laravel_workflow = (
                "2. **Laravel framework pass (Pillar 2):** After finishing Pillar 1, read the **entire** LARAVEL section. "
                "Cross-check the guide against **CURRENT CODE** — only steps that match **actual** imports, facades, "
                "`Illuminate\\`, Eloquent, HTTP, validation, middleware, config access, or bootstrap usage **in this file** "
                "get implemented. **Implement** each applicable upgrade in **MIRA_PHP** — Laravel upgradation is real "
                "code changes, not notes. Skip only items that clearly target other files you were not given. Prefer "
                "**current** Laravel patterns from the guide (e.g. `casts()`, modern middleware registration, updated facades) "
                "when named there."
            )
            merge_order = (
                f"3. **Merge both pillars into one file:** Produce **one** MIRA_PHP body that simultaneously: "
                f"(a) satisfies **PHP {to_version}** per php.net (Pillar 1), (b) applies **Laravel** upgrades from the guide "
                f"where this file uses the framework (Pillar 2). If both touch the same lines, prefer **correct PHP "
                f"semantics**, then **Laravel contracts** — one coherent upgraded file."
            )
            input_note = (
                "**Two inputs** — analyze **both** before editing, then upgrade **once**: (1) **php.net migration** for this "
                f"stage → **PHP {to_version}**; (2) **Laravel staged guide** (when this project is Laravel) — upgrade "
                "framework usage in this file where present. **All applicable items** from both must appear in MIRA_PHP."
            )
        else:
            laravel_rubric = _llm_rubric_plain_php_no_laravel(to_version)
            laravel_workflow = (
                "2. **Laravel pass:** **Skipped** — not a Laravel app (Pillar 2 N/A). Do not apply framework upgrades; add "
                "`[Laravel] N/A` per the LARAVEL section rubric."
            )
            merge_order = (
                f"3. **Single pillar (php.net):** MIRA_PHP must apply **php.net** migration for **PHP {to_version}** "
                f"where CURRENT CODE matches the docs — one coherent upgraded file."
            )
            input_note = (
                "**One primary input** — analyze the **php.net migration** text thoroughly, then modernize **to** "
                f"**PHP {to_version}**. **Ignore** accidental Laravel-like patterns unless they already exist in this file."
            )
        laravel_block = f"{laravel_rubric}\n\n{laravel_context}"
        structure_block = f"{_llm_rubric_project_structure(file_path)}\n\n{structure_context}"
        source_analysis_block = _llm_rubric_analyze_php_source(file_path, to_version)

        stage_scope = ""
        if stage_doc_folder or stage_from_version or stage_index is not None:
            lines = [
                "## This migration stage — php.net documentation (**fresh per stage; not reused from stage 1 only**)",
            ]
            if stage_index is not None:
                lines.append(f"- **Pipeline stage index:** {stage_index}.")
            if stage_from_version:
                lines.append(f"- **PHP hop:** {stage_from_version} → **{to_version}**.")
            if stage_doc_folder:
                lines.append(
                    f"- **The `## PHP MIGRATION` section below** is built from **`{stage_doc_folder}/`** for **this hop only**. "
                    f"Each later stage loads a **different** `php_migration_*_txt` folder — analyze **this** section as new text, "
                    f"not from memory of earlier stages."
                )
            lines.append(
                "- **Strict output contract:** If MIRA_NOTES_JSON lists **non‑N/A** edit strings, **MIRA_PHP** **must** "
                "show those edits. If the file needs **no** edits for this hop, MIRA_NOTES_JSON must be **only** explicit "
                "`[PHP] N/A …`, `[Laravel] N/A …` strings (as applicable) — **never** claim edits you did not write."
            )
            stage_scope = "\n".join(lines) + "\n\n"

        doc_analysis_block = ""
        phase1_path_block = ""
        analysis_full = (self._stage_documentation_analysis or "").strip()
        if analysis_full:
            phase1_path_block = (
                "## PHASE 1 — TEXT THAT REFERENCES **THIS FILE** ONLY\n"
                f"Read this block **before** the full Phase 1 brief. Bullets about `app/Exceptions/Handler.php`, "
                f"`public/index.php`, etc. **do not** require edits in **`{file_path}`** unless the **same** pattern "
                f"exists in CURRENT CODE.\n\n"
                f"{_phase1_focus_lines_for_file(analysis_full, file_path)}\n\n---\n\n"
            )
            analysis_parts = _format_labeled_doc_parts(
                analysis_full,
                _DOC_CONTEXT_CHUNK_MAX_CHARS,
                "STAGE DOCUMENTATION ANALYSIS (Phase 1)",
            )
            doc_analysis_block = (
                "## STAGE DOCUMENTATION ANALYSIS (**Phase 1 — full brief; read every PART**)\n"
                "Phase 1 consumed the **full** raw php.net bundle for this hop and **full** Laravel guide (when applicable) "
                "in **55,000-character chunks** (no truncation). Extracts were merged, then formatted into this brief. "
                "**Read all PART sections** if present, then cross-check **PHP MIGRATION** / **LARAVEL** and CURRENT CODE.\n\n"
                f"{analysis_parts}\n---\n\n"
            )

        prompt = f"""You are upgrading **one** source file in a **staged** pipeline to **PHP {to_version}**. Your job has **two equal parts**:
1. **Compatibility** — fix all breaking/deprecated/removed patterns from the php.net migration guide.
2. **Modernization** — adopt new PHP {to_version} idioms and syntax from Pillar 1b (listed in the PHP MIGRATION section).
Both parts produce real code changes in **MIRA_PHP**. A file that compiles but still uses only old syntax is **NOT** a successful upgrade.
Describing changes without writing them in **MIRA_PHP** is failure.

{stage_scope}{phase1_path_block}{doc_analysis_block}## Stage contract
- **Target PHP for this stage only:** **{to_version}** (one hop; later stages handle newer versions).
- **Inputs:** {input_note}
- **Single-file constraint:** Output only the upgraded body for **`{file_path}`**. Do not assume sibling files will be edited; avoid edits that would break this file unless a source explicitly requires them.

## Non-negotiable rules
1. **Analyze the file's PHP code and all documents before any edit:** (A) Read **CURRENT CODE** in full. (B) Read the entire **PHP MIGRATION** section — both the php.net breaking changes AND the Pillar 1b modernization directives. (C) **Map** each item to concrete lines in CURRENT CODE; only then edit. Do not invent problems.
2. **Apply every applicable change in MIRA_PHP:** (a) **Breaking/deprecated** — fix anything in CURRENT CODE that the guide says is removed or deprecated. (b) **Pillar 1b modernization** — where CURRENT CODE uses an old pattern that PHP {to_version} replaces with a better idiom, **rewrite it**. (c) **Laravel** (when applicable) — same. **Do not skip** a change for being "too small."
3. **Identical output is almost always wrong for code that has not been previously modernized:** MIRA_PHP may equal CURRENT CODE **only** if the file genuinely has no patterns matching either breaking changes OR Pillar 1b modernizations for this version. If CURRENT CODE uses old-style constructs (e.g. `switch` that could be `match`, `list()` that could be `[]`, closures that could be arrow functions, etc.) and this stage's PHP version introduced those replacements, you **must** apply them.
4. **MIRA_PHP:** The block between `{_MIRA_PHP_START}` and `{_MIRA_PHP_END}` is the **complete** file (include `<?php` if the original did). No Markdown ``` fences for the final PHP body.
5. **Update version references in comments and docblocks:** Any `@version`, `@since`, `PHP X.Y`, `PHP_VERSION`, `Requires PHP X.Y`, or similar version strings in docblock comments (`/** ... */`) or inline comments that refer to the PHP or framework version of this file **must be updated** to reflect **PHP {to_version}**. This applies to file-level docblocks, class docblocks, and method docblocks. Do not leave old version numbers in comments after the code has been migrated.

## Analysis → upgradation workflow (ordered steps)
-1. **Stage documentation (Phase 1):** If **STAGE DOCUMENTATION ANALYSIS** appears above, read **every PART** in full. Then read **PHP MIGRATION** / **LARAVEL** **word-by-word** — all sections including Pillar 1b.
0. **This file's PHP source:** Read **CURRENT CODE** completely. Note every construct: type hints, closures, switch statements, list(), foreach, catch blocks, class properties — everything that a PHP {to_version} modernization could touch.
1. **Pillar 1 — Compatibility (php.net breaking changes):** Identify and fix all breaking/deprecated patterns present in CURRENT CODE.
1b. **Pillar 1b — Modernization (new idioms):** For each modernization directive in the PHP MIGRATION section, check if CURRENT CODE has old-style code that should be updated. **If yes, update it.** Be thorough — check every function, every loop, every property, every catch block.
{laravel_workflow}
{merge_order}
4. **Write MIRA_PHP:** Apply **all** planned edits — both compatibility fixes AND modernizations — in one coherent pass.
5. **Sanity:** Preserve behavior. Do not change logic, only syntax/idioms. Keep method signatures compatible unless the guide says otherwise.

## Self-check before you send
- You are editing **`{file_path}`** only. Phase 1 may mention other paths — only implement what **this** file's CURRENT CODE contains.
- **Before finalizing:** Scan CURRENT CODE one more time for Pillar 1b items — `switch` statements, `list()`, old closures, missing typed properties, `strpos()` checks, catch blocks — and confirm you applied every applicable modernization.
- **Version comments:** Scan for any `@version`, `@since`, `Requires PHP`, `PHP X.Y`, or similar version references in doc comments. Update them to PHP {to_version}. This is mandatory even if no code changed.
- If MIRA_PHP is unchanged from CURRENT CODE: re-read Pillar 1b and verify there is truly nothing in the file that matches. If you find even one applicable pattern, apply it.
- MIRA_NOTES_JSON must match what you **did** in MIRA_PHP. If MIRA_PHP is genuinely unchanged, every MIRA_NOTES_JSON entry must start with `N/A`.
- **Truly thin files** (e.g. a config array, a blank interface): If no construct in the file matches either breaking changes or Pillar 1b modernizations, unchanged MIRA_PHP is acceptable.

## Output contract (machine-parseable — **use these markers verbatim**)
Your reply must contain **exactly** these two tagged regions in **this order** (PHP **first**, then JSON). **No** `### CHANGES:` / `### UPGRADED CODE:` and **no** Markdown ```php fence for the file body.

{_MIRA_PHP_START}
<?php
… entire file, syntactically valid PHP for PHP {to_version} …
{_MIRA_PHP_END}
{_MIRA_NOTES_JSON_START}
["[PHP] …", "[Laravel] …"]
{_MIRA_NOTES_JSON_END}

**MIRA_NOTES_JSON rules (after you finish MIRA_PHP):**
- A **JSON array of strings** only (valid JSON between the markers).
- Each string: a **visible** change in MIRA_PHP (even minimal), **or** **N/A** for that pillar (`[PHP]` or `[Laravel]`).
- If nothing applied: e.g. `"[PHP] N/A — no migration constructs from the guide present in this file."`

---

## PROJECT STRUCTURE
{structure_block}

---

## PHP MIGRATION (this stage — php.net)
{guide_block}

---

## LARAVEL
{laravel_block}

---

## SOURCE-CODE ANALYSIS (apply to CURRENT CODE below)
{source_analysis_block}

---

## FILE TO UPGRADE
`{file_path}`

- **Application PHP** = classes, routes, config, middleware, etc. **Blade** = paths ending in `.blade.php`. MIRA_PHP must be the **entire** file; only change lines when php.net / Laravel / Phase 1 clearly applies to **this** file's text.

## CURRENT CODE
```php
{code}
```"""

        if self._is_laravel_project:
            sys_laravel = (
                "This is a **Laravel** project: you must **analyze and then apply in code** — **php.net migration** for this "
                f"stage (modernize to PHP **{to_version}** per official text) and the **Laravel upgrade guide** (upgrade "
                "framework APIs/patterns in this file where the guide applies). Implement **all** in one MIRA_PHP block."
            )
        else:
            sys_laravel = (
                f"This is **plain PHP**: apply **php.net migration** for this stage (modernize to PHP **{to_version}**). "
                "**Do not** apply or invent Laravel framework changes."
            )
        base_system = (
            f"You are a senior PHP engineer performing **version upgradation** for **PHP {to_version}** (this stage only). "
            f"{sys_laravel} "
            f"You **read the literal source** in CURRENT CODE and apply **every** applicable php.net / Laravel item "
            f"as **real edits** in MIRA_PHP. **Minimal edits are enough**. "
            f"Output **only** two blocks: (1) {_MIRA_PHP_START}…{_MIRA_PHP_END} complete file, "
            f"(2) {_MIRA_NOTES_JSON_START}…{_MIRA_NOTES_JSON_END} — notes last, matching what you changed (or N/A). "
            f"No extra commentary. Preserve behavior unless a source requires change; do not invent APIs not in the user content."
        )

        approx_chars = len(prompt) + len(base_system)
        logger.info(
            "[new_version_upgradation_agent] _modernize_file: combined system+user prompt ~%s chars for %s",
            approx_chars,
            file_path,
        )

        response = self.groq_client.generate(
            system_prompt=base_system,
            user_content=prompt,
            temperature=0.7,
            max_tokens=_MODERNIZE_FILE_MAX_TOKENS,
        )
        upgraded_code, changes, parse_mode = _parse_modernize_response_unified(response, code)
        primary_notes = list(changes)

        def _pick_preserved_notes(
            *candidates: List[str],
        ) -> List[str]:
            for c in candidates:
                if _has_substantive_modernize_change_bullets(c):
                    return list(c)
            for c in candidates:
                if c:
                    return list(c)
            return []

        if (
            _has_substantive_modernize_change_bullets(primary_notes)
            and _normalize_php_text(upgraded_code) == _normalize_php_text(code)
        ):
            preview = primary_notes[0][:180] if primary_notes else ""
            logger.info(
                "[new_version_upgradation_agent] _modernize_file: primary parse_mode=%s listed substantive edits "
                "but MIRA_PHP equals CURRENT CODE — structured synthesis (1/2) for %s; first note preview: %r",
                parse_mode,
                file_path,
                preview,
            )
            syn_code, syn_notes = self._structured_synthesis_emission(
                file_path, to_version, code, primary_notes
            )
            if _normalize_php_text(syn_code) != _normalize_php_text(code):
                upgraded_code = syn_code
                changes = (
                    syn_notes
                    if syn_notes
                    else [
                        "[Structured emission] Applied INTENT list in source after primary notes/body mismatch"
                    ]
                )
            else:
                logger.info(
                    "[new_version_upgradation_agent] _modernize_file: synthesis pass 1 unchanged body — "
                    "gentle follow-up pass (2/2) for %s",
                    file_path,
                )
                syn_code2, syn_notes2 = self._structured_synthesis_emission(
                    file_path,
                    to_version,
                    code,
                    primary_notes,
                    followup=True,
                )
                if _normalize_php_text(syn_code2) != _normalize_php_text(code):
                    upgraded_code = syn_code2
                    changes = (
                        syn_notes2
                        if syn_notes2
                        else [
                            "[Follow-up synthesis] Applied INTENT with minimal edits after two-stage synthesis"
                        ]
                    )
                else:
                    upgraded_code = code
                    changes = _pick_preserved_notes(syn_notes2, syn_notes, primary_notes)

        if (
            _has_substantive_modernize_change_bullets(changes)
            and _normalize_php_text(upgraded_code) == _normalize_php_text(code)
        ):
            logger.warning(
                "[new_version_upgradation_agent] _modernize_file: OUTPUT MISMATCH %s — MIRA_PHP still equals CURRENT "
                "CODE after primary + synthesis + follow-up. **Bullets kept** in `changes` for logs/JSON. "
                "If 429s occurred, raise GROQ_MIN_REQUEST_INTERVAL_SECONDS.",
                file_path,
            )

        return upgraded_code, changes

    def _modernize_file_chunked(
        self,
        file_path: Path,
        rel_path: str,
        to_version: str,
        *,
        stage_index: Optional[int] = None,
        stage_doc_folder: Optional[str] = None,
        stage_from_version: Optional[str] = None,
        chunk_bytes: int = 100 * 1024,
    ):
        """
        Split a large source file into line-boundary chunks, modernize each chunk
        independently via _modernize_file, then reassemble.

        Returns (original_code, upgraded_code, changes_list) so the caller can
        compute a proper diff without re-reading the file.
        """
        with open(file_path, "r", encoding="utf-8", errors="ignore") as fh:
            full_code = fh.read()

        lines = full_code.splitlines(keepends=True)
        chunks: List[List[str]] = []
        current: List[str] = []
        current_bytes = 0

        for line in lines:
            lb = len(line.encode("utf-8"))
            if current_bytes + lb > chunk_bytes and current:
                chunks.append(current)
                current = []
                current_bytes = 0
            current.append(line)
            current_bytes += lb
        if current:
            chunks.append(current)

        all_changes: List[str] = []
        upgraded_parts: List[str] = []

        for idx, chunk_lines in enumerate(chunks, 1):
            chunk_code = "".join(chunk_lines)
            chunk_label = f"{rel_path} [chunk {idx}/{len(chunks)}]"
            logger.info(
                "[new_version_upgradation_agent] _modernize_file_chunked: %s (%d bytes)",
                chunk_label, len(chunk_code.encode()),
            )
            upgraded_chunk, chunk_changes = self._modernize_file(
                chunk_code,
                chunk_label,
                to_version,
                stage_index=stage_index,
                stage_doc_folder=stage_doc_folder,
                stage_from_version=stage_from_version,
            )
            upgraded_parts.append(upgraded_chunk)
            all_changes.extend(chunk_changes)

        upgraded_code = "".join(upgraded_parts)
        return full_code, upgraded_code, all_changes

    def modernize_project(
        self,
        project_path: str,
        to_version: str,
        *,
        stage_index: Optional[int] = None,
        stage_doc_folder: Optional[str] = None,
        stage_from_version: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        When called from ``run_staged_modernization``, pass ``stage_index``, ``stage_doc_folder`` (e.g.
        ``php_migration_82_txt``), and ``stage_from_version`` so each LLM call explicitly scopes php.net docs to that hop.
        """
        if stage_index is None:
            self._stage_documentation_analysis = ""
        project_dir = Path(project_path)
        # Includes `*.blade.php` (Blade = PHP/HTML templates with directives); same pipeline, whole-file MIRA output.
        php_files = [
            f
            for f in project_dir.rglob("*.php")
            if not any(ex in f.parts for ex in ["vendor", "node_modules", ".git"])
        ]
        results: List[Dict[str, Any]] = []
        stats = {
            "total": len(php_files),
            "upgraded": 0,
            "unchanged": 0,
            "notes_kept_body_unchanged": 0,
            "errors": 0,
        }
        logger.info(
            "[new_version_upgradation_agent] modernize_project: PHASE 2 (code) start — target PHP %s — %s file(s) under %s "
            "(stage=%s doc_folder=%s)",
            to_version,
            len(php_files),
            project_dir,
            stage_index,
            stage_doc_folder or "(n/a)",
        )

        # Max bytes per file before chunking. Files above this are split so the LLM
        # never exceeds its context window. Configurable via MIRA_MAX_LLM_FILE_BYTES.
        _max_file_bytes = int(os.environ.get("MIRA_MAX_LLM_FILE_BYTES", str(200 * 1024)))

        # Cancellation check: import here to avoid circular import at module load time.
        # _is_job_cancelled reads the DB synchronously using the shared pooled client.
        try:
            from app.api.v1.agents.routes import _is_job_cancelled as _check_cancelled
            import threading as _threading
            _get_job_id = lambda: getattr(getattr(_threading, "local", lambda: None)(), "current_job_id", None)
        except Exception:
            _check_cancelled = None
            _get_job_id = lambda: None

        for i, php_file in enumerate(php_files, 1):
            # Check for user cancellation between files (every 5 files to reduce DB load)
            if i % 5 == 0 and _check_cancelled is not None:
                try:
                    import threading as _t
                    _jid = getattr(_t.current_thread(), "__dict__", {}).get("_current_job_id")
                    # Fallback: use the thread-local set by routes
                    if not _jid:
                        import app.api.v1.agents.routes as _routes_mod
                        _jid = getattr(getattr(_routes_mod, "_thread_local", None), "current_job_id", None)
                    if _jid and _check_cancelled(_jid):
                        logger.info(
                            "[new_version_upgradation_agent] modernize_project: job %s was cancelled — stopping at file %s/%s",
                            _jid, i, len(php_files),
                        )
                        stats["cancelled_at_file"] = i
                        break
                except Exception:
                    pass  # Never block migration on cancellation check failure

            rel_path = php_file.relative_to(project_dir)
            file_size = php_file.stat().st_size
            logger.info(
                "[new_version_upgradation_agent] modernize_project: file %s/%s %s (%d bytes)",
                i, len(php_files), rel_path, file_size,
            )
            try:
                # Large file: read in chunks, modernize each chunk separately, reassemble.
                # This prevents exceeding Groq's context window on 10k+ line files.
                if file_size > _max_file_bytes:
                    logger.info(
                        "[new_version_upgradation_agent] modernize_project: large file %s "
                        "(%d bytes > %d limit) — chunking",
                        rel_path, file_size, _max_file_bytes,
                    )
                    original_code, upgraded_code, changes = self._modernize_file_chunked(
                        php_file, str(rel_path), to_version,
                        stage_index=stage_index,
                        stage_doc_folder=stage_doc_folder,
                        stage_from_version=stage_from_version,
                        chunk_bytes=_max_file_bytes // 2,
                    )
                else:
                    with open(php_file, "r", encoding="utf-8", errors="ignore") as f:
                        original_code = f.read()
                    upgraded_code, changes = self._modernize_file(
                        original_code,
                        str(rel_path),
                        to_version,
                        stage_index=stage_index,
                        stage_doc_folder=stage_doc_folder,
                        stage_from_version=stage_from_version,
                    )
                # Stats from actual body diff: ### CHANGES: bullets alone can lie if the model skips ```php edits.
                orig_n = _normalize_php_text(original_code)
                new_n = _normalize_php_text(upgraded_code)
                code_changed = orig_n != new_n
                notes_substantive = _has_substantive_modernize_change_bullets(changes)
                results.append(
                    {
                        "path": str(rel_path),
                        "code": upgraded_code,
                        "changes": changes,
                        "php_body_changed": code_changed,
                        "substantive_change_notes": notes_substantive,
                    }
                )
                if code_changed:
                    stats["upgraded"] += 1
                    logger.info(
                        "[new_version_upgradation_agent] modernize_project:   upgraded (file diff) %s "
                        "change_bullets=%s",
                        rel_path,
                        len(changes),
                    )
                else:
                    stats["unchanged"] += 1
                    if notes_substantive:
                        stats["notes_kept_body_unchanged"] += 1
                        logger.info(
                            "[new_version_upgradation_agent] modernize_project:   unchanged body but "
                            "MIRA change notes preserved %s bullets=%s (see results `changes`)",
                            rel_path,
                            len(changes),
                        )
                    else:
                        logger.debug(
                            "[new_version_upgradation_agent] modernize_project:   unchanged %s",
                            rel_path,
                        )
            except Exception as e:
                stats["errors"] += 1
                logger.error(
                    "[new_version_upgradation_agent] modernize_project: error on %s — %s",
                    rel_path,
                    e,
                    exc_info=True,
                )
                # Store per-file error so the API response tells the user exactly which file failed
                results.append(
                    {
                        "path": str(rel_path),
                        "code": None,
                        "changes": [],
                        "php_body_changed": False,
                        "substantive_change_notes": False,
                        "error": str(e),
                    }
                )

        logger.info(
            "[new_version_upgradation_agent] modernize_project: PHASE 2 (code) done — total=%s upgraded=%s "
            "unchanged=%s notes_kept_body_unchanged=%s errors=%s",
            stats["total"],
            stats["upgraded"],
            stats["unchanged"],
            stats["notes_kept_body_unchanged"],
            stats["errors"],
        )
        return {"stats": stats, "files": results}

    def run_staged_modernization(
        self,
        local_project_path: str,
        stages: List[MigrationStage],
        write_stage_log: bool = True,
        after_each_stage: Optional[Callable[[MigrationStage, Path, Dict[str, Any]], None]] = None,
        before_each_stage: Optional[Callable[["MigrationStage", int, int], None]] = None,
        project_name: Optional[str] = None,
        from_laravel: Optional[str] = None,
        laravel_documentation_path: Optional[str] = None,
        regenerate_reports_per_stage: bool = True,
        reports_dir: Optional[Path] = None,
    ) -> Dict[str, Any]:
        """
        If ``regenerate_reports_per_stage`` is True: **Laravel** upgrade guides are built **per stage** when the
        project is Laravel (requires ``project_name`` for synthesis output filenames). **No SonarQube** step.

        Each stage: **Phase 1** — LLM analyzes this stage's php.net bundle + Laravel guide slice (if any);
        result is embedded in per-file prompts. **Phase 2** — structure scan, then per-file upgradation to ``stage.to_version``.

        ``reports_dir`` is accepted for API compatibility but unused.
        """
        _ = reports_dir
        root = Path(local_project_path)
        if not root.is_dir():
            return {"success": False, "error": f"Project path not found: {local_project_path}"}

        if not stages:
            logger.info("[new_version_upgradation_agent] run_staged_modernization: no stages (from == to)")
            return {"success": True, "message": "No stages to run (from == to).", "stages": []}

        logger.info(
            "[new_version_upgradation_agent] run_staged_modernization: start path=%s stages=%s "
            "regenerate_reports=%s project_name=%s",
            root,
            len(stages),
            regenerate_reports_per_stage,
            project_name,
        )

        pname = (project_name or "").strip()
        # Strictly use upstream language-analysis output. No local Laravel detection fallback.
        self._is_laravel_project = bool((from_laravel or "").strip())
        logger.info(
            "[new_version_upgradation_agent] run_staged_modernization: upstream language result from_laravel=%s -> is_laravel=%s",
            from_laravel,
            self._is_laravel_project,
        )
        if regenerate_reports_per_stage and self._is_laravel_project and not pname:
            return {
                "success": False,
                "error": "regenerate_reports_per_stage with a Laravel project requires project_name (per-stage guide synthesis).",
                "stages": [],
            }

        if not regenerate_reports_per_stage:
            if self._is_laravel_project and not (self.laravel_upgrade_guide or "").strip():
                return {
                    "success": False,
                    "error": "Laravel project detected but Laravel upgrade guide is missing (load_reports or enable regenerate_reports_per_stage).",
                    "stages": [],
                }

        stage_outputs: List[Dict[str, Any]] = []

        if regenerate_reports_per_stage:
            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: per-stage Laravel synthesis when applicable",
            )
        else:
            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: using pre-loaded Laravel guide "
                "(regenerate_reports_per_stage=False)",
            )

        # Strict mode: do not re-extract project structure here; rely on upstream stage.

        total_stage_count = len(stages)
        for stage in stages:
            # Notify the orchestrator BEFORE the stage runs so the UI can log
            # "Stage 3/7: 7.6 → 7.7" the moment we start working on it (rather than
            # only seeing the final 7.4 → 8.5 forever).
            if before_each_stage:
                try:
                    before_each_stage(stage, int(stage.stage_index), total_stage_count)
                except Exception as cb_err:
                    logger.debug(
                        "[new_version_upgradation_agent] before_each_stage callback raised: %s",
                        cb_err,
                    )
            self._stage_documentation_analysis = ""
            stage_laravel_path: Optional[Path] = None

            if regenerate_reports_per_stage:
                if self._is_laravel_project:
                    logger.info(
                        "[new_version_upgradation_agent] run_staged_modernization: stage %s/%s "
                        "step B — Laravel docs slice + guide (target PHP %s)",
                        stage.stage_index,
                        len(stages),
                        stage.to_version,
                    )
                    docs_slice = collect_laravel_docs_until_php_target(
                        stage.to_version,
                        from_laravel=(from_laravel or "").strip() or None,
                        laravel_docs_path=Path(laravel_documentation_path)
                        if laravel_documentation_path
                        else None,
                    )
                    if not docs_slice.strip():
                        # RAG returned no Laravel docs for this PHP version — log and continue
                        # without a Laravel guide rather than halting the entire pipeline.
                        logger.warning(
                            "[new_version_upgradation_agent] run_staged_modernization: stage %s — "
                            "Laravel docs slice empty for PHP %s (RAG miss). "
                            "Proceeding without Laravel upgrade guide for this stage.",
                            stage.stage_index, stage.to_version,
                        )
                        self.laravel_upgrade_guide = None
                        stage_laravel_path = None
                    else:
                        l_out = synthesize_laravel_guide_for_stage(
                            self.groq_client,
                            pname,
                            stage,
                            from_laravel,
                            docs_slice,
                        )
                        if not l_out:
                            logger.warning(
                                "[new_version_upgradation_agent] run_staged_modernization: stage %s — "
                                "Laravel guide synthesis failed. Proceeding without guide.",
                                stage.stage_index,
                            )
                            self.laravel_upgrade_guide = None
                            stage_laravel_path = None
                        else:
                            stage_laravel_path = l_out
                            self.laravel_upgrade_guide = l_out.read_text(
                                encoding="utf-8", errors="replace"
                            )
                    logger.info(
                        "[new_version_upgradation_agent] run_staged_modernization: stage %s step B done — "
                        "Laravel guide %s chars",
                        stage.stage_index,
                        len(self.laravel_upgrade_guide or ""),
                    )
                else:
                    self.laravel_upgrade_guide = None
                    logger.info(
                        "[new_version_upgradation_agent] run_staged_modernization: stage %s step B skipped "
                        "(non-Laravel)",
                        stage.stage_index,
                    )

            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: stage %s/%s — %s PHP %s → %s",
                stage.stage_index,
                len(stages),
                stage.folder_name,
                stage.from_version,
                stage.to_version,
            )
            # Fresh php.net bundle per stage (do not carry materialized text from a previous stage).
            self._materialized_stage_migration_for_prompt = ""
            self.stage_migration_guide = stage.combined_documentation or ""
            if not self.stage_migration_guide.strip():
                err = (
                    f"Stage {stage.stage_index} (PHP {stage.from_version} → {stage.to_version}) has no "
                    f"migration documentation. RAG fetch may have failed for PHP {stage.to_version}. "
                    f"Check network connectivity and GROQ_API_KEY."
                )
                logger.error(err)
                return {
                    "success": False,
                    "error": err,
                    "stages": stage_outputs,
                }

            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: stage %s php.net bundle "
                "`%s` (PHP %s → %s) — combined_documentation %s chars",
                stage.stage_index,
                stage.folder_name,
                stage.from_version,
                stage.to_version,
                len(self.stage_migration_guide),
            )

            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: stage %s step C — "
                "materialize php.net migration context for PHP %s",
                stage.stage_index,
                stage.to_version,
            )
            self._materialized_stage_migration_for_prompt = (
                self._materialize_migration_guide_for_file_prompts(stage.to_version)
            )
            mig_ctx = self._get_stage_migration_context().strip()
            if not mig_ctx or "Not available (no migration documentation" in mig_ctx:
                err = (
                    f"Stage {stage.stage_index} migration context is empty after materialization "
                    f"(target PHP {stage.to_version})."
                )
                logger.error(err)
                return {
                    "success": False,
                    "error": err,
                    "stages": stage_outputs,
                }

            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: stage %s — "
                "PHASE 1 (documentation): LLM analysis START (php.net + Laravel for this hop before any file edits)",
                stage.stage_index,
            )
            self._stage_documentation_analysis = self._run_llm_stage_documentation_analysis(stage)
            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: stage %s — "
                "PHASE 1 (documentation): LLM analysis COMPLETE output_length=%s chars",
                stage.stage_index,
                len(self._stage_documentation_analysis or ""),
            )
            if (self._stage_documentation_analysis or "").strip():
                logger.info(
                    "[new_version_upgradation_agent] run_staged_modernization: stage %s — "
                    "PHASE 1 (documentation) LLM OUTPUT:\n%s",
                    stage.stage_index,
                    self._stage_documentation_analysis,
                )
            else:
                logger.warning(
                    "[new_version_upgradation_agent] run_staged_modernization: stage %s — "
                    "PHASE 1 empty; per-file prompts use raw PHP MIGRATION/LARAVEL sections only",
                    stage.stage_index,
                )

            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: stage %s — "
                "PHASE 2 (code): step D — LLM modernize all PHP files → PHP %s",
                stage.stage_index,
                stage.to_version,
            )
            results = self.modernize_project(
                str(root),
                stage.to_version,
                stage_index=stage.stage_index,
                stage_doc_folder=stage.folder_name,
                stage_from_version=stage.from_version,
            )
            stats = results.get("stats", {})
            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: stage %s — "
                "PHASE 2 (code): step E — write upgraded files to disk (%s files)",
                stage.stage_index,
                len(results.get("files", [])),
            )
            for file_info in results.get("files", []):
                rel = file_info["path"]
                out_path = root / rel
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(
                    file_info.get("code", ""), encoding="utf-8", errors="replace"
                )

            entry: Dict[str, Any] = {
                "stage": stage.to_dict(),
                "stats": stats,
                "documentation_analysis_phase1": (self._stage_documentation_analysis or ""),
                "stage_laravel_report_path": str(stage_laravel_path)
                if stage_laravel_path
                else None,
            }
            stage_outputs.append(entry)
            logger.info(
                "[new_version_upgradation_agent] run_staged_modernization: stage %s complete "
                "(upgraded=%s unchanged=%s notes_kept_body_unchanged=%s errors=%s)",
                stage.stage_index,
                stats.get("upgraded"),
                stats.get("unchanged"),
                stats.get("notes_kept_body_unchanged", 0),
                stats.get("errors"),
            )
            if after_each_stage:
                logger.info(
                    "[new_version_upgradation_agent] run_staged_modernization: stage %s callback "
                    "(e.g. remote upload)",
                    stage.stage_index,
                )
                after_each_stage(stage, root, entry)

        out: Dict[str, Any] = {
            "success": True,
            "stages": stage_outputs,
            "final_php_version": stages[-1].to_version,
        }

        if write_stage_log:
            log_path = root / "STAGED_MODERNIZATION_LOG.json"
            try:
                log_path.write_text(
                    json.dumps(
                        {"timestamp": datetime.now().isoformat(), "stages": stage_outputs},
                        indent=2,
                        default=str,
                    ),
                    encoding="utf-8",
                )
                out["log_path"] = str(log_path)
                logger.info(
                    "[new_version_upgradation_agent] run_staged_modernization: wrote %s",
                    log_path,
                )
            except OSError as e:
                logger.warning(
                    "[new_version_upgradation_agent] run_staged_modernization: could not write %s — %s",
                    log_path,
                    e,
                )

        logger.info(
            "[new_version_upgradation_agent] run_staged_modernization: pipeline finished OK "
            "final_php=%s stages_run=%s",
            stages[-1].to_version,
            len(stage_outputs),
        )
        return out

    def run_pipeline_with_remote_snapshots(
        self,
        local_project_path: str,
        from_php_version: str,
        to_php_version: str,
        project_name: str,
        ssh_conn,
        remote_migrated_versions_base: str,
        docs_txt_root: Optional[Path] = None,   # ignored — RAG is always used
        max_chars_per_stage: Optional[int] = None,
        on_stage_complete: Optional[
            Callable[[MigrationStage, Dict[str, Any], str], None]
        ] = None,
        on_stage_started: Optional[
            Callable[["MigrationStage", int, int], None]
        ] = None,
        from_laravel: Optional[str] = None,
        laravel_documentation_path: Optional[str] = None,  # ignored — RAG is used
        regenerate_reports_per_stage: bool = True,
        reports_dir: Optional[Path] = None,
    ) -> Dict[str, Any]:
        """
        Download PHP project from client server, run staged migration via RAG,
        upload each stage snapshot back to the client, and run tests after each stage.
        If tests fail, the cyclic correction loop retries up to MAX_STAGE_RETRIES times.

        docs_txt_root and laravel_documentation_path are accepted for API compatibility
        but ignored — all migration docs are sourced via the RAG system.
        """
        logger.info(
            "[new_version_upgradation_agent] run_pipeline_with_remote_snapshots: start project=%s "
            "PHP %s → %s (RAG mode, max_retries=%d)",
            project_name, from_php_version, to_php_version, self.MAX_STAGE_RETRIES,
        )
        stages = compute_migration_stages(
            from_php_version,
            to_php_version,
            load_file_contents=True,
            max_chars_per_stage=max_chars_per_stage,
        )
        if not stages:
            logger.info(
                "[new_version_upgradation_agent] run_pipeline_with_remote_snapshots: no stages required",
            )
            return {"success": True, "message": "No migration stages required.", "stages": []}

        logger.info(
            "[new_version_upgradation_agent] run_pipeline_with_remote_snapshots: %s stage(s) planned — "
            "entering staged version upgradation with cyclic correction",
            len(stages),
        )
        base = remote_migrated_versions_base.rstrip("/")

        def _upload_and_test(stage: MigrationStage, _root: Path, entry: Dict[str, Any]) -> None:
            """Upload stage snapshot and run tests; populate entry with correction results."""
            remote_dir = (
                f"{base}/{project_name}/"
                f"stage_{stage.stage_index:02d}_php{stage.folder_num}"
            )
            correction_result = self._run_stage_with_correction(
                stage, Path(local_project_path), ssh_conn, remote_dir
            )
            entry["remote_snapshot_path"] = remote_dir
            entry["remote_upload_ok"] = correction_result.get("success", False)
            entry["correction_attempts"] = correction_result.get("attempts", 1)
            entry["test_results"] = correction_result.get("test_results", {})
            if not correction_result.get("success"):
                entry["correction_error"] = correction_result.get("error")
                logger.error(
                    "[new_version_upgradation_agent] stage %d correction failed: %s",
                    stage.stage_index, correction_result.get("error"),
                )
            if on_stage_complete:
                on_stage_complete(stage, entry, remote_dir)

        run = self.run_staged_modernization(
            str(local_project_path),
            stages,
            write_stage_log=True,
            after_each_stage=_upload_and_test,
            before_each_stage=on_stage_started,
            project_name=project_name,
            from_laravel=from_laravel,
            laravel_documentation_path=None,    # RAG handles this per-stage
            regenerate_reports_per_stage=regenerate_reports_per_stage,
            reports_dir=reports_dir,
        )

        # Propagate correction failures as pipeline failures
        if run.get("success"):
            for stage_entry in run.get("stages", []):
                if stage_entry.get("correction_error"):
                    run["success"] = False
                    run["error"] = stage_entry["correction_error"]
                    break
        run["remote_migrated_versions_base"] = base
        if run.get("success"):
            logger.info(
                "[new_version_upgradation_agent] run_pipeline_with_remote_snapshots: finished success=%s",
                run.get("success"),
            )
        else:
            logger.error(
                "[new_version_upgradation_agent] run_pipeline_with_remote_snapshots: failed — %s",
                run.get("error"),
            )
        return run

    def execute(self, state: AgentState) -> AgentState:
        try:
            logger.info("[new_version_upgradation_agent] execute: start")
            local_path = state.context.get("local_project_path")
            if not local_path:
                state.add_error("local_project_path is required")
                return state

            stages = state.context.get("stages")
            if not stages:
                fv = state.context.get("from_version")
                tv = state.context.get("to_version")
                if not fv or not tv:
                    state.add_error("Provide stages or from_version and to_version")
                    return state
                root = state.context.get("docs_txt_root")
                mc = state.context.get("max_chars_per_stage")
                stages = compute_migration_stages(
                    str(fv),
                    str(tv),
                    docs_txt_root=Path(root) if root else None,
                    load_file_contents=True,
                    max_chars_per_stage=mc if isinstance(mc, int) else None,
                )

            run = self.run_staged_modernization(
                str(local_path),
                stages,
                project_name=state.context.get("project_name"),
                from_laravel=state.context.get("from_laravel"),
                laravel_documentation_path=state.context.get("laravel_documentation_path"),
                regenerate_reports_per_stage=state.context.get(
                    "regenerate_reports_per_stage", True
                ),
                reports_dir=Path(state.context["reports_dir"])
                if state.context.get("reports_dir")
                else None,
            )
            if not run.get("success"):
                state.add_error(run.get("error", "staged version upgradation failed"))
                logger.error(
                    "[new_version_upgradation_agent] execute: staged_modernization failed — %s",
                    run.get("error"),
                )
                return state
            state.results["staged_modernization"] = run
            logger.info("[new_version_upgradation_agent] execute: completed successfully")
            return state
        except Exception as e:
            logger.exception("[new_version_upgradation_agent] execute: exception")
            state.add_error(str(e))
            return state
