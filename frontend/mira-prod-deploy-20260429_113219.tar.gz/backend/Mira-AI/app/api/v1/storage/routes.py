"""Storage API routes - VM-based storage via SSH"""
from fastapi import APIRouter

router = APIRouter()

# Storage endpoints removed - not needed for current scope
