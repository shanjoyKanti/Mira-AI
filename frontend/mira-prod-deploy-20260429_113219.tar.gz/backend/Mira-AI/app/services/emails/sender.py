import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, Optional

from app.core.logging import get_logger

logger = get_logger(__name__)


def _get_settings():
    try:
        from app.core.config import settings
        return settings
    except Exception:
        return None


def _app_url() -> str:
    settings = _get_settings()
    if settings:
        return (getattr(settings, "FRONTEND_URL", None) or "").rstrip("/") or "https://mira.codsy.ai"
    return "https://mira.codsy.ai"


def _html_email_wrapper(title: str, greeting: str, paragraphs: list, cta_text: str = "View in application", cta_url: Optional[str] = None) -> str:
    url = (cta_url or _app_url()).rstrip("/")
    body = "".join(f"<p style='margin:0 0 14px; color:#374151; line-height:1.6;'>{p}</p>" for p in paragraphs)
    return f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>
</head>
<body style="margin:0; padding:0; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color:#f3f4f6;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#f3f4f6; padding: 32px 16px;">
    <tr>
      <td align="center">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px; background:#ffffff; border-radius:12px; box-shadow:0 4px 6px rgba(0,0,0,0.07); overflow:hidden;">
          <tr>
            <td style="background:linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); padding: 28px 32px; text-align:center;">
              <h1 style="margin:0; font-size:22px; font-weight:600; color:#ffffff; letter-spacing:-0.02em;">{title}</h1>
            </td>
          </tr>
          <tr>
            <td style="padding: 32px;">
              <p style="margin:0 0 20px; font-size:16px; color:#111827; font-weight:500;">{greeting}</p>
              {body}
              <table role="presentation" cellspacing="0" cellpadding="0" style="margin-top:28px;">
                <tr>
                  <td style="border-radius:8px; background:#4f46e5;">
                    <a href="{url}" target="_blank" rel="noopener" style="display:inline-block; padding:14px 28px; font-size:15px; font-weight:600; color:#ffffff; text-decoration:none;">{cta_text}</a>
                  </td>
                </tr>
              </table>
              <p style="margin:24px 0 0; font-size:13px; color:#9ca3af;">If you did not expect this email, you can ignore it.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
"""


def send_mail(
    to_email: str,
    subject: str,
    body_text: str,
    body_html: Optional[str] = None,
) -> bool:
    settings = _get_settings()
    if not settings:
        logger.warning("Email not sent: settings not available")
        return False
    username = getattr(settings, "MAIL_USERNAME", None) or ""
    password = getattr(settings, "MAIL_PASSWORD", None) or ""
    if not username or not password:
        logger.warning("Email not sent: MAIL_USERNAME or MAIL_PASSWORD not set")
        return False
    from_addr = getattr(settings, "MAIL_FROM", None) or username
    from_name = getattr(settings, "MAIL_FROM_NAME", None) or "Mira AI"
    server = getattr(settings, "MAIL_SERVER", None) or ""
    port = int(getattr(settings, "MAIL_PORT", None) or 587)
    use_tls = getattr(settings, "MAIL_TLS", True)
    use_ssl = getattr(settings, "MAIL_SSL", False)
    if not server:
        logger.warning("Email not sent: MAIL_SERVER not set")
        return False
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"{from_name} <{from_addr}>"
        msg["To"] = to_email
        msg.attach(MIMEText(body_text, "plain"))
        if body_html:
            msg.attach(MIMEText(body_html, "html"))
        if use_ssl:
            smtp = smtplib.SMTP_SSL(server, port)
        else:
            smtp = smtplib.SMTP(server, port)
            if use_tls:
                smtp.starttls()
        smtp.login(username, password)
        smtp.sendmail(from_addr, [to_email], msg.as_string())
        smtp.quit()
        logger.info("Email sent to %s: %s", to_email, subject)
        return True
    except Exception as e:
        logger.exception("Failed to send email to %s: %s", to_email, e)
        return False


def send_upgrade_analysis_complete(to_email: str, project_name: str, job_id: str) -> bool:
    subject = "Upgrade analysis complete – plan ready for review"
    app_url = _app_url()
    body_text = (
        f"Your upgrade analysis for project \"{project_name}\" has completed.\n\n"
        "The planning phase is complete. We have analyzed your codebase and prepared an upgrade plan with PHP and Laravel upgrade guides and SonarQube insights. You can now review the plan and move on to code modernization when ready.\n\n"
        f"Open the application to view your plan: {app_url}\n\n"
        "— Mira AI"
    )
    body_html = _html_email_wrapper(
        title="Upgrade analysis complete",
        greeting="Your upgrade analysis is ready for review.",
        paragraphs=[
            f"Planning for project <strong>\"{project_name}\"</strong> has finished successfully.",
            "We have analyzed your codebase and prepared an upgrade plan, including PHP and Laravel upgrade guides and SonarQube analysis. You can review the plan and proceed to code modernization when you are ready.",
            "Click the button below to open the application and view your plan.",
        ],
        cta_text="View plan in application",
        cta_url=app_url,
    )
    return send_mail(to_email, subject, body_text, body_html)


def send_upgrade_analysis_regenerated_complete(to_email: str, project_name: str, job_id: str) -> bool:
    subject = "Upgrade plan regenerated – ready for review"
    app_url = _app_url()
    body_text = (
        f"Regeneration of the upgrade plan for project \"{project_name}\" based on your requirements has completed.\n\n"
        "Your plan has been updated according to the requirements you provided. You can review the regenerated upgrade plan, including PHP and Laravel guides and SonarQube analysis, in the application.\n\n"
        f"Open the application to review: {app_url}\n\n"
        "— Mira AI"
    )
    body_html = _html_email_wrapper(
        title="Upgrade plan regenerated",
        greeting="Your plan has been regenerated based on your requirements.",
        paragraphs=[
            f"The upgrade plan for project <strong>\"{project_name}\"</strong> has been updated according to your instructions.",
            "You can now review the regenerated plan in the application and proceed to code modernization when ready.",
            "Click the button below to open the application.",
        ],
        cta_text="View plan in application",
        cta_url=app_url,
    )
    return send_mail(to_email, subject, body_text, body_html)


def send_code_modernization_complete(to_email: str, project_name: str, job_id: str, output_path: Optional[str] = None) -> bool:
    subject = "Code modernization complete – ready to check"
    app_url = _app_url()
    body_text = (
        f"Code modernization for project \"{project_name}\" has completed.\n\n"
        "All code modernization steps have finished. Your codebase has been upgraded according to the plan. You can now check the modernized code and results in the application.\n\n"
        f"Open the application to check results: {app_url}\n\n"
        "— Mira AI"
    )
    paragraphs = [
        f"Code modernization for project <strong>\"{project_name}\"</strong> has completed successfully.",
        "All upgrade steps have been applied. You can review the modernized code and outputs in the application.",
        "Click the button below to open the application and check your results.",
    ]
    body_html = _html_email_wrapper(
        title="Code modernization complete",
        greeting="Your code modernization is complete.",
        paragraphs=paragraphs,
        cta_text="Check results in application",
        cta_url=app_url,
    )
    return send_mail(to_email, subject, body_text, body_html)


def send_migration_started(
    to_email: str,
    project_name: str,
    job_id: str,
    *,
    stacks: Optional[Dict[str, bool]] = None,
    total_files: Optional[int] = None,
    estimated_runtime: Optional[str] = None,
    estimated_cost_usd: Optional[float] = None,
) -> bool:
    """Notify the user that a code-modernization run has just *started*.

    Sent at the moment the user confirms the pre-flight modal — not when the
    job finishes. Gives the user (and their stakeholders) a paper trail that
    Mira accepted the request, plus a record of the stack/version/cost choices
    so they can compare against the final result.
    """
    subject = f"Code migration started for {project_name}"
    app_url = _app_url()

    # Stack summary line, e.g. "Stacks: Frontend + Backend + API"
    stacks = stacks or {}
    chosen = [n for n, on in (("Frontend", stacks.get("frontend")),
                              ("Backend",  stacks.get("backend")),
                              ("API",      stacks.get("api"))) if on]
    stacks_line = "Stacks: " + (", ".join(chosen) if chosen else "—")

    bits = [stacks_line]
    if total_files is not None:
        bits.append(f"Files: {total_files}")
    if estimated_runtime:
        bits.append(f"Estimated runtime: {estimated_runtime}")
    if estimated_cost_usd is not None:
        bits.append(f"Estimated cost: ${estimated_cost_usd:.2f}")
    bits.append(f"Job ID: {job_id}")
    summary_block = "\n".join(f"- {b}" for b in bits)

    body_text = (
        f"Your code migration for project \"{project_name}\" has just started.\n\n"
        f"{summary_block}\n\n"
        "You will receive another email when the migration finishes. You can also\n"
        "watch live progress and download the per-job .txt log file from the application.\n\n"
        f"Open the application: {app_url}\n\n"
        "— Mira AI"
    )

    paragraphs = [
        f"Your migration for project <strong>\"{project_name}\"</strong> has just been kicked off.",
        "<br/>".join(
            ([f"<strong>Stacks:</strong> {', '.join(chosen)}"] if chosen else []) +
            ([f"<strong>Files:</strong> {total_files}"] if total_files is not None else []) +
            ([f"<strong>Estimated runtime:</strong> {estimated_runtime}"] if estimated_runtime else []) +
            ([f"<strong>Estimated cost:</strong> ${estimated_cost_usd:.2f}"] if estimated_cost_usd is not None else []) +
            [f"<strong>Job ID:</strong> {job_id}"]
        ),
        "You'll receive another email when the migration completes. In the meantime you can watch live progress in the application.",
    ]
    body_html = _html_email_wrapper(
        title="Code migration started",
        greeting="Your code migration is now running.",
        paragraphs=paragraphs,
        cta_text="Watch live progress",
        cta_url=app_url,
    )
    return send_mail(to_email, subject, body_text, body_html)
