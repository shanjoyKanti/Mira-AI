"""SonarQube API endpoints"""
from app.api.v1.sonarqube.routes import router

__all__ = ["router"]

