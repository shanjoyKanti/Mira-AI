"""Remote SonarScanner service for scanning code on remote servers via SSH"""
import os
import tempfile
import time
from typing import Optional, Dict, Any

from pathlib import Path
from app.services.ssh.ssh_service import SSHConnection, SSHService
from app.core.logging import get_logger
from app.core.config import settings

logger = get_logger(__name__)


class RemoteSonarScanner:
    """Service for running SonarScanner on remote servers via SSH"""
    
    def __init__(self, ssh_conn: SSHConnection, sonar_token: Optional[str], sonar_host_url: str = "https://sonarqube.codsy.ai"):
        """
        Initialize remote SonarScanner
        
        Args:
            ssh_conn: Active SSH connection to remote server
            sonar_token: SonarQube authentication token (required for scan; fallback to SONAR_TOKEN env if empty)
            sonar_host_url: SonarQube server URL (accessible from remote server)
        """
        self.ssh_conn = ssh_conn
        # Ensure we have a token: caller may pass None when using env; fallback to env so scan can succeed
        raw = (sonar_token or os.environ.get("SONAR_TOKEN") or "").strip()
        self.sonar_token = raw
        # Validate token is not empty
        if not self.sonar_token:
            logger.warning("SonarQube token is empty - scan will fail with 'Not authorized' error")
        self.sonar_host_url = (sonar_host_url or os.environ.get("SONAR_HOST_URL") or "https://sonarqube.codsy.ai").strip()
    
    def check_docker_available(self) -> bool:
        """Check if Docker is available on remote server"""
        try:
            result = self.ssh_conn.execute_command("docker --version")
            return result["success"] and "Docker version" in result["stdout"]
        except Exception as e:
            logger.error(f"Failed to check Docker availability: {e}")
            return False
    
    def check_scanner_installed(self) -> bool:
        """Check if SonarScanner CLI is installed on remote server"""
        try:
            result = self.ssh_conn.execute_command("which sonar-scanner")
            return result["success"] and result["stdout"].strip() != ""
        except Exception as e:
            logger.error(f"Failed to check SonarScanner installation: {e}")
            return False
    
    def wrap_sudo_script(self, script: str) -> str:
        """
        Wrap a bash script to handle sudo commands with password using SUDO_ASKPASS
        
        Args:
            script: Bash script with sudo commands
            
        Returns:
            Modified script that uses SUDO_ASKPASS for password
        """
        if not self.ssh_conn.password:
            # No password available, return as-is (might work if passwordless sudo)
            return script
        
        # Escape password for shell (handle special characters properly)
        password = self.ssh_conn.password.replace("'", "'\"'\"'").replace("$", "\\$").replace("`", "\\`").replace("\\", "\\\\")
        
        # Create an askpass script and use SUDO_ASKPASS environment variable
        # This is the cleanest way to handle sudo password in non-interactive shells
        askpass_script = f"""
# Create temporary askpass script
ASKPASS_SCRIPT=$(mktemp)
cat > "$ASKPASS_SCRIPT" << 'ASKPASS_EOF'
#!/bin/bash
echo '{password}'
ASKPASS_EOF
chmod +x "$ASKPASS_SCRIPT"
export SUDO_ASKPASS="$ASKPASS_SCRIPT"

# Replace sudo with sudo -A (use askpass)
"""
        
        # Replace all sudo commands with sudo -A (which uses SUDO_ASKPASS)
        import re
        # Replace: sudo <cmd> -> sudo -A <cmd>
        script = re.sub(r'\bsudo\s+(?!-A|-S|-n)', 'sudo -A ', script)
        
        # Add cleanup at the end
        cleanup = """
# Cleanup askpass script
rm -f "$ASKPASS_SCRIPT"
"""
        
        return askpass_script + script + cleanup
    
    def detect_linux_distro(self) -> Optional[str]:
        """Detect Linux distribution on remote server"""
        try:
            # Check for /etc/os-release (most modern distributions)
            result = self.ssh_conn.execute_command("cat /etc/os-release | grep '^ID=' | cut -d'=' -f2 | tr -d '\"'")
            if result["success"] and result["stdout"].strip():
                return result["stdout"].strip().lower()
            
            # Fallback: check for specific distribution files
            distros = {
                "debian": "cat /etc/debian_version",
                "ubuntu": "lsb_release -is 2>/dev/null | tr '[:upper:]' '[:lower:]'",
                "centos": "cat /etc/centos-release",
                "rhel": "cat /etc/redhat-release",
                "fedora": "cat /etc/fedora-release"
            }
            
            for distro, cmd in distros.items():
                result = self.ssh_conn.execute_command(cmd)
                if result["success"] and result["stdout"].strip():
                    return distro
            
            return None
        except Exception as e:
            logger.error(f"Failed to detect Linux distribution: {e}")
            return None
    
    def install_docker(self) -> Dict[str, Any]:
        """Install Docker on remote server"""
        try:
            logger.info("Attempting to install Docker on remote server")
            
            distro = self.detect_linux_distro()
            if not distro:
                return {
                    "success": False,
                    "error": "Could not detect Linux distribution"
                }
            
            # Check if already installed
            if self.check_docker_available():
                return {
                    "success": True,
                    "message": "Docker is already installed"
                }
            
            install_script = ""
            
            if distro == "ubuntu":
                install_script = """
# Update package index
sudo apt-get update -y || exit 1

# Install prerequisites
sudo apt-get install -y ca-certificates curl gnupg lsb-release || exit 1

# Add Docker's official GPG key
sudo install -m 0755 -d /etc/apt/keyrings || exit 1
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg || exit 1
sudo chmod a+r /etc/apt/keyrings/docker.gpg || exit 1

# Set up repository
ARCH=$(dpkg --print-architecture)
CODENAME=$(lsb_release -cs)
echo "deb [arch=$ARCH signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $CODENAME stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null || exit 1

# Install Docker
sudo apt-get update -y || exit 1
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin || exit 1

# Add current user to docker group (if not root)
if [ "$(whoami)" != "root" ]; then
    sudo usermod -aG docker $(whoami) || true
fi

# Start Docker service
sudo systemctl start docker || exit 1
sudo systemctl enable docker || true

# Verify installation (try with sudo if needed)
docker --version 2>/dev/null || sudo docker --version || exit 1
"""
            elif distro == "debian":
                install_script = """
# Update package index
sudo apt-get update -y || exit 1

# Install prerequisites
sudo apt-get install -y ca-certificates curl gnupg lsb-release || exit 1

ARCH=$(dpkg --print-architecture)
CODENAME=$(lsb_release -cs)

# Try Docker's official repository first
sudo install -m 0755 -d /etc/apt/keyrings || exit 1
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg || exit 1
sudo chmod a+r /etc/apt/keyrings/docker.gpg || exit 1

# Try with current codename first
echo "deb [arch=$ARCH signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian $CODENAME stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

UPDATE_OUTPUT=$(sudo apt-get update -y 2>&1)
if echo "$UPDATE_OUTPUT" | grep -q "does not have a Release file"; then
    # Codename not supported, try bookworm (Debian 12 stable)
    echo "deb [arch=$ARCH signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian bookworm stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    sudo apt-get update -y || exit 1
fi

# Try to install Docker CE
if sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin 2>&1 | grep -q "Unable to locate package\|Package.*not found"; then
    # Docker CE not available, use Debian's docker.io
    sudo rm -f /etc/apt/sources.list.d/docker.list
    sudo apt-get update -y || exit 1
    sudo apt-get install -y docker.io docker-compose || exit 1
fi

# Add current user to docker group (if not root)
if [ "$(whoami)" != "root" ]; then
    sudo usermod -aG docker $(whoami) || true
fi

# Start Docker service
sudo systemctl start docker || exit 1
sudo systemctl enable docker || true

# Verify installation (try with sudo if needed)
docker --version 2>/dev/null || sudo docker --version || exit 1
"""
            elif distro in ["centos", "rhel", "fedora"]:
                install_script = """
# Install prerequisites
sudo yum install -y yum-utils || exit 1

# Add Docker repository
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo || exit 1

# Install Docker
sudo yum install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin || exit 1

# Start Docker service
sudo systemctl start docker || exit 1
sudo systemctl enable docker || true

# Add current user to docker group (if not root)
if [ "$(whoami)" != "root" ]; then
    sudo usermod -aG docker $(whoami) || true
fi

# Verify installation (try with sudo if needed)
docker --version 2>/dev/null || sudo docker --version || exit 1
"""
            else:
                return {
                    "success": False,
                    "error": f"Unsupported Linux distribution: {distro}"
                }
            
            # Wrap script to handle sudo with password
            install_script = self.wrap_sudo_script(install_script)
            
            # Execute installation script using heredoc
            logger.info(f"Installing Docker on {distro}")
            # Use base64 encoding to safely pass the script
            import base64
            script_b64 = base64.b64encode(install_script.encode('utf-8')).decode('utf-8')
            result = self.ssh_conn.execute_command(f"bash << 'SCRIPT_EOF'\n{install_script}\nSCRIPT_EOF")
            
            # Log full output for debugging
            logger.info(f"Docker installation stdout: {result.get('stdout', '')[:500]}")
            logger.info(f"Docker installation stderr: {result.get('stderr', '')[:500]}")
            logger.info(f"Docker installation exit code: {result.get('exit_code', 'unknown')}")
            
            # Check if Docker version appears in output (success indicator)
            output_combined = (result.get("stdout", "") + " " + result.get("stderr", "")).lower()
            if "docker version" in output_combined or result["success"]:
                # Wait a moment for Docker to be ready
                time.sleep(2)
                
                # Verify installation
                if self.check_docker_available():
                    return {
                        "success": True,
                        "message": "Docker installed successfully",
                        "output": result["stdout"],
                        "errors": result["stderr"]
                    }
                else:
                    # Try with sudo
                    sudo_check = self.ssh_conn.execute_command("sudo docker --version")
                    if sudo_check["success"]:
                        return {
                            "success": True,
                            "message": "Docker installed successfully (requires sudo)",
                            "output": result["stdout"],
                            "errors": result["stderr"],
                            "requires_sudo": True
                        }
                    else:
                        return {
                            "success": False,
                            "error": "Docker installation completed but verification failed",
                            "output": result["stdout"],
                            "errors": result["stderr"],
                            "exit_code": result.get("exit_code")
                        }
            else:
                return {
                    "success": False,
                    "error": f"Docker installation failed (exit code: {result.get('exit_code', 'unknown')})",
                    "output": result["stdout"],
                    "errors": result["stderr"],
                    "exit_code": result.get("exit_code")
                }
                
        except Exception as e:
            logger.error(f"Failed to install Docker: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e)
            }
    
    def install_scanner_cli(self) -> Dict[str, Any]:
        """Install SonarScanner CLI on remote server"""
        try:
            logger.info("Attempting to install SonarScanner CLI on remote server")
            
            # Check if already installed
            if self.check_scanner_installed():
                return {
                    "success": True,
                    "message": "SonarScanner CLI is already installed"
                }
            
            install_script = """
# Clean up any failed Docker repository entries first
if [ -f /etc/apt/sources.list.d/docker.list ]; then
    sudo rm -f /etc/apt/sources.list.d/docker.list || true
fi

# Create installation directory
INSTALL_DIR="/opt/sonar-scanner"
sudo mkdir -p $INSTALL_DIR || exit 1

# Download SonarScanner (latest version)
SCANNER_VERSION="5.0.1.3006"
SCANNER_URL="https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-${SCANNER_VERSION}-linux.zip"

# Install unzip if not available
if ! command -v unzip &> /dev/null; then
    if command -v apt-get &> /dev/null; then
        sudo apt-get update -y && sudo apt-get install -y unzip || exit 1
    elif command -v yum &> /dev/null; then
        sudo yum install -y unzip || exit 1
    else
        echo "ERROR: Cannot install unzip - package manager not found"
        exit 1
    fi
fi

# Download and extract
cd /tmp || exit 1
curl -L -o sonar-scanner.zip "$SCANNER_URL" || exit 1
sudo unzip -q sonar-scanner.zip -d /tmp || exit 1
sudo mv /tmp/sonar-scanner-${SCANNER_VERSION}-linux/* $INSTALL_DIR/ || exit 1
sudo rm -rf /tmp/sonar-scanner.zip /tmp/sonar-scanner-${SCANNER_VERSION}-linux

# Create symlink in /usr/local/bin
sudo ln -sf $INSTALL_DIR/bin/sonar-scanner /usr/local/bin/sonar-scanner || exit 1

# Verify installation
export PATH=$PATH:/usr/local/bin
sonar-scanner --version || exit 1
"""
            
            # Wrap script to handle sudo with password
            install_script = self.wrap_sudo_script(install_script)
            
            logger.info("Installing SonarScanner CLI")
            # Execute using heredoc
            result = self.ssh_conn.execute_command(f"bash << 'SCRIPT_EOF'\n{install_script}\nSCRIPT_EOF")
            
            # Log full output for debugging
            logger.info(f"SonarScanner installation stdout: {result.get('stdout', '')[:500]}")
            logger.info(f"SonarScanner installation stderr: {result.get('stderr', '')[:500]}")
            logger.info(f"SonarScanner installation exit code: {result.get('exit_code', 'unknown')}")
            
            # Check if sonar-scanner appears in output (success indicator)
            output_combined = (result.get("stdout", "") + " " + result.get("stderr", "")).lower()
            if "sonar-scanner" in output_combined or result["success"]:
                # Wait a moment for PATH to update
                time.sleep(1)
                
                # Verify installation
                if self.check_scanner_installed():
                    return {
                        "success": True,
                        "message": "SonarScanner CLI installed successfully",
                        "output": result["stdout"],
                        "errors": result["stderr"]
                    }
                else:
                    # Try checking with full path
                    path_check = self.ssh_conn.execute_command("/opt/sonar-scanner/bin/sonar-scanner --version")
                    if path_check["success"]:
                        return {
                            "success": True,
                            "message": "SonarScanner CLI installed successfully (at /opt/sonar-scanner/bin/sonar-scanner)",
                            "output": result["stdout"],
                            "errors": result["stderr"],
                            "path": "/opt/sonar-scanner/bin/sonar-scanner"
                        }
                    else:
                        return {
                            "success": False,
                            "error": "SonarScanner installation completed but verification failed",
                            "output": result["stdout"],
                            "errors": result["stderr"],
                            "exit_code": result.get("exit_code")
                        }
            else:
                return {
                    "success": False,
                    "error": f"SonarScanner CLI installation failed (exit code: {result.get('exit_code', 'unknown')})",
                    "output": result["stdout"],
                    "errors": result["stderr"],
                    "exit_code": result.get("exit_code")
                }
                
        except Exception as e:
            logger.error(f"Failed to install SonarScanner CLI: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e)
            }
    
    def create_sonar_properties(self, project_key: str, project_name: str, 
                                 source_path: str, exclusions: Optional[str] = None,
                                 use_docker: bool = False) -> str:
        """
        Create sonar-project.properties content
        
        Args:
            project_key: SonarQube project key
            project_name: Project display name
            source_path: Path to source code on remote server
            exclusions: File exclusion patterns (optional)
            use_docker: If True, use relative path for Docker container (default: False)
        """
        # When using Docker, the source path is mounted to /usr/src, so use relative path
        if use_docker:
            sources_path = "."  # Current directory in Docker container (/usr/src)
        else:
            sources_path = source_path
        
        properties = f"""sonar.projectKey={project_key}
sonar.projectName={project_name}
sonar.sources={sources_path}
sonar.sourceEncoding=UTF-8
sonar.host.url={self.sonar_host_url}
sonar.login={self.sonar_token}
"""
        if exclusions:
            properties += f"sonar.exclusions={exclusions}\n"
        
        return properties
    
    def scan_with_docker(self, project_key: str, project_name: str, 
                         source_path: str, exclusions: Optional[str] = None) -> Dict[str, Any]:
        """
        Run SonarScanner using Docker on remote server
        
        Args:
            project_key: SonarQube project key
            project_name: Project display name
            source_path: Path to source code on remote server
            exclusions: File exclusion patterns (optional)
        """
        try:
            logger.info(f"Starting Docker-based scan for project: {project_key} (token: ...{self.sonar_token[-10:]})")
            
            # Create sonar-project.properties (use relative path for Docker)
            properties = self.create_sonar_properties(project_key, project_name, source_path, exclusions, use_docker=True)
            
            # Write properties file to remote server
            properties_path = f"{source_path}/sonar-project.properties"
            if not self.ssh_conn.write_file(properties_path, properties):
                return {
                    "success": False,
                    "error": "Failed to create sonar-project.properties on remote server"
                }
            
            # Determine SonarQube host URL for Docker container
            # If SonarQube is on a different host, we need to use the host's IP
            # For now, assuming SonarQube is accessible from remote server
            sonar_url = self.sonar_host_url.replace("localhost", "host.docker.internal")
            if "localhost" not in sonar_url:
                # Extract hostname/IP from URL
                sonar_url = self.sonar_host_url
            
            # Check if we need sudo for docker commands
            # Try without sudo first, fallback to sudo if needed
            # Note: Token must be escaped for shell - use single quotes where possible
            docker_cmd_base = f"""docker run --rm --network host \\
  -e SONAR_HOST_URL='{self.sonar_host_url}' \\
  -e SONAR_LOGIN='{self.sonar_token}' \\
  -v '{source_path}:/usr/src' \\
  -w /usr/src \\
  sonarsource/sonar-scanner-cli:latest"""
            
            logger.info(f"Executing Docker scan command on remote server")
            # Try without sudo first
            result = self.ssh_conn.execute_command(f"cd {source_path} && {docker_cmd_base}")
            
            # If failed and error suggests permission issue, try with sudo
            if not result["success"] and ("permission denied" in result["stderr"].lower() or "cannot connect" in result["stderr"].lower()):
                logger.info("Docker command failed, retrying with sudo...")
                result = self.ssh_conn.execute_command(f"cd {source_path} && sudo {docker_cmd_base}")
            
            # Clean up properties file (optional)
            # self.ssh_conn.delete_file(properties_path)
            
            if result["success"]:
                return {
                    "success": True,
                    "project_key": project_key,
                    "stdout": result["stdout"],
                    "stderr": result["stderr"],
                    "message": "Scan completed successfully"
                }
            else:
                return {
                    "success": False,
                    "error": result["stderr"] or "Scan failed",
                    "stdout": result["stdout"],
                    "stderr": result["stderr"]
                }
                
        except Exception as e:
            logger.error(f"Failed to run Docker scan: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e)
            }
    
    def scan_with_cli(self, project_key: str, project_name: str,
                     source_path: str, exclusions: Optional[str] = None,
                     scanner_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Run SonarScanner CLI on remote server (requires pre-installed scanner)
        
        Args:
            project_key: SonarQube project key
            project_name: Project display name
            source_path: Path to source code on remote server
            exclusions: File exclusion patterns (optional)
            scanner_path: Full path to sonar-scanner binary (optional, defaults to 'sonar-scanner')
        """
        try:
            logger.info(f"Starting CLI-based scan for project: {project_key}")
            
            # Clear SonarScanner cache to avoid checksum issues
            logger.info("Clearing SonarScanner cache...")
            cache_dir = "~/.sonar"
            self.ssh_conn.execute_command(f"rm -rf {cache_dir}/_tmp {cache_dir}/cache/* 2>/dev/null || true")
            
            # Create sonar-project.properties
            properties = self.create_sonar_properties(project_key, project_name, source_path, exclusions)
            
            # Write properties file to remote server
            properties_path = f"{source_path}/sonar-project.properties"
            if not self.ssh_conn.write_file(properties_path, properties):
                return {
                    "success": False,
                    "error": "Failed to create sonar-project.properties on remote server"
                }
            
            # Use provided path or default
            scanner_cmd = scanner_path or "sonar-scanner"
            
            # Run SonarScanner CLI
            # Token must be quoted to handle special characters (use single quotes to prevent shell expansion)
            scan_cmd = f"cd {source_path} && {scanner_cmd} -Dsonar.login='{self.sonar_token}'"
            
            logger.info(f"Executing SonarScanner CLI on remote server: {scanner_cmd} (token: ...{self.sonar_token[-10:]})")
            result = self.ssh_conn.execute_command(scan_cmd)
            
            if result["success"]:
                return {
                    "success": True,
                    "project_key": project_key,
                    "stdout": result["stdout"],
                    "stderr": result["stderr"],
                    "message": "Scan completed successfully"
                }
            else:
                # Check for specific error types and provide helpful messages
                error_msg = result["stderr"] or "Scan failed"
                
                # Authentication errors
                if "Not authorized" in error_msg or "sonar.login" in error_msg:
                    error_msg = (
                        f"{error_msg}\n\n"
                        f"⚠️  Authentication Error:\n"
                        f"SonarQube rejected your token. This usually means:\n"
                        f"1. Token is invalid or expired\n"
                        f"2. Token doesn't have permission to scan project '{project_key}'\n"
                        f"3. Token value contains special characters not properly escaped\n"
                        f"\nVerify token ({self.sonar_token[:10]}...) is correct and has 'scan' permission."
                    )
                # Connection errors
                elif "can not be reached" in error_msg or "Connection refused" in error_msg or "Failed to connect" in error_msg:
                    error_msg = (
                        f"{error_msg}\n\n"
                        f"⚠️  SonarQube Connection Issue:\n"
                        f"The remote server cannot reach SonarQube at '{self.sonar_host_url}'.\n"
                        f"If you're using 'localhost' or '127.0.0.1', the remote server will try to connect to itself.\n"
                        f"Please provide the public IP/hostname of your SonarQube server in the 'sonar_host_url' parameter.\n"
                        f"Example: 'http://YOUR_PUBLIC_IP:9000' or 'http://your-domain.com:9000'"
                    )
                # Checksum/plugin download errors - suggest clearing cache
                elif "checksum" in error_msg.lower() or "fail to download plugin" in error_msg.lower():
                    error_msg = (
                        f"{error_msg}\n\n"
                        f"⚠️  Plugin Download Issue:\n"
                        f"SonarScanner encountered a checksum mismatch while downloading plugins.\n"
                        f"This usually indicates a corrupted cache or network interruption.\n"
                        f"The cache has been cleared. Please try the scan again.\n"
                        f"If the issue persists, check network connectivity and firewall settings."
                    )
                
                return {
                    "success": False,
                    "error": error_msg,
                    "stdout": result["stdout"],
                    "stderr": result["stderr"]
                }
                
        except Exception as e:
            logger.error(f"Failed to run CLI scan: {e}", exc_info=True)
            return {
                "success": False,
                "error": str(e)
            }
    
    def scan(self, project_key: str, project_name: str, source_path: str,
             exclusions: Optional[str] = None, prefer_docker: bool = True,
             auto_install: bool = True) -> Dict[str, Any]:
        """
        Run SonarScanner on remote server (auto-detects best method)
        
        Args:
            project_key: SonarQube project key
            project_name: Project display name
            source_path: Path to source code on remote server
            exclusions: File exclusion patterns (optional)
            prefer_docker: Prefer Docker method if available
            auto_install: Automatically install Docker or SonarScanner if not available
        """
        if not self.sonar_token:
            return {
                "success": False,
                "error": "SonarQube token is missing. Set SONAR_TOKEN in .env or pass sonar_token in the scan request."
            }
        # Check if Docker is available
        if prefer_docker and self.check_docker_available():
            logger.info("Using Docker-based SonarScanner")
            return self.scan_with_docker(project_key, project_name, source_path, exclusions)
        
        # Check if CLI scanner is installed
        if self.check_scanner_installed():
            logger.info("Using CLI-based SonarScanner")
            return self.scan_with_cli(project_key, project_name, source_path, exclusions)
        
        # Try Docker anyway (might work)
        if self.check_docker_available():
            logger.info("Docker available, attempting Docker-based scan")
            return self.scan_with_docker(project_key, project_name, source_path, exclusions)
        
        # Auto-install if enabled
        if auto_install:
            logger.info("Neither Docker nor SonarScanner CLI is available. Attempting auto-installation...")
            
            docker_install_result = None
            scanner_install_result = None
            
            # Try to install Docker first (preferred)
            if prefer_docker:
                logger.info("Attempting to install Docker...")
                docker_install_result = self.install_docker()
                if docker_install_result.get("success"):
                    logger.info("Docker installed successfully, retrying scan...")
                    return self.scan_with_docker(project_key, project_name, source_path, exclusions)
                else:
                    logger.warning(f"Docker installation failed: {docker_install_result.get('error')}")
            
            # Try to install SonarScanner CLI as fallback
            logger.info("Attempting to install SonarScanner CLI...")
            scanner_install_result = self.install_scanner_cli()
            if scanner_install_result.get("success"):
                logger.info("SonarScanner CLI installed successfully, retrying scan...")
                # Use full path if provided
                scanner_path = scanner_install_result.get("path", "sonar-scanner")
                return self.scan_with_cli(project_key, project_name, source_path, exclusions, scanner_path=scanner_path)
            else:
                logger.error(f"SonarScanner CLI installation failed: {scanner_install_result.get('error')}")
                docker_error = docker_install_result.get('error', 'Not attempted') if docker_install_result else 'Not attempted'
                docker_output = docker_install_result.get('output', '')[:200] if docker_install_result else ''
                docker_errors = docker_install_result.get('errors', '')[:200] if docker_install_result else ''
                
                scanner_error = scanner_install_result.get('error', 'Unknown') if scanner_install_result else 'Unknown'
                scanner_output = scanner_install_result.get('output', '')[:200] if scanner_install_result else ''
                scanner_errors = scanner_install_result.get('errors', '')[:200] if scanner_install_result else ''
                
                error_msg = f"Failed to auto-install Docker or SonarScanner CLI.\n"
                error_msg += f"Docker error: {docker_error}\n"
                if docker_output:
                    error_msg += f"Docker output: {docker_output}\n"
                if docker_errors:
                    error_msg += f"Docker errors: {docker_errors}\n"
                error_msg += f"\nScanner CLI error: {scanner_error}\n"
                if scanner_output:
                    error_msg += f"Scanner output: {scanner_output}\n"
                if scanner_errors:
                    error_msg += f"Scanner errors: {scanner_errors}"
                
                return {
                    "success": False,
                    "error": error_msg,
                    "installation_attempts": {
                        "docker": docker_install_result,
                        "scanner_cli": scanner_install_result
                    }
                }
        
        return {
            "success": False,
            "error": "Neither Docker nor SonarScanner CLI is available on remote server. Please install Docker or SonarScanner CLI."
        }

