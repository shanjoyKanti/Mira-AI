"""
Cross-file migration state.

Problem it solves:
  * When the agent modernizes file A, it might rename `calc()` → `calculate()`,
    change a function's parameters, or replace `require('foo')` with
    `import foo from 'foo'`.
  * When the agent later processes file B, which calls `calc()` or
    `require('foo')`, it has no memory of what A did. So the two files
    end up inconsistent: A is upgraded, B still uses the old names, and
    the project breaks.

What this module does:
  * After each file is modernized, the agent asks the LLM for a small
    JSON summary of CONTRACT CHANGES it made (renames, signature
    tweaks, import replacements). One extra LLM call per file, kept
    cheap by a tiny prompt.
  * The ProjectMigrationState accumulates these changes across the
    whole pipeline.
  * On every subsequent file, the agent injects a short "project
    contract changes so far" block into the prompt so the LLM can
    make the new file consistent with what was already done.

Design notes:
  * State is per-(project, language) within a single run. Two parallel
    languages maintain separate states — they can't see each other's
    changes. That's a deliberate simplification: cross-language
    contract tracking is a different problem (API boundaries, not
    in-process calls).
  * Caps size to avoid inflating prompts as the state grows: oldest
    entries drop off once the state exceeds MAX_STATE_CHARS.
  * Thread-safe for the analyze flow (workers in ThreadPoolExecutor).
"""

from __future__ import annotations

import json
import logging
import re
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Cap the serialized state injected into prompts. Beyond this, we drop
# the oldest entries (FIFO) so long migrations don't explode token use.
MAX_STATE_CHARS = 4000


@dataclass
class ContractChange:
    """One contract-level change the agent made to an already-processed file."""
    kind: str              # "rename" | "signature" | "import" | "type" | "deprecation"
    from_: str             # old symbol / import / signature
    to: str                # new symbol / import / signature
    file: str              # where the change happened
    note: str = ""         # optional human-readable explanation

    def to_dict(self) -> Dict[str, Any]:
        return {"kind": self.kind, "from": self.from_, "to": self.to, "file": self.file, "note": self.note}


class ProjectMigrationState:
    """
    Accumulated contract changes for one language pipeline.

    Usage from an agent:
        state = ProjectMigrationState(language="php")
        for each file:
            upgraded = agent.modernize_file(code, project_context=state.as_prompt_block())
            state.ingest_llm_summary(upgraded, summary_json)
    """

    def __init__(self, language: str):
        self.language = language
        self._changes: List[ContractChange] = []
        self._files_processed: int = 0
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def add_change(self, change: ContractChange) -> None:
        with self._lock:
            self._changes.append(change)

    def ingest_llm_summary(self, file_path: str, summary_raw: Any) -> int:
        """
        Parse the LLM's contract-change summary for a file and append entries
        to this state. Returns the number of new changes added.

        Accepts either a raw string (expected to be JSON) or an already-parsed
        dict/list. Never raises — LLM output is unreliable, so we're lenient.
        """
        parsed = self._parse_summary(summary_raw)
        if not parsed:
            return 0
        added = 0
        for raw in parsed:
            if not isinstance(raw, dict):
                continue
            kind = (raw.get("kind") or "").strip().lower()
            if kind not in {"rename", "signature", "import", "type", "deprecation"}:
                # LLMs sometimes invent new categories — accept them but normalize
                kind = "rename" if kind else "other"
            frm = str(raw.get("from", "")).strip()
            to = str(raw.get("to", "")).strip()
            note = str(raw.get("note", "")).strip()
            if not frm and not to:
                continue
            with self._lock:
                self._changes.append(ContractChange(
                    kind=kind, from_=frm, to=to, file=file_path, note=note,
                ))
            added += 1
        with self._lock:
            self._files_processed += 1
        return added

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def as_prompt_block(self) -> str:
        """
        Short text block suitable to inject into the next file's prompt.
        Trimmed to MAX_STATE_CHARS (oldest-first drop).
        """
        with self._lock:
            if not self._changes:
                return ""
            # Render newest first so the most recent context survives truncation.
            lines = ["## PROJECT CONTRACT CHANGES (already applied to earlier files in this run):"]
            changes_newest_first = list(reversed(self._changes))
            for c in changes_newest_first:
                bullet = f"- [{c.kind}] {c.from_!r} → {c.to!r}"
                if c.file:
                    bullet += f"  (in {c.file})"
                if c.note:
                    bullet += f"  — {c.note}"
                lines.append(bullet)
            text = "\n".join(lines)
            if len(text) <= MAX_STATE_CHARS:
                return text + "\n"
            # Truncate in the middle: keep the header + last 30 most-recent lines.
            return "\n".join(lines[:1] + lines[1:31] + [
                f"... {len(lines) - 31} older contract changes truncated."
            ]) + "\n"

    def snapshot(self) -> Dict[str, Any]:
        """Serializable state for Mongo / telemetry."""
        with self._lock:
            return {
                "language": self.language,
                "files_processed": self._files_processed,
                "total_changes": len(self._changes),
                "changes_sample": [c.to_dict() for c in self._changes[-50:]],
            }

    # ------------------------------------------------------------------
    # Parsing helpers
    # ------------------------------------------------------------------

    _JSON_RE = re.compile(r"\{.*\}|\[.*\]", re.DOTALL)

    def _parse_summary(self, raw: Any) -> List[Dict[str, Any]]:
        """Extract a list of contract-change dicts from whatever the LLM returned."""
        if raw is None:
            return []
        if isinstance(raw, list):
            return [x for x in raw if isinstance(x, dict)]
        if isinstance(raw, dict):
            # Sometimes the LLM wraps the list: {"changes": [...]}
            for k in ("changes", "contract_changes", "items", "summary"):
                v = raw.get(k)
                if isinstance(v, list):
                    return [x for x in v if isinstance(x, dict)]
            return []
        if isinstance(raw, str):
            s = raw.strip()
            if not s:
                return []
            # Try direct parse
            try:
                return self._parse_summary(json.loads(s))
            except Exception:
                pass
            # Extract first JSON-looking span
            m = self._JSON_RE.search(s)
            if not m:
                return []
            try:
                return self._parse_summary(json.loads(m.group(0)))
            except Exception:
                return []
        return []


# ---------------------------------------------------------------------------
# Convenience prompt for asking the LLM to emit a contract-change summary
# ---------------------------------------------------------------------------

CONTRACT_SUMMARY_SYSTEM_PROMPT = (
    "You just modernized one source file. Now emit a VERY SHORT JSON summary "
    "of the CONTRACT-LEVEL changes you made — only the things other files in "
    "the same project need to know about. Skip internal/cosmetic edits."
)

CONTRACT_SUMMARY_USER_TEMPLATE = """Given the diff below (original → upgraded), return ONLY a JSON array (possibly empty).

Each entry must have keys: `kind`, `from`, `to`, and optional `note`.
Allowed `kind` values: rename, signature, import, type, deprecation.

  * "rename": a public symbol (function, method, class) was renamed
  * "signature": a public function/method signature changed (params added/removed/renamed)
  * "import": an import / require / use statement was replaced
  * "type": a type shape other files may consume was changed
  * "deprecation": a symbol was removed/deprecated and callers must stop using it

If no public-facing contracts changed, return `[]`.

ORIGINAL:
```{language}
{original}
```

UPGRADED:
```{language}
{upgraded}
```

Return ONLY the JSON array — no prose, no markdown fences."""
