"""
Post-migration validation pipeline.

Runs 3 layers of validation on every file the migration wrote back to the VM:

  1. Tree-sitter parse (local, in-process, fast)
       — catches grammar-level errors.
  2. Native linter via SSH on the client VM (authoritative)
       — php -l, node --check, python -m py_compile, javac, go vet, etc.
       — only runs if the tool is available on the remote VM;
         otherwise recorded as "skipped".
  3. SonarQube rescan delta (optional)
       — compares before/after issue counts per-project.

Each layer produces a per-file result; all results roll up into a
ValidationReport stored on the ModernizationJob. The pipeline NEVER
modifies code; it only reports. Callers decide whether to roll back
on validation failure.

Design notes:
  * We run native checks with a 10-second per-file timeout so a hung
    compiler can't stall the whole pipeline.
  * We batch SSH invocations when possible (~20 files per batch) to
    avoid 1 round-trip per file on 1000+ file projects.
  * Layer 1 runs in a ThreadPoolExecutor; Layer 2 runs sequentially
    per SSH channel (paramiko channels are not safe for concurrent use
    without extra lock discipline). For large projects, consider
    opening N parallel SSH channels if layer-2 becomes the bottleneck.
"""

from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Native syntax-check command templates per language.
# Each returns a dict: {"cmd": "shell-cmd-with-{f}-placeholder", "tool": "human-readable-tool-name"}
# The cmd must exit 0 on pass, non-zero on syntax error, and write any error
# to stdout or stderr (we capture both).
# We use a `which <tool>` preflight to detect whether the tool is available
# on the remote VM; if not, we skip the native layer for that file.
# ---------------------------------------------------------------------------
NATIVE_SYNTAX_CHECKS: Dict[str, Dict[str, str]] = {
    "php": {
        "precheck": "command -v php",
        "cmd_template": "php -l '{f}' 2>&1",
        "tool": "php -l",
    },
    "python": {
        "precheck": "command -v python3 || command -v python",
        # python -m py_compile is in the stdlib; fall back to python
        "cmd_template": "(command -v python3 >/dev/null 2>&1 && python3 -m py_compile '{f}' || python -m py_compile '{f}') 2>&1",
        "tool": "python -m py_compile",
    },
    "javascript": {
        "precheck": "command -v node",
        "cmd_template": "node --check '{f}' 2>&1",
        "tool": "node --check",
    },
    "typescript": {
        "precheck": "command -v tsc || command -v npx",
        "cmd_template": "(command -v tsc >/dev/null 2>&1 && tsc --noEmit '{f}' || npx --yes -p typescript tsc --noEmit '{f}') 2>&1",
        "tool": "tsc --noEmit",
    },
    "tsx": {
        "precheck": "command -v tsc || command -v npx",
        "cmd_template": "(command -v tsc >/dev/null 2>&1 && tsc --noEmit --jsx react '{f}' || npx --yes -p typescript tsc --noEmit --jsx react '{f}') 2>&1",
        "tool": "tsc --noEmit --jsx react",
    },
    "go": {
        # gofmt ships with the go toolchain; we use it for a syntax-only check
        # to avoid requiring the full `go build` module graph.
        "precheck": "command -v gofmt",
        "cmd_template": "gofmt -e -l '{f}' 2>&1 && echo __GOFMT_OK__",
        # gofmt prints the filename when there's a diff. We add a sentinel and
        # treat anything written before __GOFMT_OK__ as a syntax problem.
        "tool": "gofmt -e",
    },
    "java": {
        "precheck": "command -v javac",
        # -Xstdout is not portable; we write class files to /tmp so we don't
        # pollute the project, and drop the output via -d /tmp.
        "cmd_template": "javac -Xlint:none -d /tmp '{f}' 2>&1",
        "tool": "javac (syntax only)",
    },
    "c_sharp": {
        # dotnet ships `dotnet-script` only when installed; `csc` is part of
        # the .NET SDK but invocation is ugly. Try `dotnet-script --help` first.
        "precheck": "command -v dotnet",
        "cmd_template": "dotnet build --no-restore --nologo /t:SyntaxOnly '{f}' 2>&1 || dotnet build --no-restore --nologo 2>&1 | head -20",
        "tool": "dotnet build",
    },
    "ruby": {
        "precheck": "command -v ruby",
        "cmd_template": "ruby -c '{f}' 2>&1",
        "tool": "ruby -c",
    },
    "rust": {
        # `rustc --emit=metadata` parses without linking. Requires rustc.
        "precheck": "command -v rustc",
        "cmd_template": "rustc --emit=metadata --crate-type lib -o /tmp/mira_rust_check.rmeta '{f}' 2>&1",
        "tool": "rustc --emit=metadata",
    },
}

# Which tree-sitter language name to use per request language
_TREE_SITTER_LANG: Dict[str, str] = {
    "php":        "php",
    "python":     "python",
    "javascript": "javascript",
    "typescript": "typescript",
    "tsx":        "tsx",
    "java":       "java",
    "c_sharp":    "c_sharp",
    "csharp":     "c_sharp",
    "go":         "go",
    "ruby":       "ruby",
    "rust":       "rust",
    "kotlin":     "kotlin",
    "scala":      "scala",
    "cpp":        "cpp",
    "c":          "c",
}


class CheckOutcome(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIPPED = "skipped"        # tool unavailable
    TIMED_OUT = "timed_out"
    NOT_APPLICABLE = "not_applicable"  # language has no parser/linter


@dataclass
class FileValidationResult:
    """Per-file outcome across all validation layers."""
    rel_path: str
    language: str
    # Layer 1 — tree-sitter
    tree_sitter_outcome: CheckOutcome = CheckOutcome.NOT_APPLICABLE
    tree_sitter_errors: List[str] = field(default_factory=list)
    # Layer 2 — native linter
    native_outcome: CheckOutcome = CheckOutcome.NOT_APPLICABLE
    native_tool: Optional[str] = None
    native_error_excerpt: Optional[str] = None  # truncated stdout/stderr on failure

    @property
    def is_ok(self) -> bool:
        """True if every applicable check passed (skipped/NA are not failures)."""
        for outcome in (self.tree_sitter_outcome, self.native_outcome):
            if outcome == CheckOutcome.FAIL or outcome == CheckOutcome.TIMED_OUT:
                return False
        return True

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        # CheckOutcome enum → string for Mongo storage
        d["tree_sitter_outcome"] = self.tree_sitter_outcome.value
        d["native_outcome"] = self.native_outcome.value
        return d


@dataclass
class ValidationReport:
    """Rolled-up validation report for a single language pipeline."""
    language: str
    total_files: int = 0
    files: List[FileValidationResult] = field(default_factory=list)
    # Counters
    tree_sitter_passed: int = 0
    tree_sitter_failed: int = 0
    tree_sitter_not_applicable: int = 0
    native_passed: int = 0
    native_failed: int = 0
    native_skipped: int = 0
    native_timed_out: int = 0
    native_not_applicable: int = 0
    # SonarQube delta (optional)
    sonarqube_before_issues: Optional[int] = None
    sonarqube_after_issues: Optional[int] = None
    sonarqube_delta: Optional[int] = None
    sonarqube_fixed_count: Optional[int] = None
    sonarqube_new_count: Optional[int] = None
    # Timing
    duration_seconds: float = 0.0
    # Whether we consider the whole migration "clean"
    overall_ok: bool = False
    overall_summary: str = ""

    def to_dict(self, include_per_file: bool = True) -> Dict[str, Any]:
        d = {
            "language": self.language,
            "total_files": self.total_files,
            "tree_sitter_passed": self.tree_sitter_passed,
            "tree_sitter_failed": self.tree_sitter_failed,
            "tree_sitter_not_applicable": self.tree_sitter_not_applicable,
            "native_passed": self.native_passed,
            "native_failed": self.native_failed,
            "native_skipped": self.native_skipped,
            "native_timed_out": self.native_timed_out,
            "native_not_applicable": self.native_not_applicable,
            "sonarqube_before_issues": self.sonarqube_before_issues,
            "sonarqube_after_issues": self.sonarqube_after_issues,
            "sonarqube_delta": self.sonarqube_delta,
            "sonarqube_fixed_count": self.sonarqube_fixed_count,
            "sonarqube_new_count": self.sonarqube_new_count,
            "duration_seconds": round(self.duration_seconds, 2),
            "overall_ok": self.overall_ok,
            "overall_summary": self.overall_summary,
        }
        if include_per_file:
            # Cap per-file entries to avoid hitting Mongo's 16 MB document limit
            # on a 50k-file project. Callers can paginate via the per-language
            # endpoint if they need the full list.
            MAX_FILES_IN_REPORT = 2000
            files_to_serialize = self.files[:MAX_FILES_IN_REPORT]
            d["files"] = [f.to_dict() for f in files_to_serialize]
            if len(self.files) > MAX_FILES_IN_REPORT:
                d["files_truncated"] = True
                d["files_total_count"] = len(self.files)
        return d


def _native_tool_available(ssh_conn, language: str) -> Tuple[bool, str]:
    """Probe the remote VM for the language's native linter. Returns (available, tool_name)."""
    cfg = NATIVE_SYNTAX_CHECKS.get(language)
    if not cfg:
        return False, ""
    try:
        res = ssh_conn.execute_command(cfg["precheck"] + " >/dev/null 2>&1 && echo YES || echo NO")
        out = (res.get("stdout") or "").strip()
        return out == "YES", cfg["tool"]
    except Exception as e:
        logger.debug("native tool precheck for %s failed: %s", language, e)
        return False, cfg["tool"]


def _run_native_check(
    ssh_conn,
    language: str,
    remote_file: str,
    timeout_sec: int = 10,
) -> Tuple[CheckOutcome, Optional[str]]:
    """Run the native linter for `language` on `remote_file`. Returns (outcome, error_excerpt)."""
    cfg = NATIVE_SYNTAX_CHECKS.get(language)
    if not cfg:
        return CheckOutcome.NOT_APPLICABLE, None
    cmd_template = cfg["cmd_template"]
    # Build the command with `timeout` wrapper on the remote (POSIX timeout utility)
    cmd_core = cmd_template.format(f=remote_file.replace("'", "'\\''"))
    wrapped = f"timeout {timeout_sec} sh -c {_sh_quote(cmd_core)}"
    try:
        res = ssh_conn.execute_command(wrapped)
    except Exception as e:
        logger.debug("native check crashed for %s: %s", remote_file, e)
        return CheckOutcome.FAIL, f"exec error: {e}"[:500]
    exit_code = res.get("exit_code", 0) if isinstance(res, dict) else 0
    stdout = (res.get("stdout") or "") if isinstance(res, dict) else ""
    stderr = (res.get("stderr") or "") if isinstance(res, dict) else ""
    combined = (stdout + stderr).strip()
    # `timeout` returns 124 when it kills the command
    if exit_code == 124:
        return CheckOutcome.TIMED_OUT, combined[:500] or "command timed out"
    # gofmt special case: exit 0 even on format issues; look for our sentinel
    if language == "go":
        if "__GOFMT_OK__" in combined and not any(
            line.strip() and not line.startswith("__GOFMT_OK__")
            for line in combined.split("\n")[:-1]
        ):
            return CheckOutcome.PASS, None
        # gofmt emits the filename of broken files to stdout
        cleaned = combined.replace("__GOFMT_OK__", "").strip()
        if cleaned and not res.get("success", True):
            return CheckOutcome.FAIL, cleaned[:500]
        # If we have output other than the sentinel, something's wrong
        if cleaned:
            return CheckOutcome.FAIL, cleaned[:500]
        return CheckOutcome.PASS, None
    # PHP -l: "No syntax errors detected" on pass, "Parse error:" on fail
    if language == "php":
        if "No syntax errors detected" in combined:
            return CheckOutcome.PASS, None
        if "Parse error" in combined or "syntax error" in combined.lower() or exit_code != 0:
            return CheckOutcome.FAIL, combined[:500]
        # Unexpected output — pass with a note
        return CheckOutcome.PASS, None
    # Python py_compile: exit 0 on pass, non-zero on fail
    if language == "python":
        if exit_code == 0:
            return CheckOutcome.PASS, None
        return CheckOutcome.FAIL, combined[:500]
    # javac / rustc / node / tsc / ruby / dotnet all follow the same convention
    if exit_code == 0:
        return CheckOutcome.PASS, None
    return CheckOutcome.FAIL, combined[:500] or "non-zero exit"


def _sh_quote(s: str) -> str:
    """Single-quote a shell argument."""
    return "'" + s.replace("'", "'\\''") + "'"


# ---------------------------------------------------------------------------
# Tree-sitter layer
# ---------------------------------------------------------------------------

# Tree-sitter's native C parsers can SIGSEGV on pathologically large or
# adversarial inputs. Python cannot catch a segfault — it would take down
# the whole Uvicorn worker. We guard with a hard size cap (segfaults are
# overwhelmingly correlated with very large inputs), and the outer
# try/except handles anything that actually raises in Python.
_TREE_SITTER_MAX_BYTES = 2 * 1024 * 1024  # 2 MB


def _run_tree_sitter(code: str, language: str) -> Tuple[CheckOutcome, List[str]]:
    """Use app.services.code_validator to parse. Returns (outcome, error_snippets)."""
    ts_lang = _TREE_SITTER_LANG.get(language)
    if not ts_lang:
        return CheckOutcome.NOT_APPLICABLE, []
    # Size guard: skip very large files rather than risk a SIGSEGV in the
    # native parser. The file is still validated by the native linter layer.
    if len(code) > _TREE_SITTER_MAX_BYTES:
        return CheckOutcome.SKIPPED, [
            f"file is {len(code)} bytes; exceeds tree-sitter cap of {_TREE_SITTER_MAX_BYTES}"
        ]
    try:
        from app.services.code_validator import validate_syntax
        result = validate_syntax(code, ts_lang)
        if result.parse_skipped:
            return CheckOutcome.SKIPPED, []
        if result.ok:
            return CheckOutcome.PASS, []
        errors = [
            f"line {e.start_line}: [{e.kind}] {e.snippet}"
            for e in result.errors[:5]
        ]
        return CheckOutcome.FAIL, errors
    except Exception as e:
        logger.debug("tree-sitter validate crashed: %s", e)
        return CheckOutcome.SKIPPED, [f"parser crashed: {e}"]


# ---------------------------------------------------------------------------
# Main entry
# ---------------------------------------------------------------------------

def validate_upgraded_files(
    ssh_conn,
    remote_output_dir: str,
    upgraded_files: List[Dict[str, Any]],
    language: str,
    *,
    native_timeout_sec: int = 10,
    tree_sitter_concurrency: int = 4,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
) -> ValidationReport:
    """
    Validate every upgraded file. `upgraded_files` is the list produced by
    the modernization agent: each entry has {path, code, changes}.

    Args:
        ssh_conn: Active SSH connection to the client VM (used for native linter calls).
        remote_output_dir: Remote directory where the upgraded files were uploaded.
        upgraded_files: Files from the agent result, with `path` (relative) and `code`.
        language: Language key (e.g. "php", "javascript").
        native_timeout_sec: Per-file timeout for native linter.
        tree_sitter_concurrency: Parallel tree-sitter workers.
        progress_cb: Optional callable(i, total, rel_path) for live progress updates.

    Returns:
        A ValidationReport.
    """
    t_start = time.time()
    report = ValidationReport(language=language, total_files=len(upgraded_files))

    # --- Layer 1: tree-sitter (parallel, local) ---
    logger.info("Validation[%s]: tree-sitter pass on %d file(s)", language, len(upgraded_files))
    ts_results: Dict[str, Tuple[CheckOutcome, List[str]]] = {}
    with ThreadPoolExecutor(
        max_workers=max(1, tree_sitter_concurrency),
        thread_name_prefix="mira-validate-ts",
    ) as pool:
        futures = {
            pool.submit(_run_tree_sitter, f.get("code", ""), language): f.get("path", "?")
            for f in upgraded_files
        }
        for fut in as_completed(futures):
            rel = futures[fut]
            try:
                outcome, errors = fut.result()
            except Exception as e:
                outcome, errors = CheckOutcome.SKIPPED, [f"worker crashed: {e}"]
            ts_results[rel] = (outcome, errors)

    # --- Layer 2: native linter (serial over one SSH channel) ---
    # Preflight: is the tool available on the remote VM?
    native_available, tool_name = _native_tool_available(ssh_conn, language)
    if not native_available:
        logger.info(
            "Validation[%s]: native linter %r unavailable on VM; skipping layer 2",
            language, tool_name or "(no tool configured)",
        )

    native_results: Dict[str, Tuple[CheckOutcome, Optional[str]]] = {}
    if native_available:
        logger.info(
            "Validation[%s]: native pass using %r (timeout=%ds)",
            language, tool_name, native_timeout_sec,
        )
        # Process in the same order the files were uploaded so progress_cb
        # reports a sensible index.
        for i, f in enumerate(upgraded_files, start=1):
            rel = f.get("path", "?")
            remote_path = f"{remote_output_dir.rstrip('/')}/{rel}"
            if progress_cb:
                try:
                    progress_cb(i, len(upgraded_files), rel)
                except Exception:
                    pass
            try:
                outcome, err = _run_native_check(
                    ssh_conn, language, remote_path, timeout_sec=native_timeout_sec,
                )
            except Exception as e:
                outcome, err = CheckOutcome.FAIL, f"exec exception: {e}"[:500]
            native_results[rel] = (outcome, err)

    # --- Merge into per-file results ---
    for f in upgraded_files:
        rel = f.get("path", "?")
        ts_outcome, ts_errors = ts_results.get(rel, (CheckOutcome.NOT_APPLICABLE, []))
        if native_available:
            nat_outcome, nat_err = native_results.get(rel, (CheckOutcome.SKIPPED, None))
        else:
            nat_outcome, nat_err = CheckOutcome.SKIPPED, None

        fvr = FileValidationResult(
            rel_path=rel,
            language=language,
            tree_sitter_outcome=ts_outcome,
            tree_sitter_errors=ts_errors,
            native_outcome=nat_outcome,
            native_tool=tool_name if native_available else None,
            native_error_excerpt=nat_err,
        )
        report.files.append(fvr)

        # Counters
        {
            CheckOutcome.PASS:             lambda: setattr(report, "tree_sitter_passed",         report.tree_sitter_passed + 1),
            CheckOutcome.FAIL:             lambda: setattr(report, "tree_sitter_failed",         report.tree_sitter_failed + 1),
            CheckOutcome.SKIPPED:          lambda: None,
            CheckOutcome.TIMED_OUT:        lambda: setattr(report, "tree_sitter_failed",         report.tree_sitter_failed + 1),
            CheckOutcome.NOT_APPLICABLE:   lambda: setattr(report, "tree_sitter_not_applicable", report.tree_sitter_not_applicable + 1),
        }[ts_outcome]()
        {
            CheckOutcome.PASS:             lambda: setattr(report, "native_passed",         report.native_passed + 1),
            CheckOutcome.FAIL:             lambda: setattr(report, "native_failed",         report.native_failed + 1),
            CheckOutcome.SKIPPED:          lambda: setattr(report, "native_skipped",        report.native_skipped + 1),
            CheckOutcome.TIMED_OUT:        lambda: setattr(report, "native_timed_out",      report.native_timed_out + 1),
            CheckOutcome.NOT_APPLICABLE:   lambda: setattr(report, "native_not_applicable", report.native_not_applicable + 1),
        }[nat_outcome]()

    report.duration_seconds = time.time() - t_start

    # --- Overall verdict ---
    has_failures = report.tree_sitter_failed > 0 or report.native_failed > 0 or report.native_timed_out > 0
    report.overall_ok = not has_failures
    report.overall_summary = _format_summary(report)

    logger.info(
        "Validation[%s]: done in %.1fs — tree-sitter: %d pass / %d fail; native(%s): %d pass / %d fail / %d skip / %d timeout",
        language, report.duration_seconds,
        report.tree_sitter_passed, report.tree_sitter_failed,
        tool_name if native_available else "n/a",
        report.native_passed, report.native_failed, report.native_skipped, report.native_timed_out,
    )
    # Prometheus: roll up the counts so ops can watch pass/fail trends.
    try:
        from app.core.metrics import mira_validation_outcome_total
        mira_validation_outcome_total.labels(layer="tree_sitter", outcome="pass").inc(report.tree_sitter_passed)
        mira_validation_outcome_total.labels(layer="tree_sitter", outcome="fail").inc(report.tree_sitter_failed)
        mira_validation_outcome_total.labels(layer="native_linter", outcome="pass").inc(report.native_passed)
        mira_validation_outcome_total.labels(layer="native_linter", outcome="fail").inc(report.native_failed)
        mira_validation_outcome_total.labels(layer="native_linter", outcome="skip").inc(report.native_skipped)
        mira_validation_outcome_total.labels(layer="native_linter", outcome="timeout").inc(report.native_timed_out)
    except Exception:
        pass
    return report


def _format_summary(r: ValidationReport) -> str:
    """Short human-friendly summary line."""
    total_checked = r.total_files
    any_fail = r.tree_sitter_failed + r.native_failed + r.native_timed_out
    if total_checked == 0:
        return "No files to validate"
    if any_fail == 0 and r.overall_ok:
        parts = [f"All {total_checked} file(s) passed tree-sitter parse"]
        if r.native_passed > 0:
            parts.append(f"{r.native_passed} passed native linter")
        if r.native_skipped > 0:
            parts.append(f"{r.native_skipped} skipped (tool unavailable)")
        return "; ".join(parts)
    return (
        f"{any_fail} of {total_checked} file(s) failed validation — "
        f"tree-sitter: {r.tree_sitter_failed}, native: {r.native_failed}, timeout: {r.native_timed_out}"
    )


# ---------------------------------------------------------------------------
# SonarQube delta layer (optional)
# ---------------------------------------------------------------------------

def attach_sonarqube_delta(
    report: ValidationReport,
    before_issue_count: Optional[int],
    after_issue_count: Optional[int],
) -> None:
    """Attach SonarQube before/after counts to the report. Caller is responsible
    for actually running the scans and passing the numbers in."""
    if before_issue_count is None or after_issue_count is None:
        return
    report.sonarqube_before_issues = int(before_issue_count)
    report.sonarqube_after_issues = int(after_issue_count)
    delta = int(before_issue_count) - int(after_issue_count)
    report.sonarqube_delta = delta
    # A precise "fixed" count is impossible without matching issue IDs;
    # for now use delta as the headline number.
    report.sonarqube_fixed_count = max(0, delta)
    report.sonarqube_new_count = max(0, -delta)
