"""Rate limiting middleware and utilities"""
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi import Request, HTTPException, status
from functools import wraps
from typing import Callable, Optional

from app.core.config import settings


def get_rate_limit_key(request: Request) -> str:
    """
    Get rate limit key based on authenticated user, falling back to IP.

    Prefers the authenticated user's id so that multiple users behind the same
    corporate NAT (or proxy) get independent quotas. Without this, one noisy
    user can starve every teammate sharing their egress IP.
    """
    # Try to get user from token if authenticated (middleware sets this)
    user = getattr(request.state, "user", None) if request is not None else None
    if user is not None:
        uid = getattr(user, "id", None)
        if uid:
            return f"user:{uid}"

    # Fall back to IP address (unauthenticated routes still get rate-limited by IP).
    return get_remote_address(request)


# Initialize rate limiter. The key function prefers authenticated user id so
# shared-NAT users don't starve each other; unauthenticated endpoints degrade
# to IP-based limiting automatically.
limiter = Limiter(
    key_func=get_rate_limit_key,
    default_limits=["100/minute"],
    storage_uri=settings.REDIS_URL,  # Redis for distributed rate limiting
    strategy="fixed-window",
)


def custom_rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded):
    """Custom rate limit exceeded handler"""
    raise HTTPException(
        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
        detail={
            "error": "Rate limit exceeded",
            "message": "Too many requests. Please try again later.",
            "retry_after": exc.detail
        }
    )
