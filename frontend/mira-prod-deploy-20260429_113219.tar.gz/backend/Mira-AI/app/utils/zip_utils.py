"""ZIP file utilities"""
import zipfile
from pathlib import Path
from typing import List, Optional
from app.core.logging import get_logger

logger = get_logger(__name__)


def extract_zip(zip_path: Path, extract_to: Path) -> bool:
    """
    Extract ZIP file to destination
    
    Args:
        zip_path: Path to ZIP file
        extract_to: Destination directory
        
    Returns:
        True if successful, False otherwise
    """
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        logger.info(f"Extracted {zip_path} to {extract_to}")
        return True
    except Exception as e:
        logger.error(f"Failed to extract {zip_path}: {str(e)}")
        return False


def create_zip(source_dir: Path, output_path: Path, include_patterns: Optional[List[str]] = None) -> bool:
    """
    Create ZIP archive from directory
    
    Args:
        source_dir: Source directory
        output_path: Output ZIP file path
        include_patterns: Optional list of file patterns to include
        
    Returns:
        True if successful, False otherwise
    """
    try:
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
            for file_path in source_dir.rglob('*'):
                if file_path.is_file():
                    # Check if file matches include patterns
                    if include_patterns:
                        if not any(file_path.match(pattern) for pattern in include_patterns):
                            continue
                    
                    arcname = file_path.relative_to(source_dir)
                    zip_ref.write(file_path, arcname)
        
        logger.info(f"Created ZIP archive: {output_path}")
        return True
    except Exception as e:
        logger.error(f"Failed to create ZIP {output_path}: {str(e)}")
        return False


def list_zip_contents(zip_path: Path) -> List[str]:
    """
    List contents of ZIP file
    
    Args:
        zip_path: Path to ZIP file
        
    Returns:
        List of file names in the ZIP
    """
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            return zip_ref.namelist()
    except Exception as e:
        logger.error(f"Failed to list ZIP contents {zip_path}: {str(e)}")
        return []


def validate_zip(zip_path: Path) -> bool:
    """
    Validate ZIP file integrity
    
    Args:
        zip_path: Path to ZIP file
        
    Returns:
        True if valid, False otherwise
    """
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            bad_file = zip_ref.testzip()
            if bad_file:
                logger.error(f"Corrupted file in ZIP: {bad_file}")
                return False
        return True
    except Exception as e:
        logger.error(f"Invalid ZIP file {zip_path}: {str(e)}")
        return False
