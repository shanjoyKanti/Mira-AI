"""SonarQube API endpoints for remote scanning and report fetching"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from typing import Optional, List
from pydantic import BaseModel, Field
from datetime import datetime
import json

from app.core.dependencies import get_current_active_user
from app.db.mongodb_models import User, SonarQubeScanJob, SonarQubeReport, ScanJobStatus
from app.services.ssh.ssh_service import SSHService
from app.services.sonarqube.remote_scanner import RemoteSonarScanner
from app.services.sonarqube.report_fetcher import SonarQubeReportFetcher
from app.services.sonarqube.report_cache import get_report_cache
from app.core.logging import get_logger
from app.core.config import settings
from app.core.encryption import encrypt_data
from app.workers.sonarqube_tasks import scan_remote_code_async

logger = get_logger(__name__)

router = APIRouter()


class SSHCredentialsRequest(BaseModel):
    """SSH credentials for remote server"""
    hostname: str = Field(..., description="Server hostname or IP address")
    port: int = Field(22, description="SSH port")
    username: str = Field(..., description="SSH username")
    password: Optional[str] = Field(None, description="SSH password")
    private_key: Optional[str] = Field(None, description="SSH private key content")
    private_key_password: Optional[str] = Field(None, description="Private key password if encrypted")


class RemoteScanRequest(BaseModel):
    """Request for remote code scanning"""
    ssh_credentials: SSHCredentialsRequest = Field(..., description="SSH credentials")
    project_key: str = Field(..., description="SonarQube project key")
    project_name: str = Field(..., description="Project display name")
    source_path: str = Field(..., description="Path to source code on remote server")
    exclusions: Optional[str] = Field(None, description="File exclusion patterns (e.g., **/__pycache__/**,**/tests/**)")
    sonar_host_url: Optional[str] = Field(None, description="SonarQube server URL (default: https://sonarqube.codsy.ai)")
    sonar_token: Optional[str] = Field(None, description="SonarQube token (if not using user's token)")
    auto_install: bool = Field(True, description="Automatically install Docker or SonarScanner CLI if not available")
    prefer_docker: bool = Field(True, description="Prefer Docker over SonarScanner CLI")


class FetchReportRequest(BaseModel):
    """Request for fetching SonarQube report"""
    project_key: str = Field(..., description="SonarQube project key")
    include_issues: bool = Field(True, description="Include issues in report")
    include_measures: bool = Field(True, description="Include measures/metrics in report")
    include_status: bool = Field(True, description="Include quality gate status")
    issue_limit: int = Field(500, description="Maximum number of issues to fetch")
    severities: Optional[List[str]] = Field(None, description="Filter issues by severity")
    types: Optional[List[str]] = Field(None, description="Filter issues by type")


class SSHTestRequest(BaseModel):
    """Request for testing SSH connection"""
    ssh_credentials: SSHCredentialsRequest = Field(..., description="SSH credentials to test")
    source_path: Optional[str] = Field(None, description="Optional: Path to verify exists on remote server")


@router.post("/scan/remote", response_model=dict, tags=["DEPRECATED — use 4-step pipeline"], deprecated=True, summary="[DEPRECATED] Raw SonarQube scan only — use /api/v1/analyze/scan/sonarqube for full scan+report")
async def scan_remote_code(
    request: RemoteScanRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Scan code on remote server via SSH
    
    This endpoint:
    1. Connects to remote server via SSH
    2. Automatically installs Docker or SonarScanner CLI if not available (if auto_install=true)
    3. Sets up SonarScanner (Docker or CLI)
    4. Runs code analysis
    5. Uploads results to SonarQube server
    
    **Note**: SonarQube server must be accessible from the remote server.
    **Auto-installation**: Requires sudo privileges on the remote server.
    """
    try:
        # Get SonarQube token (from request or environment)
        sonar_token = request.sonar_token or getattr(settings, 'SONAR_TOKEN', None)
        if not sonar_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SonarQube token is required. Provide it in request or set SONAR_TOKEN environment variable."
            )
        
        # SonarQube host URL - must be accessible from remote server
        # Default to production SonarQube server
        sonar_host_url = request.sonar_host_url or "https://sonarqube.codsy.ai"
        
        # Warn if using localhost (remote server won't be able to reach it)
        if "localhost" in sonar_host_url or "127.0.0.1" in sonar_host_url:
            logger.warning(
                f"SonarQube URL '{sonar_host_url}' uses localhost. "
                f"Remote server {request.ssh_credentials.hostname} may not be able to reach it. "
                f"Consider providing a public IP/hostname in 'sonar_host_url' parameter."
            )
        
        # Create SSH connection
        ssh_conn = SSHService.create_connection(
            hostname=request.ssh_credentials.hostname,
            port=request.ssh_credentials.port,
            username=request.ssh_credentials.username,
            password=request.ssh_credentials.password,
            private_key=request.ssh_credentials.private_key,
            private_key_password=request.ssh_credentials.private_key_password
        )
        
        if not ssh_conn.connect():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to connect to SSH server {request.ssh_credentials.hostname}:{request.ssh_credentials.port}"
            )
        
        try:
            # Create remote scanner
            scanner = RemoteSonarScanner(
                ssh_conn=ssh_conn,
                sonar_token=sonar_token,
                sonar_host_url=sonar_host_url
            )
            
            # Run scan
            result = scanner.scan(
                project_key=request.project_key,
                project_name=request.project_name,
                source_path=request.source_path,
                exclusions=request.exclusions,
                prefer_docker=request.prefer_docker,
                auto_install=request.auto_install
            )
            
            response = {
                "success": result.get("success", False),
                "project_key": request.project_key,
                "message": result.get("message", "Scan completed"),
                "scan_output": result.get("stdout", ""),
                "scan_errors": result.get("stderr", ""),
                "error": result.get("error") if not result.get("success") else None
            }
            
            # Include installation attempts details if available
            if "installation_attempts" in result:
                response["installation_attempts"] = result["installation_attempts"]
            
            return response
            
        finally:
            ssh_conn.disconnect()
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to scan remote code: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to scan remote code: {str(e)}"
        )


@router.post("/reports/fetch", response_model=dict, tags=["Utilities — SonarQube"], summary="Fetch SonarQube report by project key (raw Sonar API)")
async def fetch_sonarqube_report(
    request: FetchReportRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Fetch SonarQube report for a project
    
    Returns comprehensive report including:
    - Project measures/metrics
    - Code issues (bugs, vulnerabilities, code smells)
    - Quality gate status
    - Project information
    """
    try:
        # Get SonarQube token (from environment or settings)
        sonar_token = getattr(settings, 'SONAR_TOKEN', None)
        if not sonar_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SonarQube token is required. Set SONAR_TOKEN environment variable."
            )
        
        # Get SonarQube host URL
        sonar_host_url = getattr(settings, 'SONAR_HOST_URL', 'https://sonarqube.codsy.ai')
        
        # Warn if using localhost (remote servers won't be able to reach it)
        if "localhost" in sonar_host_url or "127.0.0.1" in sonar_host_url:
            logger.warning(
                "Using localhost for SonarQube URL. Remote servers will not be able to reach it. "
                "Use a public domain like https://sonarqube.codsy.ai"
            )
        
        # Create report fetcher
        fetcher = SonarQubeReportFetcher(
            sonar_host_url=sonar_host_url,
            sonar_token=sonar_token
        )
        
        if request.include_measures and request.include_issues and request.include_status:
            # Get full report
            report = fetcher.get_full_report(request.project_key)
        else:
            # Get partial report based on request
            report = {"success": True, "project_key": request.project_key}
            
            if request.include_measures:
                measures = fetcher.get_project_measures(request.project_key)
                report["measures"] = measures.get("measures", []) if measures.get("success") else []
            
            if request.include_issues:
                issues = fetcher.get_project_issues(
                    request.project_key,
                    severities=request.severities,
                    types=request.types,
                    limit=request.issue_limit
                )
                report["issues"] = {
                    "total": issues.get("total", 0) if issues.get("success") else 0,
                    "items": issues.get("issues", []) if issues.get("success") else []
                }
            
            if request.include_status:
                status_result = fetcher.get_project_status(request.project_key)
                report["quality_gate"] = {
                    "status": status_result.get("status", "UNKNOWN") if status_result.get("success") else "UNKNOWN",
                    "conditions": status_result.get("conditions", []) if status_result.get("success") else []
                }
        
        if not report.get("success"):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=report.get("error", "Failed to fetch report")
            )
        
        return report
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to fetch SonarQube report: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch report: {str(e)}"
        )


@router.get("/reports/{project_key}", response_model=dict, tags=["Utilities — SonarQube"], summary="Get cached SonarQube report by project key")
async def get_project_report(
    project_key: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    Get full SonarQube report for a project (simplified endpoint)
    """
    request = FetchReportRequest(project_key=project_key)
    return await fetch_sonarqube_report(request, current_user)


# ============================================================================
# NEW ASYNC ENDPOINTS
# ============================================================================

@router.post("/scan/remote/async", response_model=dict, tags=["Utilities — SonarQube"], summary="Trigger async SonarQube scan (non-blocking, use job polling)")
async def trigger_async_scan(
    request: RemoteScanRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Trigger async remote code scan (IMPROVED VERSION)
    
    This endpoint:
    1. Creates a scan job in database
    2. Queues the scan as a Celery task
    3. Returns job_id immediately
    4. Scan runs in background with:
       - Pre-flight validation
       - Auto-installation if needed
       - CE task polling (waits for analysis completion)
       - Report caching
       - Audit logging
    
    Returns job_id that can be used to check status.
    """
    try:
        # Validate SonarQube token
        sonar_token = request.sonar_token or getattr(settings, 'SONAR_TOKEN', None)
        if not sonar_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SonarQube token is required. Provide it in request or set SONAR_TOKEN environment variable."
            )
        
        sonar_host_url = request.sonar_host_url or "https://sonarqube.codsy.ai"
        
        # Encrypt sensitive data
        ssh_creds_json = json.dumps({
            "password": request.ssh_credentials.password,
            "private_key": request.ssh_credentials.private_key,
            "private_key_password": request.ssh_credentials.private_key_password
        })
        
        ssh_creds_encrypted = encrypt_data(ssh_creds_json)
        sonar_token_encrypted = encrypt_data(sonar_token)
        
        # Create scan job in database
        job = SonarQubeScanJob(
            user_id=str(current_user.id),
            project_key=request.project_key,
            project_name=request.project_name,
            source_path=request.source_path,
            exclusions=request.exclusions,
            ssh_hostname=request.ssh_credentials.hostname,
            ssh_port=request.ssh_credentials.port,
            ssh_username=request.ssh_credentials.username,
            ssh_credentials_encrypted=ssh_creds_encrypted,
            sonar_host_url=sonar_host_url,
            sonar_token_encrypted=sonar_token_encrypted,
            status=ScanJobStatus.PENDING,
            current_step="Job queued, waiting to start...",
            progress_percent=0
        )
        
        await job.save()
        job_id = str(job.id)
        
        logger.info(f"Created scan job: {job_id} for project: {request.project_key}")
        
        # Queue Celery task
        task = scan_remote_code_async.apply_async(
            args=[job_id],
            countdown=2  # Start after 2 seconds
        )
        
        # Update job with Celery task ID
        job.celery_task_id = task.id
        await job.save()
        
        logger.info(f"Queued Celery task: {task.id} for job: {job_id}")
        
        return {
            "success": True,
            "job_id": job_id,
            "celery_task_id": task.id,
            "status": "PENDING",
            "message": "Scan job queued successfully. Use GET /scan/jobs/{job_id} to check status.",
            "check_status_url": f"/api/v1/sonarqube/scan/jobs/{job_id}"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to queue scan job: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to queue scan: {str(e)}"
        )


@router.get("/scan/jobs/{job_id}", response_model=dict, tags=["Utilities — SonarQube"])
async def get_scan_job_status(
    job_id: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    Get scan job status and progress
    
    Returns:
    - Job status (PENDING, VALIDATING, CONNECTING, SCANNING, PROCESSING, COMPLETED, FAILED)
    - Progress percentage
    - Current step description
    - Error message (if failed)
    - Report ID (if completed)
    """
    try:
        job = await SonarQubeScanJob.get(job_id)
        
        if not job:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Job not found"
            )
        
        # Verify user owns this job
        if str(job.user_id) != str(current_user.id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        response = {
            "job_id": job_id,
            "status": job.status.value,
            "progress_percent": job.progress_percent,
            "current_step": job.current_step,
            "project_key": job.project_key,
            "project_name": job.project_name,
            "created_at": job.created_at.isoformat() if job.created_at else None,
            "started_at": job.started_at.isoformat() if job.started_at else None,
            "completed_at": job.completed_at.isoformat() if job.completed_at else None,
            "duration_seconds": job.duration_seconds,
            "error_message": job.error_message,
            "retry_count": job.retry_count,
            "celery_task_id": job.celery_task_id
        }
        
        # Add report ID if completed
        if job.status == ScanJobStatus.COMPLETED and job.report_id:
            response["report_id"] = job.report_id
            response["report_url"] = f"/api/v1/sonarqube/reports/{job.project_key}"
        
        # Add estimated completion time for running jobs
        if job.status in [ScanJobStatus.SCANNING, ScanJobStatus.PROCESSING] and job.started_at:
            elapsed = (datetime.utcnow() - job.started_at).total_seconds()
            # Rough estimate: 2-5 minutes average
            estimated_total = 180  # 3 minutes
            remaining = max(0, estimated_total - elapsed)
            response["estimated_completion_seconds"] = int(remaining)
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get job status: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get job status: {str(e)}"
        )


@router.get("/scan/jobs", response_model=dict, tags=["Utilities — SonarQube"])
async def list_scan_jobs(
    current_user: User = Depends(get_current_active_user),
    status: Optional[str] = Query(None, description="Filter by status"),
    project_key: Optional[str] = Query(None, description="Filter by project key"),
    limit: int = Query(20, ge=1, le=100, description="Number of jobs to return"),
    skip: int = Query(0, ge=0, description="Number of jobs to skip")
):
    """
    List scan jobs for current user
    
    Supports filtering by status and project_key
    """
    try:
        # Build query
        query = {"user_id": str(current_user.id)}
        
        if status:
            try:
                status_enum = ScanJobStatus(status.lower())
                query["status"] = status_enum
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid status. Valid values: {[s.value for s in ScanJobStatus]}"
                )
        
        if project_key:
            query["project_key"] = project_key
        
        # Query jobs
        jobs = await SonarQubeScanJob.find(query).sort("-created_at").skip(skip).limit(limit).to_list()
        total = await SonarQubeScanJob.find(query).count()
        
        jobs_data = []
        for job in jobs:
            jobs_data.append({
                "job_id": str(job.id),
                "project_key": job.project_key,
                "project_name": job.project_name,
                "status": job.status.value,
                "progress_percent": job.progress_percent,
                "current_step": job.current_step,
                "created_at": job.created_at.isoformat() if job.created_at else None,
                "completed_at": job.completed_at.isoformat() if job.completed_at else None,
                "duration_seconds": job.duration_seconds,
                "error_message": job.error_message,
                "report_id": job.report_id
            })
        
        return {
            "success": True,
            "total": total,
            "limit": limit,
            "skip": skip,
            "jobs": jobs_data
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to list jobs: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list jobs: {str(e)}"
        )


@router.post("/scan/jobs/{job_id}/cancel", response_model=dict, tags=["Utilities — SonarQube"])
async def cancel_scan_job(
    job_id: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    Cancel a running scan job
    
    Note: This will attempt to revoke the Celery task, but if the scan is already
    running on the remote server, it may complete anyway.
    """
    try:
        job = await SonarQubeScanJob.get(job_id)
        
        if not job:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Job not found"
            )
        
        # Verify user owns this job
        if str(job.user_id) != str(current_user.id):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
        
        # Check if job can be cancelled
        if job.status in [ScanJobStatus.COMPLETED, ScanJobStatus.FAILED, ScanJobStatus.CANCELLED]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Cannot cancel job in {job.status.value} status"
            )
        
        # Revoke Celery task
        if job.celery_task_id:
            from app.workers.celery_app import celery_app
            celery_app.control.revoke(job.celery_task_id, terminate=True)
            logger.info(f"Revoked Celery task: {job.celery_task_id}")
        
        # Update job status
        job.status = ScanJobStatus.CANCELLED
        job.completed_at = datetime.utcnow()
        job.error_message = "Cancelled by user"
        await job.save()
        
        return {
            "success": True,
            "job_id": job_id,
            "message": "Job cancelled successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to cancel job: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to cancel job: {str(e)}"
        )


@router.get("/reports/{project_key}/cached", response_model=dict, tags=["Utilities — SonarQube"])
async def get_cached_report(
    project_key: str,
    force_refresh: bool = Query(False, description="Force refresh from SonarQube (bypass cache)"),
    current_user: User = Depends(get_current_active_user)
):
    """
    Get SonarQube report with Redis caching (IMPROVED VERSION)
    
    This endpoint:
    1. Checks Redis cache first (instant response if cached)
    2. Falls back to database if cache miss
    3. Falls back to live SonarQube API if database miss
    4. Caches result for 1 hour
    
    Use force_refresh=true to bypass cache and get latest data.
    """
    try:
        cache = get_report_cache()
        
        # Check cache first (unless force refresh)
        if not force_refresh:
            cached_report = cache.get_report(project_key)
            if cached_report:
                return {
                    "success": True,
                    "source": "cache",
                    **cached_report
                }
        
        # Check database
        db_report = await SonarQubeReport.find_one({
            "project_key": project_key,
            "user_id": str(current_user.id)
        }, sort=[("analysis_date", -1)])
        
        if db_report and not force_refresh:
            # Check if cache hasn't expired
            if db_report.cache_expires_at and db_report.cache_expires_at > datetime.utcnow():
                report_data = db_report.full_report
                report_data["_source"] = "database"
                
                # Re-cache in Redis
                cache.set_report(project_key, report_data)
                
                return {
                    "success": True,
                    "source": "database",
                    **report_data
                }
        
        # Fetch from SonarQube API
        sonar_token = getattr(settings, 'SONAR_TOKEN', None)
        if not sonar_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SonarQube token not configured"
            )
        
        sonar_host_url = getattr(settings, 'SONAR_HOST_URL', 'https://sonarqube.codsy.ai')
        
        fetcher = SonarQubeReportFetcher(sonar_host_url, sonar_token)
        report = fetcher.get_full_report(project_key)
        
        if not report.get("success"):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=report.get("error", "Failed to fetch report")
            )
        
        report["_source"] = "live_api"
        
        # Cache in Redis
        cache.set_report(project_key, report)
        
        return {
            "success": True,
            "source": "live_api",
            **report
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get cached report: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get report: {str(e)}"
        )


@router.delete("/reports/{project_key}/cache", response_model=dict, tags=["Utilities — SonarQube"])
async def invalidate_report_cache(
    project_key: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    Invalidate cached report for a project
    
    Use this after triggering a new scan to ensure fresh data.
    """
    try:
        cache = get_report_cache()
        deleted_count = cache.invalidate_project(project_key)
        
        return {
            "success": True,
            "message": f"Invalidated {deleted_count} cache entries for {project_key}"
        }
        
    except Exception as e:
        logger.error(f"Failed to invalidate cache: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to invalidate cache: {str(e)}"
        )


@router.post("/test/ssh", response_model=dict, tags=["DEPRECATED — use 4-step pipeline"], deprecated=True, summary="[DEPRECATED] Test SSH — use /api/v1/analyze/test/ssh instead")
async def test_ssh_connection(
    request: SSHTestRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Test SSH connection to user's remote server
    
    This endpoint allows users to verify their SSH credentials before starting a scan.
    Useful for multi-tenant scenarios where each user has their own server.
    
    **Features:**
    - Tests SSH connection with provided credentials
    - Optionally verifies source path exists
    - Returns detailed connection information
    - Does NOT store credentials (test only)
    """
    try:
        logger.info(f"User {current_user.id} testing SSH connection to {request.ssh_credentials.hostname}:{request.ssh_credentials.port}")
        
        # Test SSH connection
        test_result = SSHService.test_connection(
            hostname=request.ssh_credentials.hostname,
            port=request.ssh_credentials.port,
            username=request.ssh_credentials.username,
            password=request.ssh_credentials.password,
            private_key=request.ssh_credentials.private_key,
            private_key_password=request.ssh_credentials.private_key_password
        )
        
        if not test_result.get("success"):
            return {
                "success": False,
                "connection_test": False,
                "message": test_result.get("message", "SSH connection failed"),
                "error": test_result.get("error"),
                "source_path_verified": False
            }
        
        # If source path provided, verify it exists
        source_path_verified = False
        source_path_info = None
        
        if request.source_path:
            try:
                conn = SSHService.create_connection(
                    hostname=request.ssh_credentials.hostname,
                    port=request.ssh_credentials.port,
                    username=request.ssh_credentials.username,
                    password=request.ssh_credentials.password,
                    private_key=request.ssh_credentials.private_key,
                    private_key_password=request.ssh_credentials.private_key_password
                )
                
                if conn.connect():
                    # Check if path exists
                    check_result = conn.execute_command(f"test -d '{request.source_path}' && echo 'DIRECTORY' || (test -f '{request.source_path}' && echo 'FILE' || echo 'NOT_FOUND')")
                    
                    if check_result.get("success"):
                        path_type = check_result.get("stdout", "").strip()
                        
                        if path_type in ["DIRECTORY", "FILE"]:
                            source_path_verified = True
                            
                            # Get additional info
                            if path_type == "DIRECTORY":
                                # Get file count and size
                                info_result = conn.execute_command(
                                    f"cd '{request.source_path}' && "
                                    f"echo 'FILES:' && find . -type f | wc -l && "
                                    f"echo 'SIZE:' && du -sh . | cut -f1"
                                )
                                if info_result.get("success"):
                                    source_path_info = {
                                        "type": "directory",
                                        "exists": True,
                                        "details": info_result.get("stdout", "")
                                    }
                            else:
                                # Get file size
                                size_result = conn.execute_command(f"stat -c%s '{request.source_path}' 2>/dev/null || echo '0'")
                                if size_result.get("success"):
                                    source_path_info = {
                                        "type": "file",
                                        "exists": True,
                                        "size_bytes": int(size_result.get("stdout", "0").strip() or "0")
                                    }
                        else:
                            source_path_info = {
                                "exists": False,
                                "error": f"Path '{request.source_path}' not found on remote server"
                            }
                    
                    conn.disconnect()
            except Exception as e:
                logger.warning(f"Failed to verify source path: {e}")
                source_path_info = {
                    "exists": False,
                    "error": f"Could not verify path: {str(e)}"
                }
        
        return {
            "success": True,
            "connection_test": True,
            "message": "SSH connection successful",
            "server_info": {
                "hostname": request.ssh_credentials.hostname,
                "port": request.ssh_credentials.port,
                "username": request.ssh_credentials.username,
                "connected": True
            },
            "source_path_verified": source_path_verified,
            "source_path_info": source_path_info,
            "ready_for_scan": source_path_verified if request.source_path else True
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"SSH connection test failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"SSH connection test failed: {str(e)}"
        )


@router.get("/cache/stats", response_model=dict, tags=["Utilities — SonarQube"])
async def get_cache_statistics(
    current_user: User = Depends(get_current_active_user)
):
    """
    Get cache statistics (admin/monitoring)
    """
    try:
        cache = get_report_cache()
        stats = cache.get_cache_stats()
        
        return {
            "success": True,
            **stats
        }
        
    except Exception as e:
        logger.error(f"Failed to get cache stats: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get cache stats: {str(e)}"
        )

