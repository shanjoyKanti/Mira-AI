"""
Version Ladder Enforcer for Mira AI.

Defines the ordered migration steps for every supported language/framework.
Direct version jumps (e.g. PHP 7.4 → 8.3) are FORBIDDEN — migrations must
climb the ladder one step at a time so each incremental change can be tested.

Usage:
    from app.services.rag.version_ladder import get_version_steps, VersionLadderError

    steps = get_version_steps("php", None, "7.4", "8.2")
    # → ["8.0", "8.1", "8.2"]

    steps = get_version_steps("php", "laravel", "9", "12")
    # → ["10", "11", "12"]
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class VersionLadderError(Exception):
    """Raised when a version jump violates the mandatory ladder sequence."""


# ---------------------------------------------------------------------------
# Static ladder definitions
# ---------------------------------------------------------------------------

# PHP language steps — must match PHP_MIGRATION_CHAIN in planning_agent.py.
# Starts from PHP 4.0 so any legacy project can be migrated incrementally.
PHP_VERSION_LADDER: List[str] = [
    "4.0", "4.1", "4.2", "4.3", "4.4",
    "5.0", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6",
    "7.0", "7.1", "7.2", "7.3", "7.4",
    "8.0", "8.1", "8.2", "8.3", "8.4", "8.5",
]

# Laravel framework steps (major/minor lines matching laravel.com upgrade guides)
LARAVEL_VERSION_LADDER: List[str] = [
    "4.2",
    "5.0", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6", "5.7", "5.8",
    "6", "7", "8", "9", "10", "11", "12",
]

# Symfony
SYMFONY_VERSION_LADDER: List[str] = [
    "4.4", "5.0", "5.4", "6.0", "6.4", "7.0", "7.2", "7.4", "8.0",
]

# Python language
PYTHON_VERSION_LADDER: List[str] = [
    "3.5", "3.6", "3.7", "3.8", "3.9", "3.10", "3.11", "3.12", "3.13", "3.14",
]

# Django
DJANGO_VERSION_LADDER: List[str] = [
    "3.0", "3.1", "3.2", "4.0", "4.1", "4.2", "5.0", "5.1", "5.2", "6.0",
]

# Flask
FLASK_VERSION_LADDER: List[str] = [
    "2.0", "2.1", "2.2", "2.3", "3.0", "3.1",
]

# JavaScript (Node.js LTS lines)
JAVASCRIPT_VERSION_LADDER: List[str] = [
    "14", "16", "18", "20", "21", "22",
]

# React
REACT_VERSION_LADDER: List[str] = [
    "15", "16", "17", "18", "19",
]

# Angular
ANGULAR_VERSION_LADDER: List[str] = [
    "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
]

# Vue.js
VUE_VERSION_LADDER: List[str] = [
    "2", "3", "3.1", "3.2", "3.3", "3.4",
]

# Next.js
NEXTJS_VERSION_LADDER: List[str] = [
    "11", "12", "13", "14", "15",
]

# NestJS
NESTJS_VERSION_LADDER: List[str] = [
    "8", "9", "10", "11",
]

# TypeScript
TYPESCRIPT_VERSION_LADDER: List[str] = [
    "3.8", "3.9",
    "4.0", "4.1", "4.2", "4.3", "4.4", "4.5", "4.6", "4.7", "4.8", "4.9",
    "5.0", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6", "5.7",
]

# Java
JAVA_VERSION_LADDER: List[str] = [
    "11", "17", "21", "25", "26",
]

# Spring Boot
SPRINGBOOT_VERSION_LADDER: List[str] = [
    "2.5", "2.6", "2.7", "3.0", "3.1", "3.2", "3.3", "4.0",
]

# .NET
DOTNET_VERSION_LADDER: List[str] = [
    "4.7.2", "4.8", "5.0", "6.0", "7.0", "8.0", "9.0", "10.0",
]

# Kotlin
KOTLIN_VERSION_LADDER: List[str] = [
    "1.5", "1.6", "1.7", "1.8", "1.9", "2.0", "2.1",
]

# Ktor (Kotlin framework)
KTOR_VERSION_LADDER: List[str] = [
    "1.6", "2.0", "2.1", "2.2", "2.3", "3.0",
]

# Rust
RUST_VERSION_LADDER: List[str] = [
    "1.50", "1.55", "1.60", "1.65", "1.70", "1.71", "1.72", "1.73", "1.74",
    "1.75", "1.76", "1.77", "1.78", "1.79", "1.80", "1.81", "1.82", "1.83",
    "1.84", "1.85", "1.86", "1.87", "1.88",
]

# Rust frameworks
ACTIX_VERSION_LADDER: List[str] = [
    "3.0", "4.0", "4.1", "4.2", "4.3", "4.4", "4.5", "4.6",
]

AXUM_VERSION_LADDER: List[str] = [
    "0.1", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7",
]

# Go
GOLANG_VERSION_LADDER: List[str] = [
    "1.17", "1.18", "1.19", "1.20", "1.21", "1.22", "1.23", "1.24", "1.25", "1.26",
]

# Go frameworks
GIN_VERSION_LADDER: List[str] = [
    "1.5", "1.6", "1.7", "1.8", "1.9",
]

# C# / .NET
CSHARP_VERSION_LADDER: List[str] = [
    "9.0", "10.0", "11.0", "12.0", "13.0", "14.0",
]

ASPNET_VERSION_LADDER: List[str] = [
    "6.0", "7.0", "8.0", "9.0", "10.0",
]

EFCORE_VERSION_LADDER: List[str] = [
    "6.0", "7.0", "8.0", "9.0", "10.0",
]

# Svelte
SVELTE_VERSION_LADDER: List[str] = [
    "3", "4", "5",
]

# Express
EXPRESS_VERSION_LADDER: List[str] = [
    "4.16", "4.17", "4.18", "5.0",
]

# Java frameworks
SPRING_VERSION_LADDER: List[str] = [
    "5.0", "5.1", "5.2", "5.3", "6.0", "6.1",
]

JAKARTA_VERSION_LADDER: List[str] = [
    "8.0", "9.0", "9.1", "10.0", "11.0",
]

QUARKUS_VERSION_LADDER: List[str] = [
    "1.11", "1.13", "2.0", "2.1", "2.13", "3.0", "3.1", "3.2",
]

# Python frameworks
FASTAPI_VERSION_LADDER: List[str] = [
    "0.100", "0.110", "0.111", "0.112", "0.113", "0.114", "0.115",
    "0.116", "0.120", "0.125", "0.130", "0.135",
]

# Scala
SCALA_VERSION_LADDER: List[str] = [
    "2.11", "2.12", "2.13", "3.0", "3.1", "3.2", "3.3", "3.4",
]

# Scala frameworks
PLAY_VERSION_LADDER: List[str] = [
    "2.7", "2.8", "2.9", "3.0",
]

# Elixir
ELIXIR_VERSION_LADDER: List[str] = [
    "1.10", "1.11", "1.12", "1.13", "1.14", "1.15", "1.16",
]

PHOENIX_VERSION_LADDER: List[str] = [
    "1.5", "1.6", "1.7", "1.8",
]

# Swift
SWIFT_VERSION_LADDER: List[str] = [
    "5.0", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6", "5.7", "5.8", "5.9", "6.0",
]

# Dart / Flutter
DART_VERSION_LADDER: List[str] = [
    "2.0", "2.5", "2.10", "2.15", "2.17", "2.18", "2.19", "3.0", "3.1", "3.2", "3.3", "3.4",
]

FLUTTER_VERSION_LADDER: List[str] = [
    "2.0", "2.5", "3.0", "3.5", "3.10", "3.13", "3.16", "3.19", "3.22",
]

# TypeScript frameworks (reuses JS ones + own)
NUXT_VERSION_LADDER: List[str] = [
    "2.0", "2.5", "2.10", "2.14", "2.15", "3.0", "3.1", "3.2", "3.3",
]

# HCL / Terraform
HCL_VERSION_LADDER: List[str] = [
    "0.12", "0.13", "0.14", "0.15", "1.0", "1.1", "1.2", "1.3",
    "1.4", "1.5", "1.6", "1.7", "1.8", "1.9",
]

# Kubernetes YAML
YAML_VERSION_LADDER: List[str] = [
    "1.18", "1.19", "1.20", "1.21", "1.22", "1.23", "1.24",
    "1.25", "1.26", "1.27", "1.28", "1.29", "1.30",
]

# Haskell (GHC versions)
HASKELL_VERSION_LADDER: List[str] = [
    "8.8", "8.10", "9.0", "9.2", "9.4", "9.6", "9.8", "9.10",
]

# R
R_VERSION_LADDER: List[str] = [
    "3.6", "4.0", "4.1", "4.2", "4.3", "4.4",
]

# Julia
JULIA_VERSION_LADDER: List[str] = [
    "1.0", "1.1", "1.2", "1.3", "1.4", "1.5", "1.6", "1.7", "1.8", "1.9", "1.10",
]

# COBOL
COBOL_VERSION_LADDER: List[str] = [
    "1968", "1974", "1985", "2002", "2014",
]

# Fortran
FORTRAN_VERSION_LADDER: List[str] = [
    "77", "90", "95", "2003", "2008", "2015", "2023",
]

# ---------------------------------------------------------------------------
# Registry: (language, framework|None) → ladder list
# ---------------------------------------------------------------------------

_STATIC_LADDERS: Dict[Tuple[str, Optional[str]], List[str]] = {
    # PHP
    ("php", None): PHP_VERSION_LADDER,
    ("php", "laravel"): LARAVEL_VERSION_LADDER,
    ("php", "symfony"): SYMFONY_VERSION_LADDER,
    # Python
    ("python", None): PYTHON_VERSION_LADDER,
    ("python", "django"): DJANGO_VERSION_LADDER,
    ("python", "flask"): FLASK_VERSION_LADDER,
    ("python", "fastapi"): FASTAPI_VERSION_LADDER,
    # JavaScript / Node.js
    ("javascript", None): JAVASCRIPT_VERSION_LADDER,
    ("javascript", "react"): REACT_VERSION_LADDER,
    ("javascript", "angular"): ANGULAR_VERSION_LADDER,
    ("javascript", "vue"): VUE_VERSION_LADDER,
    ("javascript", "nextjs"): NEXTJS_VERSION_LADDER,
    ("javascript", "nestjs"): NESTJS_VERSION_LADDER,
    ("javascript", "svelte"): SVELTE_VERSION_LADDER,
    ("javascript", "express"): EXPRESS_VERSION_LADDER,
    ("javascript", "nuxt"): NUXT_VERSION_LADDER,
    # TypeScript (reuses JS frameworks where applicable)
    ("typescript", None): TYPESCRIPT_VERSION_LADDER,
    ("typescript", "react"): REACT_VERSION_LADDER,
    ("typescript", "angular"): ANGULAR_VERSION_LADDER,
    ("typescript", "nextjs"): NEXTJS_VERSION_LADDER,
    ("typescript", "nestjs"): NESTJS_VERSION_LADDER,
    ("typescript", "vue"): VUE_VERSION_LADDER,
    # Java
    ("java", None): JAVA_VERSION_LADDER,
    ("java", "springboot"): SPRINGBOOT_VERSION_LADDER,
    ("java", "spring"): SPRING_VERSION_LADDER,
    ("java", "jakarta"): JAKARTA_VERSION_LADDER,
    ("java", "quarkus"): QUARKUS_VERSION_LADDER,
    # .NET / C#
    ("dotnet", None): DOTNET_VERSION_LADDER,
    ("dotnet", "aspnet"): ASPNET_VERSION_LADDER,
    ("dotnet", "efcore"): EFCORE_VERSION_LADDER,
    ("dotnet", "blazor"): ASPNET_VERSION_LADDER,
    ("csharp", None): CSHARP_VERSION_LADDER,
    # Kotlin
    ("kotlin", None): KOTLIN_VERSION_LADDER,
    ("kotlin", "ktor"): KTOR_VERSION_LADDER,
    # Rust
    ("rust", None): RUST_VERSION_LADDER,
    ("rust", "actix"): ACTIX_VERSION_LADDER,
    ("rust", "axum"): AXUM_VERSION_LADDER,
    # Go
    ("golang", None): GOLANG_VERSION_LADDER,
    ("golang", "gin"): GIN_VERSION_LADDER,
    ("go", None): GOLANG_VERSION_LADDER,
    ("go", "gin"): GIN_VERSION_LADDER,
    # Scala
    ("scala", None): SCALA_VERSION_LADDER,
    ("scala", "play"): PLAY_VERSION_LADDER,
    # Elixir
    ("elixir", None): ELIXIR_VERSION_LADDER,
    ("elixir", "phoenix"): PHOENIX_VERSION_LADDER,
    # Swift
    ("swift", None): SWIFT_VERSION_LADDER,
    # Dart / Flutter
    ("dart", None): DART_VERSION_LADDER,
    ("dart", "flutter"): FLUTTER_VERSION_LADDER,
    # HCL / Terraform
    ("hcl", None): HCL_VERSION_LADDER,
    ("terraform", None): HCL_VERSION_LADDER,
    # Kubernetes YAML
    ("yaml", None): YAML_VERSION_LADDER,
    ("kubernetes", None): YAML_VERSION_LADDER,
    # Haskell
    ("haskell", None): HASKELL_VERSION_LADDER,
    # R
    ("r", None): R_VERSION_LADDER,
    # Julia
    ("julia", None): JULIA_VERSION_LADDER,
    # COBOL
    ("cobol", None): COBOL_VERSION_LADDER,
    # Fortran
    ("fortran", None): FORTRAN_VERSION_LADDER,
}

# Cache for ladders loaded from config.json at runtime
_config_ladders: Optional[Dict[Tuple[str, Optional[str]], List[str]]] = None


def _load_config_ladders() -> Dict[Tuple[str, Optional[str]], List[str]]:
    """Load known_versions from rag/Search_tool/config.json as fallback ladders."""
    global _config_ladders
    if _config_ladders is not None:
        return _config_ladders

    config_path = Path(__file__).resolve().parents[4] / "rag" / "Search_tool" / "config.json"
    if not config_path.exists():
        logger.warning("version_ladder: config.json not found at %s — no fallback ladders", config_path)
        _config_ladders = {}
        return _config_ladders

    try:
        with open(config_path, encoding="utf-8") as f:
            config = json.load(f)
    except Exception as e:
        logger.error("version_ladder: failed to load config.json: %s", e)
        _config_ladders = {}
        return _config_ladders

    result: Dict[Tuple[str, Optional[str]], List[str]] = {}
    for lang_code, lang_data in config.get("languages", {}).items():
        lang_versions = lang_data.get("known_versions", [])
        if lang_versions:
            result[(lang_code, None)] = [str(v) for v in lang_versions]
        for fw_code, fw_data in lang_data.get("frameworks", {}).items():
            fw_versions = fw_data.get("known_versions", [])
            if fw_versions:
                result[(lang_code, fw_code)] = [str(v) for v in fw_versions]

    _config_ladders = result
    logger.info("version_ladder: loaded %d ladder entries from config.json", len(result))
    return _config_ladders


def _get_ladder(language: str, framework: Optional[str]) -> List[str]:
    """
    Return the version ladder for the given language/framework combination.
    Checks static definitions first, then config.json fallback.
    Raises VersionLadderError if no ladder is defined.
    """
    lang = language.lower().strip()
    fw = framework.lower().strip() if framework else None
    key = (lang, fw)

    # Check static registry first
    if key in _STATIC_LADDERS:
        return _STATIC_LADDERS[key]

    # Fall back to config.json
    config_ladders = _load_config_ladders()
    if key in config_ladders:
        return config_ladders[key]

    # Try language-only ladder if framework not found
    if fw is not None:
        lang_key = (lang, None)
        if lang_key in _STATIC_LADDERS:
            logger.warning(
                "version_ladder: no framework-specific ladder for %s/%s — using language ladder",
                lang, fw,
            )
            return _STATIC_LADDERS[lang_key]
        if lang_key in config_ladders:
            logger.warning(
                "version_ladder: no framework-specific ladder for %s/%s in config — using language ladder",
                lang, fw,
            )
            return config_ladders[lang_key]

    raise VersionLadderError(
        f"No version ladder defined for language='{language}' framework='{framework}'. "
        f"Available languages: {sorted({k[0] for k in _STATIC_LADDERS})}"
    )


def get_version_steps(
    language: str,
    framework: Optional[str],
    from_version: str,
    to_version: str,
) -> List[str]:
    """
    Return the ordered list of intermediate version steps needed to migrate
    from *from_version* to *to_version*, exclusive of *from_version*,
    inclusive of *to_version*.

    Examples:
        get_version_steps("php", None, "7.4", "8.2")  → ["8.0", "8.1", "8.2"]
        get_version_steps("php", "laravel", "9", "11") → ["10", "11"]
        get_version_steps("php", None, "8.0", "8.0")  → []

    Raises:
        VersionLadderError: if either version is absent from the ladder,
                            if to_version precedes from_version (downgrade),
                            or if no ladder is defined for the language/framework.
    """
    from_v = str(from_version).strip()
    to_v = str(to_version).strip()

    ladder = _get_ladder(language, framework)

    if from_v == to_v:
        return []

    if from_v not in ladder:
        raise VersionLadderError(
            f"from_version '{from_v}' is not in the {language}"
            f"{f'/{framework}' if framework else ''} version ladder. "
            f"Valid versions: {ladder}"
        )

    if to_v not in ladder:
        raise VersionLadderError(
            f"to_version '{to_v}' is not in the {language}"
            f"{f'/{framework}' if framework else ''} version ladder. "
            f"Valid versions: {ladder}"
        )

    from_idx = ladder.index(from_v)
    to_idx = ladder.index(to_v)

    if to_idx < from_idx:
        raise VersionLadderError(
            f"Downgrade forbidden: '{from_v}' → '{to_v}' for {language}"
            f"{f'/{framework}' if framework else ''}. "
            f"Migration only proceeds forward along the ladder."
        )

    steps = ladder[from_idx + 1 : to_idx + 1]
    logger.info(
        "version_ladder: %s%s %s → %s = %d step(s): %s",
        language,
        f"/{framework}" if framework else "",
        from_v,
        to_v,
        len(steps),
        steps,
    )
    return steps
