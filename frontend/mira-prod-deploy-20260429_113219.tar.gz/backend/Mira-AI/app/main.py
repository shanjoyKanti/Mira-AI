"""Mira AI FastAPI Application - Main Entry Point"""
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from contextlib import asynccontextmanager
import os

from app.core.config import settings
from app.core.logging import setup_logging, get_logger
from app.core.rate_limiter import limiter, custom_rate_limit_exceeded_handler
from app.core.service_registry import registry
from app.core.exceptions import (
    mira_ai_exception_handler,
    validation_exception_handler,
    general_exception_handler,
    MiraAIException
)
from app.core.middleware import RequestLoggingMiddleware, SecurityHeadersMiddleware
from app.api.v1.router import router as api_v1_router
from app.core.init_admin import create_admin_user
from app.services.storage.file_storage import FileStorageService
from app.services.llm.llm_service import get_llm_service
from fastapi.exceptions import RequestValidationError

# Setup logging
setup_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan events - runs on startup and shutdown"""
    # Initialize MongoDB (Primary Database)
    try:
        from app.db.mongodb import init_mongodb
        await init_mongodb()
        logger.info("✅ MongoDB initialized successfully")
    except Exception as e:
        logger.error(f"❌ Failed to initialize MongoDB: {e}", exc_info=True)
        raise RuntimeError("MongoDB initialization failed - application cannot start without database")
    
    # Startup: Initialize services and register them
    # Note: Storage is now VM-based via SSH, no local storage service needed
    # FileStorageService kept for backward compatibility if needed
    try:
        from app.services.storage.file_storage import FileStorageService
        storage_service = FileStorageService()
        registry.register("storage", storage_service)  # For cleanup/admin tasks if needed
    except PermissionError as e:
        logger.warning(f"Could not initialize local storage service (permission denied): {e}")
        logger.warning("Storage service will not be available - this is expected in containerized environments")
    except Exception as e:
        logger.warning(f"Could not initialize storage service: {e}")
    
    # Initialize LLM service
    llm_service = get_llm_service()
    registry.register("llm", llm_service)
    
    # Create admin user (in MongoDB)
    await create_admin_user()
    
    logger.info(f"LLM Provider: {settings.LLM_PROVIDER}")
    logger.info(f"LLM Model: {settings.LLM_MODEL}")

    # ─── Orphaned-job recovery ─────────────────────────────────────────────
    # Jobs that were still "running" when the last API instance died have no
    # worker thread. Flip them to "interrupted" so the user's resume endpoint
    # can restart them. Threshold is configurable — default 5 minutes of no
    # progress-heartbeat activity.
    try:
        from datetime import datetime, timedelta
        import os as _os
        from app.db.mongodb_models import ModernizationJob
        stuck_threshold_sec = int(_os.environ.get("MIRA_JOB_STUCK_THRESHOLD_SECONDS", "300"))
        cutoff = datetime.utcnow() - timedelta(seconds=stuck_threshold_sec)
        stuck_jobs = await ModernizationJob.find(
            ModernizationJob.status == "running",
        ).to_list()
        recovered = 0
        for j in stuck_jobs:
            hb = j.last_progress_update_at or j.updated_at
            if hb is None or hb < cutoff:
                j.status = "interrupted"
                j.error_message = (
                    "Job was interrupted by an API restart or crash. "
                    "Use POST /agents/jobs/{job_id}/resume to continue from the last completed file."
                )
                j.completed_at = datetime.utcnow()
                j.updated_at = datetime.utcnow()
                await j.save()
                recovered += 1
        if recovered:
            logger.warning("⚠️  Recovered %d orphaned job(s) from prior API instance", recovered)
            try:
                from app.core.metrics import mira_orphaned_jobs_recovered_total
                mira_orphaned_jobs_recovered_total.inc(recovered)
            except Exception:
                pass
        else:
            logger.info("✅ Job recovery scan clean — no orphaned jobs found")
    except Exception as _e:
        logger.warning(f"Orphaned-job recovery scan failed: {_e}")

    yield
    
    # Shutdown: Cleanup
    try:
        from app.db.mongodb import close_mongodb
        await close_mongodb()
    except Exception as e:
        logger.warning(f"Error closing MongoDB connection: {e}")
    
    registry.clear()


# ─── OpenAPI tag metadata (shown as section descriptions in /docs) ────────────
_OPENAPI_TAGS = [
    {
        "name": "Step 1 — Onboarding & Project Setup",
        "description": (
            "**Start here.** Register, authenticate, save SSH credentials, and create your project record.\n\n"
            "**Required sequence before running the migration pipeline:**\n"
            "1. `POST /accounts/signup` → create account\n"
            "2. `POST /accounts/login` → get `access_token` (add as `Authorization: Bearer <token>` on every subsequent request)\n"
            "3. `POST /analyze/test/ssh` → test SSH to your VM **and** save credentials + `source_path` on your account\n"
            "4. `POST /analyze/projects` → create a project record (optional metadata, not required for pipeline)\n\n"
            "After step 3 the SSH credentials are persisted on your account. All pipeline endpoints (Steps 1–4) "
            "read them automatically — **you only need `project_name`** in subsequent calls."
        ),
    },
    {
        "name": "Step 2 — Analyze (pick one mode)",
        "description": (
            "Scan the **original source code** on your VM and generate a security/quality report. Pick **one** mode:\n\n"
            "| Mode | Endpoint | What it does |\n"
            "|------|----------|--------------|\n"
            "| **A** | `POST /analyze/scan/sonarqube` | SonarQube scan only — raw metrics & issues, no LLM |\n"
            "| **B** | `POST /analyze/scan` | SonarQube scan **+** LLM-enhanced narrative report |\n"
            "| **C** | `POST /analyze/scan/analyse-project` | LLM-only deep analysis (no SonarQube required) |\n\n"
            "All three modes use the SSH credentials and `source_path` saved in Step 1. "
            "Just pass `project_name`."
        ),
    },
    {
        "name": "Step 3 — Migration (4-step pipeline)",
        "description": (
            "**The core migration pipeline.** Each step builds on the previous one. "
            "All steps are **async** — they return a `job_id` immediately; poll the matching "
            "`GET …/status/{job_id}` endpoint until `status` is `completed` or `failed`.\n\n"
            "**Recommended polling interval:** 5 seconds while running.\n\n"
            "```\n"
            "Step 1 → POST /agents/run-structure-language-and-version-upgradation\n"
            "         returns: transform_id, job_id\n"
            "         does: SSH download → detect language/version → staged migration per version\n"
            "         saves: stage snapshots on your VM under migrated-codes/{project}/stage_XX_phpYY/\n\n"
            "Step 2 → POST /agents/run-upgrade-analysis-simple\n"
            "         returns: job_id  (transform_id auto-fetched from DB)\n"
            "         does: SonarQube scan of migrated code → LLM upgrade guide\n\n"
            "Step 3 → POST /agents/run-upgrade-analysis  (same as Step 2 but accepts user_input)\n"
            "         returns: job_id\n"
            "         does: same as Step 2 + incorporates custom user requirements\n\n"
            "Step 4 → POST /agents/run-code-modernization\n"
            "         returns: job_id\n"
            "         does: LLM code modernization guided by SonarQube report\n"
            "         saves: final code on your VM under upgraded-codes/{project}/upgraded_{project}_{timestamp}/\n"
            "```\n\n"
            "**After Step 1 completes**, subsequent steps need only `project_name` — "
            "`transform_id` and paths are auto-resolved from the database.\n\n"
            "**Version ladder** is enforced: migrations always step through every intermediate version "
            "(e.g. PHP 7.0 → 7.4 → 8.0 → 8.1 → 8.2 → 8.3). Direct jumps are not allowed."
        ),
    },
    {
        "name": "Step 4 — Post-Migration Security Fix",
        "description": (
            "**Optional post-migration step.** After the pipeline completes, run a security cross-check "
            "that compares the modernized code against the original SonarQube findings and applies "
            "targeted fixes for any remaining issues.\n\n"
            "Also exposes `POST /agents/fix-sonar-issues` for re-running SonarQube-guided fixes "
            "on already-upgraded code without re-running the full pipeline."
        ),
    },
    {
        "name": "Utilities — Projects & Reports",
        "description": (
            "Helpers for listing projects, downloading reports, tracking jobs, and managing transforms.\n\n"
            "- `GET /analyze/projects/recent` — list recently scanned projects\n"
            "- `GET /analyze/reports` — list all generated reports\n"
            "- `GET /analyze/reports/{id}/download` — download report as HTML, PDF, DOCX, or MD\n"
            "- `GET /agents/transforms` — list all migration pipeline runs with per-step status\n"
            "- `POST /agents/jobs/{job_id}/cancel` — cancel a running job\n"
            "- `GET /agents/run-modernization/status/{job_id}/logs` — fetch job logs"
        ),
    },
    {
        "name": "Utilities — SonarQube",
        "description": (
            "Low-level SonarQube helpers for fetching raw metrics, managing scan jobs, and cache operations. "
            "These are used internally by the pipeline; most frontend integrations do not need to call them directly."
        ),
    },
    {
        "name": "Utilities — Full Pipeline (legacy single-shot)",
        "description": (
            "**Legacy single-shot pipeline** that runs all four steps in one call. "
            "Prefer the individual Step 1–4 endpoints for better control, status visibility, and retry capability. "
            "This endpoint is kept for backward compatibility."
        ),
    },
    {
        "name": "DEPRECATED — use 4-step pipeline",
        "description": (
            "These endpoints are **deprecated** and will be removed in a future release. "
            "Use the `Step 3 — Migration (4-step pipeline)` endpoints instead."
        ),
    },
]

# Create FastAPI app
app = FastAPI(
    title="Mira AI",
    version=settings.APP_VERSION,
    debug=settings.DEBUG,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    openapi_tags=_OPENAPI_TAGS,
    description=(
        "# Mira AI — Automated Code Modernization Platform\n\n"
        "Mira AI is a **language-agnostic** platform that migrates legacy codebases to modern versions "
        "using a combination of RAG-based documentation retrieval (Qdrant + web scraping), "
        "LLM-driven code transformation, and SonarQube static analysis.\n\n"
        "**Supported languages:** PHP, Python, JavaScript, TypeScript, Java, Go, Ruby, Rust, C#, and more.\n\n"
        "---\n\n"
        "## Authentication\n\n"
        "All endpoints (except `/accounts/signup`, `/accounts/login`, `/health`) require a **JWT Bearer token**.\n\n"
        "```\n"
        "Authorization: Bearer <access_token>\n"
        "```\n\n"
        "Tokens are obtained from `POST /api/v1/accounts/login`. "
        "The `access_token` expires in **2 hours**; use `POST /api/v1/accounts/refresh` with the "
        "`refresh_token` to get a new one without re-logging in.\n\n"
        "---\n\n"
        "## Quick-Start: Full Migration in 4 Steps\n\n"
        "```\n"
        "1. POST /api/v1/analyze/test/ssh          — save SSH credentials for your VM\n"
        "2. POST /api/v1/agents/run-structure-language-and-version-upgradation\n"
        "                                           — detect language/version, run staged migration\n"
        "   GET  /api/v1/agents/run-structure-language-and-version-upgradation/status/{job_id}\n"
        "                                           — poll until completed\n"
        "3. POST /api/v1/agents/run-upgrade-analysis-simple\n"
        "                                           — SonarQube scan + LLM upgrade guide\n"
        "   GET  /api/v1/agents/run-upgrade-analysis/status/{job_id}\n"
        "4. POST /api/v1/agents/run-code-modernization\n"
        "                                           — apply LLM code modernization\n"
        "   GET  /api/v1/agents/run-code-modernization/status/{job_id}\n"
        "```\n\n"
        "After step 1, all subsequent steps need only `{ \"project_name\": \"my-app\" }` — "
        "everything else is auto-resolved from the database.\n\n"
        "---\n\n"
        "## Async Job Pattern\n\n"
        "Pipeline endpoints return immediately with `{ \"job_id\": \"...\", \"status\": \"running\" }`. "
        "Poll the corresponding `GET …/status/{job_id}` every **5 seconds** until "
        "`status` is `completed` or `failed`.\n\n"
        "```json\n"
        "{ \"status\": \"running\",   \"current_task\": \"Modernizing file 3/12\" }\n"
        "{ \"status\": \"completed\", \"result\": { ... } }\n"
        "{ \"status\": \"failed\",    \"error\": \"...\" }\n"
        "```\n\n"
        "---\n\n"
        "## Error Responses\n\n"
        "All errors follow this shape:\n\n"
        "```json\n"
        "{ \"detail\": \"Human-readable error message\" }\n"
        "```\n\n"
        "| HTTP Code | Meaning |\n"
        "|-----------|--------|\n"
        "| 400 | Bad request — invalid input or missing prerequisite (e.g. SSH not configured) |\n"
        "| 401 | Unauthorized — missing or expired token |\n"
        "| 403 | Forbidden — insufficient role |\n"
        "| 404 | Resource not found |\n"
        "| 422 | Validation error — request body schema mismatch |\n"
        "| 429 | Rate limit exceeded |\n"
        "| 500 | Internal server error |\n\n"
        "---\n\n"
        "## Rate Limits\n\n"
        "| Endpoint | Limit |\n"
        "|----------|-------|\n"
        "| `POST /accounts/signup` | 5 per minute |\n"
        "| `POST /accounts/login` | 5 per minute |\n"
        "| All other endpoints | No hard limit (governed by LLM concurrency caps) |\n\n"
        "Maximum **3 concurrent migration pipelines** and **3 concurrent LLM calls** system-wide "
        "(configurable via `MIRA_MAX_CONCURRENT_PIPELINES` / `MIRA_MAX_CONCURRENT_LLM_CALLS`).\n\n"
        "---\n\n"
        "## Migration Output Locations (on your VM)\n\n"
        "| Output | Location |\n"
        "|--------|----------|\n"
        "| Per-version stage snapshots | `~/migrated-codes/{project}/stage_XX_php{VV}/` |\n"
        "| Final modernized code | `~/upgraded-codes/{project}/upgraded_{project}_{timestamp}/` |\n"
        "| SonarQube upgrade guides | Stored in DB; returned in job result as `sonarqube_report_path` |"
    ),
    lifespan=lifespan,
)

# Add rate limiter state
app.state.limiter = limiter

# Add exception handlers
app.add_exception_handler(MiraAIException, mira_ai_exception_handler)
app.add_exception_handler(RequestValidationError, validation_exception_handler)
# SQLAlchemy exception handler removed - using MongoDB only
app.add_exception_handler(Exception, general_exception_handler)
app.add_exception_handler(RateLimitExceeded, custom_rate_limit_exceeded_handler)

# Add middleware (order matters - last added is first executed)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RequestLoggingMiddleware)

# CORS middleware
# Ensure BACKEND_CORS_ORIGINS is a list
cors_origins = settings.BACKEND_CORS_ORIGINS
if isinstance(cors_origins, str):
    cors_origins = [i.strip() for i in cors_origins.split(",") if i.strip()]

# Log CORS origins for debugging
logger.info(f"CORS allowed origins: {cors_origins}")

# CORS middleware with support for Netlify subdomains and localhost
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"(https?://.*\.netlify\.(app|com)|https?://localhost:\d+|https?://127\.0\.0\.1:\d+)",  # Allow Netlify subdomains and localhost
    allow_origins=cors_origins,  # Also allow explicitly configured origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)


@app.get("/api")
async def root():
    """Root API info endpoint"""
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs",
        "health": "/health"
    }


@app.get("/upcoming-deliverables", response_class=HTMLResponse)
async def upcoming_deliverables():
    """
    Upcoming Deliverables & Progress Report
    
    This page shows the current status, dependencies, and timeline
    for upcoming feature deliverables requested by clients.
    """
    html_file_path = os.path.join(os.path.dirname(__file__), "static", "upcoming-deliverables.html")
    
    if os.path.exists(html_file_path):
        with open(html_file_path, "r", encoding="utf-8") as f:
            html_content = f.read()
        return HTMLResponse(content=html_content)
    else:
        return HTMLResponse(
            content="<h1>Report Not Found</h1><p>The deliverables report is currently unavailable.</p>",
            status_code=404
        )


@app.get("/health")
async def health_check():
    """
    Enhanced health check endpoint
    
    Checks:
    - Application status
    - Database connectivity
    - Redis connectivity
    - LLM service availability
    """
    health_status = {
        "status": "healthy",
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "checks": {}
    }
    
    # Check Redis
    try:
        import redis
        r = redis.from_url(settings.REDIS_URL)
        r.ping()
        health_status["checks"]["redis"] = "healthy"
    except Exception as e:
        logger.error(f"Redis health check failed: {str(e)}")
        health_status["checks"]["redis"] = "unhealthy"
        health_status["status"] = "degraded"
    
    # Check MongoDB
    try:
        from app.db.mongodb import get_mongodb_client
        client = get_mongodb_client()
        await client.admin.command('ping')
        health_status["checks"]["mongodb"] = "healthy"
    except Exception as e:
        logger.error(f"MongoDB health check failed: {str(e)}")
        health_status["checks"]["mongodb"] = "unhealthy"
        health_status["status"] = "degraded"
    
    # Check LLM service
    try:
        llm_service = registry.get("llm")
        if llm_service and llm_service.provider.validate_config():
            health_status["checks"]["llm"] = "healthy"
        else:
            health_status["checks"]["llm"] = "unhealthy"
            health_status["status"] = "degraded"
    except Exception as e:
        logger.error(f"LLM service health check failed: {str(e)}")
        health_status["checks"]["llm"] = "unhealthy"
        health_status["status"] = "degraded"
    
    # Return with appropriate status code (503 for degraded, 200 for healthy)
    from fastapi.responses import JSONResponse
    status_code = 200 if health_status["status"] == "healthy" else 503
    return JSONResponse(content=health_status, status_code=status_code)

# Include API v1 routes
app.include_router(api_v1_router, prefix=settings.API_V1_PREFIX)

# Prometheus /metrics endpoint for SRE scraping. Mounted at the root so operators
# can point Prometheus at /metrics without a prefix (standard convention).
try:
    from app.core.metrics import router as metrics_router
    app.include_router(metrics_router)
    logger.info("✅ Prometheus metrics exposed at /metrics")
except Exception as _mex:
    logger.warning(f"Could not mount /metrics endpoint: {_mex}")

# ── Frontend static file serving ──────────────────────────────────────────────
# Serve the built React frontend from /app/frontend/dist (mounted in Docker)
# The SPA catch-all must be registered LAST so API routes take priority.
_FRONTEND_DIST = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend", "dist")

if os.path.isdir(_FRONTEND_DIST):
    from fastapi.staticfiles import StaticFiles
    app.mount("/assets", StaticFiles(directory=os.path.join(_FRONTEND_DIST, "assets")), name="assets")

    # Static client-facing presentation deck. Mounted BEFORE the SPA catch-all so
    # /presentation never falls through to the React app. Source mounted from the
    # host via docker-compose volume; html=True makes /presentation/ serve index.html.
    _PRESENTATION_DIR = "/app/presentation"
    if os.path.isdir(_PRESENTATION_DIR):
        app.mount(
            "/presentation",
            StaticFiles(directory=_PRESENTATION_DIR, html=True),
            name="presentation",
        )
        logger.info(f"✅ Presentation deck served from {_PRESENTATION_DIR} at /presentation")
    else:
        logger.info(f"ℹ️  Presentation directory not mounted at {_PRESENTATION_DIR}; skipping /presentation route")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str):
        """Serve the React SPA index.html for all non-API routes."""
        # For known static files (vite.svg etc.) try to serve directly
        candidate = os.path.join(_FRONTEND_DIST, full_path)
        if full_path and os.path.isfile(candidate):
            return FileResponse(candidate)
        return FileResponse(os.path.join(_FRONTEND_DIST, "index.html"))

    logger.info(f"✅ Frontend static files served from {_FRONTEND_DIST}")
else:
    logger.warning(f"⚠️  Frontend dist not found at {_FRONTEND_DIST} — skipping static file serving")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG
    )
