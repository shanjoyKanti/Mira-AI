"""LLM Provider Factory - Creates LLM providers based on configuration"""
from typing import Dict, Any, Optional
from app.services.llm.base_provider import BaseLLMProvider
from app.services.llm.providers.openai_provider import OpenAIProvider
from app.services.llm.providers.local_llm_provider import LocalLLMProvider
from app.services.llm.providers.groq_provider import GroqProvider
from app.core.logging import get_logger

logger = get_logger(__name__)


class LLMFactory:
    """Factory for creating LLM providers"""
    
    _providers = {
        "openai": OpenAIProvider,
        "groq": GroqProvider,
        "anthropic": None,  # TODO: Implement
        "google": None,  # TODO: Implement
        "local": LocalLLMProvider,
        "ollama": LocalLLMProvider,  # Alias for local with ollama
        "llama": LocalLLMProvider,  # Alias for local
        "vllm": LocalLLMProvider,  # Alias for local with vllm
    }
    
    @classmethod
    def create_provider(cls, provider_type: str, config: Dict[str, Any]) -> BaseLLMProvider:
        """
        Create an LLM provider instance
        
        Args:
            provider_type: Type of provider (openai, local, ollama, etc.)
            config: Provider configuration
            
        Returns:
            LLM provider instance
        """
        provider_type = provider_type.lower()
        
        if provider_type not in cls._providers:
            raise ValueError(f"Unknown LLM provider: {provider_type}")
        
        provider_class = cls._providers.get(provider_type)
        if provider_class is None:
            raise NotImplementedError(f"Provider {provider_type} is not yet implemented")
        
        # For local providers, set provider_type in config
        if provider_type in ["local", "ollama", "llama", "vllm"]:
            if "provider_type" not in config:
                config["provider_type"] = provider_type if provider_type != "local" else "ollama"
        
        try:
            provider = provider_class(config)
            if not provider.validate_config():
                raise ValueError(f"Invalid configuration for provider {provider_type}")
            return provider
        except Exception as e:
            logger.error(f"Failed to create LLM provider {provider_type}: {str(e)}", exc_info=True)
            raise
    
    @classmethod
    def register_provider(cls, name: str, provider_class: type):
        """
        Register a custom LLM provider
        
        Args:
            name: Provider name
            provider_class: Provider class (must extend BaseLLMProvider)
        """
        if not issubclass(provider_class, BaseLLMProvider):
            raise ValueError("Provider class must extend BaseLLMProvider")
        cls._providers[name.lower()] = provider_class
        logger.info(f"Registered custom LLM provider: {name}")

