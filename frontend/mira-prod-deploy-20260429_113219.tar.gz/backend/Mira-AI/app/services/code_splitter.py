"""
Language-agnostic code splitter for migration chunking.

Goal: split an oversized source file into LLM-sized chunks that NEVER break a
syntactic block. The LLM always sees complete functions / classes / methods
so its output is stitchable.

Approach: use tree-sitter ASTs. tree-sitter-languages ships pre-built parsers
for ~30 languages. For each supported language we list the AST node kinds
that represent "things you do NOT want to cut through" (function/class/method
definitions). We walk top-level nodes, group consecutive small ones into a
chunk up to `max_bytes`, and subdivide a too-large class/module by its own
top-level members (methods inside a class).

If a single indivisible unit (e.g. one huge function body) exceeds max_bytes,
we raise ValueError. The caller (`_modernize_large_file`) treats that file
as failed per the pipeline's all-or-nothing policy.

For unknown / unsupported languages or for files where tree-sitter fails to
parse, we fall back to byte chunking with a warning. That's a best-effort
path; syntax may or may not stitch cleanly, so the caller should prefer
treating byte-chunked files with care.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Per-language configuration.
# Keys are the tree-sitter language names (matching tree_sitter_languages).
# "block_kinds" = AST node.type values that represent splittable block units.
# "container_kinds" = node types whose body can be further subdivided by their
# members (e.g. a class whose body contains methods).
# ---------------------------------------------------------------------------
LANGUAGE_CONFIG: Dict[str, Dict[str, List[str]]] = {
    "php": {
        "block_kinds": [
            "function_definition",
            "method_declaration",
            "class_declaration",
            "interface_declaration",
            "trait_declaration",
            "enum_declaration",
            "namespace_definition",
        ],
        "container_kinds": [
            "class_declaration",
            "interface_declaration",
            "trait_declaration",
            "enum_declaration",
            "namespace_definition",
        ],
    },
    "python": {
        "block_kinds": [
            "function_definition",
            "class_definition",
            "decorated_definition",
        ],
        "container_kinds": [
            "class_definition",
            "decorated_definition",
        ],
    },
    "javascript": {
        "block_kinds": [
            "function_declaration",
            "function_expression",
            "arrow_function",
            "class_declaration",
            "method_definition",
            "generator_function_declaration",
            "lexical_declaration",  # const/let at top-level counts as a block
        ],
        "container_kinds": ["class_declaration"],
    },
    "typescript": {
        "block_kinds": [
            "function_declaration",
            "class_declaration",
            "interface_declaration",
            "type_alias_declaration",
            "method_definition",
            "abstract_class_declaration",
        ],
        "container_kinds": [
            "class_declaration",
            "abstract_class_declaration",
            "interface_declaration",
        ],
    },
    "tsx": {
        "block_kinds": [
            "function_declaration",
            "class_declaration",
            "interface_declaration",
            "method_definition",
        ],
        "container_kinds": [
            "class_declaration",
            "interface_declaration",
        ],
    },
    "java": {
        "block_kinds": [
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "method_declaration",
            "constructor_declaration",
            "record_declaration",
        ],
        "container_kinds": [
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
            "record_declaration",
        ],
    },
    "c_sharp": {
        "block_kinds": [
            "class_declaration",
            "interface_declaration",
            "struct_declaration",
            "enum_declaration",
            "method_declaration",
            "constructor_declaration",
            "namespace_declaration",
            "record_declaration",
            "delegate_declaration",
        ],
        "container_kinds": [
            "class_declaration",
            "interface_declaration",
            "struct_declaration",
            "namespace_declaration",
            "record_declaration",
        ],
    },
    "go": {
        "block_kinds": [
            "function_declaration",
            "method_declaration",
            "type_declaration",
        ],
        "container_kinds": [],  # Go has no class bodies to subdivide
    },
    "ruby": {
        "block_kinds": [
            "class",
            "module",
            "method",
            "singleton_method",
        ],
        "container_kinds": ["class", "module"],
    },
    "rust": {
        "block_kinds": [
            "function_item",
            "impl_item",
            "struct_item",
            "enum_item",
            "trait_item",
            "mod_item",
            "function_signature_item",
        ],
        "container_kinds": ["impl_item", "trait_item", "mod_item"],
    },
    "cpp": {
        "block_kinds": [
            "function_definition",
            "class_specifier",
            "struct_specifier",
            "namespace_definition",
        ],
        "container_kinds": ["class_specifier", "struct_specifier", "namespace_definition"],
    },
    "c": {
        "block_kinds": ["function_definition", "declaration"],
        "container_kinds": [],
    },
    "kotlin": {
        "block_kinds": [
            "class_declaration",
            "object_declaration",
            "function_declaration",
            "property_declaration",
        ],
        "container_kinds": ["class_declaration", "object_declaration"],
    },
    "scala": {
        "block_kinds": [
            "class_definition",
            "trait_definition",
            "object_definition",
            "function_definition",
        ],
        "container_kinds": ["class_definition", "trait_definition", "object_definition"],
    },
}


def _get_parser(language: str):
    """Return a tree-sitter parser for `language`, or None if unavailable."""
    try:
        from tree_sitter_languages import get_parser
        return get_parser(language)
    except Exception as e:
        logger.debug("tree-sitter parser for %r unavailable: %s", language, e)
        return None


def _byte_chunk_fallback(code: str, max_bytes: int) -> List[Tuple[str, str]]:
    """Last-resort splitter: plain byte chunks. Returns list of (text, label).
    Used when we don't have a parser for the language. Can stitch poorly —
    caller should treat this as best-effort.
    """
    if not code:
        return [(code, "empty")]
    n_chunks = max(1, (len(code) + max_bytes - 1) // max_bytes)
    chunks = []
    for i in range(n_chunks):
        start = i * max_bytes
        end = min(start + max_bytes, len(code))
        chunks.append((code[start:end], f"byte-chunk {i + 1}/{n_chunks}"))
    return chunks


def _node_bytes(code_bytes: bytes, node) -> int:
    return node.end_byte - node.start_byte


def _extract_children_spans(code_bytes: bytes, node, block_kinds: set):
    """
    Walk `node.children` and return a list of (start_byte, end_byte, node_type)
    for children that are either in `block_kinds` (real block definitions) or
    "gap" ranges of source between them (top-level code, comments, imports).

    Gap spans are typed "gap".
    """
    out: List[Tuple[int, int, str]] = []
    children = list(node.children)
    if not children:
        out.append((node.start_byte, node.end_byte, "gap"))
        return out
    cursor = node.start_byte
    for child in children:
        if child.start_byte > cursor:
            out.append((cursor, child.start_byte, "gap"))
        if child.type in block_kinds:
            out.append((child.start_byte, child.end_byte, child.type))
            cursor = child.end_byte
        else:
            out.append((child.start_byte, child.end_byte, "gap"))
            cursor = child.end_byte
    if cursor < node.end_byte:
        out.append((cursor, node.end_byte, "gap"))
    return out


def _find_body_node(node):
    """For a container node (class/namespace/impl) return the child node that
    is the body (the `{ ... }` block), or None if not locatable.
    Most tree-sitter grammars name this field 'body' or provide a
    block/declaration_list child.
    """
    # Try common body field names first
    for field in ("body", "declaration_list", "class_body", "declarations"):
        b = node.child_by_field_name(field) if hasattr(node, "child_by_field_name") else None
        if b is not None:
            return b
    # Fallback: last child that spans a `{...}` region
    for child in reversed(list(node.children)):
        ctype = child.type
        if ctype in ("block", "compound_statement", "declaration_list", "class_body", "field_declaration_list"):
            return child
    return None


def _subdivide_container(
    code_bytes: bytes,
    container_node,
    max_bytes: int,
    block_kinds: set,
) -> Optional[List[Tuple[str, str]]]:
    """
    When a single container (e.g. a class) exceeds max_bytes, try to split by
    its members. We keep the container header + trailing `}` intact and group
    consecutive member definitions into chunks. Each emitted chunk is the
    container header + a subset of members + the closing brace so each chunk
    is (locally) parseable.

    Returns list of (text, label) or None if not possible.
    """
    body = _find_body_node(container_node)
    if body is None:
        return None

    # Body typically starts with `{` and ends with `}`. Header = everything up to
    # and INCLUDING the opening `{`; trailer = the closing `}` and whatever comes
    # after it (whitespace, etc.). We want to chunk the body's INNER contents —
    # NOT re-include the braces in each member span.
    body_start = body.start_byte
    body_end = body.end_byte
    body_text = code_bytes[body_start:body_end].decode("utf-8", errors="ignore")

    has_open_brace = body_text.startswith("{")
    has_close_brace = body_text.endswith("}")

    # Header runs from container start through the opening brace of the body.
    header_end = body_start + 1 if has_open_brace else body_start
    header = code_bytes[container_node.start_byte:header_end].decode("utf-8", errors="ignore")
    # Trailer is the closing brace + any trailing bytes up to container end.
    trailer_start = body_end - 1 if has_close_brace else body_end
    trailer = code_bytes[trailer_start:container_node.end_byte].decode("utf-8", errors="ignore")

    # The inner region (where members live) is between header_end and trailer_start.
    # We extract children of `body` but clamp their span to [header_end, trailer_start]
    # so we never re-include the braces.
    raw_members = _extract_children_spans(code_bytes, body, block_kinds)
    members: List[Tuple[int, int, str]] = []
    for s, e, kind in raw_members:
        s_clamped = max(s, header_end)
        e_clamped = min(e, trailer_start)
        if e_clamped > s_clamped:
            members.append((s_clamped, e_clamped, kind))
    if not members:
        return None

    wrap_cost = len(header.encode()) + len(trailer.encode()) + 16
    chunks: List[Tuple[str, str]] = []
    cur_parts: List[str] = []
    cur_bytes = 0
    first_idx = 1

    for idx, (s, e, kind) in enumerate(members, 1):
        seg_bytes = e - s
        if seg_bytes + wrap_cost > max_bytes:
            return None  # single member too big
        if cur_bytes + seg_bytes + wrap_cost > max_bytes and cur_parts:
            text = header + "".join(cur_parts) + trailer
            chunks.append((text, f"members {first_idx}-{idx - 1}"))
            cur_parts = []
            cur_bytes = 0
            first_idx = idx
        cur_parts.append(code_bytes[s:e].decode("utf-8", errors="ignore"))
        cur_bytes += seg_bytes

    if cur_parts:
        text = header + "".join(cur_parts) + trailer
        chunks.append((text, f"members {first_idx}-{len(members)}"))

    return chunks if len(chunks) > 1 else None


def split_code(
    code: str,
    language: str,
    max_bytes: int,
) -> List[Tuple[str, str]]:
    """
    Split `code` into chunks not exceeding `max_bytes`, respecting language
    block boundaries when possible.

    Args:
        code: The source text.
        language: tree-sitter language name. "generic" or unknown → byte fallback.
        max_bytes: Maximum UTF-8 byte size per chunk.

    Returns: list of (chunk_text, label).

    Raises:
        ValueError: If a single indivisible block exceeds max_bytes. Caller
                    should treat this as file-level failure.
    """
    if not code:
        return [("", "empty")]

    code_bytes = code.encode("utf-8")
    total_bytes = len(code_bytes)

    # Small files — no split needed.
    if total_bytes <= max_bytes:
        return [(code, "whole-file")]

    config = LANGUAGE_CONFIG.get(language)
    if not config:
        logger.warning(
            "No tree-sitter config for language=%r (size=%d bytes); falling back to byte chunks",
            language, total_bytes,
        )
        return _byte_chunk_fallback(code, max_bytes)

    parser = _get_parser(language)
    if parser is None:
        logger.warning(
            "tree-sitter parser for %r not available; falling back to byte chunks", language,
        )
        return _byte_chunk_fallback(code, max_bytes)

    try:
        tree = parser.parse(code_bytes)
        root = tree.root_node
    except Exception as e:
        logger.warning("tree-sitter parse failed for %s: %s; falling back to byte chunks", language, e)
        return _byte_chunk_fallback(code, max_bytes)

    block_kinds = set(config["block_kinds"])
    container_kinds = set(config["container_kinds"])

    # Get top-level spans: every top-level block, plus gaps between them (top-level statements).
    spans = _extract_children_spans(code_bytes, root, block_kinds)
    if not spans:
        return _byte_chunk_fallback(code, max_bytes)

    # Build chunks greedily.
    chunks: List[Tuple[str, str]] = []
    cur_parts: List[str] = []
    cur_bytes = 0
    first_idx = 1

    def _flush(upto_idx: int):
        nonlocal cur_parts, cur_bytes, first_idx
        if cur_parts:
            chunks.append(("".join(cur_parts), f"blocks {first_idx}-{upto_idx}"))
            cur_parts = []
            cur_bytes = 0
            first_idx = upto_idx + 1

    for idx, (s, e, kind) in enumerate(spans, 1):
        seg = code_bytes[s:e].decode("utf-8", errors="ignore")
        sb = e - s

        if sb > max_bytes:
            # Too big for a single chunk. Flush what we have.
            _flush(idx - 1)

            # Try to subdivide if this is a known container type
            if kind in container_kinds:
                # Re-parse just this node to find members
                # (we already have tree, just find the node again by position)
                container_node = None
                for ch in root.children:
                    if ch.start_byte == s and ch.end_byte == e and ch.type == kind:
                        container_node = ch
                        break
                if container_node is not None:
                    sub = _subdivide_container(code_bytes, container_node, max_bytes, block_kinds)
                    if sub is not None:
                        for sub_idx, (st, sl) in enumerate(sub, 1):
                            chunks.append((st, f"{kind} part {sub_idx}/{len(sub)}: {sl}"))
                        first_idx = idx + 1
                        continue

            # Could not subdivide. Fail loudly so caller can record file as failed.
            raise ValueError(
                f"Single top-level unit ({kind}, {sb} bytes) exceeds max_bytes={max_bytes} "
                f"and cannot be subdivided. Consider raising MIRA_MAX_LLM_FILE_BYTES."
            )

        # Fits. If adding it would overflow, flush first.
        if cur_bytes + sb > max_bytes and cur_parts:
            _flush(idx - 1)
            first_idx = idx

        cur_parts.append(seg)
        cur_bytes += sb

    _flush(len(spans))
    return chunks
