"""Account schemas (Pydantic models for request/response)"""
from typing import Optional
from datetime import datetime
from pydantic import BaseModel, EmailStr, Field, validator
from app.core.constants import UserRole


# Password validation error messages (constants to avoid duplication)
PASSWORD_ERROR_DIGIT = "Password must contain at least one digit"
PASSWORD_ERROR_UPPERCASE = "Password must contain at least one uppercase letter"
PASSWORD_ERROR_LOWERCASE = "Password must contain at least one lowercase letter"
PASSWORD_ERROR_SPECIAL = "Password must contain at least one special character (!@#$%^&*)"


def validate_password_strength(password: str) -> str:
    """
    Shared password validation helper.
    Validates password meets strength requirements.
    """
    if not any(char.isdigit() for char in password):
        raise ValueError(PASSWORD_ERROR_DIGIT)
    if not any(char.isupper() for char in password):
        raise ValueError(PASSWORD_ERROR_UPPERCASE)
    if not any(char.islower() for char in password):
        raise ValueError(PASSWORD_ERROR_LOWERCASE)
    if not any(char in "!@#$%^&*()_+-=[]{}|;:,.<>?" for char in password):
        raise ValueError(PASSWORD_ERROR_SPECIAL)
    return password


class UserBase(BaseModel):
    """Base user schema"""
    email: EmailStr = Field(..., description="User email address")
    username: Optional[str] = Field(None, description="Display name (optional)")


class UserCreate(UserBase):
    """Register a new Mira AI account."""
    email: EmailStr = Field(..., description="Email address — used for login and notifications", examples=["alice@example.com"])
    username: Optional[str] = Field(None, description="Display name (optional)")
    password: str = Field(
        ...,
        min_length=8,
        max_length=100,
        description="Password (min 8 chars, must include uppercase, lowercase, digit, and special character)",
        examples=["Str0ng!Pass"],
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{"email": "alice@example.com", "password": "Str0ng!Pass"}]
        }
    }

    @validator('password')
    def validate_password(cls, v):
        """Validate password strength"""
        return validate_password_strength(v)


class UserLogin(BaseModel):
    """Authenticate with email and password."""
    email: EmailStr = Field(..., description="Registered email address", examples=["alice@example.com"])
    password: str = Field(..., description="Account password")

    model_config = {
        "json_schema_extra": {
            "examples": [{"email": "alice@example.com", "password": "Str0ng!Pass"}]
        }
    }


class UserUpdate(BaseModel):
    """Update display name or email for the current user."""
    username: Optional[str] = Field(None, description="New display name")
    email: Optional[EmailStr] = Field(None, description="New email address")


class SSHCredentials(BaseModel):
    """SSH credentials for connecting to your VM. Saved against your account after a successful test."""
    hostname: str = Field(..., description="Server hostname or IP address (e.g. '10.240.92.4')", examples=["10.240.92.4"])
    port: int = Field(22, description="SSH port (default 22)")
    username: str = Field(..., description="SSH username on the remote server", examples=["ubuntu"])
    password: Optional[str] = Field(None, description="SSH password. Provide either password or private_key.")
    private_key: Optional[str] = Field(None, description="PEM-encoded SSH private key content.")
    private_key_password: Optional[str] = Field(None, description="Passphrase for the encrypted private key.")
    source_path: Optional[str] = Field(
        None,
        description=(
            "Path to the project directory on the remote server (e.g. /home/usama/app2). "
            "Saved as ssh_source_path and used automatically by all pipeline endpoints so "
            "you only need to provide project_name in subsequent calls."
        ),
    )


class SSHCredentialsUpdate(BaseModel):
    """Partial update for saved SSH credentials (all fields optional)."""
    hostname: Optional[str] = Field(None, description="New server hostname or IP")
    port: Optional[int] = Field(None, description="New SSH port")
    username: Optional[str] = Field(None, description="New SSH username")
    password: Optional[str] = Field(None, description="New SSH password")
    private_key: Optional[str] = Field(None, description="New PEM-encoded private key")
    private_key_password: Optional[str] = Field(None, description="New private key passphrase")


class UserResponse(UserBase):
    """Current user profile including SSH connection state."""
    id: str = Field(..., description="User ID (MongoDB ObjectId as string)")
    role: UserRole = Field(..., description="User role: user | admin")
    is_active: bool = Field(..., description="Account is active")
    is_superuser: bool = Field(..., description="Has superuser privileges")
    is_email_verified: bool = Field(..., description="Email address has been verified")
    ssh_verified: bool = Field(False, description="SSH connection has been successfully tested")
    ssh_hostname: Optional[str] = Field(None, description="Saved SSH hostname")
    ssh_port: Optional[int] = Field(None, description="Saved SSH port")
    ssh_username: Optional[str] = Field(None, description="Saved SSH username")
    ssh_source_path: Optional[str] = Field(None, description="Saved project source path on the remote server")
    last_login_at: Optional[datetime] = Field(None, description="UTC timestamp of last login")
    created_at: datetime = Field(..., description="UTC timestamp when the account was created")
    updated_at: Optional[datetime] = Field(None, description="UTC timestamp of last profile update")

    @classmethod
    def from_mongo_user(cls, user):
        """Create UserResponse from MongoDB User document"""
        return cls(
            id=str(user.id),
            email=user.email,
            username=user.username,
            role=user.role,
            is_active=user.is_active,
            is_superuser=user.is_superuser,
            is_email_verified=user.is_email_verified,
            ssh_verified=user.ssh_verified,
            ssh_hostname=user.ssh_hostname,
            ssh_port=user.ssh_port,
            ssh_username=user.ssh_username,
            ssh_source_path=user.ssh_source_path,
            last_login_at=user.last_login_at,
            created_at=user.created_at,
            updated_at=user.updated_at
        )
    
    class Config:
        from_attributes = True
        populate_by_name = True
        json_encoders = {
            # Ensure ObjectId is serialized as string
            "ObjectId": str
        }


class TokenResponse(BaseModel):
    """JWT token pair returned by /refresh."""
    access_token: str = Field(..., description="Short-lived JWT access token (Bearer)")
    refresh_token: str = Field(..., description="Long-lived refresh token for renewing access")
    token_type: str = Field("bearer", description="Token type — always 'bearer'")
    expires_in: int = Field(1800, description="Access token lifetime in seconds (default: 1800 = 30 min)")


class LoginResponse(BaseModel):
    """JWT token pair + full user profile returned on successful login."""
    access_token: str = Field(..., description="Short-lived JWT access token (Bearer)")
    refresh_token: str = Field(..., description="Long-lived refresh token for renewing access")
    token_type: str = Field("bearer", description="Token type — always 'bearer'")
    expires_in: int = Field(1800, description="Access token lifetime in seconds")
    user: UserResponse = Field(..., description="Full user profile")


class TokenPayload(BaseModel):
    """Decoded JWT payload (internal use)."""
    sub: str = Field(..., description="Subject — user ID (MongoDB ObjectId string)")
    exp: datetime = Field(..., description="Token expiry (UTC)")
    type: str = Field(..., description="Token type: access | refresh")


class RefreshTokenRequest(BaseModel):
    """Refresh token to exchange for a new access token."""
    refresh_token: str = Field(..., description="Refresh token obtained from /login or /refresh")


class EmailVerificationRequest(BaseModel):
    """Email verification token (from the link sent to user's inbox)."""
    token: str = Field(..., description="Email verification token from the verification link")


class ForgotPasswordRequest(BaseModel):
    """Request a password reset email."""
    email: EmailStr = Field(..., description="Email address of the account to reset")


class ResetPasswordRequest(BaseModel):
    """Set a new password using a reset token."""
    token: str = Field(..., description="Password reset token from the email link")
    new_password: str = Field(
        ...,
        min_length=8,
        max_length=100,
        description="New password (min 8 chars, must include uppercase, lowercase, digit, special character)",
    )

    @validator('new_password')
    def validate_password(cls, v):
        """Validate password strength"""
        return validate_password_strength(v)


class ChangePasswordRequest(BaseModel):
    """Change password for the currently authenticated user."""
    current_password: str = Field(..., description="Current account password")
    new_password: str = Field(
        ...,
        min_length=8,
        max_length=100,
        description="New password (min 8 chars, must include uppercase, lowercase, digit, special character)",
    )
    
    @validator('new_password')
    def validate_password(cls, v):
        """Validate password strength"""
        return validate_password_strength(v)


class MessageResponse(BaseModel):
    """Generic status message response."""
    message: str = Field(..., description="Human-readable status message")
    detail: Optional[str] = Field(None, description="Additional detail or context")
