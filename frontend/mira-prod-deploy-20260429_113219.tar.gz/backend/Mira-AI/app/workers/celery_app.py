"""Celery application configuration"""
from celery import Celery
from app.core.config import settings

# Initialize Celery app
celery_app = Celery(
    "mira_ai",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[
        "app.workers.scan_tasks",
        "app.workers.report_tasks",
        "app.workers.upgrade_tasks",
        "app.workers.cleanup_tasks",
        "app.workers.sonarqube_tasks"  # SonarQube async scanning tasks
    ]
)

# Celery configuration
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=30 * 60,  # 30 minutes
    task_soft_time_limit=25 * 60,  # 25 minutes
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=1000,
    broker_connection_retry_on_startup=True,  # For Celery 6.0+ compatibility
)
