"""Email service for sending verification and password reset emails"""
from typing import List
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType
from pydantic import EmailStr
from app.core.config import settings


class EmailConfig:
    """Email configuration"""
    
    @staticmethod
    def get_config() -> ConnectionConfig:
        """Get email connection configuration"""
        return ConnectionConfig(
            MAIL_USERNAME=settings.MAIL_USERNAME or "",
            MAIL_PASSWORD=settings.MAIL_PASSWORD or "",
            MAIL_FROM=settings.MAIL_FROM or "",
            MAIL_PORT=settings.MAIL_PORT,
            MAIL_SERVER=settings.MAIL_SERVER or "",
            MAIL_FROM_NAME=settings.MAIL_FROM_NAME,
            MAIL_STARTTLS=settings.MAIL_TLS,
            MAIL_SSL_TLS=settings.MAIL_SSL,
            USE_CREDENTIALS=True,
            VALIDATE_CERTS=True,
            TEMPLATE_FOLDER="app/templates/email"
        )


class EmailService:
    """Email service for sending emails"""
    
    def __init__(self):
        if settings.MAIL_USERNAME and settings.MAIL_SERVER:
            self.config = EmailConfig.get_config()
            self.fast_mail = FastMail(self.config)
        else:
            self.fast_mail = None
    
    async def send_email(
        self,
        subject: str,
        recipients: List[EmailStr],
        body: str,
        subtype: MessageType = MessageType.html
    ):
        """Send email"""
        if not self.fast_mail:
            # In development, just print the email content
            print(f"\n{'='*60}")
            print(f"EMAIL WOULD BE SENT (Email not configured)")
            print(f"To: {recipients}")
            print(f"Subject: {subject}")
            print(f"Body: {body}")
            print(f"{'='*60}\n")
            return
        
        message = MessageSchema(
            subject=subject,
            recipients=recipients,
            body=body,
            subtype=subtype
        )
        
        await self.fast_mail.send_message(message)
    
    async def send_verification_email(self, email: str, token: str, username: str = None):
        """Send email verification email"""
        verification_url = f"{settings.BACKEND_URL}/api/v1/accounts/verify-email?token={token}"
        
        body = f"""
        <html>
            <body>
                <h2>Welcome to {settings.APP_NAME}!</h2>
                <p>Hello {username or 'there'},</p>
                <p>Thank you for signing up. Please verify your email address by clicking the link below:</p>
                <p>
                    <a href="{verification_url}" style="padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px;">
                        Verify Email Address
                    </a>
                </p>
                <p>Or copy and paste this link into your browser:</p>
                <p>{verification_url}</p>
                <p>This link will expire in {settings.EMAIL_VERIFICATION_TOKEN_EXPIRE_HOURS} hours.</p>
                <p>If you didn't create an account, you can safely ignore this email.</p>
                <br>
                <p>Best regards,<br>{settings.APP_NAME} Team</p>
            </body>
        </html>
        """
        
        await self.send_email(
            subject=f"Verify your {settings.APP_NAME} account",
            recipients=[email],
            body=body
        )
    
    async def send_password_reset_email(self, email: str, token: str, username: str = None):
        """Send password reset email"""
        reset_url = f"{settings.FRONTEND_URL}/reset-password?token={token}"
        
        body = f"""
        <html>
            <body>
                <h2>{settings.APP_NAME} - Password Reset Request</h2>
                <p>Hello {username or 'there'},</p>
                <p>You requested to reset your password. Click the link below to reset it:</p>
                <p>
                    <a href="{reset_url}" style="padding: 10px 20px; background-color: #2196F3; color: white; text-decoration: none; border-radius: 5px;">
                        Reset Password
                    </a>
                </p>
                <p>Or copy and paste this link into your browser:</p>
                <p>{reset_url}</p>
                <p>This link will expire in {settings.PASSWORD_RESET_TOKEN_EXPIRE_HOURS} hours.</p>
                <p>If you didn't request a password reset, please ignore this email or contact support if you have concerns.</p>
                <br>
                <p>Best regards,<br>{settings.APP_NAME} Team</p>
            </body>
        </html>
        """
        
        await self.send_email(
            subject=f"{settings.APP_NAME} - Password Reset Request",
            recipients=[email],
            body=body
        )
    
    async def send_password_changed_email(self, email: str, username: str = None):
        """Send password changed confirmation email"""
        body = f"""
        <html>
            <body>
                <h2>{settings.APP_NAME} - Password Changed</h2>
                <p>Hello {username or 'there'},</p>
                <p>This email confirms that your password has been successfully changed.</p>
                <p>If you didn't make this change, please contact our support team immediately.</p>
                <br>
                <p>Best regards,<br>{settings.APP_NAME} Team</p>
            </body>
        </html>
        """
        
        await self.send_email(
            subject=f"{settings.APP_NAME} - Password Changed",
            recipients=[email],
            body=body
        )


# Create global email service instance
email_service = EmailService()
