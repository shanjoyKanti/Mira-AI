"""
Unit tests for app/services/rag/rag_adapter.py

Tests cover:
  - fetch_php_migration_docs: cache hit, cache miss, scrape failure, multi-step
  - fetch_laravel_docs: correct version selected, scrape failure returns ""
  - fetch_migration_docs: generic multi-language
  - _laravel_version_for_php_target: PHP→Laravel mapping
  - RagFetchError propagation
  - combined_documentation is non-empty for each returned stage

All tests mock UniversalMigrationTool so no Qdrant/network calls are made.
"""

import pytest
from unittest.mock import MagicMock, patch, call

from app.services.rag.rag_adapter import (
    RagAdapter,
    RagFetchError,
    RagStageDoc,
    _laravel_version_for_php_target,
)
from app.services.rag.version_ladder import VersionLadderError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_success_result(content: str, version: str, source: str = "qdrant") -> dict:
    return {
        "success": True,
        "language": "php",
        "version": version,
        "content": content,
        "url": f"https://www.php.net/manual/en/migration{version.replace('.', '')}.php",
        "source": source,
        "error": None,
    }


def _make_empty_result(version: str, error: str = "empty") -> dict:
    return {
        "success": False,
        "language": "php",
        "version": version,
        "content": "",
        "url": "",
        "source": "fetched",
        "error": error,
    }


def _build_adapter_with_mock_tool(mock_tool: MagicMock) -> RagAdapter:
    """Create a RagAdapter bypassing __init__ and inject mock tool."""
    adapter = RagAdapter.__new__(RagAdapter)
    adapter._tool = mock_tool
    return adapter


# ---------------------------------------------------------------------------
# _laravel_version_for_php_target
# ---------------------------------------------------------------------------

class TestLaravelVersionForPhpTarget:
    def test_php_80_maps_to_laravel_9(self):
        assert _laravel_version_for_php_target("8.0") == "9"

    def test_php_81_maps_to_laravel_10(self):
        assert _laravel_version_for_php_target("8.1") == "10"

    def test_php_82_maps_to_laravel_11(self):
        assert _laravel_version_for_php_target("8.2") == "11"

    def test_php_83_maps_to_laravel_12(self):
        assert _laravel_version_for_php_target("8.3") == "12"

    def test_php_74_maps_to_laravel_8(self):
        # Laravel 8 requires PHP 7.3+
        assert _laravel_version_for_php_target("7.4") == "8"

    def test_php_72_maps_to_laravel_7(self):
        assert _laravel_version_for_php_target("7.2") == "7"

    def test_php_too_old_returns_none(self):
        # PHP 4.x — no Laravel version satisfies
        result = _laravel_version_for_php_target("4.0")
        assert result is None

    def test_php_version_with_dotx(self):
        # e.g. "8.2.x" normalised properly
        result = _laravel_version_for_php_target("8.2.x")
        assert result == "11"


# ---------------------------------------------------------------------------
# fetch_php_migration_docs — cache hit path
# ---------------------------------------------------------------------------

class TestFetchPhpMigrationDocsCacheHit:
    def test_single_step_cache_hit(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = _make_success_result(
            "PHP 8.0 migration guide content", "8.0", source="qdrant"
        )
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_php_migration_docs("7.4", "8.0")

        assert len(docs) == 1
        assert docs[0].from_version == "7.4"
        assert docs[0].to_version == "8.0"
        assert docs[0].content == "PHP 8.0 migration guide content"
        assert docs[0].source == "qdrant"
        mock_tool.fetch_migration.assert_called_once_with(
            language="php", version="8.0", framework=None, force_refresh=False
        )

    def test_multi_step_cache_hit(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.side_effect = [
            _make_success_result("PHP 8.0 content", "8.0", "qdrant"),
            _make_success_result("PHP 8.1 content", "8.1", "qdrant"),
            _make_success_result("PHP 8.2 content", "8.2", "qdrant"),
        ]
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_php_migration_docs("7.4", "8.2")

        assert len(docs) == 3
        assert [d.to_version for d in docs] == ["8.0", "8.1", "8.2"]
        assert [d.from_version for d in docs] == ["7.4", "8.0", "8.1"]
        assert all(d.source == "qdrant" for d in docs)

    def test_all_stages_have_non_empty_combined_documentation(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.side_effect = [
            _make_success_result(f"content for step {v}", v, "qdrant")
            for v in ["8.0", "8.1", "8.2", "8.3"]
        ]
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_php_migration_docs("7.4", "8.3")

        assert all(d.content for d in docs), "All stages must have non-empty content"


# ---------------------------------------------------------------------------
# fetch_php_migration_docs — cache miss (fetched path)
# ---------------------------------------------------------------------------

class TestFetchPhpMigrationDocsCacheMiss:
    def test_first_miss_then_fetch(self):
        """First call returns empty (cache miss); second call returns fetched content."""
        mock_tool = MagicMock()
        mock_tool.fetch_migration.side_effect = [
            _make_empty_result("8.0"),                              # attempt 1: miss
            _make_success_result("PHP 8.0 fetched", "8.0", "fetched"),  # attempt 2: web
        ]
        adapter = _build_adapter_with_mock_tool(mock_tool)

        with patch("app.services.rag.rag_adapter.time") as mock_time:
            mock_time.sleep = MagicMock()
            docs = adapter.fetch_php_migration_docs("7.4", "8.0")

        assert len(docs) == 1
        assert docs[0].source == "fetched"
        assert docs[0].content == "PHP 8.0 fetched"
        assert mock_tool.fetch_migration.call_count == 2

    def test_fetch_migration_tool_exception_retried(self):
        """If fetch_migration raises an exception it is retried once."""
        mock_tool = MagicMock()
        mock_tool.fetch_migration.side_effect = [
            RuntimeError("network error"),                          # attempt 1: exception
            _make_success_result("PHP 8.0 fetched", "8.0", "fetched"),  # attempt 2: ok
        ]
        adapter = _build_adapter_with_mock_tool(mock_tool)

        with patch("app.services.rag.rag_adapter.time") as mock_time:
            mock_time.sleep = MagicMock()
            docs = adapter.fetch_php_migration_docs("7.4", "8.0")

        assert len(docs) == 1
        assert docs[0].content == "PHP 8.0 fetched"

    def test_same_version_returns_empty_list(self):
        mock_tool = MagicMock()
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_php_migration_docs("8.0", "8.0")

        assert docs == []
        mock_tool.fetch_migration.assert_not_called()


# ---------------------------------------------------------------------------
# fetch_php_migration_docs — scrape failure
# ---------------------------------------------------------------------------

class TestFetchPhpMigrationDocsScrapeFailure:
    def test_all_retries_empty_raises_rag_fetch_error(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = _make_empty_result("8.0", "site down")
        adapter = _build_adapter_with_mock_tool(mock_tool)

        with patch("app.services.rag.rag_adapter.time") as mock_time:
            mock_time.sleep = MagicMock()
            with pytest.raises(RagFetchError, match="8.0"):
                adapter.fetch_php_migration_docs("7.4", "8.0")

        # Should have tried _SCRAPE_MAX_RETRIES times
        assert mock_tool.fetch_migration.call_count == adapter._SCRAPE_MAX_RETRIES

    def test_all_retries_exception_raises_rag_fetch_error(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.side_effect = ConnectionError("connection refused")
        adapter = _build_adapter_with_mock_tool(mock_tool)

        with patch("app.services.rag.rag_adapter.time") as mock_time:
            mock_time.sleep = MagicMock()
            with pytest.raises(RagFetchError):
                adapter.fetch_php_migration_docs("7.4", "8.0")

    def test_invalid_versions_raise_version_ladder_error(self):
        mock_tool = MagicMock()
        adapter = _build_adapter_with_mock_tool(mock_tool)

        with pytest.raises(VersionLadderError):
            adapter.fetch_php_migration_docs("7.4", "9.9")  # 9.9 not in ladder


# ---------------------------------------------------------------------------
# fetch_laravel_docs
# ---------------------------------------------------------------------------

class TestFetchLaravelDocs:
    def test_php_80_fetches_laravel_9_guide(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = {
            "success": True,
            "content": "Laravel 9 upgrade instructions",
            "url": "https://laravel.com/docs/9.x/upgrade",
            "source": "qdrant",
            "error": None,
        }
        adapter = _build_adapter_with_mock_tool(mock_tool)

        result = adapter.fetch_laravel_docs("8.0")

        assert "Laravel 9 upgrade instructions" in result
        assert "Laravel 9 Upgrade Guide" in result
        mock_tool.fetch_migration.assert_called_once_with(
            language="php", version="9", framework="laravel", force_refresh=False
        )

    def test_php_82_fetches_laravel_11_guide(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = {
            "success": True,
            "content": "Laravel 11 upgrade instructions",
            "url": "https://laravel.com/docs/11.x/upgrade",
            "source": "qdrant",
            "error": None,
        }
        adapter = _build_adapter_with_mock_tool(mock_tool)

        result = adapter.fetch_laravel_docs("8.2")

        assert "Laravel 11" in result

    def test_php_version_with_no_laravel_mapping_returns_empty(self):
        mock_tool = MagicMock()
        adapter = _build_adapter_with_mock_tool(mock_tool)

        result = adapter.fetch_laravel_docs("4.0")  # no Laravel maps to PHP 4

        assert result == ""
        mock_tool.fetch_migration.assert_not_called()

    def test_scrape_failure_returns_empty_string(self):
        """fetch_laravel_docs should never raise — failure returns empty string."""
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = _make_empty_result("9", "network failure")
        adapter = _build_adapter_with_mock_tool(mock_tool)

        with patch("app.services.rag.rag_adapter.time") as mock_time:
            mock_time.sleep = MagicMock()
            result = adapter.fetch_laravel_docs("8.0")

        assert result == ""

    def test_from_laravel_kwarg_is_accepted(self):
        """from_laravel is informational only — should not affect result."""
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = {
            "success": True,
            "content": "Laravel 9 guide",
            "url": "https://laravel.com/docs/9.x/upgrade",
            "source": "qdrant",
            "error": None,
        }
        adapter = _build_adapter_with_mock_tool(mock_tool)

        result_with = adapter.fetch_laravel_docs("8.0", from_laravel="8")
        result_without = adapter.fetch_laravel_docs("8.0")

        assert result_with == result_without

    def test_guide_has_version_header(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = {
            "success": True,
            "content": "Laravel 9 upgrade content here",
            "url": "https://laravel.com/docs/9.x/upgrade",
            "source": "fetched",
            "error": None,
        }
        adapter = _build_adapter_with_mock_tool(mock_tool)

        result = adapter.fetch_laravel_docs("8.0")

        # Should have a section header
        assert result.startswith("--- Laravel 9 Upgrade Guide ---")


# ---------------------------------------------------------------------------
# fetch_migration_docs (generic)
# ---------------------------------------------------------------------------

class TestFetchMigrationDocsGeneric:
    def test_python_migration_steps(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.side_effect = [
            {
                "success": True,
                "content": "Python 3.9 migration notes",
                "url": "https://docs.python.org/3/whatsnew/3.9.html",
                "source": "qdrant",
                "error": None,
            },
            {
                "success": True,
                "content": "Python 3.10 migration notes",
                "url": "https://docs.python.org/3/whatsnew/3.10.html",
                "source": "qdrant",
                "error": None,
            },
        ]
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_migration_docs("python", None, "3.8", "3.10")

        assert len(docs) == 2
        assert docs[0].to_version == "3.9"
        assert docs[1].to_version == "3.10"
        mock_tool.fetch_migration.assert_any_call(
            language="python", version="3.9", framework=None, force_refresh=False
        )
        mock_tool.fetch_migration.assert_any_call(
            language="python", version="3.10", framework=None, force_refresh=False
        )

    def test_django_framework_passed_correctly(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = {
            "success": True,
            "content": "Django 5.0 release notes",
            "url": "https://docs.djangoproject.com/en/5.0/releases/5.0/",
            "source": "fetched",
            "error": None,
        }
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_migration_docs("python", "django", "4.2", "5.0")

        assert len(docs) == 1
        mock_tool.fetch_migration.assert_called_once_with(
            language="python", version="5.0", framework="django", force_refresh=False
        )

    def test_same_version_returns_empty_list(self):
        mock_tool = MagicMock()
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_migration_docs("python", None, "3.10", "3.10")

        assert docs == []
        mock_tool.fetch_migration.assert_not_called()

    def test_unknown_language_raises_version_ladder_error(self):
        mock_tool = MagicMock()
        adapter = _build_adapter_with_mock_tool(mock_tool)

        with pytest.raises(VersionLadderError):
            adapter.fetch_migration_docs("cobol", None, "1.0", "2.0")

    def test_chain_order_preserved(self):
        """Steps must be in ascending ladder order."""
        mock_tool = MagicMock()
        mock_tool.fetch_migration.side_effect = [
            _make_success_result(f"Node.js {v}", v, "qdrant")
            for v in ["18", "20"]
        ]
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_migration_docs("javascript", None, "16", "20")

        assert [d.to_version for d in docs] == ["18", "20"]
        assert docs[0].from_version == "16"
        assert docs[1].from_version == "18"


# ---------------------------------------------------------------------------
# RagStageDoc NamedTuple
# ---------------------------------------------------------------------------

class TestRagStageDoc:
    def test_namedtuple_fields(self):
        doc = RagStageDoc(
            from_version="7.4",
            to_version="8.0",
            content="some content",
            source_url="https://example.com",
            source="qdrant",
        )
        assert doc.from_version == "7.4"
        assert doc.to_version == "8.0"
        assert doc.content == "some content"
        assert doc.source_url == "https://example.com"
        assert doc.source == "qdrant"

    def test_namedtuple_immutable(self):
        doc = RagStageDoc("7.4", "8.0", "content", "url", "qdrant")
        with pytest.raises(AttributeError):
            doc.from_version = "8.0"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Integration-style: full PHP 7.4 → 8.1 pipeline check
# ---------------------------------------------------------------------------

class TestPhpFullPipelineIntegration:
    """Validates the complete flow from fetch_php_migration_docs through to
    the structure expected by planning_agent (combined_documentation per stage)."""

    def test_74_to_81_produces_two_stage_docs(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.side_effect = [
            _make_success_result("PHP 8.0 breaking changes: ...", "8.0", "qdrant"),
            _make_success_result("PHP 8.1 enums, fibers, ...", "8.1", "fetched"),
        ]
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_php_migration_docs("7.4", "8.1")

        # Two stages: 7.4→8.0 and 8.0→8.1
        assert len(docs) == 2

        # Stage 1: 7.4 → 8.0
        stage1 = docs[0]
        assert stage1.from_version == "7.4"
        assert stage1.to_version == "8.0"
        assert stage1.content  # non-empty → maps to MigrationStage.combined_documentation

        # Stage 2: 8.0 → 8.1
        stage2 = docs[1]
        assert stage2.from_version == "8.0"
        assert stage2.to_version == "8.1"
        assert stage2.content

    def test_docs_source_url_populated(self):
        mock_tool = MagicMock()
        mock_tool.fetch_migration.return_value = _make_success_result(
            "content", "8.0", "qdrant"
        )
        adapter = _build_adapter_with_mock_tool(mock_tool)

        docs = adapter.fetch_php_migration_docs("7.4", "8.0")

        assert docs[0].source_url  # non-empty URL
