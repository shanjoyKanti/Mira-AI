"""API route endpoints for code analysis."""
from beanie import PydanticObjectId
import time
import json
import os
import re
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import FileResponse
from typing import Optional, Dict, Any, List
from datetime import datetime

from app.core.dependencies import get_current_active_user
from app.db.mongodb_models import (
    User, SonarQubeScanJob, SonarQubeReport, ScanJobStatus,
    UserProject, ProjectType, Industry, ConversionEnvironment,
    CodeSourceType, LLMOption, MonthlyTraffic, ReportType, AnalysisReport
)
from app.services.ssh.ssh_service import SSHService
from app.services.sonarqube.remote_scanner import RemoteSonarScanner
from app.services.sonarqube.report_fetcher import SonarQubeReportFetcher
from app.services.llm.llm_service import get_llm_service
from app.core.logging import get_logger
from app.core.config import settings
from app.core.security import encrypt_data, decrypt_data

from app.api.v1.analyze.schemas import (
    SSHCredentialsInput,
    CodeAnalysisRequest,
    ProjectCreateRequest,
    ProjectUpdateRequest,
    SSHTestRequest,
    ProjectAnalysisRequest,
)
from app.api.v1.analyze.utils import (
    REPORTS_DIR,
    gather_file_structure,
    gather_source_code,
    _sanitize_for_xml,
)
from app.api.v1.analyze.generators import (
    REPORT_GENERATORS,
    REPORT_TYPE_LABELS,
    REPORT_CATEGORIES,
    build_report_from_sonarqube_only,
    enhance_report_with_llm,
    generate_project_analysis_report,
)
from app.api.v1.analyze.formatters import (
    generate_markdown_report,
    generate_html_report,
    generate_pdf_report,
    generate_docx_report,
)

logger = get_logger(__name__)

router = APIRouter()


# ---------------------------------------------------------------------------
# Analyze-flow progress tracking — in-memory map of analysis_id -> progress dict.
# The UI kicks off an analysis with POST /scan/analyse-project, receives the
# analysis_id in the streaming-response header (or starts polling immediately),
# and polls GET /scan/progress/{analysis_id} every 1-2s to see real state.
# Entries auto-expire ~10 minutes after completion to cap memory.
# ---------------------------------------------------------------------------
import threading as _threading
import uuid as _uuid

_ANALYSIS_PROGRESS: Dict[str, Dict[str, Any]] = {}
_ANALYSIS_PROGRESS_LOCK = _threading.Lock()


# Canonical step list — frontend renders checkmarks against this exact order.
ANALYZE_STEPS: List[Dict[str, str]] = [
    {"id": "ssh_connect",        "label": "Connecting to server"},
    {"id": "discover_files",     "label": "Mapping project structure"},
    {"id": "collect_source",     "label": "Reading source code"},
    {"id": "llm_map",            "label": "Analyzing code in parallel (deep scan)"},
    {"id": "llm_reduce",         "label": "Synthesizing findings"},
    {"id": "render_formats",     "label": "Compiling comprehensive report"},
]


def _new_analysis_progress(project_name: str) -> str:
    """Create a progress record and return its analysis_id."""
    analysis_id = _uuid.uuid4().hex[:16]
    with _ANALYSIS_PROGRESS_LOCK:
        _ANALYSIS_PROGRESS[analysis_id] = {
            "analysis_id": analysis_id,
            "project_name": project_name,
            "status": "running",
            "current_step_id": ANALYZE_STEPS[0]["id"],
            "current_step_label": ANALYZE_STEPS[0]["label"],
            "current_step_index": 0,
            "total_steps": len(ANALYZE_STEPS),
            "steps": [{**s, "status": "pending"} for s in ANALYZE_STEPS],
            "percent": 0,
            "detail": "",           # free-form detail (e.g. "chunk 5/10")
            "error": None,
            "started_at": time.time(),
            "completed_at": None,
        }
    return analysis_id


def _update_analysis_step(
    analysis_id: Optional[str],
    step_id: str,
    status_: str = "running",   # pending | running | done | failed
    detail: str = "",
) -> None:
    """Flip one step's status. Called by the analyze handler at stage boundaries."""
    if not analysis_id:
        return
    with _ANALYSIS_PROGRESS_LOCK:
        rec = _ANALYSIS_PROGRESS.get(analysis_id)
        if not rec:
            return
        for i, s in enumerate(rec["steps"]):
            if s["id"] == step_id:
                s["status"] = status_
                if status_ == "running":
                    rec["current_step_id"] = step_id
                    rec["current_step_label"] = s["label"]
                    rec["current_step_index"] = i
                    # Mark prior steps done
                    for prev in rec["steps"][:i]:
                        if prev["status"] == "pending":
                            prev["status"] = "done"
                break
        if detail:
            rec["detail"] = detail
        # Compute percent: done = full weight, running = half, pending = 0
        done_count = sum(1 for s in rec["steps"] if s["status"] == "done")
        running_count = sum(1 for s in rec["steps"] if s["status"] == "running")
        total = max(1, len(rec["steps"]))
        rec["percent"] = int(((done_count + 0.5 * running_count) / total) * 100)
        if status_ == "failed":
            rec["status"] = "failed"


def _finish_analysis_progress(analysis_id: Optional[str], error: Optional[str] = None) -> None:
    if not analysis_id:
        return
    with _ANALYSIS_PROGRESS_LOCK:
        rec = _ANALYSIS_PROGRESS.get(analysis_id)
        if not rec:
            return
        rec["completed_at"] = time.time()
        if error:
            rec["status"] = "failed"
            rec["error"] = error
        else:
            rec["status"] = "completed"
            for s in rec["steps"]:
                if s["status"] != "failed":
                    s["status"] = "done"
            rec["percent"] = 100


def _cleanup_stale_analysis_progress(max_age_sec: int = 600) -> None:
    """Drop records older than max_age_sec since completion. Called opportunistically."""
    now = time.time()
    with _ANALYSIS_PROGRESS_LOCK:
        drop = [
            aid for aid, rec in _ANALYSIS_PROGRESS.items()
            if rec.get("completed_at") and now - rec["completed_at"] > max_age_sec
        ]
        for aid in drop:
            _ANALYSIS_PROGRESS.pop(aid, None)


@router.get(
    "/scan/progress/{analysis_id}",
    response_model=dict,
    tags=["Step 2 — Analyze (pick one mode)"],
    summary="Poll live progress for an in-flight analyze-project run",
)
async def get_analyze_progress(
    analysis_id: str,
    current_user: User = Depends(get_current_active_user),
):
    """Returns the live progress record for an analysis run. Frontend polls every 1-2s
    while the analyze endpoint is still executing; stops polling once status=='completed'
    or 'failed'. Records are kept for 10 minutes after completion then garbage-collected."""
    _cleanup_stale_analysis_progress()
    with _ANALYSIS_PROGRESS_LOCK:
        rec = _ANALYSIS_PROGRESS.get(analysis_id)
        if not rec:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No progress record for analysis_id={analysis_id}. It may have been garbage-collected.",
            )
        return dict(rec)  # copy so caller can't mutate our state


@router.post("/projects", response_model=dict, tags=["Step 1 — Onboarding & Project Setup"])
async def create_project(
    request: ProjectCreateRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Create a new project
    
    This endpoint creates and saves a project in the database.
    Projects are required before running scans and appear in project stats/recent lists.
    """
    try:
        user_id = str(current_user.id)
        
        project_key = request.project_name.strip() if request.project_name else request.project_name
        
        # Validate enum values
        conversion_env = ConversionEnvironment(request.conversion_environment) if request.conversion_environment else ConversionEnvironment.ON_PREMISES_SERVER
        code_source = CodeSourceType(request.code_source_type) if request.code_source_type else CodeSourceType.EXISTS_ON_SERVER
        llm_opt = LLMOption(request.llm_option) if request.llm_option else LLMOption.MIRAAI_HOSTED
        industry_val = Industry(request.industry) if request.industry else Industry.TECHNOLOGY
        traffic_val = MonthlyTraffic(request.monthly_traffic) if request.monthly_traffic else None
        
        # Conditional validation based on code_source_type
        if code_source == CodeSourceType.NEEDS_UPLOAD:
            # Git clone flow: git_repo_url is required, additional_files are allowed
            if not request.git_repo_url:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="git_repo_url is required when code_source_type is 'needs_upload'"
                )
        else:
            # Code exists on server: no git fields or additional files needed
            # Clear any accidentally sent git/upload fields
            pass
        
        # Check if project with same name already exists for this user
        existing_project = await UserProject.find_one(
            UserProject.user_id == user_id,
            UserProject.project_name == request.project_name
        )
        
        if existing_project:
            # Update existing project
            existing_project.project_key = project_key
            existing_project.organization_name = request.organization_name or existing_project.organization_name
            existing_project.project_description = request.project_description or existing_project.project_description
            existing_project.vm_code_path = request.source_path or existing_project.vm_code_path
            existing_project.project_type = ProjectType(request.project_type) if request.project_type else existing_project.project_type
            existing_project.legacy_technology = request.legacy_technology or existing_project.legacy_technology
            existing_project.frameworks = request.frameworks or existing_project.frameworks
            existing_project.industry = industry_val
            existing_project.deployment_regions = request.deployment_regions or existing_project.deployment_regions
            existing_project.monthly_traffic = traffic_val
            existing_project.peak_concurrent_users = request.peak_concurrent_users
            existing_project.conversion_environment = conversion_env
            existing_project.code_source_type = code_source
            existing_project.llm_option = llm_opt
            
            # Git/upload fields only apply when needs_upload
            if code_source == CodeSourceType.NEEDS_UPLOAD:
                existing_project.git_repo_url = request.git_repo_url or existing_project.git_repo_url
                existing_project.git_access_token = request.git_access_token or existing_project.git_access_token
                existing_project.additional_files = request.additional_files or existing_project.additional_files
            else:
                existing_project.git_repo_url = None
                existing_project.git_access_token = None
                existing_project.additional_files = []
            
            existing_project.updated_at = datetime.utcnow()
            await existing_project.save()
            
            return {
                "success": True,
                "message": "Project updated successfully",
                "project": {
                    "id": str(existing_project.id),
                    "project_key": existing_project.project_key,
                    "project_name": existing_project.project_name,
                    "organization_name": existing_project.organization_name,
                    "project_description": existing_project.project_description,
                    "source_path": existing_project.vm_code_path,
                    "project_type": existing_project.project_type.value,
                    "legacy_technology": existing_project.legacy_technology,
                    "frameworks": existing_project.frameworks,
                    "industry": existing_project.industry.value,
                    "deployment_regions": existing_project.deployment_regions,
                    "monthly_traffic": existing_project.monthly_traffic.value if existing_project.monthly_traffic else None,
                    "peak_concurrent_users": existing_project.peak_concurrent_users,
                    "conversion_environment": existing_project.conversion_environment.value,
                    "code_source_type": existing_project.code_source_type.value,
                    "git_repo_url": existing_project.git_repo_url,
                    "additional_files": existing_project.additional_files,
                    "llm_option": existing_project.llm_option.value,
                    "created_at": existing_project.created_at.isoformat() if existing_project.created_at else None,
                    "updated_at": existing_project.updated_at.isoformat() if existing_project.updated_at else None
                }
            }
        
        # Build git/upload fields based on code_source_type
        git_url = request.git_repo_url if code_source == CodeSourceType.NEEDS_UPLOAD else None
        git_token = request.git_access_token if code_source == CodeSourceType.NEEDS_UPLOAD else None
        add_files = request.additional_files if code_source == CodeSourceType.NEEDS_UPLOAD else []
        
        # Create new project
        project = UserProject(
            user_id=user_id,
            project_key=project_key,
            project_name=request.project_name,
            organization_name=request.organization_name or "My Organization",
            project_description=request.project_description,
            project_type=ProjectType(request.project_type) if request.project_type else ProjectType.WEB,
            legacy_technology=request.legacy_technology or [],
            frameworks=request.frameworks or [],
            industry=industry_val,
            deployment_regions=request.deployment_regions or [],
            monthly_traffic=traffic_val,
            peak_concurrent_users=request.peak_concurrent_users,
            vm_code_path=request.source_path,
            conversion_environment=conversion_env,
            code_source_type=code_source,
            git_repo_url=git_url,
            git_access_token=git_token,
            additional_files=add_files or [],
            llm_option=llm_opt
        )
        
        await project.insert()
        
        logger.info(f"Created project '{request.project_name}' (key: {project_key}) for user {user_id}")
        
        return {
            "success": True,
            "message": "Project created successfully",
            "project": {
                "id": str(project.id),
                "project_key": project.project_key,
                "project_name": project.project_name,
                "organization_name": project.organization_name,
                "project_description": project.project_description,
                "source_path": project.vm_code_path,
                "project_type": project.project_type.value,
                "legacy_technology": project.legacy_technology,
                "frameworks": project.frameworks,
                "industry": project.industry.value,
                "deployment_regions": project.deployment_regions,
                "monthly_traffic": project.monthly_traffic.value if project.monthly_traffic else None,
                "peak_concurrent_users": project.peak_concurrent_users,
                "conversion_environment": project.conversion_environment.value,
                "code_source_type": project.code_source_type.value,
                "git_repo_url": project.git_repo_url,
                "additional_files": project.additional_files,
                "llm_option": project.llm_option.value,
                "created_at": project.created_at.isoformat() if project.created_at else None
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to create project: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create project: {str(e)}"
        )


@router.put("/projects/{project_id}", response_model=dict, tags=["Step 1 — Onboarding & Project Setup"])
async def update_project(
    project_id: str,
    request: ProjectUpdateRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Update an existing project
    
    This endpoint updates a project's details. Only provided fields are updated;
    omitted fields remain unchanged. The project must belong to the current user.
    """
    try:
        user_id = str(current_user.id)
        
        # Validate project_id format
        try:
            obj_id = PydanticObjectId(project_id)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid project ID format"
            )
        
        # Find the project and verify ownership
        project = await UserProject.find_one(
            UserProject.id == obj_id,
            UserProject.user_id == user_id
        )
        
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found or you don't have permission to update it"
            )
        
        # Apply updates only for provided (non-None) fields
        if request.project_name is not None:
            project.project_name = request.project_name
            project.project_key = request.project_name.strip() if request.project_name else request.project_name
        if request.organization_name is not None:
            project.organization_name = request.organization_name
        if request.project_description is not None:
            project.project_description = request.project_description
        if request.source_path is not None:
            project.vm_code_path = request.source_path
        if request.project_type is not None:
            project.project_type = ProjectType(request.project_type)
        if request.legacy_technology is not None:
            project.legacy_technology = request.legacy_technology
        if request.frameworks is not None:
            project.frameworks = request.frameworks
        if request.industry is not None:
            project.industry = Industry(request.industry)
        if request.deployment_regions is not None:
            project.deployment_regions = request.deployment_regions
        if request.monthly_traffic is not None:
            project.monthly_traffic = MonthlyTraffic(request.monthly_traffic)
        if request.peak_concurrent_users is not None:
            project.peak_concurrent_users = request.peak_concurrent_users
        if request.conversion_environment is not None:
            project.conversion_environment = ConversionEnvironment(request.conversion_environment)
        if request.code_source_type is not None:
            project.code_source_type = CodeSourceType(request.code_source_type)
        if request.llm_option is not None:
            project.llm_option = LLMOption(request.llm_option)
        
        # Git/upload fields
        if request.git_repo_url is not None:
            project.git_repo_url = request.git_repo_url
        if request.git_access_token is not None:
            project.git_access_token = request.git_access_token
        if request.additional_files is not None:
            project.additional_files = request.additional_files
        
        project.updated_at = datetime.utcnow()
        await project.save()
        
        logger.info(f"Updated project '{project.project_name}' (id: {project_id}) for user {user_id}")
        
        return {
            "success": True,
            "message": "Project updated successfully",
            "project": {
                "id": str(project.id),
                "project_key": project.project_key,
                "project_name": project.project_name,
                "organization_name": project.organization_name,
                "project_description": project.project_description,
                "source_path": project.vm_code_path,
                "project_type": project.project_type.value,
                "legacy_technology": project.legacy_technology,
                "frameworks": project.frameworks,
                "industry": project.industry.value,
                "deployment_regions": project.deployment_regions,
                "monthly_traffic": project.monthly_traffic.value if project.monthly_traffic else None,
                "peak_concurrent_users": project.peak_concurrent_users,
                "conversion_environment": project.conversion_environment.value,
                "code_source_type": project.code_source_type.value,
                "git_repo_url": project.git_repo_url,
                "additional_files": project.additional_files,
                "llm_option": project.llm_option.value,
                "created_at": project.created_at.isoformat() if project.created_at else None,
                "updated_at": project.updated_at.isoformat() if project.updated_at else None
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update project: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update project: {str(e)}"
        )


@router.delete("/projects/{project_id}", response_model=dict, tags=["Step 1 — Onboarding & Project Setup"])
async def delete_project(
    project_id: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    Delete a project and all its associated reports
    
    This endpoint permanently deletes a project and all its associated
    analysis reports. The project must belong to the current user.
    """
    try:
        user_id = str(current_user.id)
        
        # Validate project_id format
        try:
            obj_id = PydanticObjectId(project_id)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid project ID format"
            )
        
        # Find the project and verify ownership
        project = await UserProject.find_one(
            UserProject.id == obj_id,
            UserProject.user_id == user_id
        )
        
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found or you don't have permission to delete it"
            )
        
        project_name = project.project_name
        
        # Delete all associated analysis reports
        deleted_reports = await AnalysisReport.find(
            AnalysisReport.project_id == project_id
        ).delete()
        
        reports_deleted_count = deleted_reports.deleted_count if deleted_reports else 0
        
        # Delete the project itself
        await project.delete()
        
        logger.info(
            f"Deleted project '{project_name}' (id: {project_id}) and "
            f"{reports_deleted_count} associated report(s) for user {user_id}"
        )
        
        return {
            "success": True,
            "message": f"Project '{project_name}' deleted successfully",
            "deleted_project_id": project_id,
            "deleted_reports_count": reports_deleted_count
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete project: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete project: {str(e)}"
        )


@router.post(
    "/scan",
    response_model=dict,
    tags=["Step 2 — Analyze (pick one mode)"],
    summary="[Mode B] SonarQube Scan + LLM Enhancement",
    include_in_schema=True,
)
async def analyze_code_workflow(
    request: CodeAnalysisRequest,
    current_user: User = Depends(get_current_active_user),
    use_llm: bool = True,
):
    """
    **SonarQube Scan + LLM Enhancement**
    
    Runs SonarQube scan on your code, then enhances the report with AI analysis.
    
    **Workflow:** SSH → SonarQube scan → Fetch report → **LLM analysis** → Return enhanced report (HTML, PDF, DOCX)
    
    **Request body:** project_name (required), report_types, exclusions, etc. Response includes md_preview for frontend.
    
    **Before use:** Test SSH via POST /api/v1/analyze/test/ssh
    """
    start_time = time.time()
    ssh_conn = None
    
    try:
        # Step 0.1: SSH — request body overrides JWT account (for service / admin token + customer VM)
        sc_body = request.ssh_credentials
        if sc_body:
            if not sc_body.hostname or not sc_body.username:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="ssh_credentials must include hostname and username.",
                )
            ssh_hostname = sc_body.hostname
            ssh_port = sc_body.port or 22
            ssh_username = sc_body.username
            # Treat empty strings as None for password and keys
            password = sc_body.password.strip() if sc_body.password and sc_body.password.strip() else None
            private_key = sc_body.private_key.strip() if sc_body.private_key and sc_body.private_key.strip() else None
            private_key_password = sc_body.private_key_password.strip() if sc_body.private_key_password and sc_body.private_key_password.strip() else None
        elif current_user.ssh_hostname and current_user.ssh_username:
            ssh_hostname = current_user.ssh_hostname
            ssh_port = current_user.ssh_port or 22
            ssh_username = current_user.ssh_username
            
            # Decrypt saved credentials
            password = None
            private_key = None
            private_key_password = None
            
            if current_user.ssh_password_encrypted:
                decrypted_pwd = decrypt_data(current_user.ssh_password_encrypted)
                if not decrypted_pwd:
                    logger.warning("Failed to decrypt SSH password from database")
                else:
                    password = decrypted_pwd
            
            if current_user.ssh_private_key_encrypted:
                decrypted_key = decrypt_data(current_user.ssh_private_key_encrypted)
                if not decrypted_key:
                    logger.warning("Failed to decrypt SSH private key from database")
                else:
                    private_key = decrypted_key
            
            if current_user.ssh_private_key_password_encrypted:
                decrypted_key_pwd = decrypt_data(current_user.ssh_private_key_password_encrypted)
                if not decrypted_key_pwd:
                    logger.warning("Failed to decrypt SSH private key password from database")
                else:
                    private_key_password = decrypted_key_pwd
            
            if not password and not private_key:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Failed to retrieve SSH credentials from database. Please re-add your SSH credentials via POST /api/v1/ssh/credentials"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No SSH credentials: pass ssh_credentials in the request body or save SSH via /api/v1/analyze/test/ssh on the logged-in account.",
            )

        request_path = (request.source_path or "").strip()
        saved_base = (current_user.ssh_source_path or "").strip().rstrip("/")
        project_name_clean = (request.project_name or "").strip()

        # Prefer per-project vm_code_path stored on UserProject; request.source_path
        # overrides (explicit input wins), then fall back to deriving from saved base.
        stored_project_path = None
        if project_name_clean:
            existing_up = await UserProject.find_one(
                UserProject.user_id == str(current_user.id),
                UserProject.project_name == project_name_clean
            )
            if existing_up and existing_up.vm_code_path:
                stored_project_path = existing_up.vm_code_path.strip().rstrip("/")

        if not request_path and not stored_project_path and not saved_base:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    "No source path configured. Save your SSH credentials first via "
                    "POST /api/v1/analyze/test/ssh — that saves your project base path automatically."
                ),
            )

        # Resolution order: explicit request path > stored per-project path > derive from saved base
        if request_path:
            source_path = request_path
            path_source = "request.source_path"
        elif stored_project_path:
            source_path = stored_project_path
            path_source = "UserProject.vm_code_path"
        else:
            from pathlib import Path as _Path
            if project_name_clean and _Path(saved_base).name != project_name_clean:
                source_path = f"{saved_base}/{project_name_clean}"
            else:
                source_path = saved_base
            path_source = "user.ssh_source_path (derived)"

        project_key = project_name_clean or source_path.rstrip("/").split("/")[-1]
        logger.info(f"Resolved source_path={source_path} for project={project_key} (from {path_source})")
        
        # Get SonarQube configuration (request body > settings > env)
        import os
        sonar_token = (request.sonar_token or getattr(settings, 'SONAR_TOKEN', None) or os.environ.get('SONAR_TOKEN') or '').strip()
        if not sonar_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SonarQube token is required. Set SONAR_TOKEN in .env or pass sonar_token in the request body."
            )
        sonar_host_url = (request.sonar_host_url or getattr(settings, 'SONAR_HOST_URL', None) or os.environ.get('SONAR_HOST_URL') or 'https://sonarqube.codsy.ai').strip()
        
        logger.info(f"Starting code analysis workflow for project: {project_key}")
        
        # Step 0.3: Create or update project in database
        user_id = str(current_user.id)
        try:
            existing_project = await UserProject.find_one(
                UserProject.user_id == user_id,
                UserProject.project_name == request.project_name
            )
            
            if existing_project:
                # Update existing project with latest info
                existing_project.project_key = project_key
                existing_project.last_sonar_project_key = project_key
                existing_project.vm_code_path = source_path
                existing_project.updated_at = datetime.utcnow()
                await existing_project.save()
                logger.info(f"Updated project '{request.project_name}' in database")
            else:
                # Create new project
                project = UserProject(
                    user_id=user_id,
                    project_key=project_key,
                    last_sonar_project_key=project_key,
                    project_name=request.project_name,
                    organization_name="My Organization",
                    project_description=f"Code analysis project: {request.project_name}",
                    vm_code_path=source_path,
                    project_type=ProjectType.WEB,
                    industry=Industry.TECHNOLOGY
                )
                await project.insert()
                logger.info(f"Created project '{request.project_name}' during scan workflow")
        except Exception as e:
            logger.warning(f"Failed to save project to database: {e}, continuing with scan...")
        
        # Step 1: Connect via SSH
        logger.info("Step 1: Connecting to SSH server...")
        ssh_conn = SSHService.create_connection(
            hostname=ssh_hostname,
            port=ssh_port,
            username=ssh_username,
            password=password,
            private_key=private_key,
            private_key_password=private_key_password
        )
        
        if not ssh_conn.connect():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to connect to SSH server {ssh_hostname}:{ssh_port}. Please re-test your SSH connection."
            )
        
        logger.info("SSH connection established")
        
        # Step 2: Gather file/directory structure from source path
        logger.info("Step 2: Gathering file/directory structure...")
        file_structure = gather_file_structure(ssh_conn, source_path)
        logger.info(f"File structure gathered ({len(file_structure)} chars)")
        
        # Step 3: Run SonarQube scanner
        logger.info("Step 3: Running SonarQube scanner...")
        scanner = RemoteSonarScanner(
            ssh_conn=ssh_conn,
            sonar_token=sonar_token,
            sonar_host_url=sonar_host_url
        )
        
        scan_result = scanner.scan(
            project_key=project_key,
            project_name=request.project_name,
            source_path=source_path,
            exclusions=request.exclusions,
            prefer_docker=request.prefer_docker,
            auto_install=request.auto_install
        )
        
        if not scan_result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Scan failed: {scan_result.get('error', 'Unknown error')}"
            )
        
        logger.info("SonarQube scan completed successfully")
        
        # Step 4: Wait a bit for SonarQube to process results
        logger.info("Step 4: Waiting for SonarQube to process results...")
        time.sleep(10)  # Give SonarQube time to process initial indexing

        # Step 5: Fetch report from SonarQube, retrying if measures/issues are not
        # yet indexed. SonarQube finishes the scan upload before it finishes
        # computing measures; fetching too early yields an empty report that
        # downstream formatters render as a near-empty document.
        logger.info("Step 5: Fetching report from SonarQube server...")
        fetcher = SonarQubeReportFetcher(
            sonar_host_url=sonar_host_url,
            sonar_token=sonar_token
        )

        report = None
        for attempt in range(1, 6):
            report = fetcher.get_full_report(project_key)
            if not report.get("success"):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to fetch report: {report.get('error', 'Unknown error')}"
                )
            measures_ok = bool(report.get("measures"))
            issues_total = report.get("issues", {}).get("total", 0)
            if measures_ok or issues_total > 0 or attempt == 5:
                if attempt > 1:
                    logger.info(f"SonarQube report ready on attempt {attempt}")
                break
            logger.info(f"SonarQube report not yet indexed (attempt {attempt}/5) — waiting 6s...")
            time.sleep(6)

        logger.info("Report fetched successfully")
        
        # Step 6: Validate and resolve report_types (use_llm passed from endpoint)
        # Both modes honor the user's selected report_types so that picking multiple
        # compliance frameworks (e.g. generic_security + owasp_top_10) produces one
        # report per framework per format, even when use_llm=False.
        valid_report_types = list(REPORT_GENERATORS.keys())
        requested_types = request.report_types or ["generic_security"]
        invalid_types = [rt for rt in requested_types if rt not in valid_report_types]
        if invalid_types:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid report types: {invalid_types}. Valid types: {valid_report_types}"
            )
        if not use_llm:
            logger.info("Step 6: Using original SonarQube report only (no LLM enhancement)")
        
        project_info = {
            "project_key": project_key,
            "project_name": request.project_name,
            "source_path": source_path,
        }
        
        # Step 7: Generate reports (LLM-enhanced or original SonarQube only)
        enhancement_type = "llm_enhanced" if use_llm else "original"
        logger.info(f"Step 7: Generating {len(requested_types)} report(s): {requested_types} (enhancement_type={enhancement_type})")
        generated_reports = {}
        
        # Find or create the project for linking reports
        project_doc = await UserProject.find_one(
            UserProject.user_id == user_id,
            UserProject.project_name == request.project_name
        )
        project_id = str(project_doc.id) if project_doc else "unknown"
        
        for report_type in requested_types:
            logger.info(f"  Generating report: {REPORT_TYPE_LABELS.get(report_type, report_type)}")
            if use_llm:
                generator = REPORT_GENERATORS[report_type]
                report_content = generator(report, file_structure, project_info)
                # If the LLM call failed or produced error stub, fall back to a
                # SonarQube-only report framed for this report_type so users
                # still get a usable document instead of a 2-line error page.
                if isinstance(report_content, dict) and report_content.get("error"):
                    logger.warning(
                        f"  LLM generator for {report_type} returned an error "
                        f"({report_content.get('error')}); falling back to SonarQube-only report."
                    )
                    report_content = build_report_from_sonarqube_only(report, project_info, report_type)
                    report_content["llm_fallback"] = True
            else:
                report_content = build_report_from_sonarqube_only(report, project_info, report_type)
            
            report_label = REPORT_TYPE_LABELS.get(report_type, report_type)
            generated_reports[report_type] = {
                "report_type": report_type,
                "report_label": report_label,
                "content": report_content,
                "generated_at": datetime.utcnow().isoformat(),
                "formats": {},
                "md_preview": None,
            }
            
            # Generate Markdown (preview in response + save for download)
            md_path = None
            try:
                md_content = generate_markdown_report(
                    report_type=report_type,
                    report_label=report_label,
                    report_content=report_content,
                    project_info=project_info,
                    sonar_report=report
                )
                generated_reports[report_type]["md_preview"] = md_content
                # Save MD file for download — include microseconds + short uuid to
                # match the other formats and prevent collisions when several
                # report types are generated in quick succession.
                import uuid as _uuid
                timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S_%f')[:21]
                md_uid = _uuid.uuid4().hex[:6]
                project_key = project_info.get('project_key', 'unknown')
                md_filename = f"{project_key}_{report_type}_{timestamp}_{md_uid}.md"
                md_path = os.path.join(REPORTS_DIR, md_filename)
                with open(md_path, 'w', encoding='utf-8') as f:
                    f.write(md_content)
                md_path = os.path.abspath(md_path)
                generated_reports[report_type]["formats"]["md"] = {"file": md_path, "filename": md_filename}
            except Exception as md_err:
                logger.warning(f"  Failed to generate MD for {report_type}: {md_err}")
            
            # Generate all supported formats by default
            requested_formats = ["html", "pdf", "docx"]
            
            # 1. Generate HTML (always needed for PDF, or if requested)
            html_path = None
            if "html" in requested_formats or "pdf" in requested_formats:
                try:
                    html_path = generate_html_report(
                        report_type=report_type,
                        report_label=report_label,
                        report_content=report_content,
                        project_info=project_info,
                        sonar_report=report
                    )
                    if "html" in requested_formats:
                        generated_reports[report_type]["formats"]["html"] = {
                            "file": html_path,
                            "filename": os.path.basename(html_path)
                        }
                except Exception as html_err:
                    logger.warning(f"  Failed to generate HTML for {report_type}: {html_err}")

            # 2. Generate PDF
            if "pdf" in requested_formats:
                try:
                    pdf_path = generate_pdf_report(
                        report_type=report_type,
                        report_label=report_label,
                        report_content=report_content,
                        project_info=project_info,
                        sonar_report=report
                    )
                    if pdf_path:
                        generated_reports[report_type]["formats"]["pdf"] = {
                            "file": pdf_path,
                            "filename": os.path.basename(pdf_path)
                        }
                except Exception as pdf_err:
                    logger.warning(f"  Failed to generate PDF for {report_type}: {pdf_err}")

            # 3. Generate DOCX
            if "docx" in requested_formats:
                try:
                    docx_path = generate_docx_report(
                        report_type=report_type,
                        report_label=report_label,
                        report_content=report_content,
                        project_info=project_info,
                        sonar_report=report
                    )
                    if docx_path:
                        generated_reports[report_type]["formats"]["docx"] = {
                            "file": docx_path,
                            "filename": os.path.basename(docx_path)
                        }
                except Exception as docx_err:
                    logger.warning(f"  Failed to generate DOCX for {report_type}: {docx_err}")

            # Backward compatibility fields (keeping html_file if it exists)
            if "html" in generated_reports[report_type]["formats"]:
                generated_reports[report_type]["html_file"] = generated_reports[report_type]["formats"]["html"]["file"]
                generated_reports[report_type]["html_filename"] = generated_reports[report_type]["formats"]["html"]["filename"]
            
            # Save each report to MongoDB
            try:
                # Helper to ensure list items are dicts (AnalysisReport expects List[Dict])
                def _to_dict_list(items):
                    if not isinstance(items, list):
                        return []
                    return [item if isinstance(item, dict) else {"description": item} for item in items]

                rc = report_content if isinstance(report_content, dict) else {}
                
                # We store all generated report file paths in the DB
                html_path = generated_reports[report_type]["formats"].get("html", {}).get("file")
                pdf_path = generated_reports[report_type]["formats"].get("pdf", {}).get("file")
                docx_path = generated_reports[report_type]["formats"].get("docx", {}).get("file")
                md_path = generated_reports[report_type]["formats"].get("md", {}).get("file")

                analysis_report = AnalysisReport(
                    project_id=project_id,
                    report_type=report_type,
                    enhancement_type=enhancement_type,
                    summary=rc.get("executive_summary", ""),
                    security_issues=_to_dict_list(rc.get("critical_findings", rc.get("critical_vulnerabilities", []))),
                    compliance_violations=_to_dict_list(rc.get("non_conformities", rc.get("high_risk_areas", []))),
                    owasp_findings=_to_dict_list(rc.get("owasp_categories", [])),
                    recommendations=_to_dict_list(rc.get("recommendations_summary", rc.get("remediation_plan", rc.get("remediation_priority", [])))),
                    total_issues=report.get("issues", {}).get("total", 0),
                    critical_issues=rc.get("security_score", rc.get("owasp_score", rc.get("compliance_score", rc.get("maturity_score", 0)))),
                    files_analyzed=len(file_structure.split('\n')) if file_structure else 0,
                    report_file_local=html_path,
                    report_file_pdf=pdf_path,
                    report_file_docx=docx_path,
                    report_file_md=md_path
                )
                await analysis_report.insert()
                generated_reports[report_type]["report_id"] = str(analysis_report.id)
                logger.info(f"  Saved {report_type} report to DB (id: {analysis_report.id})")
            except Exception as db_err:
                logger.warning(f"  Failed to save {report_type} report to DB: {db_err}")
        
        # Step 8: Run legacy LLM enhancement only when use_llm=True
        if use_llm:
            logger.info("Step 8: Running legacy LLM enhancement...")
            llm_enhancement = enhance_report_with_llm(report)
        else:
            llm_enhancement = {}
        
        # Combine everything
        enhanced_report = {
            **report,
            **llm_enhancement,
            "security_reports": generated_reports,
            "report_types_generated": list(generated_reports.keys()),
            "file_structure_summary": {
                "source_path": source_path,
                "total_entries": len(file_structure.split('\n')) if file_structure else 0,
                "preview": file_structure[:1000] if file_structure else "",
            },
            "workflow_metadata": {
                "project_key": project_key,
                "project_name": request.project_name,
                "source_path": source_path,
                "report_types_requested": requested_types,
                "analysis_date": datetime.utcnow().isoformat(),
                "total_time_seconds": round(time.time() - start_time, 2)
            }
        }
        
        logger.info(f"Code analysis workflow completed in {time.time() - start_time:.2f} seconds")
        
        return {
            "success": True,
            "message": f"Code analysis completed with {len(generated_reports)} report(s) generated",
            "report_types_generated": list(generated_reports.keys()),
            "report": enhanced_report
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Code analysis workflow failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Workflow failed: {str(e)}"
        )
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


@router.post(
    "/scan/analyse-project",
    response_model=dict,
    tags=["Step 2 — Analyze (pick one mode)"],
    summary="[Mode C] Analyse Project — LLM Only (No SonarQube)",
    include_in_schema=True,
)
async def analyse_project_workflow(
    request: ProjectAnalysisRequest,
    current_user: User = Depends(get_current_active_user),
    analysis_id: Optional[str] = Query(
        default=None,
        description="Client-generated progress ID. If provided, the UI can start polling "
                    "GET /scan/progress/{analysis_id} the moment the POST is dispatched. "
                    "If omitted, a server-side ID is generated and returned in the final response.",
    ),
):
    """
    **Standalone Project Analysis — No SonarQube**

    Connects via saved SSH credentials, gathers the file structure,
    and generates a comprehensive 10-section codebase analysis report
    using AI. No SonarQube scan is involved.

    **Sections:** Directory Structure, Entry Points, External Interfaces,
    Architectural Styles, Design Patterns, Anti-Patterns & Code Smells,
    Configuration & Environment, Modules & Components, Dependency Analysis,
    Execution Flow.

    **Before use:** Test SSH via POST /api/v1/analyze/test/ssh
    """
    start_time = time.time()
    ssh_conn = None
    # Prefer the client-provided analysis_id so the UI can poll immediately. If none
    # was provided, generate one server-side and return it in the final response.
    if analysis_id:
        with _ANALYSIS_PROGRESS_LOCK:
            _ANALYSIS_PROGRESS[analysis_id] = {
                "analysis_id": analysis_id,
                "project_name": request.project_name or "unknown",
                "status": "running",
                "current_step_id": ANALYZE_STEPS[0]["id"],
                "current_step_label": ANALYZE_STEPS[0]["label"],
                "current_step_index": 0,
                "total_steps": len(ANALYZE_STEPS),
                "steps": [{**s, "status": "pending"} for s in ANALYZE_STEPS],
                "percent": 0,
                "detail": "",
                "error": None,
                "started_at": time.time(),
                "completed_at": None,
            }
    else:
        analysis_id = _new_analysis_progress(request.project_name or "unknown")

    try:
        # Step 1: Check for saved SSH credentials
        if not current_user.ssh_hostname or not current_user.ssh_username:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No saved SSH credentials found. Please test your SSH connection first via /api/v1/analyze/test/ssh to build the connection."
            )

        # Decrypt credentials
        password = decrypt_data(current_user.ssh_password_encrypted) if current_user.ssh_password_encrypted else None
        private_key = decrypt_data(current_user.ssh_private_key_encrypted) if current_user.ssh_private_key_encrypted else None
        private_key_password = decrypt_data(current_user.ssh_private_key_password_encrypted) if current_user.ssh_private_key_password_encrypted else None

        project_key = request.project_name.strip() if request.project_name else request.project_name

        # Resolution order:
        #   1) UserProject.vm_code_path (per-project path set at project creation)
        #   2) user.ssh_source_path + '/' + project_name (derive when project row has no path)
        #   3) user.ssh_source_path alone (only if saved base already ends with project_name)
        user_project = await UserProject.find_one(
            UserProject.user_id == str(current_user.id),
            UserProject.project_name == project_key
        )
        stored_project_path = user_project.vm_code_path.strip().rstrip("/") if user_project and user_project.vm_code_path else None
        saved_base = (current_user.ssh_source_path or "").strip().rstrip("/")

        if stored_project_path:
            source_path = stored_project_path
            path_source = "UserProject.vm_code_path"
        elif saved_base and project_key:
            from pathlib import Path as _Path
            if _Path(saved_base).name == project_key:
                source_path = saved_base
                path_source = "user.ssh_source_path (base matches project)"
            else:
                source_path = f"{saved_base}/{project_key}"
                path_source = "derived from ssh_source_path + project_name"
        elif saved_base:
            source_path = saved_base
            path_source = "user.ssh_source_path (no project_name)"
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"No source path found for project '{project_key}'. Set vm_code_path on the project or test SSH to configure a default path."
            )

        # Persist the resolved path back to UserProject so future calls hit the fast path.
        if user_project and not user_project.vm_code_path:
            try:
                user_project.vm_code_path = source_path
                user_project.updated_at = datetime.utcnow()
                await user_project.save()
                logger.info(f"Backfilled vm_code_path={source_path} for project '{project_key}'")
            except Exception as save_err:
                logger.warning(f"Failed to backfill vm_code_path for '{project_key}': {save_err}")

        logger.info(
            f"Starting project analysis for: {project_key} | source_path={source_path} | resolved_from={path_source}"
        )

        # Step 2: SSH connect and gather file structure
        _update_analysis_step(analysis_id, "ssh_connect", "running")
        ssh_conn = SSHService.create_connection(
            hostname=current_user.ssh_hostname,
            port=current_user.ssh_port or 22,
            username=current_user.ssh_username,
            password=password,
            private_key=private_key,
            private_key_password=private_key_password
        )
        if not ssh_conn.connect():
            _update_analysis_step(analysis_id, "ssh_connect", "failed",
                                  f"Could not reach {current_user.ssh_hostname}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to connect to SSH server {current_user.ssh_hostname}:{current_user.ssh_port}. Please re-test your SSH connection."
            )
        _update_analysis_step(analysis_id, "ssh_connect", "done")
        logger.info("SSH connected — gathering file structure")

        _update_analysis_step(analysis_id, "discover_files", "running")
        file_structure = gather_file_structure(ssh_conn, source_path)
        entry_count = len(file_structure.split(chr(10)))
        logger.info(f"File structure gathered: {entry_count} entries")
        _update_analysis_step(analysis_id, "discover_files", "done",
                              f"{entry_count} paths discovered")

        # Step 2b: Read actual source code from key files
        _update_analysis_step(analysis_id, "collect_source", "running")
        logger.info("Reading source code files...")
        source_code = gather_source_code(ssh_conn, source_path, file_structure)
        logger.info(f"Source code collected: {len(source_code)} bytes")
        _update_analysis_step(
            analysis_id, "collect_source", "done",
            f"{len(source_code):,} bytes of source code collected"
        )

        ssh_conn.disconnect()
        ssh_conn = None

        # Step 3: Build project info and empty SonarQube report placeholder
        project_info = {
            "project_key": project_key,
            "project_name": request.project_name,
            "source_path": source_path,
        }
        # Empty report — no SonarQube data
        empty_report = {
            "measures": [],
            "issues": {"items": [], "total": 0},
            "quality_gate": {"status": "N/A"},
        }

        # Step 4: Generate the project analysis report via LLM (map-reduce)
        report_type = "project_analysis"
        report_label = REPORT_TYPE_LABELS.get(report_type, "Comprehensive Project Analysis")
        logger.info(f"Generating {report_label} via LLM...")
        _update_analysis_step(analysis_id, "llm_map", "running",
                              "Running map-reduce LLM analysis")

        report_content = generate_project_analysis_report(
            empty_report, file_structure, project_info, source_code=source_code
        )

        # Report metadata tells us how many chunks actually ran
        meta = (report_content or {}).get("_analysis_metadata", {}) if isinstance(report_content, dict) else {}
        chunks_total = meta.get("chunks_total", 0)
        chunks_ok = meta.get("chunks_analyzed", 0)
        chunks_failed = meta.get("chunks_failed", 0)
        _update_analysis_step(
            analysis_id, "llm_map", "done",
            f"{chunks_ok}/{chunks_total} chunks analyzed"
            + (f" ({chunks_failed} failed)" if chunks_failed else "")
        )
        _update_analysis_step(
            analysis_id, "llm_reduce", "done",
            f"Synthesized report from {meta.get('files_seen_in_findings', 0)} files"
        )

        # Step 5: Generate all output formats
        _update_analysis_step(analysis_id, "render_formats", "running")
        generated_report = {
            "report_type": report_type,
            "report_label": report_label,
            "content": report_content,
            "generated_at": datetime.utcnow().isoformat(),
            "formats": {},
            "md_preview": None,
        }

        # MD
        try:
            md_content = generate_markdown_report(
                report_type=report_type,
                report_label=report_label,
                report_content=report_content,
                project_info=project_info,
                sonar_report=empty_report
            )
            generated_report["md_preview"] = md_content
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            md_filename = f"{project_key}_{report_type}_{timestamp}.md"
            md_path = os.path.join(REPORTS_DIR, md_filename)
            with open(md_path, 'w', encoding='utf-8') as f:
                f.write(md_content)
            md_path = os.path.abspath(md_path)
            generated_report["formats"]["md"] = {"file": md_path, "filename": md_filename}
        except Exception as md_err:
            logger.warning(f"Failed to generate MD: {md_err}")

        # HTML
        try:
            html_path = generate_html_report(
                report_type=report_type,
                report_label=report_label,
                report_content=report_content,
                project_info=project_info,
                sonar_report=empty_report
            )
            generated_report["formats"]["html"] = {"file": html_path, "filename": os.path.basename(html_path)}
        except Exception as html_err:
            logger.warning(f"Failed to generate HTML: {html_err}")

        # PDF
        try:
            pdf_path = generate_pdf_report(
                report_type=report_type,
                report_label=report_label,
                report_content=report_content,
                project_info=project_info,
                sonar_report=empty_report
            )
            if pdf_path:
                generated_report["formats"]["pdf"] = {"file": pdf_path, "filename": os.path.basename(pdf_path)}
        except Exception as pdf_err:
            logger.warning(f"Failed to generate PDF: {pdf_err}")

        # DOCX
        try:
            docx_path = generate_docx_report(
                report_type=report_type,
                report_label=report_label,
                report_content=report_content,
                project_info=project_info,
                sonar_report=empty_report
            )
            if docx_path:
                generated_report["formats"]["docx"] = {"file": docx_path, "filename": os.path.basename(docx_path)}
        except Exception as docx_err:
            logger.warning(f"Failed to generate DOCX: {docx_err}")

        # Step 6: Save to DB
        user_id = str(current_user.id)
        try:
            project_doc = await UserProject.find_one(
                UserProject.user_id == user_id,
                UserProject.project_name == request.project_name
            )
            if not project_doc:
                # Auto-create a project for standalone analysis
                project_doc = UserProject(
                    user_id=user_id,
                    project_name=request.project_name,
                    organization_name="N/A",
                    project_key=project_key,
                    vm_code_path=source_path,
                )
                await project_doc.insert()
                logger.info(f"Auto-created project '{request.project_name}' for analysis")
            project_id = str(project_doc.id)

            def _to_dict_list(items):
                if not isinstance(items, list):
                    return []
                return [item if isinstance(item, dict) else {"description": item} for item in items]

            rc = report_content if isinstance(report_content, dict) else {}

            analysis_report = AnalysisReport(
                project_id=project_id,
                report_type=report_type,
                enhancement_type="llm_enhanced",
                summary=rc.get("executive_summary", ""),
                security_issues=_to_dict_list(rc.get("critical_findings", [])),
                compliance_violations=[],
                owasp_findings=[],
                recommendations=_to_dict_list(rc.get("recommendations_summary", [])),
                total_issues=0,
                critical_issues=rc.get("analysis_score", 0),
                files_analyzed=len(file_structure.split('\n')) if file_structure else 0,
                report_file_local=generated_report["formats"].get("html", {}).get("file"),
                report_file_pdf=generated_report["formats"].get("pdf", {}).get("file"),
                report_file_docx=generated_report["formats"].get("docx", {}).get("file"),
                report_file_md=generated_report["formats"].get("md", {}).get("file")
            )
            await analysis_report.insert()
            generated_report["report_id"] = str(analysis_report.id)
            logger.info(f"Saved project analysis report to DB (id: {analysis_report.id})")
        except Exception as db_err:
            logger.warning(f"Failed to save report to DB: {db_err}")

        _update_analysis_step(analysis_id, "render_formats", "done",
                              f"{len(generated_report.get('formats', {}))} format(s) rendered")
        _finish_analysis_progress(analysis_id)

        total_time = round(time.time() - start_time, 2)
        logger.info(f"Project analysis completed in {total_time}s")

        return {
            "success": True,
            "message": "Project analysis completed",
            "analysis_id": analysis_id,
            "report_id": generated_report.get("report_id"),
            "report_type": report_type,
            "report_label": report_label,
            "report": {
                "security_reports": {report_type: generated_report},
                "report_types_generated": [report_type],
                "file_structure_summary": {
                    "source_path": source_path,
                    "total_entries": len(file_structure.split('\n')) if file_structure else 0,
                    "preview": file_structure[:1000] if file_structure else "",
                },
                "workflow_metadata": {
                    "project_key": project_key,
                    "project_name": request.project_name,
                    "source_path": source_path,
                    "analysis_date": datetime.utcnow().isoformat(),
                    "total_time_seconds": total_time
                }
            }
        }

    except HTTPException as he:
        _finish_analysis_progress(analysis_id, error=str(he.detail))
        raise
    except Exception as e:
        _finish_analysis_progress(analysis_id, error=str(e))
        logger.error(f"Project analysis failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Project analysis failed: {str(e)}"
        )
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


@router.post("/scan/sonarqube", response_model=dict, tags=["Step 2 — Analyze (pick one mode)"], summary="[Mode A] SonarQube Scan Only (No LLM)")
async def analyze_code_workflow_original(
    request: CodeAnalysisRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    **SonarQube Scan Only — No LLM**

    Runs SonarQube scan and returns the raw report. No AI enhancement.

    **Workflow:** SSH → SonarQube scan → Fetch report → Return formatted report (HTML, PDF, DOCX). Response includes md_preview.
    """
    return await analyze_code_workflow(request, current_user, use_llm=False)


@router.post(
    "/scan/with-llm",
    response_model=dict,
    tags=["Step 2 — Analyze (pick one mode)"],
    summary="[Mode B alias] SonarQube Scan + LLM Enhancement",
    include_in_schema=True,
)
async def analyze_code_workflow_with_llm(
    request: CodeAnalysisRequest,
    current_user: User = Depends(get_current_active_user),
):
    """
    Alias for POST /scan with use_llm=True. Kept for frontend compatibility —
    the UI's "Generate AI-Enhanced Report" button targets this path.
    """
    return await analyze_code_workflow(request, current_user, use_llm=True)


@router.post("/test/ssh", response_model=dict, tags=["Step 1 — Onboarding & Project Setup"], summary="Test SSH connection and save credentials")
async def test_ssh_connection(
    request: SSHTestRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Test SSH connection and get directory structure
    
    This endpoint:
    1. Tests SSH connection with provided credentials
    2. Returns connection status (success/failure)
    3. Shows directory structure from the specified path (default: /)
    4. Provides server information
    
    Use this endpoint before starting the code analysis workflow to verify SSH access.
    """
    ssh_conn = None
    
    try:
        # Step 1: Test SSH connection
        logger.info(f"Testing SSH connection to {request.ssh_credentials.hostname}:{request.ssh_credentials.port}")
        
        ssh_conn = SSHService.create_connection(
            hostname=request.ssh_credentials.hostname,
            port=request.ssh_credentials.port,
            username=request.ssh_credentials.username,
            password=request.ssh_credentials.password,
            private_key=request.ssh_credentials.private_key,
            private_key_password=request.ssh_credentials.private_key_password
        )
        
        # Try to connect and capture detailed error information
        connection_success = False
        error_details = None
        error_type = None
        
        try:
            connection_success = ssh_conn.connect()
        except Exception as conn_error:
            connection_success = False
            error_details = str(conn_error)
            error_type = type(conn_error).__name__
            logger.error(f"SSH connection exception: {error_details}")
        
        if not connection_success:
            # Try to get more specific error information
            import socket
            import paramiko
            
            # Test if host is reachable
            host_reachable = False
            port_open = False
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                result = sock.connect_ex((request.ssh_credentials.hostname, request.ssh_credentials.port))
                sock.close()
                if result == 0:
                    port_open = True
                    host_reachable = True
                else:
                    host_reachable = False
                    port_open = False
            except Exception as e:
                logger.warning(f"Could not test host reachability: {e}")
            
            # Build detailed error message
            error_messages = []
            if not host_reachable:
                error_messages.append(f"Host {request.ssh_credentials.hostname} is not reachable or port {request.ssh_credentials.port} is closed")
            else:
                error_messages.append("Host is reachable but SSH connection failed")
            
            if error_details:
                error_messages.append(f"Error details: {error_details}")
            
            # Check authentication method
            auth_method = "none"
            if request.ssh_credentials.private_key:
                auth_method = "private_key"
            elif request.ssh_credentials.password:
                auth_method = "password"
            else:
                error_messages.append("No authentication method provided (password or private_key required)")
            
            return {
                "success": False,
                "connection_status": "failed",
                "message": f"Failed to connect to SSH server {request.ssh_credentials.hostname}:{request.ssh_credentials.port}",
                "error_details": {
                    "host_reachable": host_reachable,
                    "port_open": port_open,
                    "authentication_method": auth_method,
                    "error_type": error_type,
                    "error_message": error_details,
                    "troubleshooting": error_messages
                },
                "server_info": {
                    "hostname": request.ssh_credentials.hostname,
                    "port": request.ssh_credentials.port,
                    "username": request.ssh_credentials.username,
                    "connected": False
                },
                "directory_structure": None
            }
        
        logger.info("SSH connection successful")
        
        # Step 1.5: Save credentials and path to user account
        logger.info(f"Saving SSH credentials and source path for user {current_user.id}")
        current_user.ssh_hostname = request.ssh_credentials.hostname
        current_user.ssh_port = request.ssh_credentials.port
        current_user.ssh_username = request.ssh_credentials.username
        
        if request.ssh_credentials.password:
            current_user.ssh_password_encrypted = encrypt_data(request.ssh_credentials.password)
        
        if request.ssh_credentials.private_key:
            current_user.ssh_private_key_encrypted = encrypt_data(request.ssh_credentials.private_key)
            
        if request.ssh_credentials.private_key_password:
            current_user.ssh_private_key_password_encrypted = encrypt_data(request.ssh_credentials.private_key_password)
            
        current_user.ssh_source_path = request.source_path
        current_user.ssh_verified = True
        current_user.ssh_verified_at = datetime.utcnow()
        await current_user.save()
        logger.info("SSH credentials saved successfully")

        # Step 2: Get server information
        server_info_result = ssh_conn.execute_command("uname -a")
        server_info = server_info_result.get("stdout", "").strip() if server_info_result.get("success") else "Unknown"
        
        # Step 3: Get directory structure
        path = request.source_path
        directory_structure = None
        
        try:
            # List directory contents
            result = ssh_conn.execute_command(
                f"ls -la {path} 2>/dev/null | tail -n +2"
            )
            
            if result.get("success"):
                items = []
                lines = result["stdout"].strip().split('\n')
                for line in lines:
                    if line.strip():
                        parts = line.split()
                        if len(parts) >= 9:
                            item_type = "directory" if parts[0].startswith("d") else "file"
                            items.append({
                                "name": ' '.join(parts[8:]),
                                "type": item_type,
                                "permissions": parts[0],
                                "owner": parts[2],
                                "group": parts[3],
                                "size": parts[4],
                                "modified": f"{parts[5]} {parts[6]} {parts[7]}"
                            })
                
                directory_structure = {
                    "path": path,
                    "items": items,
                    "total_items": len(items),
                    "directories": [item for item in items if item["type"] == "directory"],
                    "files": [item for item in items if item["type"] == "file"]
                }
            else:
                directory_structure = {
                    "path": path,
                    "error": "Could not list directory contents",
                    "items": []
                }
        except Exception as e:
            logger.warning(f"Failed to get directory structure: {e}")
            directory_structure = {
                "path": path,
                "error": str(e),
                "items": []
            }
        
        # Step 4: Test basic commands
        test_commands = {
            "pwd": ssh_conn.execute_command("pwd"),
            "whoami": ssh_conn.execute_command("whoami"),
            "df": ssh_conn.execute_command("df -h / | tail -1")
        }
        
        return {
            "success": True,
            "connection_status": "success",
            "message": "SSH connection successful and credentials saved",
            "server_info": {
                "hostname": request.ssh_credentials.hostname,
                "port": request.ssh_credentials.port,
                "username": request.ssh_credentials.username,
                "connected": True,
                "system_info": server_info,
                "current_user": test_commands["whoami"].get("stdout", "").strip() if test_commands["whoami"].get("success") else "Unknown",
                "current_directory": test_commands["pwd"].get("stdout", "").strip() if test_commands["pwd"].get("success") else "Unknown",
                "disk_space": test_commands["df"].get("stdout", "").strip() if test_commands["df"].get("success") else "Unknown"
            },
            "directory_structure": directory_structure,
            "ready_for_workflow": True
        }
        
    except Exception as e:
        logger.error(f"SSH connection test failed: {e}", exc_info=True)
        return {
            "success": False,
            "connection_status": "error",
            "message": f"SSH connection test failed: {str(e)}",
            "server_info": {
                "hostname": request.ssh_credentials.hostname,
                "port": request.ssh_credentials.port,
                "username": request.ssh_credentials.username,
                "connected": False
            },
            "directory_structure": None,
            "error": str(e)
        }
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


@router.get("/projects/recent", response_model=dict, tags=["Utilities — Projects & Reports"])
async def get_recent_projects(
    limit: int = Query(10, ge=1, le=100, description="Number of recent projects to return"),
    current_user: User = Depends(get_current_active_user)
):
    """
    Get list of recent projects for the current user
    
    Returns projects sorted by most recent scan/analysis date.
    """
    try:
        user_id = str(current_user.id)
        
        # Get saved projects from database
        saved_projects = await UserProject.find(
            UserProject.user_id == user_id
        ).sort(-UserProject.created_at).limit(limit * 2).to_list()
        
        # Get recent scan jobs (most recent first)
        recent_jobs = await SonarQubeScanJob.find(
            SonarQubeScanJob.user_id == user_id
        ).sort(-SonarQubeScanJob.created_at).limit(limit * 2).to_list()  # Get more to account for duplicates
        
        # Get unique projects with their latest information
        projects_map = {}
        
        # First, add saved projects (even if they haven't been scanned)
        for saved_project in saved_projects:
            # Use project_key if available, otherwise generate from project_name
            project_key = saved_project.project_key or (saved_project.project_name.strip() if getattr(saved_project, 'project_name', None) else '')
            
            if project_key not in projects_map:
                projects_map[project_key] = {
                    "project_id": str(saved_project.id),
                    "id": str(saved_project.id),
                    "project_key": project_key,
                    "project_name": saved_project.project_name,
                    "organization_name": getattr(saved_project, "organization_name", None) or "",
                    "source_path": saved_project.vm_code_path,
                    "industry": saved_project.industry.value if hasattr(saved_project, "industry") and saved_project.industry else "",
                    "project_type": saved_project.project_type.value if hasattr(saved_project, "project_type") and saved_project.project_type else "",
                    "llm_option": saved_project.llm_option.value if hasattr(saved_project, "llm_option") and saved_project.llm_option else "",
                    "legacy_technology": [t.value if hasattr(t, "value") else str(t) for t in (saved_project.legacy_technology or [])],
                    "last_scan_date": None,
                    "status": "not_scanned",
                    "progress_percent": 0,
                    "quality_gate_status": None,
                    "total_issues": None,
                    "bugs": None,
                    "vulnerabilities": None,
                    "code_smells": None,
                    "has_report": False,
                    "created_at": saved_project.created_at.isoformat() if saved_project.created_at else None
                }
        
        # Then, add/update with scan job information
        for job in recent_jobs:
            project_key = job.project_key
            
            # If we haven't seen this project yet, or this job is more recent
            if project_key not in projects_map:
                # Try to get the latest report for this project
                latest_report = await SonarQubeReport.find_one(
                    SonarQubeReport.project_key == project_key,
                    SonarQubeReport.user_id == user_id
                ).sort(-SonarQubeReport.created_at)
                
                # Try to get the UserProject ID for this project
                user_project = await UserProject.find_one(
                    UserProject.user_id == user_id,
                    UserProject.project_key == project_key
                )
                
                project_info = {
                    "project_id": str(user_project.id) if user_project else None,
                    "id": str(user_project.id) if user_project else None,
                    "project_key": project_key,
                    "project_name": job.project_name,
                    "source_path": job.source_path,
                    "last_scan_date": job.created_at.isoformat() if job.created_at else None,
                    "status": job.status.value if isinstance(job.status, ScanJobStatus) else str(job.status),
                    "progress_percent": job.progress_percent,
                    "quality_gate_status": None,
                    "total_issues": None,
                    "bugs": None,
                    "vulnerabilities": None,
                    "code_smells": None,
                    "has_report": False
                }
                
                # Add report information if available
                if latest_report:
                    project_info["has_report"] = True
                    project_info["quality_gate_status"] = latest_report.quality_gate_status
                    project_info["total_issues"] = latest_report.total_issues
                    project_info["bugs"] = latest_report.bugs_count
                    project_info["vulnerabilities"] = latest_report.vulnerabilities_count
                    project_info["code_smells"] = latest_report.code_smells_count
                    project_info["last_analysis_date"] = latest_report.analysis_date.isoformat() if latest_report.analysis_date else None
                
                projects_map[project_key] = project_info
        
        # Convert to list and sort by last_scan_date or created_at (most recent first)
        projects = list(projects_map.values())
        projects.sort(key=lambda x: x.get("last_scan_date") or x.get("created_at") or "", reverse=True)
        
        return {
            "success": True,
            "total": len(projects),
            "projects": projects[:limit]
        }
        
    except Exception as e:
        logger.error(f"Failed to get recent projects: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get recent projects: {str(e)}"
        )


@router.get("/projects/stats", response_model=dict, tags=["Utilities — Projects & Reports"])
async def get_project_statistics(
    current_user: User = Depends(get_current_active_user)
):
    """
    Get project statistics for the current user
    
    Returns:
    - total_projects: Total number of unique projects
    - completed_projects: Number of projects with completed scans
    - in_progress_projects: Number of projects currently being scanned
    - failed_projects: Number of projects with failed scans
    - progress_percentage: Overall completion percentage
    """
    try:
        user_id = str(current_user.id)
        
        # Get all scan jobs for the user
        all_jobs = await SonarQubeScanJob.find(
            SonarQubeScanJob.user_id == user_id
        ).to_list()
        
        # Get all reports for the user
        all_reports = await SonarQubeReport.find(
            SonarQubeReport.user_id == user_id
        ).to_list()
        
        # Start with saved projects
        unique_projects = set()
        all_saved_projects = await UserProject.find(
            UserProject.user_id == user_id
        ).to_list()
        for project in all_saved_projects:
            # Use project_key if available, otherwise generate from project_name
            project_key = project.project_key or (project.project_name.strip() if getattr(project, 'project_name', None) else '')
            unique_projects.add(project_key)
        
        # Calculate statistics from scan jobs
        completed_projects = set()
        in_progress_projects = set()
        failed_projects = set()
        
        for job in all_jobs:
            project_key = job.project_key
            unique_projects.add(project_key)
            
            job_status = job.status.value if isinstance(job.status, ScanJobStatus) else str(job.status)
            
            if job_status == ScanJobStatus.COMPLETED.value:
                completed_projects.add(project_key)
            elif job_status in [ScanJobStatus.SCANNING.value, ScanJobStatus.PROCESSING.value, 
                               ScanJobStatus.FETCHING_REPORT.value, ScanJobStatus.VALIDATING.value,
                               ScanJobStatus.CONNECTING.value, ScanJobStatus.PENDING.value]:
                in_progress_projects.add(project_key)
            elif job_status == ScanJobStatus.FAILED.value:
                failed_projects.add(project_key)
        
        # Count projects with reports (completed analyses)
        projects_with_reports = set()
        for report in all_reports:
            projects_with_reports.add(report.project_key)
        
        total_projects = len(unique_projects)
        completed_count = len(completed_projects.union(projects_with_reports))
        in_progress_count = len(in_progress_projects)
        failed_count = len(failed_projects)
        
        # Calculate progress percentage
        if total_projects > 0:
            progress_percentage = round((completed_count / total_projects) * 100, 2)
        else:
            progress_percentage = 0.0
        
        return {
            "success": True,
            "statistics": {
                "total_projects": total_projects,
                "completed_projects": completed_count,
                "in_progress_projects": in_progress_count,
                "failed_projects": failed_count,
                "pending_projects": total_projects - completed_count - in_progress_count - failed_count,
                "progress_percentage": progress_percentage
            },
            "breakdown": {
                "by_status": {
                    "completed": completed_count,
                    "in_progress": in_progress_count,
                    "failed": failed_count,
                    "pending": total_projects - completed_count - in_progress_count - failed_count
                },
                "with_reports": len(projects_with_reports),
                "without_reports": total_projects - len(projects_with_reports)
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to get project statistics: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get project statistics: {str(e)}"
        )


@router.get("/reports", response_model=dict, tags=["Utilities — Projects & Reports"])
async def list_reports(
    current_user: User = Depends(get_current_active_user)
):
    """
    List all saved analysis reports for the current user.
    No input needed — just execute and get all reports.
    """
    try:
        user_id = str(current_user.id)
        
        # Get user's projects
        user_projects = await UserProject.find({"user_id": user_id}).to_list()
        project_ids = [str(p.id) for p in user_projects]
        project_map = {str(p.id): p.project_name for p in user_projects}
        
        if not project_ids:
            return {"success": True, "reports": [], "total": 0}
        
        # Get all reports for those projects
        reports = await AnalysisReport.find({"project_id": {"$in": project_ids}}).sort("-created_at").to_list()
        
        report_list = []
        for r in reports:
            report_list.append({
                "id": str(r.id),
                "project_id": r.project_id,
                "project_name": project_map.get(r.project_id, "Unknown"),
                "report_type": r.report_type,
                "report_label": REPORT_TYPE_LABELS.get(r.report_type, r.report_type),
                "enhancement_type": getattr(r, "enhancement_type", "llm_enhanced"),
                "summary": (r.summary or "")[:200],
                "total_issues": r.total_issues,
                "has_html_file": bool(r.report_file_local and os.path.exists(r.report_file_local)),
                "html_filename": os.path.basename(r.report_file_local) if r.report_file_local else None,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            })
        
        return {"success": True, "reports": report_list, "total": len(report_list)}
        
    except Exception as e:
        logger.error(f"Failed to list reports: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list reports: {str(e)}"
        )


@router.get("/reports/{report_id}/download", tags=["Utilities — Projects & Reports"])
async def download_report(
    report_id: str,
    format: str = Query("html", description="Format to download: html, pdf, docx, md"),
    current_user: User = Depends(get_current_active_user)
):
    """
    Download a saved report in the specified format (html, pdf, docx, md).
    """
    try:
        from bson import ObjectId
        
        report = await AnalysisReport.get(ObjectId(report_id))
        if not report:
            raise HTTPException(status_code=404, detail="Report not found")
        
        # Verify user owns this report
        user_id = str(current_user.id)
        try:
            project = await UserProject.find_one(
                UserProject.id == ObjectId(report.project_id),
                UserProject.user_id == user_id
            )
        except Exception:
            project = None
        if not project:
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Determine file path and media type based on format
        file_path = None
        media_type = "text/html"
        
        format_lower = format.lower()
        if format_lower == "pdf":
            file_path = report.report_file_pdf
            media_type = "application/pdf"
        elif format_lower == "docx":
            file_path = report.report_file_docx
            media_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        elif format_lower == "html":
            file_path = report.report_file_local
            media_type = "text/html"
        elif format_lower == "md":
            file_path = getattr(report, "report_file_md", None)
            media_type = "text/markdown"
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid format '{format}'. Supported formats: html, pdf, docx, md"
            )
            
        if not file_path or not os.path.exists(file_path):
            raise HTTPException(
                status_code=404, 
                detail=f"Report file for format '{format}' not found on server"
            )
        
        filename = os.path.basename(file_path)
        return FileResponse(
            path=file_path,
            media_type=media_type,
            filename=filename,
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to download report: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to download report: {str(e)}"
        )


@router.get("/reports/{report_id}/view", tags=["Utilities — Projects & Reports"])
async def view_report(
    report_id: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    View a saved HTML report in the browser (returns HTML content directly).
    """
    try:
        from bson import ObjectId
        
        report = await AnalysisReport.get(ObjectId(report_id))
        if not report:
            raise HTTPException(status_code=404, detail="Report not found")
        
        # Verify user owns this report
        user_id = str(current_user.id)
        project = await UserProject.find_one(
            UserProject.id == ObjectId(report.project_id),
            UserProject.user_id == user_id
        )
        if not project:
            raise HTTPException(status_code=403, detail="Access denied")
        
        if not report.report_file_local or not os.path.exists(report.report_file_local):
            raise HTTPException(status_code=404, detail="HTML report file not found on server")
        
        return FileResponse(
            path=report.report_file_local,
            media_type="text/html"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to view report: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to view report: {str(e)}"
        )
