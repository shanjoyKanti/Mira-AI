"""Service Registry - Loose coupling pattern for service management"""
from typing import Dict, Any, Optional, Type, TypeVar
from app.core.logging import get_logger

logger = get_logger(__name__)

T = TypeVar('T')


class ServiceRegistry:
    """Registry for managing services with loose coupling"""
    
    _instance: Optional['ServiceRegistry'] = None
    _services: Dict[str, Any] = {}
    _service_factories: Dict[str, callable] = {}
    
    def __new__(cls):
        """Singleton pattern"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def register(self, name: str, service: Any):
        """
        Register a service instance
        
        Args:
            name: Service name
            service: Service instance
        """
        self._services[name] = service
        logger.info(f"Registered service: {name}")
    
    def register_factory(self, name: str, factory: callable):
        """
        Register a service factory
        
        Args:
            name: Service name
            factory: Factory function that creates the service
        """
        self._service_factories[name] = factory
        logger.info(f"Registered service factory: {name}")
    
    def get(self, name: str, default: Any = None) -> Any:
        """
        Get a service by name
        
        Args:
            name: Service name
            default: Default value if service not found
            
        Returns:
            Service instance
        """
        if name in self._services:
            return self._services[name]
        
        if name in self._service_factories:
            service = self._service_factories[name]()
            self._services[name] = service  # Cache the instance
            return service
        
        if default is not None:
            return default
        
        raise ValueError(f"Service '{name}' not found in registry")
    
    def unregister(self, name: str):
        """Unregister a service"""
        if name in self._services:
            del self._services[name]
            logger.info(f"Unregistered service: {name}")
    
    def clear(self):
        """Clear all registered services"""
        self._services.clear()
        self._service_factories.clear()
        logger.info("Cleared service registry")
    
    def list_services(self) -> list:
        """List all registered service names"""
        return list(set(list(self._services.keys()) + list(self._service_factories.keys())))


# Global service registry instance
registry = ServiceRegistry()

