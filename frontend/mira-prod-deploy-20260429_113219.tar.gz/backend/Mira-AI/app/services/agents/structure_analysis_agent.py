"""
Project Structure Tree Analyzer for MIRA-AI
Analyzes project folder and returns structure tree using Groq (Qwen).
"""

import os
import re
from pathlib import Path
from typing import Optional

from app.services.agents.base_agent import BaseAgent, AgentState, GroqClient
from app.core.logging import get_logger

logger = get_logger(__name__)


STRUCTURE_TREE_SYSTEM_PROMPT = """You must output ONLY the hierarchical project structure tree. No other text whatsoever.

STRICT RULES:
- Do NOT output <think>, </think>, or any thinking/reasoning. Do NOT explain. Do NOT add commentary.
- Your entire response must be ONLY the tree: lines of directory names (ending with /) and file names, with indentation (2 spaces per level).
- Each directory appears once with its direct children (subdirs and files) indented under it. Do NOT repeat a directory as its own child (e.g. under "app/" list "Console/", "Http/", etc., not "app/" again).
- Directories end with "/". Files do not. Use 2 spaces for each indent level.
- Include every directory and every file from the input. No icons, emojis, headers, or extra lines.
- First character of your response must be the root directory name (e.g. project/ or .). Last character must be the end of the last line of the tree. Nothing before, nothing after.

Example (your output must look exactly like this, with no added text):
project/
  src/
    main.py
    utils.py
  config/
    settings.json
  README.md"""


class StructureTreeAnalyzer(BaseAgent):
    """Analyzes project structure and generates tree using Groq (Qwen)."""

    def __init__(self, groq_client: Optional[GroqClient] = None):
        """
        Initialize analyzer

        Args:
            groq_client: Optional GroqClient instance
        """
        super().__init__(
            name="structure_tree_analyzer",
            description="Analyzes project structure and generates hierarchical tree",
            groq_client=groq_client
        )
        self.ignore_patterns = [
            '.git', '.svn', '.hg', '__pycache__', 'node_modules',
            '.venv', 'venv', 'vendor', '.idea', '.vscode'
        ]

    def execute(self, state: AgentState) -> AgentState:
        """
        Execute structure tree analysis
        
        Args:
            state: Agent state containing project_path and project_name
            
        Returns:
            Updated agent state with structure tree result
        """
        try:
            project_path = state.project_path
            project_name = state.project_name
            
            if not project_path:
                state.add_error("project_path is required")
                return state
                
            if not project_name:
                project_name = Path(project_path).name
                state.project_name = project_name
            
            folder_path = Path(project_path)
            if not folder_path.exists():
                state.add_error(f"Project path does not exist: {project_path}")
                return state
                
            if not folder_path.is_dir():
                state.add_error(f"Project path is not a directory: {project_path}")
                return state
            
            logger.info(f"Analyzing project structure: {project_name} at {project_path}")
            
            # Build context from directory structure
            context_text = self._build_structure_context(folder_path, project_name)
            
            # Get structure tree from LLM (Groq/Qwen)
            raw = self.groq_client.generate(
                system_prompt=STRUCTURE_TREE_SYSTEM_PROMPT,
                user_content=context_text,
                temperature=0.7,
            )
            structure_tree = self._extract_tree_only(raw)

            # Store results
            state.add_result("structure_tree", structure_tree)
            state.add_result("project_stats", self._get_project_stats(folder_path))
            state.context["structure_analysis_completed"] = True

            # Log full extracted structure tree
            logger.info("Structure tree extracted:\n%s", structure_tree)
            logger.info(f"Structure analysis completed for {project_name}")
            return state
            
        except Exception as e:
            state.add_error(f"Structure analysis failed: {str(e)}")
            logger.error(f"Structure analysis failed: {e}", exc_info=True)
            return state

    def analyze(self, folder_path: Path, folder_name: str) -> str:
        """
        Legacy method for backward compatibility
        
        Args:
            folder_path: Path to project folder
            folder_name: Name of the project folder
            
        Returns:
            Structure tree as string
        """
        result = self.run(project_path=str(folder_path), project_name=folder_name)
        if result["success"]:
            return result["results"].get("structure_tree", "")
        else:
            raise Exception(result.get("error", "Unknown error"))

    def _should_ignore(self, name: str) -> bool:
        """Return True if file/dir name should be ignored."""
        return any(p in name for p in self.ignore_patterns)

    def _build_structure_context(self, project_root: Path, project_name: str) -> str:
        """Build text context from directory structure (file names only, no contents)"""
        lines = []
        lines.append(f"Project name: {project_name}")
        lines.append(f"Project root: {project_root}")
        lines.append("=" * 80)
        lines.append("PROJECT DIRECTORY STRUCTURE AND FILE LISTING")
        lines.append("=" * 80)
        lines.append("")
        
        # Build structure with file names only (no file contents)
        dirs = []
        all_files = []
        
        for root, dirnames, filenames in os.walk(project_root):
            # Filter ignored directories
            dirnames[:] = [d for d in dirnames if not self._should_ignore(d)]
            
            rel_root = os.path.relpath(root, project_root)
            if rel_root == '.':
                rel_root = ''
            
            # Track directories
            if rel_root:
                dirs.append(rel_root)
            
            # Process ALL files
            for filename in filenames:
                if self._should_ignore(filename):
                    continue
                
                file_path = Path(root) / filename
                rel_path = os.path.relpath(file_path, project_root)
                
                try:
                    file_size = file_path.stat().st_size
                    extension = file_path.suffix.lower()
                    all_files.append((rel_path, extension, file_size))
                except (OSError, PermissionError):
                    continue
        
        # Add complete directory tree
        lines.append("DIRECTORY STRUCTURE:")
        lines.append("")
        for dir_path in sorted(set(dirs)):
            lines.append(f"{dir_path}/")
        
        lines.append("")
        lines.append("=" * 80)
        lines.append("FILE LISTING")
        lines.append("=" * 80)
        lines.append("")
        
        # Add file listing (names and paths only, no contents)
        for rel_path, ext, size in sorted(all_files):
            lines.append(f"{rel_path} ({ext}, {size:,} bytes)")
        
        lines.append("")
        lines.append("=" * 80)
        lines.append("SUMMARY STATISTICS")
        lines.append("=" * 80)
        lines.append(f"Total directories: {len(set(dirs))}")
        lines.append(f"Total files: {len(all_files)}")
        lines.append(f"Total size: {sum(size for _, _, size in all_files):,} bytes")
        
        return "\n".join(lines)

    @staticmethod
    def _extract_tree_only(raw: str) -> str:
        """Strip think blocks and any non-tree text so the result is only the tree."""
        text = raw.strip()
        # Remove think/reasoning blocks from model output
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE).strip()
        # Drop lines before the first line that looks like tree (starts with optional spaces + name, optionally ending with /)
        lines = text.splitlines()
        start = 0
        for i, line in enumerate(lines):
            s = line.strip()
            if not s:
                continue
            # Tree line: alphanumeric path segment, maybe with / at end, or path like .env.example
            if re.match(r"^[\w./\-]+/?\s*$", s) or "/" in s or s.endswith("/"):
                start = i
                break
        # Drop trailing non-tree lines (empty or obvious commentary)
        end = len(lines)
        for i in range(len(lines) - 1, start - 1, -1):
            s = lines[i].strip()
            if not s:
                continue
            if re.match(r"^[\w\s./\-]+/?\s*$", s) or s.endswith("/") or ("/" in s and " " not in s.lstrip()):
                end = i + 1
                break
        return "\n".join(lines[start:end]).strip()
    
    def _get_project_stats(self, project_root: Path) -> dict:
        """Get basic project statistics"""
        total_files = 0
        total_directories = 0
        total_size = 0
        file_types = {}

        for root, dirnames, filenames in os.walk(project_root):
            # Filter ignored directories
            dirnames[:] = [d for d in dirnames if not self._should_ignore(d)]
            total_directories += len(dirnames)

            for filename in filenames:
                if self._should_ignore(filename):
                    continue

                file_path = Path(root) / filename
                try:
                    file_size = file_path.stat().st_size
                    extension = file_path.suffix.lower() or 'no_extension'

                    total_files += 1
                    total_size += file_size
                    file_types[extension] = file_types.get(extension, 0) + 1

                except (OSError, PermissionError):
                    continue

        return {
            'total_files': total_files,
            'total_directories': total_directories,
            'total_size': total_size,
            'file_types': file_types
        }


def analyze_structure_tree(folder_path: str, folder_name: str) -> str:
    """
    Convenience function to analyze project structure tree
    
    Args:
        folder_path: Path to project folder
        folder_name: Name of the project folder
        
    Returns:
        Structure tree as string
    """
    analyzer = StructureTreeAnalyzer()
    return analyzer.analyze(Path(folder_path), folder_name)
