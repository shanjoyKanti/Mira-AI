"""API v1 Router - aggregates all v1 endpoints"""
from fastapi import APIRouter

from app.api.v1.accounts.routes import router as accounts_router
from app.api.v1.analyze.routes import router as analyze_router
from app.api.v1.agents.routes import router as agents_router
from app.api.v1.sonarqube.routes import router as sonarqube_router
from app.api.v1.ssh.routes import router as ssh_router


router = APIRouter()

router.include_router(accounts_router, prefix="/accounts")
router.include_router(analyze_router, prefix="/analyze")
router.include_router(agents_router, prefix="/agents")
router.include_router(sonarqube_router, prefix="/sonarqube")
router.include_router(ssh_router, prefix="/ssh")
