"""
Unit tests for app/services/rag/version_ladder.py

Tests cover:
  - Valid forward migrations return the correct intermediate steps
  - Same-version requests return []
  - Downgrade attempts raise VersionLadderError
  - Unknown versions raise VersionLadderError
  - All static ladders (PHP, Laravel, Python, Django, etc.) are well-formed
  - Config.json fallback (mocked)
"""

import pytest
from unittest.mock import patch

from app.services.rag.version_ladder import (
    VersionLadderError,
    PHP_VERSION_LADDER,
    LARAVEL_VERSION_LADDER,
    PYTHON_VERSION_LADDER,
    DJANGO_VERSION_LADDER,
    JAVASCRIPT_VERSION_LADDER,
    REACT_VERSION_LADDER,
    JAVA_VERSION_LADDER,
    SPRINGBOOT_VERSION_LADDER,
    DOTNET_VERSION_LADDER,
    GOLANG_VERSION_LADDER,
    get_version_steps,
    _STATIC_LADDERS,
)


# ---------------------------------------------------------------------------
# PHP ladder tests
# ---------------------------------------------------------------------------

class TestPhpLadder:
    def test_valid_forward_single_step(self):
        steps = get_version_steps("php", None, "7.4", "8.0")
        assert steps == ["8.0"]

    def test_valid_forward_multiple_steps(self):
        steps = get_version_steps("php", None, "7.4", "8.2")
        assert steps == ["8.0", "8.1", "8.2"]

    def test_valid_forward_from_56_to_71(self):
        steps = get_version_steps("php", None, "5.6", "7.1")
        assert steps == ["7.0", "7.1"]

    def test_same_version_returns_empty(self):
        steps = get_version_steps("php", None, "8.0", "8.0")
        assert steps == []

    def test_same_version_returns_empty_74(self):
        steps = get_version_steps("php", None, "7.4", "7.4")
        assert steps == []

    def test_downgrade_raises(self):
        with pytest.raises(VersionLadderError, match="[Dd]owngrade"):
            get_version_steps("php", None, "8.1", "7.4")

    def test_downgrade_single_step_raises(self):
        with pytest.raises(VersionLadderError):
            get_version_steps("php", None, "8.1", "8.0")

    def test_unknown_from_version_raises(self):
        with pytest.raises(VersionLadderError, match="from_version"):
            get_version_steps("php", None, "6.0", "8.0")

    def test_unknown_to_version_raises(self):
        with pytest.raises(VersionLadderError, match="to_version"):
            get_version_steps("php", None, "7.4", "8.6")

    def test_full_ladder_forward(self):
        """7.4 → 8.5 should return all intermediate steps."""
        steps = get_version_steps("php", None, "7.4", "8.5")
        assert steps == ["8.0", "8.1", "8.2", "8.3", "8.4", "8.5"]

    def test_first_to_last(self):
        steps = get_version_steps("php", None, PHP_VERSION_LADDER[0], PHP_VERSION_LADDER[-1])
        assert steps == PHP_VERSION_LADDER[1:]

    def test_steps_exclude_from_version(self):
        steps = get_version_steps("php", None, "7.3", "7.4")
        assert "7.3" not in steps
        assert steps == ["7.4"]

    def test_case_insensitive_language(self):
        steps = get_version_steps("PHP", None, "7.4", "8.0")
        assert steps == ["8.0"]


# ---------------------------------------------------------------------------
# Laravel ladder tests
# ---------------------------------------------------------------------------

class TestLaravelLadder:
    def test_valid_forward(self):
        steps = get_version_steps("php", "laravel", "9", "11")
        assert steps == ["10", "11"]

    def test_single_step_laravel(self):
        steps = get_version_steps("php", "laravel", "11", "12")
        assert steps == ["12"]

    def test_same_version_laravel(self):
        steps = get_version_steps("php", "laravel", "10", "10")
        assert steps == []

    def test_downgrade_laravel_raises(self):
        with pytest.raises(VersionLadderError):
            get_version_steps("php", "laravel", "11", "9")

    def test_unknown_laravel_version_raises(self):
        with pytest.raises(VersionLadderError):
            get_version_steps("php", "laravel", "9", "13")

    def test_laravel_5x_steps(self):
        steps = get_version_steps("php", "laravel", "5.0", "5.3")
        assert steps == ["5.1", "5.2", "5.3"]

    def test_laravel_full_ladder_well_formed(self):
        assert LARAVEL_VERSION_LADDER[0] == "4.2"
        assert LARAVEL_VERSION_LADDER[-1] == "12"
        assert "9" in LARAVEL_VERSION_LADDER
        assert "10" in LARAVEL_VERSION_LADDER
        assert "11" in LARAVEL_VERSION_LADDER


# ---------------------------------------------------------------------------
# Python / Django ladder tests
# ---------------------------------------------------------------------------

class TestPythonLadder:
    def test_valid_python_steps(self):
        steps = get_version_steps("python", None, "3.8", "3.10")
        assert steps == ["3.9", "3.10"]

    def test_django_valid_steps(self):
        steps = get_version_steps("python", "django", "4.2", "5.1")
        assert steps == ["5.0", "5.1"]

    def test_django_downgrade_raises(self):
        with pytest.raises(VersionLadderError):
            get_version_steps("python", "django", "5.0", "4.2")


# ---------------------------------------------------------------------------
# JavaScript / frameworks
# ---------------------------------------------------------------------------

class TestJavaScriptLadder:
    def test_node_steps(self):
        steps = get_version_steps("javascript", None, "16", "20")
        assert steps == ["18", "20"]

    def test_react_steps(self):
        steps = get_version_steps("javascript", "react", "17", "19")
        assert steps == ["18", "19"]

    def test_angular_valid(self):
        steps = get_version_steps("javascript", "angular", "16", "18")
        assert steps == ["17", "18"]


# ---------------------------------------------------------------------------
# Java / Spring Boot
# ---------------------------------------------------------------------------

class TestJavaLadder:
    def test_java_steps(self):
        steps = get_version_steps("java", None, "11", "21")
        assert steps == ["17", "21"]

    def test_springboot_steps(self):
        steps = get_version_steps("java", "springboot", "2.7", "3.1")
        assert steps == ["3.0", "3.1"]


# ---------------------------------------------------------------------------
# Go
# ---------------------------------------------------------------------------

class TestGoLadder:
    def test_golang_steps(self):
        steps = get_version_steps("golang", None, "1.20", "1.22")
        assert steps == ["1.21", "1.22"]

    def test_golang_downgrade_raises(self):
        with pytest.raises(VersionLadderError):
            get_version_steps("golang", None, "1.22", "1.20")


# ---------------------------------------------------------------------------
# .NET
# ---------------------------------------------------------------------------

class TestDotNetLadder:
    def test_dotnet_steps(self):
        steps = get_version_steps("dotnet", None, "6.0", "9.0")
        assert steps == ["7.0", "8.0", "9.0"]


# ---------------------------------------------------------------------------
# Unknown language
# ---------------------------------------------------------------------------

class TestUnknownLadder:
    def test_unknown_language_raises(self):
        with pytest.raises(VersionLadderError, match="No version ladder"):
            get_version_steps("cobol", None, "1.0", "2.0")

    def test_unknown_framework_falls_back_to_language_ladder(self):
        # PHP has a static ladder but "unknown_fw" doesn't;
        # should fall back to PHP language ladder without error.
        steps = get_version_steps("php", "unknown_fw", "7.4", "8.0")
        assert steps == ["8.0"]


# ---------------------------------------------------------------------------
# Static ladder well-formedness
# ---------------------------------------------------------------------------

class TestLadderIntegrity:
    def test_all_static_ladders_are_lists(self):
        for key, ladder in _STATIC_LADDERS.items():
            assert isinstance(ladder, list), f"Ladder for {key} is not a list"
            assert len(ladder) > 0, f"Ladder for {key} is empty"

    def test_all_static_ladder_elements_are_strings(self):
        for key, ladder in _STATIC_LADDERS.items():
            for v in ladder:
                assert isinstance(v, str), f"Non-string version in {key}: {v!r}"

    def test_php_ladder_contains_required_versions(self):
        for v in ("5.5", "5.6", "7.4", "8.0", "8.1", "8.2", "8.3"):
            assert v in PHP_VERSION_LADDER, f"PHP ladder missing {v}"

    def test_no_duplicate_versions_in_php_ladder(self):
        assert len(PHP_VERSION_LADDER) == len(set(PHP_VERSION_LADDER))

    def test_no_duplicate_versions_in_laravel_ladder(self):
        assert len(LARAVEL_VERSION_LADDER) == len(set(LARAVEL_VERSION_LADDER))


# ---------------------------------------------------------------------------
# Config.json fallback
# ---------------------------------------------------------------------------

class TestConfigFallback:
    def test_config_fallback_used_when_static_missing(self):
        """If a language is absent from static ladders but present in config.json,
        get_version_steps should use the config fallback."""
        fake_config_ladders = {
            ("rubylang", None): ["2.7", "3.0", "3.1", "3.2"],
        }
        # Patch the internal cache so _load_config_ladders returns our fake data
        with patch(
            "app.services.rag.version_ladder._config_ladders",
            fake_config_ladders,
        ):
            steps = get_version_steps("rubylang", None, "3.0", "3.2")
            assert steps == ["3.1", "3.2"]

    def test_config_fallback_not_used_when_static_exists(self):
        """Static ladder takes priority over config.json fallback."""
        fake_config_ladders = {
            ("php", None): ["7.4", "8.0"],  # incomplete — should NOT be used
        }
        with patch(
            "app.services.rag.version_ladder._config_ladders",
            fake_config_ladders,
        ):
            # Full PHP ladder from static registry should still be used
            steps = get_version_steps("php", None, "5.6", "7.0")
            assert steps == ["7.0"]
