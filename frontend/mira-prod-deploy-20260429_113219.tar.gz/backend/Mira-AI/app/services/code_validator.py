"""
Syntax validator for LLM-generated code.

After the modernization agent returns upgraded code, we parse it with
tree-sitter and look for syntax errors. If the output doesn't parse, we
can either:
  (a) reject the upgrade and keep the original file (safest, default), or
  (b) return the error to the caller so they can retry the LLM with
      the parse errors included in the prompt.

Tree-sitter reports errors in two ways:
  * `node.type == "ERROR"` — a chunk of source that couldn't be parsed
  * `node.is_missing` — a node the grammar expected but isn't there

A single ERROR at the top level is enough to flag the output as broken.
For languages we don't have parsers for (Swift, COBOL, etc.) we skip
validation and return success — the existing all-or-nothing policy
still applies if the LLM returned nothing.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ValidationError:
    """One syntax error surfaced by tree-sitter."""
    start_line: int
    end_line: int
    kind: str          # "ERROR" or "MISSING"
    snippet: str       # first ~120 chars of the offending region

    def format(self) -> str:
        return f"  line {self.start_line}: [{self.kind}] {self.snippet!r}"


@dataclass
class ValidationResult:
    """Outcome of a single syntax check."""
    ok: bool
    language: str
    errors: List[ValidationError]
    parse_skipped: bool = False  # True when no parser exists; treated as "ok" but flagged

    def format_errors(self, max_errors: int = 5) -> str:
        if not self.errors:
            return "(no errors)"
        lines = [e.format() for e in self.errors[:max_errors]]
        if len(self.errors) > max_errors:
            lines.append(f"  ... and {len(self.errors) - max_errors} more")
        return "\n".join(lines)


def validate_syntax(code: str, language: str) -> ValidationResult:
    """
    Parse `code` with tree-sitter and return a ValidationResult.

    - ok=True, parse_skipped=False → parse succeeded with zero errors.
    - ok=True, parse_skipped=True  → no parser available; treat as best-effort pass.
    - ok=False                     → parser available, code has syntax errors (details in .errors).

    Never raises on malformed input — just reports.
    """
    if not code or not code.strip():
        return ValidationResult(ok=False, language=language, errors=[
            ValidationError(start_line=0, end_line=0, kind="ERROR", snippet="(empty output)")
        ])

    try:
        from tree_sitter_languages import get_parser
    except Exception as e:
        logger.debug("tree-sitter-languages unavailable, skipping validation: %s", e)
        return ValidationResult(ok=True, language=language, errors=[], parse_skipped=True)

    try:
        parser = get_parser(language)
    except Exception as e:
        logger.debug("no tree-sitter parser for %r, skipping validation: %s", language, e)
        return ValidationResult(ok=True, language=language, errors=[], parse_skipped=True)

    try:
        tree = parser.parse(code.encode("utf-8"))
    except Exception as e:
        logger.warning("tree-sitter parser crashed on %r: %s", language, e)
        return ValidationResult(ok=True, language=language, errors=[], parse_skipped=True)

    errors: List[ValidationError] = []
    code_bytes = code.encode("utf-8")

    def visit(node):
        # is_missing => expected token not present (e.g. missing closing brace)
        if getattr(node, "is_missing", False):
            errors.append(ValidationError(
                start_line=node.start_point[0] + 1,
                end_line=node.end_point[0] + 1,
                kind="MISSING",
                snippet=f"missing {node.type}",
            ))
            return
        if node.type == "ERROR":
            snippet_bytes = code_bytes[node.start_byte:node.end_byte][:120]
            try:
                snippet = snippet_bytes.decode("utf-8", errors="replace")
            except Exception:
                snippet = "<binary>"
            errors.append(ValidationError(
                start_line=node.start_point[0] + 1,
                end_line=node.end_point[0] + 1,
                kind="ERROR",
                snippet=snippet.replace("\n", " ")[:120],
            ))
            # Don't descend into ERROR children — children are garbage anyway
            return
        # Fast-path: if the node has no errors anywhere in its subtree, skip it.
        if hasattr(node, "has_error") and not node.has_error:
            return
        for child in node.children:
            visit(child)

    if tree.root_node.has_error:
        visit(tree.root_node)

    return ValidationResult(ok=(len(errors) == 0), language=language, errors=errors)


def validate_with_retry(
    code: str,
    original_code: str,
    language: str,
    retry_fn,
    max_retries: int = 2,
) -> tuple:
    """
    Validate `code` with tree-sitter. If it fails, call `retry_fn(previous_code,
    errors_text)` up to `max_retries` times to get a fixed version. If still
    broken, return (original_code, False, reason) so the caller can mark the
    file as failed (all-or-nothing policy).

    Args:
        code:          The LLM's first attempt.
        original_code: The pre-modernization code (returned if we give up).
        language:      tree-sitter language name.
        retry_fn:      Callable(code, errors_text) → new code string. Will be
                       called ≤ max_retries times. Raise or return falsy to
                       abort retries early.
        max_retries:   Maximum retry rounds.

    Returns:
        (code_to_use, validated_ok, reason)
          code_to_use:   The code to write to disk (upgraded if valid, else original)
          validated_ok:  True if parse succeeded (or was skipped for unsupported lang)
          reason:        Debug string describing outcome
    """
    current = code
    result = validate_syntax(current, language)
    if result.ok:
        return (
            current, True,
            "parse skipped (no parser)" if result.parse_skipped else "parsed clean"
        )

    for attempt in range(1, max_retries + 1):
        errors_text = result.format_errors()
        logger.warning(
            "Syntax validation failed for %s (attempt %d/%d); %d error(s):\n%s",
            language, attempt, max_retries, len(result.errors), errors_text,
        )
        try:
            fixed = retry_fn(current, errors_text)
        except Exception as e:
            logger.warning("Retry fn raised on attempt %d: %s — giving up", attempt, e)
            return (original_code, False, f"retry raised: {e}")
        if not fixed or not fixed.strip():
            logger.warning("Retry fn returned empty on attempt %d — giving up", attempt)
            return (original_code, False, "retry returned empty")
        current = fixed
        result = validate_syntax(current, language)
        if result.ok:
            return (current, True, f"fixed after {attempt} retry")

    # Exhausted retries — fall back to original
    return (original_code, False, f"still broken after {max_retries} retries")
