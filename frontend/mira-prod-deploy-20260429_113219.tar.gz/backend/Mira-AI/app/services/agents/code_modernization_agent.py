"""
PHP Modernization Agent for MIRA-AI

Flow (Sonar guide + project → LLM → upgraded files → save on client):
1. Load the SonarQube-derived upgrade guide (.txt) from app/data/upgrade-guide/
2. Receive project: PHP files fetched from the client (via SSH in the API route), ideally from the
   migrated-codes stage folder matching the target PHP version (resolved in routes).
3. Analyze project structure (list of PHP files and sizes)
4. For each file: pass Sonar issues for that file + structure + code; LLM applies remediations only
5. Save upgraded code on the client server under ``upgraded-codes/`` (via SSH in the API route, or
   ``save_to_server`` when using the agent ``execute`` path).
"""

import os
import re
import shutil
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import json

from app.services.agents.base_agent import BaseAgent, AgentState, GroqClient
from app.core.logging import get_logger

logger = get_logger(__name__)

# Remote output leaf directory (matches ``DEFAULT_REMOTE_UPGRADED_CODES_DIR`` in agents routes).
REMOTE_UPGRADED_CODES_DIR = "upgraded-codes"


# File extension → language name used by the tree-sitter code splitter.
# Keys MUST match the language names in app.services.code_splitter.LANGUAGE_PARSERS.
_EXT_TO_LANGUAGE: Dict[str, str] = {
    ".php": "php",
    ".phtml": "php",
    ".py": "python", ".pyi": "python",
    ".js": "javascript", ".mjs": "javascript", ".cjs": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "tsx",
    ".java": "java",
    ".go": "go",
    ".rb": "ruby",
    ".rs": "rust",
    ".cs": "c_sharp",
    ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp", ".hpp": "cpp", ".hh": "cpp",
    ".kt": "kotlin", ".kts": "kotlin",
    ".scala": "scala",
    ".swift": "swift",
    ".lua": "lua",
    ".sh": "bash", ".bash": "bash",
    ".html": "html", ".htm": "html",
    ".css": "css",
    ".json": "json",
    ".yaml": "yaml", ".yml": "yaml",
    ".toml": "toml",
}


class PHPModernizationAgent(BaseAgent):
    """Modernizes PHP code using the SonarQube upgrade guide only."""

    def __init__(self, groq_client: Optional[GroqClient] = None):
        super().__init__(
            name="php_modernization_agent",
            description="Modernizes PHP code based on SonarQube upgrade guide",
            groq_client=groq_client,
        )
        self.sonarqube_report = None
        self.project_structure = None
    
    # ============================================================================
    # STEP 1: FETCH PROJECT FROM CLIENT SERVER
    # ============================================================================
    
    def fetch_project(self, client_server_path: str, local_path: str) -> bool:
        """
        Fetch project from client server
        
        Args:
            client_server_path: Path on client server
            local_path: Local destination path
            
        Returns:
            True if successful
        """
        try:
            logger.info("Fetching project from %s", client_server_path)
            if os.path.exists(client_server_path):
                shutil.copytree(client_server_path, local_path, dirs_exist_ok=True)
                logger.info("Project fetched to %s", local_path)
                return True
            logger.error("Server path not found: %s", client_server_path)
            return False
        except Exception as e:
            logger.error("Error fetching project: %s", e)
            return False
    
    # ============================================================================
    # STEP 2: ANALYZE PROJECT STRUCTURE
    # ============================================================================
    
    # Maximum bytes for a single source file. Files above this are sent to the LLM
    # in chunks rather than as one giant prompt.
    MAX_LLM_FILE_BYTES: int = int(os.environ.get("MIRA_MAX_LLM_FILE_BYTES", str(200 * 1024)))  # 200 KB

    def analyze_structure(self, project_path: str) -> Dict:
        """
        Analyze project structure using only file sizes (stat), NOT by reading file contents
        into memory. This avoids OOM for large projects.

        Args:
            project_path: Path to project on the local Docker container.

        Returns:
            Structure dict with total_files and files list (path + size in bytes).
        """
        logger.info("Analyzing project structure (stat-only, no full reads)")

        project_dir = Path(project_path)
        excluded = {"vendor", "node_modules", ".git", "cache"}
        php_files = [
            f for f in project_dir.rglob("*.php")
            if not any(ex in f.parts for ex in excluded)
        ]

        structure: Dict = {"total_files": len(php_files), "files": []}

        for php_file in php_files:
            try:
                size = php_file.stat().st_size  # bytes — no file read needed
                structure["files"].append({
                    "path": str(php_file.relative_to(project_dir)),
                    "size": size,
                })
            except Exception as e:
                logger.warning("Could not stat %s: %s", php_file.name, e)

        logger.info("Found %d PHP files", len(php_files))
        self.project_structure = structure
        return structure
    
    # ============================================================================
    # STEP 3: LOAD GENERATED REPORTS
    # ============================================================================
    
    def load_reports(
        self,
        project_name: str,
        sonarqube_report_path: Optional[str] = None,
        php_upgrade_guide_path: Optional[str] = None,
        laravel_upgrade_guide_path: Optional[str] = None,
    ) -> bool:
        """
        Load the SonarQube upgrade guide (.txt). ``php_upgrade_guide_path`` and ``laravel_upgrade_guide_path`` are ignored (compatibility).

        If ``sonarqube_report_path`` is omitted, resolves ``app/data/upgrade-guide/{project}_sonarqube_analysis*.txt``.
        """
        _ = (php_upgrade_guide_path, laravel_upgrade_guide_path)
        logger.info("Loading SonarQube upgrade guide only")
        base = Path("app/data/upgrade-guide")
        if sonarqube_report_path:
            sonar_path = Path(sonarqube_report_path)
        else:
            sonar_path = base / f"{project_name}_sonarqube_analysis.txt"
            if not sonar_path.exists():
                candidates = sorted(
                    base.glob(f"{project_name}_sonarqube_analysis_*.txt"),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                )
                if candidates:
                    sonar_path = candidates[0]
        if sonar_path.exists():
            with open(sonar_path, "r", encoding="utf-8") as f:
                self.sonarqube_report = f.read()
            logger.info("Loaded SonarQube guide: %s (%s chars)", sonar_path, len(self.sonarqube_report))
        else:
            logger.warning("SonarQube report not found: %s", sonar_path)
            self.sonarqube_report = None

        return bool(self.sonarqube_report)
    
    # ============================================================================
    # STEP 4: MODERNIZE PROJECT CODE
    # ============================================================================
    
    # Severity order: lower number = higher priority (fixed first)
    _SEVERITY_ORDER = {"BLOCKER": 0, "CRITICAL": 1, "MAJOR": 2, "MINOR": 3, "INFO": 4}

    def _severity_rank_for_file(self, rel_path: str) -> int:
        """
        Return the highest-priority (lowest numeric) severity found in the SonarQube
        report for this file. Files with BLOCKER issues sort before CRITICAL, etc.
        Files with no issues get rank 99 (processed last).
        """
        if not self.sonarqube_report:
            return 99
        section = self._get_sonarqube_context_for_file(str(rel_path))
        rank = 99
        for sev, val in self._SEVERITY_ORDER.items():
            if sev in section.upper():
                rank = min(rank, val)
        return rank

    def modernize_project(
        self,
        project_path: str,
        to_version: str,
        on_progress: Optional[callable] = None,
        already_completed: Optional[set] = None,
    ) -> Dict:
        """
        Modernize all source files in the project, processing files with the highest-severity
        SonarQube issues first (BLOCKER → CRITICAL → MAJOR → MINOR → INFO → no issues).

        Large files (> MAX_LLM_FILE_BYTES) are split into chunks before being sent to the LLM
        so they never exceed the model's context window.

        Args:
            project_path:     Path to project on the local Docker container.
            to_version:       Target version string (PHP version, or language version).
            on_progress:      Called per file as on_progress(i, total, rel_path, status). 'status'
                              is one of 'start' | 'done' | 'error' | 'skipped_resume'. Caller
                              uses it to write checkpoint rows to Mongo.
            already_completed: Set of rel_path strings that were completed in a prior run.
                               These files are skipped (used for resume).

        Returns:
            {"stats": {...}, "files": [...]}
        """
        logger.info("Modernizing code to version %s (severity-ordered, large-file chunking)", to_version)

        project_dir = Path(project_path)
        # Use the shared skip filter so vendored/generated/binary files never hit the LLM.
        try:
            from app.api.v1.analyze.utils import should_skip_path as _should_skip  # type: ignore
        except Exception:  # pragma: no cover — fall back to old behavior if import fails
            _should_skip = lambda p: (any(ex in p.split("/") for ex in ["vendor", "node_modules", ".git"]), "legacy")

        source_files: List[Path] = []
        for f in project_dir.rglob("*.php"):
            rel_str = str(f.relative_to(project_dir))
            skip, _reason = _should_skip(rel_str)
            if skip:
                continue
            source_files.append(f)

        # Sort by severity so BLOCKER files are fixed before CRITICAL, then MAJOR, etc.
        source_files.sort(key=lambda f: self._severity_rank_for_file(str(f.relative_to(project_dir))))

        results: List[Dict[str, Any]] = []
        stats: Dict[str, int] = {
            "total": len(source_files),
            "upgraded": 0, "unchanged": 0, "errors": 0,
            "skipped_large": 0, "skipped_resume": 0,
            # PHP now also gets tree-sitter validation (same counters as the generic agent).
            "validated_clean": 0, "validation_retried": 0, "validation_failed": 0,
        }
        total = len(source_files)
        completed_set = already_completed or set()

        for i, source_file in enumerate(source_files, 1):
            rel_path = source_file.relative_to(project_dir)
            rel_str = str(rel_path)

            # Resume: skip files that a prior run already processed.
            if rel_str in completed_set:
                stats["skipped_resume"] += 1
                if on_progress:
                    on_progress(i, total, rel_str, "skipped_resume")
                continue

            severity_rank = self._severity_rank_for_file(rel_str)
            sev_label = next(
                (k for k, v in self._SEVERITY_ORDER.items() if v == severity_rank), "NONE"
            )

            if on_progress:
                on_progress(i, total, rel_str, "start")

            logger.info("[%d/%d] %s (severity: %s)", i, total, rel_path, sev_label)

            try:
                file_size = source_file.stat().st_size
                if file_size > self.MAX_LLM_FILE_BYTES:
                    logger.info(
                        "   Large file (%d bytes > %d limit) — processing in chunks",
                        file_size, self.MAX_LLM_FILE_BYTES,
                    )
                    upgraded_code, changes = self._modernize_large_file(
                        source_file, rel_str, to_version
                    )
                else:
                    with open(source_file, "r", encoding="utf-8", errors="ignore") as f:
                        original_code = f.read()
                    upgraded_code, changes = self._modernize_file(
                        original_code, rel_str, to_version
                    )

                # ─── Syntax validation (tree-sitter + retry) ────────────
                # Same policy as GenericModernizationAgent: if the LLM output
                # doesn't parse, ask the LLM to fix; if still broken after
                # retries, keep the ORIGINAL (no broken writes).
                from app.services.code_validator import validate_with_retry

                def _php_syntax_retry(prev_code: str, errors_text: str) -> str:
                    # Build a short "fix syntax" prompt. Uses the agent's own
                    # groq_client so rate limits and throttling apply.
                    fix_prompt = (
                        f"The previous modernization produced code with SYNTAX ERRORS. "
                        f"Fix ONLY the syntax errors; keep all other logic unchanged.\n\n"
                        f"### SYNTAX ERRORS:\n{errors_text}\n\n"
                        f"### BROKEN CODE:\n```php\n{prev_code}\n```\n\n"
                        f"Return the corrected file in this exact format:\n"
                        f"### CHANGES:\n- <what you fixed>\n\n"
                        f"### UPGRADED CODE:\n```php\n<complete fixed file>\n```"
                    )
                    response = self.groq_client.generate(
                        system_prompt=(
                            "You are a senior PHP engineer. Fix ONLY the reported "
                            "syntax errors. Preserve every other aspect of the code. "
                            "Output MUST be a ```php block preceded by ### CHANGES:."
                        ),
                        user_content=fix_prompt,
                        temperature=0.0,
                    )
                    # Extract the ```php block from the response
                    import re as _re
                    m = _re.search(r"```php\s*(.*?)\s*```", response, _re.DOTALL)
                    return m.group(1) if m else prev_code

                final_code, validated, reason = validate_with_retry(
                    code=upgraded_code,
                    original_code=original_code,
                    language="php",
                    retry_fn=_php_syntax_retry,
                    max_retries=2,
                )
                if validated:
                    if "retry" in reason:
                        stats["validation_retried"] += 1
                    else:
                        stats["validated_clean"] += 1
                else:
                    stats["validation_failed"] += 1
                    logger.warning(
                        "   %s: syntax validation failed (%s); keeping original",
                        rel_path, reason,
                    )
                    changes = []
                upgraded_code = final_code

                if changes:
                    results.append({
                        "path": rel_str, "code": upgraded_code, "changes": changes,
                        "validated": True,
                    })
                    stats["upgraded"] += 1
                    logger.info("   %d change(s) applied", len(changes))
                else:
                    results.append({
                        "path": rel_str, "code": upgraded_code, "changes": [],
                        "validated": validated,
                        "validation_reason": reason if not validated else None,
                    })
                    stats["unchanged"] += 1

                if on_progress:
                    on_progress(i, total, rel_str, "done")

            except Exception as e:
                stats["errors"] += 1
                logger.error("   Error modernizing %s: %s", rel_path, e)
                if on_progress:
                    on_progress(i, total, rel_str, f"error: {e}")

        return {"stats": stats, "files": results}

    def _modernize_large_file(
        self, source_file: Path, rel_path: str, to_version: str
    ):
        """
        Modernize a file that exceeds MAX_LLM_FILE_BYTES.

        Uses the language-agnostic tree-sitter splitter (`app.services.code_splitter`)
        to find real top-level block boundaries (functions, classes, methods)
        for any supported language (PHP, JS/TS, Python, C#, Java, Go, etc.).

        If the splitter cannot produce valid chunks (e.g. a single function is
        larger than the cap, or the language is unsupported and byte-chunking
        is also unsafe), the file is flagged as failed per pipeline policy:
        this method raises, the caller records it in `stats['errors']`, and no
        partial/broken code is written back.

        Returns (upgraded_code, changes_list).
        """
        from app.services.code_splitter import split_code  # local import: avoids startup cost

        with open(source_file, "r", encoding="utf-8", errors="ignore") as f:
            full_code = f.read()

        chunk_size = int(self.MAX_LLM_FILE_BYTES * 0.9)  # 10% safety margin
        # Best-effort language detection from extension; the splitter falls
        # back to byte chunks for unknown languages.
        ext = Path(rel_path).suffix.lower()
        language_hint = _EXT_TO_LANGUAGE.get(ext, "generic")

        try:
            chunks = split_code(full_code, language=language_hint, max_bytes=chunk_size)
        except ValueError as e:
            logger.warning(
                "   Cannot split %s cleanly (%s). Recording as failed; no write-back.",
                rel_path, e,
            )
            raise

        if len(chunks) == 1:
            return self._modernize_file(chunks[0][0], rel_path, to_version)

        logger.info(
            "   %s: split into %d language-aware chunks (lang=%s)",
            rel_path, len(chunks), language_hint,
        )

        all_changes: List[str] = []
        assembled_parts: List[str] = []

        for idx, (chunk_code, label) in enumerate(chunks, 1):
            logger.info(
                "   chunk %d/%d (%s, %d bytes)",
                idx, len(chunks), label, len(chunk_code.encode()),
            )
            upgraded_chunk, chunk_changes = self._modernize_file(
                chunk_code,
                f"{rel_path} [{label}]",
                to_version,
            )
            assembled_parts.append(upgraded_chunk)
            all_changes.extend(chunk_changes)

        upgraded_code = "".join(assembled_parts)
        return upgraded_code, all_changes
    
    def _get_sonarqube_context_for_file(self, file_path: str) -> str:
        """
        Extract from the SonarQube report the issues for this file.
        Report format: ## ISSUES BY FILE, then ### <file_path> with per-issue lines.
        Falls back to full report (truncated) if no file-specific section found.
        """
        if not self.sonarqube_report:
            return "Not available"
        # Normalize: allow match by full path or basename
        base = Path(file_path).name
        report = self.sonarqube_report
        # Find "## ISSUES BY FILE" and then look for ### <path> matching this file
        by_file = report.find("## ISSUES BY FILE")
        if by_file == -1:
            return report[:5000] if len(report) > 5000 else report
        section = report[by_file:]
        # Find subsection for this file: ### path/to/file.php or ### file.php
        sub_start = -1
        for line in section.split("\n"):
            stripped = line.strip()
            if stripped.startswith("### "):
                heading_path = stripped[4:].strip()
                if heading_path == file_path or heading_path.endswith("/" + file_path) or Path(heading_path).name == base:
                    sub_start = by_file + section.find(stripped)
                    break
        if sub_start == -1:
            return report[:5000] if len(report) > 5000 else report
        # From sub_start to next ### or ## (next subsection)
        rest = report[sub_start:]
        pos = rest.find("\n### ", 1)
        pos2 = rest.find("\n## ", 1)
        if pos2 != -1 and (pos == -1 or pos2 < pos):
            pos = pos2
        if pos != -1:
            rest = rest[:pos]
        file_section = rest.strip()
        return file_section if file_section else (report[:5000] if len(report) > 5000 else report)

    def _get_project_structure_context(self, current_file_path: str) -> str:
        """
        Format project structure for LLM context so it can analyze the project layout.
        Uses self.project_structure set by analyze_structure().
        """
        if not self.project_structure or not self.project_structure.get("files"):
            return "Project structure not available (single file or not yet analyzed)."
        total = self.project_structure.get("total_files", 0)
        files = self.project_structure.get("files", [])
        lines = [f"Total PHP files in project: {total}", ""]
        for f in files[:200]:  # cap at 200 paths to avoid huge prompts
            path = f.get("path", "")
            size = f.get("size", 0)
            marker = "  <-- CURRENT FILE" if path == current_file_path else ""
            lines.append(f"  - {path} ({size:,} chars){marker}")
        if len(files) > 200:
            lines.append(f"  ... and {len(files) - 200} more files")
        return "\n".join(lines)

    def _modernize_file(self, code: str, file_path: str, to_version: str):
        """Modernize a single PHP file using SonarQube findings and project structure only."""

        sonar_context = self._get_sonarqube_context_for_file(file_path)
        structure_context = self._get_project_structure_context(file_path)

        prompt = f"""You are upgrading a single PHP file for an automated modernization pipeline. Your output must be parseable: exactly the sections ### CHANGES: and ### UPGRADED CODE: with valid PHP in the code block.

WORKFLOW:
1. Identify every SonarQube issue that applies to this file (match by file path in the report). For each, apply the stated Remediation exactly as described.
2. Produce one upgraded file that fixes all applicable SonarQube findings and remains valid, idiomatic PHP for PHP {to_version}. Do not invent extra refactors beyond what the Sonar remediations require. Do not add or remove functionality; preserve behavior; preserve comments and structure where they do not conflict with fixes.

**PROJECT STRUCTURE:**
{structure_context}

**SONARQUBE ISSUES FOR THIS FILE (fix every one using the Remediation given):**
{sonar_context}

**FILE TO UPGRADE:** {file_path}

**CURRENT CODE:**
```php
{code}
```

**REQUIRED OUTPUT FORMAT (do not omit or reorder):**

### CHANGES:
- [One line per change, or "No changes needed."]

### UPGRADED CODE:
```php
[Complete file contents; valid PHP; must start with <?php if the original had it]
```"""

        response = self.groq_client.generate(
            system_prompt=(
                f"You are a PHP code modernization expert. Output MUST include exactly ### CHANGES: and ### UPGRADED CODE: "
                f"with one ```php block. Apply every SonarQube Remediation listed for this file. Target PHP {to_version}. "
                f"Preserve behavior; do not add/remove features. No PHP manual or Laravel docs — Sonar guide only."
            ),
            user_content=prompt,
            temperature=0.7,
        )
        
        # Parse response
        changes = []
        upgraded_code = code  # Default to original
        
        # Extract changes
        changes_match = re.search(r'### CHANGES:(.*?)(?:### UPGRADED CODE:|```php)', response, re.DOTALL)
        if changes_match:
            changes_text = changes_match.group(1).strip()
            if "no changes needed" not in changes_text.lower():
                changes = [c.strip() for c in re.findall(r'-\s*(.+)', changes_text)]
        
        # Extract upgraded code
        code_match = re.search(r'```php\s*(.*?)\s*```', response, re.DOTALL)
        if code_match:
            upgraded_code = code_match.group(1).strip()
            if not upgraded_code.startswith('<?php'):
                upgraded_code = '<?php\n' + upgraded_code
        
        return upgraded_code, changes
    
    # ============================================================================
    # STEP 5: SAVE TO CLIENT SERVER
    # ============================================================================

    def _resolved_upgraded_codes_output_dir(
        self, client_server_path: str, project_name: str
    ) -> Path:
        """
        Resolve ``.../upgraded-codes/upgraded_{project}_{timestamp}/`` for writing outputs.

        For typical Linux paths ``/home/{user}/...``, uses ``/home/{user}/upgraded-codes/``.
        Otherwise uses ``{parent-of-project}/upgraded-codes/`` relative to ``client_server_path``.
        """
        p = Path(client_server_path).expanduser()
        try:
            p = p.resolve()
        except OSError:
            pass
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_folder = f"upgraded_{project_name}_{ts}"
        parts = p.parts
        if (
            len(parts) >= 3
            and parts[0] == "/"
            and parts[1] == "home"
            and parts[2]
        ):
            user_home = Path("/") / "home" / parts[2]
            return user_home / REMOTE_UPGRADED_CODES_DIR / run_folder
        return p.parent / REMOTE_UPGRADED_CODES_DIR / run_folder

    def save_to_server(self, files: List[Dict], client_server_path: str, 
                      project_name: str) -> bool:
        """
        Save modernized code under the client's ``upgraded-codes`` directory
        (``.../upgraded-codes/upgraded_{project_name}_{timestamp}/``).
        
        Args:
            files: List of file dictionaries with code
            client_server_path: Project (or server) path used to infer home / parent for ``upgraded-codes``
            project_name: Project name
            
        Returns:
            True if successful
        """
        logger.info("Saving to client server under %s", REMOTE_UPGRADED_CODES_DIR)
        
        output_path = self._resolved_upgraded_codes_output_dir(client_server_path, project_name)
        output_path.mkdir(parents=True, exist_ok=True)
        logger.info("Modernized files output directory: %s", output_path)
        
        try:
            saved_count = 0
            for file_info in files:
                file_path = output_path / file_info['path']
                file_path.parent.mkdir(parents=True, exist_ok=True)
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(file_info['code'])
                
                saved_count += 1
            
            # Save changelog
            changelog_path = output_path / "MODERNIZATION_LOG.json"
            with open(changelog_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'timestamp': datetime.now().isoformat(),
                    'files': [{
                        'path': f['path'],
                        'changes_count': len(f['changes']),
                        'changes': f['changes']
                    } for f in files]
                }, f, indent=2)
            
            logger.info("Saved %s files to %s", saved_count, output_path)
            logger.info("Changelog: %s", changelog_path)
            
            return True
            
        except Exception as e:
            logger.error("Error saving: %s", e)
            return False
    
    # ============================================================================
    # MAIN EXECUTION
    # ============================================================================
    
    def execute(self, state: AgentState) -> AgentState:
        """
        Execute modernization workflow
        
        Expected state parameters:
        - client_server_path: Path on client server
        - project_name: Project name
        - to_version: Target PHP version
        """
        try:
            client_server_path = state.context.get('client_server_path')
            project_name = state.context.get('project_name')
            to_version = state.context.get('to_version')
            
            # Step 1: Fetch project
            local_path = f"/tmp/{project_name}"
            if not self.fetch_project(client_server_path, local_path):
                state.add_error("Failed to fetch project")
                return state
            
            # Step 2: Analyze structure
            self.analyze_structure(local_path)
            
            # Step 3: Load SonarQube guide
            if not self.load_reports(project_name):
                state.add_error("Failed to load SonarQube upgrade guide")
                return state
            
            # Step 4: Modernize code
            results = self.modernize_project(local_path, to_version)
            
            # Step 5: Save to server
            self.save_to_server(
                results['files'],
                client_server_path,
                project_name
            )
            
            # Store results
            state.add_result("modernization_stats", results['stats'])
            
            logger.info("Modernization completed: upgraded=%s, unchanged=%s, errors=%s",
                        results["stats"]["upgraded"], results["stats"]["unchanged"], results["stats"]["errors"])
            
            return state
            
        except Exception as e:
            state.add_error(f"Modernization failed: {str(e)}")
            return state
