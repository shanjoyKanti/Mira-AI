"""
Generic, language-agnostic code modernization agent.

This is the pipeline plumbing for languages other than PHP. It is NOT tuned
per-language — the prompt is generic and will give a "reasonable first pass,
needs human review" result. That's consistent with what industry tools
(Amazon Q Developer Transformations, GitHub Copilot) ship for languages
outside their primary focus.

Responsibilities:
  * Walk the project directory for files matching the target language's
    extensions.
  * Apply the shared skip filter (vendor/, node_modules/, binaries, minified).
  * For each file, call the tree-sitter splitter to get syntactically-whole
    chunks that fit within MAX_LLM_FILE_BYTES.
  * For each chunk, build a migration prompt including target_version context
    pulled from the RAG adapter (falls back gracefully if RAG is unavailable),
    call GroqClient, and collect the upgraded code.
  * Concatenate chunks and emit a result dict with the same shape as
    PHPModernizationAgent.modernize_project.
  * Support per-file checkpointing via `on_progress` + `already_completed`.
  * Treat an oversized-indivisible-block file as failed (no partial writes)
    per the project's all-or-nothing policy.

Design notes:
  * We deliberately do NOT reuse PHPModernizationAgent — that class is
    tightly bound to SonarQube-guide-driven PHP prompts. Forcing it to
    handle other languages would corrupt PHP accuracy.
  * The prompt is kept short and JSON-driven so we can extend per-language
    nuance later without rewriting the agent.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from app.services.agents.base_agent import GroqClient

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Language → file glob patterns (matches _LANGUAGE_EXTENSIONS in agents/routes.py)
# ---------------------------------------------------------------------------
_LANGUAGE_FILE_GLOBS: Dict[str, List[str]] = {
    "python":     ["*.py"],
    "javascript": ["*.js", "*.mjs", "*.cjs", "*.jsx"],
    "typescript": ["*.ts", "*.tsx"],
    "java":       ["*.java"],
    "kotlin":     ["*.kt", "*.kts"],
    "go":         ["*.go"],
    "ruby":       ["*.rb"],
    "rust":       ["*.rs"],
    "csharp":     ["*.cs"],
    "c_sharp":    ["*.cs"],
    "cpp":        ["*.cpp", "*.cc", "*.cxx", "*.h", "*.hpp"],
    "c":          ["*.c", "*.h"],
    "scala":      ["*.scala"],
    "swift":      ["*.swift"],
}

# Language → tree-sitter language name (used by the splitter)
_LANGUAGE_TO_TREESITTER: Dict[str, str] = {
    "python":     "python",
    "javascript": "javascript",
    "typescript": "typescript",
    "java":       "java",
    "kotlin":     "kotlin",
    "go":         "go",
    "ruby":       "ruby",
    "rust":       "rust",
    "csharp":     "c_sharp",
    "c_sharp":    "c_sharp",
    "cpp":        "cpp",
    "c":          "c",
    "scala":      "scala",
    "swift":      "swift",
}


class GenericModernizationAgent:
    """
    Language-agnostic modernization agent. Drop-in replacement for
    PHPModernizationAgent.modernize_project() for non-PHP languages.

    Usage:
        agent = GenericModernizationAgent(language="javascript", from_version="es2018")
        # optional: load framework/migration docs, similar to PHPModernizationAgent.load_reports
        agent.load_migration_context(from_version="es2018", to_version="es2024")
        result = agent.modernize_project(project_path, to_version="es2024")
    """

    # Default max bytes per single LLM call. Can be overridden via env
    # MIRA_MAX_LLM_FILE_BYTES elsewhere; we pass chunk_size to the splitter.
    MAX_LLM_FILE_BYTES: int = 500_000  # 500 KB ≈ 125K tokens, safely under Qwen3-32B's 131K window

    def __init__(
        self,
        language: str,
        from_version: Optional[str] = None,
        groq_client: Optional[GroqClient] = None,
    ):
        self.language = (language or "").strip().lower()
        if not self.language:
            raise ValueError("GenericModernizationAgent requires a non-empty language name")
        self.from_version = from_version or ""
        # Share a single GroqClient across all language agents in the same
        # pipeline (audit finding #5). Each GroqClient has its own rate-limit
        # throttle; if each language got its own, N parallel languages would
        # burst N concurrent requests past the 3-req shared budget.
        self.groq_client = groq_client or GroqClient()
        # Migration context text (rule list, breaking changes, etc.) — filled by load_migration_context().
        self._migration_context: str = ""
        self._tree_sitter_lang = _LANGUAGE_TO_TREESITTER.get(self.language, self.language)
        # Cross-file reasoning — populated per run, consulted by each file's prompt.
        from app.services.agents.migration_state import ProjectMigrationState
        self.migration_state = ProjectMigrationState(language=self.language)

    # -----------------------------------------------------------------
    # Context loading (pulls from RAG if available; best-effort)
    # -----------------------------------------------------------------

    def load_migration_context(
        self,
        from_version: Optional[str] = None,
        to_version: Optional[str] = None,
        framework: Optional[str] = None,
    ) -> None:
        """
        Populate self._migration_context with migration rules/notes for the
        given language + version jump. Uses a per-process prompt cache so
        repeated calls within the same process (common in a multi-file
        pipeline) don't redo the RAG fetch.
        """
        if from_version:
            self.from_version = from_version

        # Fast path: prompt cache. This is the single biggest token-saver
        # across a multi-file pipeline — without it, every file would pay
        # the RAG web-scraping cost.
        from app.services.agents.prompt_cache import get_or_populate

        def _do_fetch() -> Dict[str, Any]:
            try:
                from app.services.rag.rag_adapter import RagAdapter  # heavy dep
                adapter = RagAdapter()
                docs = adapter.fetch_migration_docs(
                    language=self.language,
                    framework=framework,
                    from_v=self.from_version or "",
                    to_v=to_version or "",
                )
            except Exception as e:
                logger.warning(
                    "GenericModernizationAgent[%s]: RAG load failed (%s); running without migration docs",
                    self.language, e,
                )
                return {"migration_context": ""}
            if not docs:
                return {"migration_context": ""}
            pieces = []
            for d in docs[:4]:
                content = getattr(d, "content", None) or (d.get("content") if isinstance(d, dict) else "")
                if content:
                    pieces.append(content[:8000])
            ctx = "\n\n---\n\n".join(pieces)[:24_000]
            logger.info(
                "GenericModernizationAgent[%s]: loaded %d doc(s), %d chars context",
                self.language, len(docs), len(ctx),
            )
            return {"migration_context": ctx}

        entry = get_or_populate(
            language=self.language,
            from_version=self.from_version or "",
            to_version=to_version or "",
            framework=framework or "",
            populate_fn=_do_fetch,
        )
        self._migration_context = entry.get("migration_context", "")
        return

        # Unreachable — kept so the old try/except structure below doesn't
        # syntax-break if future edits restore the direct-call path.
        try:  # pragma: no cover
            from app.services.rag.rag_adapter import RagAdapter
            adapter = RagAdapter()
            docs = adapter.fetch_migration_docs(
                language=self.language,
                framework=framework,
                from_v=self.from_version or "",
                to_v=to_version or "",
            )
            if docs:
                # Collapse stage docs into a single truncated context block
                pieces = []
                for d in docs[:4]:  # cap at 4 stages to bound prompt size
                    content = getattr(d, "content", None) or (d.get("content") if isinstance(d, dict) else "")
                    if content:
                        pieces.append(content[:8000])
                self._migration_context = "\n\n---\n\n".join(pieces)[:24_000]  # hard cap ~24 KB
                logger.info(
                    "GenericModernizationAgent[%s]: loaded %d doc(s), %d chars context",
                    self.language, len(docs), len(self._migration_context),
                )
        except Exception as e:
            logger.warning(
                "GenericModernizationAgent[%s]: RAG load failed (%s); running without migration docs",
                self.language, e,
            )

    # -----------------------------------------------------------------
    # Main entry point (same signature as PHPModernizationAgent.modernize_project)
    # -----------------------------------------------------------------

    def modernize_project(
        self,
        project_path: str,
        to_version: str,
        on_progress: Optional[Callable[[int, int, str, str], None]] = None,
        already_completed: Optional[Set[str]] = None,
    ) -> Dict[str, Any]:
        """
        Modernize every source file for self.language in the project.

        Returns:
            {"stats": {"total": N, "upgraded": X, "unchanged": Y, "errors": Z, ...},
             "files": [{"path": "...", "code": "...", "changes": [...]}, ...]}
        """
        project_dir = Path(project_path)
        if not project_dir.is_dir():
            raise ValueError(f"project_path is not a directory: {project_path}")

        # Shared skip filter — identical policy to analyze flow and PHP agent.
        try:
            from app.api.v1.analyze.utils import should_skip_path as _should_skip
        except Exception:
            _should_skip = lambda p: (
                any(x in p.split("/") for x in ["vendor", "node_modules", ".git", "dist", "build"]),
                "legacy",
            )

        globs = _LANGUAGE_FILE_GLOBS.get(self.language)
        if not globs:
            logger.warning(
                "GenericModernizationAgent[%s]: no file globs registered; returning empty result",
                self.language,
            )
            return {
                "stats": {"total": 0, "upgraded": 0, "unchanged": 0, "errors": 0,
                          "skipped_large": 0, "skipped_resume": 0},
                "files": [],
            }

        # Collect and sort files
        source_files: List[Path] = []
        for pat in globs:
            for f in project_dir.rglob(pat):
                if not f.is_file():
                    continue
                rel = str(f.relative_to(project_dir))
                skip, _reason = _should_skip(rel)
                if skip:
                    continue
                source_files.append(f)
        source_files = sorted(set(source_files), key=str)

        total = len(source_files)
        stats: Dict[str, int] = {
            "total": total,
            "upgraded": 0, "unchanged": 0, "errors": 0,
            "skipped_large": 0, "skipped_resume": 0,
            # Validation counters: files where the LLM produced code that didn't
            # parse after all retries. These fall back to the original code and
            # count as `validation_failed`, but the file still lands in results.
            "validated_clean": 0, "validation_retried": 0, "validation_failed": 0,
        }
        results: List[Dict[str, Any]] = []
        completed_set = already_completed or set()

        logger.info(
            "GenericModernizationAgent[%s]: found %d file(s) to modernize to %s",
            self.language, total, to_version,
        )

        for i, source_file in enumerate(source_files, 1):
            rel_path = source_file.relative_to(project_dir)
            rel_str = str(rel_path)

            if rel_str in completed_set:
                stats["skipped_resume"] += 1
                if on_progress:
                    on_progress(i, total, rel_str, "skipped_resume")
                continue

            if on_progress:
                on_progress(i, total, rel_str, "start")

            try:
                with open(source_file, "r", encoding="utf-8", errors="ignore") as fh:
                    original_code = fh.read()
            except Exception as read_err:
                logger.error("   read failed %s: %s", rel_path, read_err)
                stats["errors"] += 1
                if on_progress:
                    on_progress(i, total, rel_str, f"error: {read_err}")
                continue

            try:
                if len(original_code.encode("utf-8")) > self.MAX_LLM_FILE_BYTES:
                    upgraded_code, changes = self._modernize_large_file(original_code, rel_str, to_version)
                else:
                    upgraded_code, changes = self._modernize_chunk(original_code, rel_str, to_version)
            except ValueError as split_err:
                # Oversized indivisible block — per policy, record file as failed, do not write partial.
                logger.warning("   splitter refused %s: %s", rel_path, split_err)
                stats["errors"] += 1
                if on_progress:
                    on_progress(i, total, rel_str, f"error: {split_err}")
                continue
            except Exception as e:
                logger.error("   modernization error for %s: %s", rel_path, e)
                stats["errors"] += 1
                if on_progress:
                    on_progress(i, total, rel_str, f"error: {e}")
                continue

            # ─── Syntax validation ──────────────────────────────────────
            # Parse the upgraded code with tree-sitter. If it doesn't parse,
            # ask the LLM to fix its own output; if still broken after retries,
            # fall back to the original file (per the all-or-nothing policy)
            # and record the failure in stats but DON'T abort the pipeline.
            from app.services.code_validator import validate_with_retry

            def _syntax_retry_fn(prev_code: str, errors_text: str) -> str:
                fix_up, _fix_changes = self._modernize_chunk_with_fix(
                    prev_code, rel_str, to_version, errors_text,
                )
                return fix_up

            final_code, validated, reason = validate_with_retry(
                code=upgraded_code,
                original_code=original_code,
                language=self._tree_sitter_lang,
                retry_fn=_syntax_retry_fn,
                max_retries=2,
            )
            if validated:
                if "retry" in reason:
                    stats["validation_retried"] += 1
                else:
                    stats["validated_clean"] += 1
            else:
                stats["validation_failed"] += 1
                # Log a short excerpt of the broken response at WARN so ops can diagnose
                # why the LLM produced unparseable output. Without this excerpt the only
                # signal is "validation_failed=1" with no way to see what went wrong.
                _excerpt = (upgraded_code or "")[:500].replace("\n", "\\n")
                logger.warning(
                    "   %s: syntax validation failed (%s); keeping original. "
                    "LLM response excerpt: %r",
                    rel_path, reason, _excerpt,
                )
                # Surface the excerpt on the per-file stat so the frontend/validation
                # report can show the user WHY a file was skipped, not just that it was.
                try:
                    stats.setdefault("validation_failures", []).append({
                        "file": rel_path,
                        "reason": reason,
                        "llm_excerpt": _excerpt,
                    })
                except Exception:
                    pass
                changes = []  # clear — we didn't actually apply the broken changes

            upgraded_code = final_code

            # ─── Cross-file reasoning: extract contract-change summary ──
            # Only if the file was actually upgraded AND the diff is non-trivial.
            # This is one extra LLM call per file; costs ~40% more tokens but
            # keeps multi-file migrations internally consistent.
            if validated and changes and upgraded_code != original_code:
                try:
                    self._extract_contract_changes(original_code, upgraded_code, rel_str)
                except Exception as state_err:
                    # Non-fatal: worst case is less context for later files.
                    logger.debug("contract-summary extract failed for %s: %s", rel_str, state_err)

            if changes:
                results.append({
                    "path": rel_str, "code": upgraded_code, "changes": changes,
                    "validated": True,
                })
                stats["upgraded"] += 1
            else:
                results.append({
                    "path": rel_str, "code": upgraded_code, "changes": [],
                    "validated": validated,
                    "validation_reason": reason if not validated else None,
                })
                stats["unchanged"] += 1

            if on_progress:
                on_progress(i, total, rel_str, "done")

        logger.info(
            "GenericModernizationAgent[%s]: done — %d/%d upgraded, %d unchanged, %d errors",
            self.language, stats["upgraded"], total, stats["unchanged"], stats["errors"],
        )
        return {"stats": stats, "files": results}

    # -----------------------------------------------------------------
    # Per-chunk LLM call
    # -----------------------------------------------------------------

    def _modernize_chunk(self, code: str, rel_path: str, to_version: str):
        """Send one chunk of code to the LLM and return (upgraded_code, changes_list)."""
        from app.services.agents.language_prompts import get_system_prompt

        # Use the tuned per-language prompt when available; falls back to a
        # generic template for languages without a specific one.
        system_prompt = get_system_prompt(
            language=self.language,
            to_version=to_version,
            from_version=self.from_version or "",
        )

        # Inject the accumulated cross-file contract changes so this file
        # stays consistent with prior renames / signature changes / import
        # replacements in the same run.
        contract_block = self.migration_state.as_prompt_block() if hasattr(self, "migration_state") else ""

        ctx_block = f"\n\n## MIGRATION CONTEXT (from official docs):\n{self._migration_context}\n" \
            if self._migration_context else ""

        user_prompt = (
            f"FILE: {rel_path}\n"
            f"TARGET {self.language.upper()} VERSION: {to_version}"
            f"{(' (from ' + self.from_version + ')') if self.from_version else ''}"
            f"{ctx_block}\n"
            f"{contract_block}\n"
            f"## ORIGINAL CODE:\n```{self.language}\n{code}\n```\n\n"
            f"Return the modernized file in this exact format:\n"
            f"### CHANGES:\n- <change 1>\n- <change 2>\n\n"
            f"### UPGRADED CODE:\n```{self.language}\n<complete file contents>\n```"
        )

        response = self.groq_client.generate(
            system_prompt=system_prompt,
            user_content=user_prompt,
            temperature=0.2,  # low but nonzero — code modernization benefits from minor creativity
        )

        return self._parse_response(response, fallback_code=code)

    def _extract_contract_changes(self, original_code: str, upgraded_code: str, rel_path: str) -> int:
        """Ask the LLM for a small JSON summary of contract-level changes in
        this file's diff. Feeds self.migration_state so subsequent files can
        stay consistent. Best-effort — on any failure we just skip this file's
        contribution to the state."""
        from app.services.agents.migration_state import (
            CONTRACT_SUMMARY_SYSTEM_PROMPT,
            CONTRACT_SUMMARY_USER_TEMPLATE,
        )
        # Cap the diff size we send — full original+upgraded would double token
        # cost. 4 KB per side is enough for most signature-level changes.
        cap = 4000
        orig_snippet = original_code[:cap] + ("\n... [truncated]" if len(original_code) > cap else "")
        up_snippet = upgraded_code[:cap] + ("\n... [truncated]" if len(upgraded_code) > cap else "")
        prompt = CONTRACT_SUMMARY_USER_TEMPLATE.format(
            language=self.language,
            original=orig_snippet,
            upgraded=up_snippet,
        )
        try:
            response = self.groq_client.generate(
                system_prompt=CONTRACT_SUMMARY_SYSTEM_PROMPT,
                user_content=prompt,
                temperature=0.0,
                max_tokens=1000,
            )
        except Exception as e:
            logger.debug("contract-summary LLM call failed for %s: %s", rel_path, e)
            return 0
        added = self.migration_state.ingest_llm_summary(rel_path, response)
        if added:
            logger.info("   %s: recorded %d contract change(s) into project state", rel_path, added)
        return added

    def _modernize_chunk_with_fix(
        self,
        broken_code: str,
        rel_path: str,
        to_version: str,
        errors_text: str,
    ):
        """Retry pass: ask the LLM to fix syntax errors in its own prior output.

        The error messages from tree-sitter are included verbatim so the model
        knows exactly what broke (e.g. 'line 42: MISSING missing }').
        """
        system_prompt = (
            f"You are a senior {self.language} engineer. The previous attempt "
            f"to modernize this file produced code with SYNTAX ERRORS. Fix ONLY "
            f"the syntax errors; preserve all other logic. Output MUST be the "
            f"complete corrected file in a single ```{self.language} block, "
            f"preceded by ### CHANGES: describing what you fixed."
        )
        user_prompt = (
            f"FILE: {rel_path}\n"
            f"TARGET {self.language.upper()} VERSION: {to_version}\n\n"
            f"## SYNTAX ERRORS REPORTED BY PARSER:\n{errors_text}\n\n"
            f"## BROKEN CODE (fix the errors above without changing logic):\n"
            f"```{self.language}\n{broken_code}\n```\n\n"
            f"Return the FIXED file in this exact format:\n"
            f"### CHANGES:\n- <what you fixed>\n\n"
            f"### UPGRADED CODE:\n```{self.language}\n<complete fixed file>\n```"
        )
        response = self.groq_client.generate(
            system_prompt=system_prompt,
            user_content=user_prompt,
            temperature=0.0,  # deterministic — we want the minimal syntax fix
        )
        return self._parse_response(response, fallback_code=broken_code)

    def _modernize_large_file(self, full_code: str, rel_path: str, to_version: str):
        """Split the file with tree-sitter, modernize each chunk, reassemble."""
        from app.services.code_splitter import split_code

        chunk_size = int(self.MAX_LLM_FILE_BYTES * 0.9)  # 10% safety margin for prompt wrapper
        chunks = split_code(full_code, language=self._tree_sitter_lang, max_bytes=chunk_size)

        if len(chunks) == 1:
            return self._modernize_chunk(chunks[0][0], rel_path, to_version)

        logger.info(
            "   %s: %d language-aware chunk(s) (lang=%s)",
            rel_path, len(chunks), self._tree_sitter_lang,
        )

        assembled: List[str] = []
        all_changes: List[str] = []
        for idx, (chunk_text, label) in enumerate(chunks, 1):
            logger.info("   chunk %d/%d (%s, %d bytes)", idx, len(chunks), label, len(chunk_text.encode()))
            up, ch = self._modernize_chunk(chunk_text, f"{rel_path} [{label}]", to_version)
            assembled.append(up)
            all_changes.extend(ch)

        return "".join(assembled), all_changes

    # -----------------------------------------------------------------
    # Response parsing
    # -----------------------------------------------------------------

    _CHANGES_RE = re.compile(r"###\s*CHANGES\s*:?\s*(.*?)(?=###\s*UPGRADED\s*CODE|```)", re.DOTALL | re.IGNORECASE)
    _CODE_RE = re.compile(r"```(?:[a-zA-Z_#+]+)?\s*(.*?)\s*```", re.DOTALL)

    @classmethod
    def _parse_response(cls, response: str, fallback_code: str):
        """
        Extract (upgraded_code, changes_list) from the LLM's response.
        Falls back to the original code if we can't find a valid code block —
        this is safer than writing garbage.
        """
        if not response:
            return fallback_code, []

        # Pull changes bullets
        changes: List[str] = []
        m_changes = cls._CHANGES_RE.search(response)
        if m_changes:
            block = m_changes.group(1)
            for line in block.splitlines():
                stripped = line.strip().lstrip("-*•").strip()
                if stripped:
                    changes.append(stripped)

        # Pull the UPGRADED CODE block. Prefer the code block that appears
        # after "### UPGRADED CODE"; if not labelled, take the last fenced block.
        upgraded_match = re.search(
            r"###\s*UPGRADED\s*CODE\s*:?\s*```(?:[a-zA-Z_#+]+)?\s*(.*?)\s*```",
            response, re.DOTALL | re.IGNORECASE,
        )
        if upgraded_match:
            upgraded = upgraded_match.group(1)
        else:
            all_blocks = cls._CODE_RE.findall(response)
            upgraded = all_blocks[-1] if all_blocks else fallback_code

        upgraded = upgraded.strip("\n")
        # If the LLM returned an essentially empty or broken block, keep the original.
        if not upgraded.strip():
            return fallback_code, []
        return upgraded, changes
