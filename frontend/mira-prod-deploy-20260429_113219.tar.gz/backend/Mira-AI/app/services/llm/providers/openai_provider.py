"""OpenAI LLM provider"""
from typing import List, Dict, Any, AsyncIterator
from openai import OpenAI
from app.services.llm.base_provider import BaseLLMProvider, LLMMessage, LLMResponse
from app.core.logging import get_logger

logger = get_logger(__name__)


class OpenAIProvider(BaseLLMProvider):
    """OpenAI GPT provider"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        api_key = config.get("api_key")
        if not api_key:
            raise ValueError("OpenAI API key is required")
        
        self.client = OpenAI(api_key=api_key)
        self.model = config.get("model", "gpt-4-turbo-preview")
    
    def generate(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Generate response using OpenAI"""
        try:
            formatted_messages = [
                {"role": msg.role, "content": msg.content}
                for msg in messages
            ]
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=formatted_messages,
                temperature=kwargs.get("temperature", self.temperature),
                max_tokens=kwargs.get("max_tokens", self.max_tokens)
            )
            
            return LLMResponse(
                content=response.choices[0].message.content,
                model=response.model,
                usage={
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens
                } if response.usage else None,
                finish_reason=response.choices[0].finish_reason
            )
        except Exception as e:
            logger.error(f"OpenAI generation failed: {str(e)}", exc_info=True)
            raise
    
    async def agenerate(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Async generate response using OpenAI"""
        # OpenAI client doesn't have async, so we use sync in async context
        import asyncio
        return await asyncio.to_thread(self.generate, messages, **kwargs)
    
    async def stream(self, messages: List[LLMMessage], **kwargs) -> AsyncIterator[str]:
        """Stream responses from OpenAI"""
        formatted_messages = [
            {"role": msg.role, "content": msg.content}
            for msg in messages
        ]
        
        try:
            stream = self.client.chat.completions.create(
                model=self.model,
                messages=formatted_messages,
                temperature=kwargs.get("temperature", self.temperature),
                max_tokens=kwargs.get("max_tokens", self.max_tokens),
                stream=True
            )
            
            for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            logger.error(f"OpenAI streaming failed: {str(e)}", exc_info=True)
            raise
    
    def validate_config(self) -> bool:
        """Validate OpenAI configuration"""
        return bool(self.config.get("api_key"))

