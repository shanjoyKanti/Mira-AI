"""Tests for account endpoints"""
import pytest
from fastapi import status


def test_register_user(client):
    """Test user registration"""
    user_data = {
        "email": "newuser@example.com",
        "password": "password123",
        "username": "newuser"
    }
    
    response = client.post("/api/v1/accounts/register", json=user_data)
    assert response.status_code == status.HTTP_201_CREATED
    assert response.json()["email"] == user_data["email"]
    assert "id" in response.json()


def test_register_duplicate_email(client):
    """Test registration with duplicate email"""
    user_data = {
        "email": "duplicate@example.com",
        "password": "password123"
    }
    
    # First registration
    client.post("/api/v1/accounts/register", json=user_data)
    
    # Second registration with same email
    response = client.post("/api/v1/accounts/register", json=user_data)
    assert response.status_code == status.HTTP_400_BAD_REQUEST


def test_login(client, db):
    """Test user login"""
    # Register user
    user_data = {
        "email": "login@example.com",
        "password": "password123"
    }
    client.post("/api/v1/accounts/register", json=user_data)
    
    # Login
    response = client.post("/api/v1/accounts/login", json=user_data)
    assert response.status_code == status.HTTP_200_OK
    assert "access_token" in response.json()
    assert "refresh_token" in response.json()


def test_login_invalid_credentials(client):
    """Test login with invalid credentials"""
    login_data = {
        "email": "invalid@example.com",
        "password": "wrongpassword"
    }
    
    response = client.post("/api/v1/accounts/login", json=login_data)
    assert response.status_code == status.HTTP_401_UNAUTHORIZED


def test_get_current_user(client, auth_headers):
    """Test getting current user info"""
    response = client.get("/api/v1/accounts/me", headers=auth_headers)
    assert response.status_code == status.HTTP_200_OK
    assert "email" in response.json()


def test_update_user(client, auth_headers):
    """Test updating user info"""
    update_data = {"username": "updatedname"}
    
    response = client.put("/api/v1/accounts/me", json=update_data, headers=auth_headers)
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["username"] == "updatedname"
