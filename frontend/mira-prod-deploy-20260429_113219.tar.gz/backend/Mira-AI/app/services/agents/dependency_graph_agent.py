"""
Dependency Graph Agent — Phase 0 of full-stack migration.

Builds a directed graph of which files import / require / use which other
files. Both Mira's migration scheduler and the (planned) Strangler Fig
proxy use this graph to decide *order* — never migrate a dependent before
its dependency, never reroute a frontend page before the API call it
depends on is migrated.

Solves doc Issue I-02:
    "In a full-stack codebase, a single frontend component may call three
    different backend controllers, which each depend on two shared services.
    Without a cross-stack dependency graph, migration agents have no
    awareness of these relationships."

Implementation strategy:
    Like the Contract Extraction Agent, this is a deterministic regex pass
    over source files — no LLM. We extract the most common import idioms per
    language and emit a graph as JSON. Frameworks/idioms we don't recognise
    fall through cleanly: their files appear as nodes with no outgoing edges,
    which is safe (treated as "no known dependencies").

Output graph shape:
    {
      "nodes": [
        {"id": "<rel/path>", "language": "php", "stack": "backend", "kind": "controller"},
        ...
      ],
      "edges": [
        {"from": "<src>", "to": "<dst>", "kind": "use|require|import|api_call"},
        ...
      ],
      "metadata": {...}
    }

Cross-stack edges (frontend → API call → backend route) are intentionally
NOT inferred here — that's a job for the Contract Validation Agent which
correlates frontend `fetch()/axios()` calls against the Contract Registry.
This agent only handles in-stack file-level dependencies.
"""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


_DEFAULT_GRAPH_DIR = Path(
    os.environ.get("MIRA_DEPENDENCY_GRAPH_DIR", "/app/app/data/graphs")
)


def graph_dir_for(project_name: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", project_name or "unknown")
    return _DEFAULT_GRAPH_DIR / safe


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

@dataclass
class GraphNode:
    id: str                          # file path relative to source_root
    language: str = "unknown"
    stack: str = "unknown"           # frontend / backend / api / unknown
    kind: str = "module"             # module / controller / model / view / config / route
    size_bytes: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class GraphEdge:
    src: str
    dst: str
    kind: str = "import"             # import / require / use / include

    def to_dict(self) -> Dict[str, Any]:
        return {"from": self.src, "to": self.dst, "kind": self.kind}


@dataclass
class DependencyGraph:
    project_name: str
    source_root: str
    generated_at: str
    nodes: List[GraphNode] = field(default_factory=list)
    edges: List[GraphEdge] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "project_name": self.project_name,
            "source_root": self.source_root,
            "generated_at": self.generated_at,
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "metadata": self.metadata,
        }


# ---------------------------------------------------------------------------
# Per-language extractors
# ---------------------------------------------------------------------------

# PHP: include / include_once / require / require_once with 'string' or "string"
# expression-form requires (e.g. require __DIR__ . '/foo.php') are partially
# captured — we keep just the literal segment.
_PHP_INCLUDE_RE = re.compile(
    r"""\b(?P<kind>include|include_once|require|require_once)\s*
        \(?\s*
        (?:[^'";]*?)            # leading expression chunks like __DIR__ .
        ['"](?P<path>[^'"]+)['"]
    """,
    re.VERBOSE | re.IGNORECASE,
)
_PHP_USE_RE = re.compile(r"^\s*use\s+(?P<fqcn>[A-Za-z_][\w\\]*)\s*(?:as\s+\w+)?\s*;", re.MULTILINE)

# Node / JS / TS
_JS_IMPORT_RE = re.compile(
    r"""(?:import\s+[^'"]*?from\s+|import\s+|require\s*\(\s*)
        ['"`](?P<path>[^'"`]+)['"`]
    """,
    re.VERBOSE,
)

# Python
_PY_IMPORT_RE = re.compile(
    r"""^\s*(?:from\s+(?P<from_mod>[\w.]+)\s+import\s+[^#\n]+
            |import\s+(?P<imp_mod>[\w.]+(?:\s*,\s*[\w.]+)*))""",
    re.VERBOSE | re.MULTILINE,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _classify_kind(rel_path: str) -> str:
    p = rel_path.lower()
    if "controller" in p:
        return "controller"
    if "/models/" in p or p.endswith("model.php") or p.endswith("model.py"):
        return "model"
    if "/views/" in p or p.endswith((".html", ".vue", ".tsx", ".jsx", ".svelte")):
        return "view"
    if "/routes/" in p or p.endswith(("routes.php", "urls.py")):
        return "route"
    if p.endswith((".env", ".env.local", ".ini", ".conf", ".yaml", ".yml", ".json")):
        return "config"
    return "module"


def _classify_stack(rel_path: str, language: str) -> str:
    """Mirror of routes._classify_file_stack but copied locally to keep this
    module standalone (no cross-imports to the route layer)."""
    p = (rel_path or "").lower()
    ext = "." + p.rsplit(".", 1)[-1] if "." in p else ""
    if ext in (".jsx", ".tsx", ".vue", ".svelte", ".html", ".css", ".scss"):
        return "frontend"
    if ext in (".php", ".py", ".java", ".go", ".rb", ".rs", ".cs"):
        return "backend"
    if ext in (".proto", ".graphql", ".gql"):
        return "api"
    if language in ("javascript", "typescript"):
        if any(h in p for h in ("/frontend/", "/client/", "/components/", "/pages/", "/views/")):
            return "frontend"
        if any(h in p for h in ("/backend/", "/server/", "/controllers/", "/routes/", "/services/")):
            return "backend"
        return "frontend"
    return "backend"


def _resolve_php_include(src_file: str, raw_target: str, source_root: str) -> Optional[str]:
    """Best-effort resolution of a PHP include path to an absolute file path.
    Returns None if we can't be sure (we don't want to invent edges)."""
    if not raw_target:
        return None
    candidate = raw_target.strip().strip("'\"")
    if not candidate:
        return None
    if candidate.startswith(("/", "\\")):
        if os.path.isfile(candidate):
            return candidate
        # Fall through to try project-root-relative below.
        candidate = candidate.lstrip("/\\")
    # Relative to the file that did the include.
    base_dir = os.path.dirname(src_file)
    abs_path = os.path.normpath(os.path.join(base_dir, candidate))
    if os.path.isfile(abs_path):
        return abs_path
    # Sometimes the path is relative to the project root.
    abs_root = os.path.normpath(os.path.join(source_root, candidate))
    if os.path.isfile(abs_root):
        return abs_root
    return None


def _resolve_js_import(src_file: str, raw_target: str, source_root: str) -> Optional[str]:
    """Best-effort JS/TS module path resolution. Skips package imports
    ('react', 'lodash') — they're not project files."""
    if not raw_target or not raw_target.startswith((".", "/")):
        return None  # external package — out of project scope
    base_dir = os.path.dirname(src_file)
    abs_path = os.path.normpath(os.path.join(base_dir, raw_target))
    # Try common JS resolution: as-is, with extensions, as index.*
    candidates = [
        abs_path,
        abs_path + ".js", abs_path + ".jsx", abs_path + ".ts", abs_path + ".tsx",
        os.path.join(abs_path, "index.js"),
        os.path.join(abs_path, "index.ts"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_graph(
    source_root: str,
    project_name: str,
    *,
    files_by_language: Optional[Dict[str, List[str]]] = None,
    save: bool = True,
    max_files_per_language: int = 5000,
) -> DependencyGraph:
    """Walk ``source_root`` and emit a file-level dependency graph.

    Args:
        source_root: Project root.
        project_name: Used for storage path.
        files_by_language: Optional pre-walked file list (e.g. from /migration/estimate).
            When omitted we walk locally and skip the usual junk dirs.
        save: When True, persist to ``{GRAPH_DIR}/<project>/graph-<ts>.json``
            plus a ``graph-latest.json`` for stable lookups.
        max_files_per_language: Soft cap so a 50K-file monorepo doesn't blow
            the parser's memory. The cap applies per-language so a 130-file
            PHP project won't be affected.

    Returns:
        DependencyGraph (in-memory). Persisted to disk too when ``save``.
    """
    src = Path(source_root).resolve()
    g = DependencyGraph(
        project_name=project_name,
        source_root=str(src),
        generated_at=datetime.utcnow().isoformat() + "Z",
    )

    if files_by_language is None:
        files_by_language = _walk_local(src)
    files_by_language = files_by_language or {}

    # Index path → node, so we can dedup edges and keep the node list unique.
    nodes_by_abs: Dict[str, GraphNode] = {}

    # Pre-pass: register every file as a node first. Edges come second so we
    # never reference a missing node.
    for lang, files in files_by_language.items():
        capped = (files or [])[:max_files_per_language]
        if files and len(files) > max_files_per_language:
            g.metadata.setdefault("truncated_languages", []).append(
                {"language": lang, "had": len(files), "kept": max_files_per_language}
            )
        for f in capped:
            try:
                rel = str(Path(f).resolve().relative_to(src))
            except Exception:
                rel = os.path.relpath(f, str(src))
            try:
                size = os.path.getsize(f)
            except OSError:
                size = 0
            n = GraphNode(
                id=rel,
                language=lang,
                stack=_classify_stack(rel, lang),
                kind=_classify_kind(rel),
                size_bytes=size,
            )
            nodes_by_abs[os.path.abspath(f)] = n

    # Edge pass.
    for lang, files in files_by_language.items():
        capped = (files or [])[:max_files_per_language]
        for f in capped:
            try:
                with open(f, "r", encoding="utf-8", errors="replace") as fh:
                    content = fh.read()
            except (OSError, IOError):
                continue
            src_abs = os.path.abspath(f)
            src_node = nodes_by_abs.get(src_abs)
            if src_node is None:
                continue

            if lang == "php":
                for m in _PHP_INCLUDE_RE.finditer(content):
                    target_abs = _resolve_php_include(f, m.group("path"), str(src))
                    if target_abs and target_abs in nodes_by_abs:
                        g.edges.append(GraphEdge(src_node.id, nodes_by_abs[target_abs].id, m.group("kind").lower()))
                # PHP `use` statements (namespace imports) — too noisy to
                # resolve to file paths without a full classmap, but we still
                # attach them as metadata so the graph reader can see them.
                ns_imports = list({m.group("fqcn") for m in _PHP_USE_RE.finditer(content)})
                if ns_imports:
                    g.metadata.setdefault("php_namespace_uses", {})[src_node.id] = ns_imports[:50]
            elif lang in ("javascript", "typescript"):
                for m in _JS_IMPORT_RE.finditer(content):
                    target_abs = _resolve_js_import(f, m.group("path"), str(src))
                    if target_abs and target_abs in nodes_by_abs:
                        g.edges.append(GraphEdge(src_node.id, nodes_by_abs[target_abs].id, "import"))
            elif lang == "python":
                # We don't try to resolve Python imports to filesystem paths
                # (sys.path resolution is too project-specific). We just
                # record the imported module names in metadata.
                modules: Set[str] = set()
                for m in _PY_IMPORT_RE.finditer(content):
                    name = m.group("from_mod") or m.group("imp_mod") or ""
                    for piece in re.split(r"\s*,\s*", name):
                        if piece:
                            modules.add(piece.strip())
                if modules:
                    g.metadata.setdefault("python_imports", {})[src_node.id] = sorted(modules)[:50]

    g.nodes = list(nodes_by_abs.values())

    # Dedup edges (same src→dst→kind triple may appear multiple times).
    seen: Set[Tuple[str, str, str]] = set()
    deduped: List[GraphEdge] = []
    for e in g.edges:
        key = (e.src, e.dst, e.kind)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(e)
    g.edges = deduped

    g.metadata["totals"] = {
        "nodes": len(g.nodes),
        "edges": len(g.edges),
        "by_stack": _count_by(g.nodes, lambda n: n.stack),
        "by_language": _count_by(g.nodes, lambda n: n.language),
        "by_kind": _count_by(g.nodes, lambda n: n.kind),
    }

    if save:
        _save_graph(project_name, g)
    return g


def _count_by(items, key) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for it in items:
        k = key(it)
        out[k] = out.get(k, 0) + 1
    return out


def _save_graph(project_name: str, g: DependencyGraph) -> Path:
    out_dir = graph_dir_for(project_name)
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    timestamped = out_dir / f"graph-{ts}.json"
    timestamped.write_text(json.dumps(g.to_dict(), indent=2), encoding="utf-8")
    latest = out_dir / "graph-latest.json"
    latest.write_text(json.dumps(g.to_dict(), indent=2), encoding="utf-8")
    logger.info(
        "Dependency Graph Agent: project=%s nodes=%d edges=%d → %s",
        project_name, len(g.nodes), len(g.edges), timestamped,
    )
    return timestamped


def _walk_local(source_root: Path) -> Dict[str, List[str]]:
    skip_dirs = {".git", "node_modules", "vendor", "__pycache__", "dist", "build", ".venv", "target"}
    result: Dict[str, List[str]] = {"php": [], "javascript": [], "typescript": [], "python": []}
    if not source_root.exists():
        return result
    for root, dirs, files in os.walk(source_root):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fn in files:
            full = os.path.join(root, fn)
            if fn.endswith(".php"):
                result["php"].append(full)
            elif fn.endswith((".js", ".mjs", ".cjs")):
                result["javascript"].append(full)
            elif fn.endswith((".ts", ".tsx")):
                result["typescript"].append(full)
            elif fn.endswith(".py"):
                result["python"].append(full)
    return result


def load_latest_graph(project_name: str) -> Optional[Dict[str, Any]]:
    p = graph_dir_for(project_name) / "graph-latest.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("Failed to load graph %s: %s", p, e)
        return None
