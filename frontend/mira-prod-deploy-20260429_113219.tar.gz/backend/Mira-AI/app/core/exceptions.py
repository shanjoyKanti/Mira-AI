"""Custom exceptions and global exception handlers"""
from fastapi import Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from app.core.logging import get_logger

# Note: SQLAlchemy exception handler removed - using MongoDB only

logger = get_logger(__name__)


class MiraAIException(Exception):
    """Base exception for Mira AI"""
    def __init__(self, message: str, status_code: int = 500, detail: str = None):
        self.message = message
        self.status_code = status_code
        self.detail = detail
        super().__init__(self.message)


class ValidationError(MiraAIException):
    """Validation error"""
    def __init__(self, message: str, detail: str = None):
        super().__init__(message, status_code=400, detail=detail)


class AuthenticationError(MiraAIException):
    """Authentication error"""
    def __init__(self, message: str = "Authentication failed", detail: str = None):
        super().__init__(message, status_code=401, detail=detail)


class AuthorizationError(MiraAIException):
    """Authorization error"""
    def __init__(self, message: str = "Not authorized", detail: str = None):
        super().__init__(message, status_code=403, detail=detail)


class NotFoundError(MiraAIException):
    """Resource not found error"""
    def __init__(self, message: str = "Resource not found", detail: str = None):
        super().__init__(message, status_code=404, detail=detail)


class ServiceError(MiraAIException):
    """Service error"""
    def __init__(self, message: str, detail: str = None):
        super().__init__(message, status_code=500, detail=detail)


async def mira_ai_exception_handler(request: Request, exc: MiraAIException):
    """Handle MiraAI custom exceptions"""
    logger.error(f"MiraAI Exception: {exc.message}", exc_info=True)
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "error": exc.message,
            "detail": exc.detail,
            "path": str(request.url.path)
        }
    )


async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Handle validation errors"""
    errors = exc.errors()
    logger.warning(f"Validation error: {errors}")
    
    # Clean up errors to make them JSON serializable
    cleaned_errors = []
    for error in errors:
        cleaned_error = {
            "type": error.get("type"),
            "loc": error.get("loc"),
            "msg": error.get("msg"),
            "input": error.get("input")
        }
        # Convert exception objects in ctx to strings
        if "ctx" in error:
            cleaned_ctx = {}
            for key, value in error["ctx"].items():
                if isinstance(value, Exception):
                    cleaned_ctx[key] = str(value)
                else:
                    cleaned_ctx[key] = value
            cleaned_error["ctx"] = cleaned_ctx
        cleaned_errors.append(cleaned_error)
    
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "success": False,
            "error": "Validation error",
            "detail": cleaned_errors,
            "path": str(request.url.path)
        }
    )


async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "success": False,
            "error": "Internal server error",
            "detail": "An unexpected error occurred. Please try again later.",
            "path": str(request.url.path)
        }
    )

