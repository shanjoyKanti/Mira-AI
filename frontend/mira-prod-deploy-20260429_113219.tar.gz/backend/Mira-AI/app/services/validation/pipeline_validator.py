"""
Pipeline Pre-flight Validator for Mira AI.

Runs a set of fast, non-destructive checks before the staged PHP modernization
pipeline begins. Catches misconfiguration early so the user gets a clear error
immediately rather than deep inside a multi-hour migration run.

Usage (called automatically by _run_staged_modernization_api_sync):

    from app.services.validation.pipeline_validator import PipelineValidator

    issues = PipelineValidator.run_all(
        ssh_conn=ssh_conn,
        source_path=project_source_path,
        from_version=request.from_version,
        to_version=request.to_version,
    )
    if issues.has_errors():
        raise ValueError(issues.error_summary())
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from app.core.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

SEVERITY_ERROR = "error"
SEVERITY_WARNING = "warning"


@dataclass
class ValidationIssue:
    severity: str   # "error" | "warning"
    code: str       # short identifier, e.g. "NO_GROQ_KEY"
    message: str


@dataclass
class ValidationResult:
    issues: List[ValidationIssue] = field(default_factory=list)

    def add_error(self, code: str, message: str) -> None:
        self.issues.append(ValidationIssue(SEVERITY_ERROR, code, message))

    def add_warning(self, code: str, message: str) -> None:
        self.issues.append(ValidationIssue(SEVERITY_WARNING, code, message))

    def has_errors(self) -> bool:
        return any(i.severity == SEVERITY_ERROR for i in self.issues)

    def errors(self) -> List[ValidationIssue]:
        return [i for i in self.issues if i.severity == SEVERITY_ERROR]

    def warnings(self) -> List[ValidationIssue]:
        return [i for i in self.issues if i.severity == SEVERITY_WARNING]

    def error_summary(self) -> str:
        return "; ".join(f"[{i.code}] {i.message}" for i in self.errors())

    def to_dict(self) -> dict:
        return {
            "valid": not self.has_errors(),
            "errors": [{"code": i.code, "message": i.message} for i in self.errors()],
            "warnings": [{"code": i.code, "message": i.message} for i in self.warnings()],
        }


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------

class PipelineValidator:
    """
    Collection of pre-flight checks for the staged PHP modernization pipeline.
    Each check method adds issues to `result` and returns None.
    Call `run_all()` to execute all checks at once.
    """

    # PHP versions known to the migration chain.
    # Must match PHP_MIGRATION_CHAIN in app/services/agents/planning_agent.py and
    # PHP_VERSION_LADDER in app/services/rag/version_ladder.py — the chain supports
    # 4.0 → 8.5 incrementally, so legacy projects (PHP 5.3, 5.4, etc.) can be
    # modernized step-by-step. This whitelist must mirror the real ladder;
    # otherwise valid old projects get rejected at pre-flight.
    SUPPORTED_PHP_FROM = {
        "4.0", "4.1", "4.2", "4.3", "4.4",
        "5.0", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6",
        "7.0", "7.1", "7.2", "7.3", "7.4",
        "8.0", "8.1", "8.2", "8.3", "8.4",
    }
    SUPPORTED_PHP_TO = {
        "4.1", "4.2", "4.3", "4.4",
        "5.0", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6",
        "7.0", "7.1", "7.2", "7.3", "7.4",
        "8.0", "8.1", "8.2", "8.3", "8.4", "8.5",
    }

    # ------------------------------------------------------------------
    # Scope limits (file count / total bytes / projected runtime).
    # Configurable via env; a `force=true` request can bypass the hard block
    # if MIRA_SCOPE_ALLOW_OVERRIDE is enabled.
    # ------------------------------------------------------------------
    @staticmethod
    def _scope_limits() -> dict:
        return {
            "max_files": int(os.environ.get("MIRA_SCOPE_MAX_FILES", "300000")),
            "max_total_bytes": int(os.environ.get("MIRA_SCOPE_MAX_TOTAL_BYTES", str(3 * 1024 ** 3))),
            "max_runtime_hours": int(os.environ.get("MIRA_SCOPE_MAX_RUNTIME_HOURS", "72")),
            "allow_override": (os.environ.get("MIRA_SCOPE_ALLOW_OVERRIDE", "true").lower() == "true"),
        }

    @classmethod
    def run_all(
        cls,
        ssh_conn,
        source_path: str,
        from_version: str,
        to_version: str,
        project_name: Optional[str] = None,
        force_scope: bool = False,
    ) -> ValidationResult:
        """
        Run all pre-flight checks. Returns a ValidationResult with all issues found.
        Errors block pipeline start; warnings are logged but do not block.

        ``force_scope=True`` suppresses the hard PROJECT_OUT_OF_SCOPE error into a
        warning, letting a user explicitly override the scope cap.
        """
        result = ValidationResult()
        validator = cls()

        validator.check_groq_api_key(result)
        validator.check_rag_dependencies(result)
        validator.check_php_versions(result, from_version, to_version)
        validator.check_upgrade_guide_dir_writable(result)
        validator.check_ssh_source_path(result, ssh_conn, source_path, project_name)
        validator.check_project_scope(result, ssh_conn, source_path, force=force_scope)
        validator.check_target_toolchain(result, ssh_conn, to_version=to_version, language="php")

        if result.has_errors():
            logger.error(
                "[pipeline_validator] Pre-flight FAILED — %d error(s): %s",
                len(result.errors()), result.error_summary(),
            )
        elif result.warnings():
            logger.warning(
                "[pipeline_validator] Pre-flight PASSED with %d warning(s): %s",
                len(result.warnings()),
                "; ".join(f"[{w.code}] {w.message}" for w in result.warnings()),
            )
        else:
            logger.info("[pipeline_validator] Pre-flight PASSED — no issues.")

        return result

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    def check_groq_api_key(self, result: ValidationResult) -> None:
        """GROQ_API_KEY must be set — required for both RAG scraping and LLM modernization."""
        key = (os.environ.get("GROQ_API_KEY") or "").strip()
        if not key:
            result.add_error(
                "NO_GROQ_KEY",
                "GROQ_API_KEY environment variable is not set. "
                "All LLM calls (RAG, code modernization, correction loop) will fail.",
            )
        elif not key.startswith("gsk_"):
            result.add_warning(
                "UNEXPECTED_GROQ_KEY_FORMAT",
                "GROQ_API_KEY does not start with 'gsk_'. It may be invalid.",
            )

    def check_rag_dependencies(self, result: ValidationResult) -> None:
        """Critical RAG packages must be importable before the pipeline starts."""
        missing = []
        try:
            import qdrant_client  # noqa: F401
        except ImportError:
            missing.append("qdrant-client")

        try:
            import sentence_transformers  # noqa: F401
        except ImportError:
            missing.append("sentence-transformers")

        try:
            import groq  # noqa: F401
        except ImportError:
            missing.append("groq")

        try:
            import trafilatura  # noqa: F401
        except ImportError:
            missing.append("trafilatura")

        if missing:
            result.add_error(
                "MISSING_RAG_DEPS",
                f"Missing RAG dependencies: {', '.join(missing)}. "
                "Run: pip install -r rag/requirements.txt",
            )

    def check_php_versions(
        self, result: ValidationResult, from_version: str, to_version: str
    ) -> None:
        """from_version and to_version must both be in the supported migration chain."""
        from app.services.agents.planning_agent import normalize_php_version
        from_v = normalize_php_version(from_version or "")
        to_v = normalize_php_version(to_version or "")

        if not from_v:
            result.add_error("INVALID_FROM_VERSION", "from_version is empty or unparseable.")
        elif from_v not in self.SUPPORTED_PHP_FROM:
            result.add_error(
                "UNSUPPORTED_FROM_VERSION",
                f"from_version '{from_v}' is not in the supported migration chain. "
                f"Supported: {sorted(self.SUPPORTED_PHP_FROM)}",
            )

        if not to_v:
            result.add_error("INVALID_TO_VERSION", "to_version is empty or unparseable.")
        elif to_v not in self.SUPPORTED_PHP_TO:
            result.add_error(
                "UNSUPPORTED_TO_VERSION",
                f"to_version '{to_v}' is not in the supported migration chain. "
                f"Supported: {sorted(self.SUPPORTED_PHP_TO)}",
            )

        if from_v and to_v and from_v in self.SUPPORTED_PHP_FROM and to_v in self.SUPPORTED_PHP_TO:
            # Version comparison check
            def _php_tuple(v: str):
                parts = v.split(".")
                return (int(parts[0]), int(parts[1]) if len(parts) > 1 else 0)

            if _php_tuple(from_v) >= _php_tuple(to_v):
                result.add_error(
                    "VERSION_ORDER",
                    f"from_version ({from_v}) must be strictly less than to_version ({to_v}).",
                )

    def check_upgrade_guide_dir_writable(self, result: ValidationResult) -> None:
        """The upgrade-guide directory must be writable for Laravel guide synthesis."""
        _APP_DIR = Path(__file__).resolve().parent.parent.parent
        upgrade_guide_dir = _APP_DIR / "data" / "upgrade-guide"

        if upgrade_guide_dir.exists():
            if not os.access(upgrade_guide_dir, os.W_OK):
                result.add_error(
                    "UPGRADE_GUIDE_DIR_NOT_WRITABLE",
                    f"upgrade-guide directory '{upgrade_guide_dir}' exists but is not writable. "
                    "Laravel guide synthesis will fail.",
                )
        else:
            try:
                upgrade_guide_dir.mkdir(parents=True, exist_ok=True)
                logger.info("[pipeline_validator] Created upgrade-guide directory: %s", upgrade_guide_dir)
            except OSError as e:
                result.add_error(
                    "UPGRADE_GUIDE_DIR_CREATION_FAILED",
                    f"Cannot create upgrade-guide directory '{upgrade_guide_dir}': {e}",
                )

    def check_ssh_source_path(
        self,
        result: ValidationResult,
        ssh_conn,
        source_path: str,
        project_name: Optional[str] = None,
    ) -> None:
        """The source path must exist on the remote SSH server and contain PHP files."""
        if not source_path:
            result.add_error("NO_SOURCE_PATH", "source_path is empty.")
            return

        # Check directory exists on remote
        dir_check = ssh_conn.execute_command(
            f"test -d '{source_path}' && echo 'exists' || echo 'missing'"
        )
        if not (dir_check.get("success") and "exists" in (dir_check.get("stdout") or "")):
            result.add_error(
                "SOURCE_PATH_NOT_FOUND",
                f"source_path '{source_path}' does not exist on the remote server. "
                "Verify the path before starting migration.",
            )
            return

        # Check for PHP files
        php_check = ssh_conn.execute_command(
            f"find '{source_path}' -name '*.php' -not -path '*/vendor/*' "
            f"-not -path '*/node_modules/*' | head -5 | wc -l"
        )
        php_count_str = (php_check.get("stdout") or "0").strip()
        try:
            php_count = int(php_count_str)
        except ValueError:
            php_count = 0

        if php_count == 0:
            result.add_error(
                "NO_PHP_FILES",
                f"No PHP files found in '{source_path}' (excluding vendor/node_modules). "
                "Verify the path points to the PHP project root.",
            )
        elif php_count < 5:
            result.add_warning(
                "FEW_PHP_FILES",
                f"Only {php_count} PHP file(s) found in '{source_path}' (sample check). "
                "Verify the project has sufficient source files.",
            )

    def check_project_scope(
        self,
        result: ValidationResult,
        ssh_conn,
        source_path: str,
        *,
        force: bool = False,
    ) -> None:
        """
        Hard scope gate: count files + total bytes on the remote tree. If the
        project exceeds the configured ceilings (file count, total size, or projected
        runtime) add an error so the pipeline refuses to start.

        With ``force=True`` the error is downgraded to a warning so a user can
        explicitly override after acknowledging the risk (only respected when
        ``MIRA_SCOPE_ALLOW_OVERRIDE=true``, which is the default).
        """
        if not source_path:
            return  # check_ssh_source_path already errors on empty path

        limits = self._scope_limits()

        # Count files (excluding vendor/node_modules/.git). Using `find | wc -l`
        # is fast even on 3 GB projects. Using `du -sb` for total bytes.
        count_cmd = (
            f"find '{source_path}' -type f "
            "-not -path '*/vendor/*' -not -path '*/node_modules/*' "
            "-not -path '*/.git/*' 2>/dev/null | wc -l"
        )
        bytes_cmd = (
            f"find '{source_path}' -type f "
            "-not -path '*/vendor/*' -not -path '*/node_modules/*' "
            "-not -path '*/.git/*' -printf '%s\\n' 2>/dev/null "
            "| awk '{s+=$1} END {print s+0}'"
        )

        total_files = 0
        total_bytes = 0
        try:
            c = ssh_conn.execute_command(count_cmd)
            total_files = int((c.get("stdout") or "0").strip() or 0)
        except Exception as e:
            logger.warning("[pipeline_validator] scope file-count failed: %s", e)
        try:
            b = ssh_conn.execute_command(bytes_cmd)
            total_bytes = int((b.get("stdout") or "0").strip() or 0)
        except Exception as e:
            logger.warning("[pipeline_validator] scope byte-sum failed: %s", e)

        if total_files == 0 and total_bytes == 0:
            logger.info("[pipeline_validator] scope measurement returned zeros; skipping cap check")
            return

        # Projected runtime ≈ (files × avg_seconds_per_file) / concurrent_llm_calls
        avg_sec_per_file = int(os.environ.get("MIRA_JOB_TIMEOUT_PER_FILE_SECONDS", "3"))
        concurrent_llm = int(os.environ.get("MIRA_MAX_CONCURRENT_LLM_CALLS", "3"))
        projected_seconds = (total_files * avg_sec_per_file) // max(1, concurrent_llm)
        projected_hours = projected_seconds / 3600.0

        breaches: List[str] = []
        if total_files > limits["max_files"]:
            breaches.append(
                f"file count {total_files:,} exceeds MIRA_SCOPE_MAX_FILES={limits['max_files']:,}"
            )
        if total_bytes > limits["max_total_bytes"]:
            gb = total_bytes / (1024 ** 3)
            cap_gb = limits["max_total_bytes"] / (1024 ** 3)
            breaches.append(
                f"total size {gb:.2f} GB exceeds MIRA_SCOPE_MAX_TOTAL_BYTES={cap_gb:.2f} GB"
            )
        if projected_hours > limits["max_runtime_hours"]:
            breaches.append(
                f"projected runtime {projected_hours:.1f} h exceeds "
                f"MIRA_SCOPE_MAX_RUNTIME_HOURS={limits['max_runtime_hours']} h"
            )

        logger.info(
            "[pipeline_validator] scope: files=%d bytes=%d projected_hours=%.1f breaches=%d",
            total_files, total_bytes, projected_hours, len(breaches),
        )

        if not breaches:
            return

        human = "; ".join(breaches)
        if force and limits["allow_override"]:
            result.add_warning(
                "PROJECT_OUT_OF_SCOPE_OVERRIDDEN",
                (
                    "Project exceeds supported scope but user override accepted "
                    f"(force=true). Proceeding anyway — {human}. "
                    "Expect long runtimes and multiple resumes."
                ),
            )
            return

        result.add_error(
            "PROJECT_OUT_OF_SCOPE",
            (
                f"This project exceeds the supported scope ({human}). "
                "Either (a) split the repository into smaller sub-projects, "
                "(b) raise the MIRA_SCOPE_* env ceilings if your deployment can handle it, "
                "or (c) resubmit with force=true to acknowledge the risk and proceed anyway."
            ),
        )
        # Count the rejection per-dimension so the dashboard can show which ceiling hits most.
        try:
            from app.core.metrics import mira_scope_rejections_total
            if total_files > limits["max_files"]:
                mira_scope_rejections_total.labels(reason="files").inc()
            if total_bytes > limits["max_total_bytes"]:
                mira_scope_rejections_total.labels(reason="bytes").inc()
            if projected_hours > limits["max_runtime_hours"]:
                mira_scope_rejections_total.labels(reason="runtime").inc()
        except Exception:
            pass

    def check_target_toolchain(
        self,
        result: ValidationResult,
        ssh_conn,
        *,
        to_version: str,
        language: str = "php",
    ) -> None:
        """
        Probe the remote VM for the target language toolchain. If the user's VM only has
        PHP 7.4 installed but they're asking to upgrade TO 8.3, they'll get "upgraded" code
        they can't actually run. Better to fail loudly here than silently at their CI step.

        WARNING-level: we don't want this to hard-block (a user may intentionally run
        validation on a different host), but it surfaces prominently in the status response.
        """
        lang = (language or "php").strip().lower()
        tv = (to_version or "").strip()
        if not tv:
            return

        # Parse target major.minor from arbitrary input (e.g. "8.3", "php8.3", "net8.0")
        import re as _re
        m = _re.search(r"(\d+)\.(\d+)", tv)
        if not m:
            return
        major, minor = int(m.group(1)), int(m.group(2))

        cmd, expected_substring = None, None
        if lang == "php":
            cmd = "php -v 2>/dev/null | head -1"
            expected_substring = f"{major}.{minor}"
        elif lang in ("c#", "csharp", "dotnet", ".net"):
            cmd = "dotnet --list-sdks 2>/dev/null"
            expected_substring = f"{major}."
        elif lang == "python":
            cmd = f"python{major}.{minor} --version 2>/dev/null || python3 --version 2>/dev/null"
            expected_substring = f"{major}.{minor}"
        elif lang in ("javascript", "typescript", "node", "nodejs"):
            cmd = "node --version 2>/dev/null"
            expected_substring = f"v{major}"
        elif lang == "java":
            cmd = "javac -version 2>&1 | head -1"
            expected_substring = str(major)
        elif lang == "go":
            cmd = "go version 2>/dev/null"
            expected_substring = f"{major}.{minor}"
        elif lang == "ruby":
            cmd = "ruby --version 2>/dev/null"
            expected_substring = f"{major}.{minor}"
        elif lang == "rust":
            cmd = "rustc --version 2>/dev/null"
            expected_substring = None  # any rustc is usually enough
        else:
            return

        try:
            res = ssh_conn.execute_command(cmd)
            out = (res.get("stdout") or "").strip()
        except Exception as e:
            logger.debug("toolchain probe failed: %s", e)
            return

        if not out:
            result.add_warning(
                "TOOLCHAIN_MISSING",
                (
                    f"Could not detect the {lang} {tv} toolchain on the VM "
                    f"(command `{cmd}` returned no output). "
                    "The upgraded code will be written back but may not run until you "
                    f"install {lang} {tv} on the VM."
                ),
            )
            return
        if expected_substring and expected_substring not in out:
            result.add_warning(
                "TOOLCHAIN_VERSION_MISMATCH",
                (
                    f"VM has {lang} but not version {tv} (detected: {out[:120]}). "
                    f"Install {lang} {tv} alongside the existing version before running the "
                    "upgraded code — Mira will still write the upgrade, but native validation "
                    "will target the wrong version."
                ),
            )
