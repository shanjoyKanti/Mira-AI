"""Placeholder for scan tests"""
# TODO: Add scan functionality tests
