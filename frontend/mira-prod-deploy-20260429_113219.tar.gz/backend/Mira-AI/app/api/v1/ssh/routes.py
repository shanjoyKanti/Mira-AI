"""SSH credentials management routes"""
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from typing import Optional
from datetime import datetime

from app.core.dependencies import get_current_active_user
from app.core.security import encrypt_data, decrypt_data
from app.api.v1.accounts import schemas
from app.db.mongodb_models import User
from app.services.ssh.ssh_service import SSHService
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(tags=["Step 1 — Onboarding & Project Setup"])


@router.post(
    "/credentials",
    response_model=schemas.MessageResponse,
    summary="Add/Update SSH credentials",
    description="Add or update SSH credentials for VM access"
)
async def add_ssh_credentials(
    ssh_creds: schemas.SSHCredentials,
    current_user: User = Depends(get_current_active_user)
):
    """Add or update SSH credentials for VM access"""
    # Encrypt sensitive data
    current_user.ssh_hostname = ssh_creds.hostname
    current_user.ssh_port = ssh_creds.port
    current_user.ssh_username = ssh_creds.username
    
    # EXPLICITLY set password - encrypt if provided, set to None if empty
    if ssh_creds.password and ssh_creds.password.strip():
        current_user.ssh_password_encrypted = encrypt_data(ssh_creds.password)
    else:
        current_user.ssh_password_encrypted = None
    
    # EXPLICITLY set private key - encrypt if provided, set to None if empty
    if ssh_creds.private_key and ssh_creds.private_key.strip():
        current_user.ssh_private_key_encrypted = encrypt_data(ssh_creds.private_key)
    else:
        current_user.ssh_private_key_encrypted = None
    
    # EXPLICITLY set private key password - encrypt if provided, set to None if empty
    if ssh_creds.private_key_password and ssh_creds.private_key_password.strip():
        current_user.ssh_private_key_password_encrypted = encrypt_data(ssh_creds.private_key_password)
    else:
        current_user.ssh_private_key_password_encrypted = None

    if ssh_creds.source_path:
        current_user.ssh_source_path = ssh_creds.source_path.strip().rstrip("/")

    # Test connection
    test_result = SSHService.test_connection(
        hostname=ssh_creds.hostname,
        port=ssh_creds.port,
        username=ssh_creds.username,
        password=ssh_creds.password,
        private_key=ssh_creds.private_key,
        private_key_password=ssh_creds.private_key_password
    )
    
    if test_result["success"]:
        current_user.ssh_verified = True
        current_user.ssh_verified_at = datetime.utcnow()
        await current_user.save()
        return schemas.MessageResponse(
            message="SSH credentials added and verified successfully",
            detail="Your VM is now accessible for code analysis"
        )
    else:
        await current_user.save()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SSH connection test failed: {test_result.get('message', 'Unknown error')}"
        )


@router.post(
    "/credentials/test",
    response_model=schemas.MessageResponse,
    summary="Test SSH credentials",
    description="Test SSH connection and save credentials if authenticated"
)
async def test_ssh_credentials(
    ssh_creds: schemas.SSHCredentials,
    current_user: User = Depends(get_current_active_user)
):
    """Test SSH credentials and save to user record on success."""
    # Treat empty strings as None
    password = ssh_creds.password.strip() if ssh_creds.password and ssh_creds.password.strip() else None
    private_key = ssh_creds.private_key.strip() if ssh_creds.private_key and ssh_creds.private_key.strip() else None
    private_key_password = ssh_creds.private_key_password.strip() if ssh_creds.private_key_password and ssh_creds.private_key_password.strip() else None

    test_result = SSHService.test_connection(
        hostname=ssh_creds.hostname,
        port=ssh_creds.port,
        username=ssh_creds.username,
        password=password,
        private_key=private_key,
        private_key_password=private_key_password
    )

    if test_result["success"]:
        current_user.ssh_hostname = ssh_creds.hostname
        current_user.ssh_port = ssh_creds.port
        current_user.ssh_username = ssh_creds.username
        current_user.ssh_password_encrypted = encrypt_data(password) if password else None
        current_user.ssh_private_key_encrypted = encrypt_data(private_key) if private_key else None
        current_user.ssh_private_key_password_encrypted = encrypt_data(private_key_password) if private_key_password else None
        if ssh_creds.source_path and ssh_creds.source_path.strip():
            current_user.ssh_source_path = ssh_creds.source_path.strip().rstrip("/")
        current_user.ssh_verified = True
        current_user.ssh_verified_at = datetime.utcnow()
        await current_user.save()
        return schemas.MessageResponse(
            message="SSH connection test successful",
            detail=test_result.get("test_output", "")
        )
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SSH connection test failed: {test_result.get('message', 'Unknown error')}"
        )


@router.post(
    "/credentials/test-upload",
    response_model=schemas.MessageResponse,
    summary="Test SSH key file upload",
    description="Test SSH connection with uploaded key file without saving credentials"
)
async def test_ssh_key_upload(
    hostname: str = Form(...),
    port: int = Form(22),
    username: str = Form(...),
    private_key_file: UploadFile = File(...),
    private_key_password: Optional[str] = Form(None),
    password: Optional[str] = Form(None)
):
    """Test SSH connection with uploaded key file without saving"""
    # Read file content
    try:
        content = await private_key_file.read()
        
        # Limit file size
        max_size = 10 * 1024  # 10KB
        if len(content) > max_size:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"File size exceeds maximum allowed size of {max_size} bytes"
            )
        
        private_key_content = content.decode('utf-8')
        
        # Validate it looks like a private key
        if not any(marker in private_key_content for marker in ['BEGIN', 'PRIVATE', 'KEY']):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="File does not appear to be a valid private key file"
            )
        
    except UnicodeDecodeError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="File is not a valid text file. Please upload a .pem or .key file."
        )
    except Exception as e:
        logger.error(f"Error reading uploaded SSH key file: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing uploaded file: {str(e)}"
        )
    
    # Test connection
    test_result = SSHService.test_connection(
        hostname=hostname,
        port=port,
        username=username,
        password=password,
        private_key=private_key_content,
        private_key_password=private_key_password
    )
    
    if test_result["success"]:
        return schemas.MessageResponse(
            message="SSH connection test successful",
            detail=test_result.get("test_output", "")
        )
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SSH connection test failed: {test_result.get('message', 'Unknown error')}"
        )


@router.get(
    "/credentials",
    summary="Get SSH credentials status",
    description="Get SSH credentials status (credentials are not returned for security)"
)
async def get_ssh_credentials_status(
    current_user: User = Depends(get_current_active_user)
):
    """Get SSH credentials status"""
    return {
        "has_credentials": bool(current_user.ssh_hostname and current_user.ssh_username),
        "hostname": current_user.ssh_hostname,
        "port": current_user.ssh_port,
        "username": current_user.ssh_username,
        "verified": current_user.ssh_verified,
        "verified_at": current_user.ssh_verified_at.isoformat() if current_user.ssh_verified_at else None
    }


@router.post(
    "/credentials/upload-key",
    response_model=schemas.MessageResponse,
    summary="Upload SSH private key file (.pem, .key, etc.)",
    description="Upload SSH private key file for VM access"
)
async def upload_ssh_key(
    hostname: str = Form(...),
    port: int = Form(22),
    username: str = Form(...),
    private_key_file: UploadFile = File(...),
    private_key_password: Optional[str] = Form(None),
    password: Optional[str] = Form(None),
    current_user: User = Depends(get_current_active_user)
):
    """
    Upload SSH private key file (.pem, .key, etc.)
    
    Accepts:
    - .pem, .key, .ppk, or any text file containing private key
    - Maximum file size: 10KB (for security)
    """
    # Validate file extension
    allowed_extensions = {'.pem', '.key', '.ppk', '.rsa', '.ed25519', '.id_rsa', '.id_ed25519'}
    file_extension = None
    if private_key_file.filename:
        file_extension = '.' + private_key_file.filename.split('.')[-1].lower()
    
    if file_extension and file_extension not in allowed_extensions:
        # Allow files without extension or with .txt (some users save keys as .txt)
        if not file_extension or file_extension != '.txt':
            logger.warning(f"Uploaded file has non-standard extension: {file_extension}")
    
    # Read file content
    try:
        content = await private_key_file.read()
        
        # Limit file size to 10KB for security
        max_size = 10 * 1024  # 10KB
        if len(content) > max_size:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"File size exceeds maximum allowed size of {max_size} bytes"
            )
        
        # Decode content
        private_key_content = content.decode('utf-8')
        
        # Validate it looks like a private key
        if not any(marker in private_key_content for marker in ['BEGIN', 'PRIVATE', 'KEY']):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="File does not appear to be a valid private key file"
            )
        
        logger.info(f"User {current_user.id} uploaded SSH key file: {private_key_file.filename}")
        
    except UnicodeDecodeError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="File is not a valid text file. Please upload a .pem or .key file."
        )
    except Exception as e:
        logger.error(f"Error reading uploaded SSH key file: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing uploaded file: {str(e)}"
        )
    
    # Store credentials
    current_user.ssh_hostname = hostname
    current_user.ssh_port = port
    current_user.ssh_username = username
    
    if password:
        current_user.ssh_password_encrypted = encrypt_data(password)
    
    current_user.ssh_private_key_encrypted = encrypt_data(private_key_content)
    
    if private_key_password:
        current_user.ssh_private_key_password_encrypted = encrypt_data(private_key_password)
    
    # Test connection
    test_result = SSHService.test_connection(
        hostname=hostname,
        port=port,
        username=username,
        password=password,
        private_key=private_key_content,
        private_key_password=private_key_password
    )
    
    if test_result["success"]:
        current_user.ssh_verified = True
        current_user.ssh_verified_at = datetime.utcnow()
        await current_user.save()
        return schemas.MessageResponse(
            message="SSH key uploaded and verified successfully",
            detail="Your VM is now accessible for code analysis"
        )
    else:
        await current_user.save()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SSH connection test failed: {test_result.get('message', 'Unknown error')}"
        )


@router.post(
    "/credentials/test-stored",
    response_model=schemas.MessageResponse,
    summary="Test stored SSH credentials",
    description="Test SSH connection using stored credentials"
)
async def test_stored_ssh_credentials(
    current_user: User = Depends(get_current_active_user),
):
    """Test SSH connection using stored credentials"""
    # Check if user has stored credentials
    if not current_user.ssh_hostname or not current_user.ssh_username:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No SSH credentials stored. Please upload SSH credentials first."
        )
    
    # Decrypt stored credentials
    password = None
    private_key = None
    private_key_password = None
    
    if current_user.ssh_password_encrypted:
        try:
            password = decrypt_data(current_user.ssh_password_encrypted)
        except Exception:
            pass
    
    if current_user.ssh_private_key_encrypted:
        try:
            private_key = decrypt_data(current_user.ssh_private_key_encrypted)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to decrypt stored private key"
            )
    
    if current_user.ssh_private_key_password_encrypted:
        try:
            private_key_password = decrypt_data(current_user.ssh_private_key_password_encrypted)
        except Exception:
            pass
    
    if not password and not private_key:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No authentication method stored (neither password nor private key)"
        )
    
    # Test connection
    test_result = SSHService.test_connection(
        hostname=current_user.ssh_hostname,
        port=current_user.ssh_port or 22,
        username=current_user.ssh_username,
        password=password,
        private_key=private_key,
        private_key_password=private_key_password
    )
    
    if test_result["success"]:
        return schemas.MessageResponse(
            message="SSH connection test successful",
            detail=test_result.get("test_output", "")
        )
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SSH connection test failed: {test_result.get('message', 'Unknown error')}"
        )


@router.delete(
    "/credentials",
    response_model=schemas.MessageResponse,
    summary="Remove SSH credentials",
    description="Remove SSH credentials from account"
)
async def remove_ssh_credentials(
    current_user: User = Depends(get_current_active_user)
):
    """Remove SSH credentials"""
    current_user.ssh_hostname = None
    current_user.ssh_port = 22
    current_user.ssh_username = None
    current_user.ssh_password_encrypted = None
    current_user.ssh_private_key_encrypted = None
    current_user.ssh_private_key_password_encrypted = None
    current_user.ssh_verified = False
    current_user.ssh_verified_at = None
    
    await current_user.save()
    return schemas.MessageResponse(
        message="SSH credentials removed successfully"
    )

