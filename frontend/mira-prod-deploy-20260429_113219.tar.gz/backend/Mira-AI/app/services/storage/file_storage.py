"""VM-based file storage service using local filesystem"""
import os
import shutil
import json
from pathlib import Path
from typing import Optional, List, Dict
from datetime import datetime
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class FileStorageService:
    """VM-based file storage service using local filesystem"""
    
    def __init__(self, workspace_root: Optional[str] = None):
        """
        Initialize file storage service
        
        Args:
            workspace_root: Root directory for workspace (defaults to config value)
        """
        self.workspace_root = Path(workspace_root or settings.WORKSPACE_ROOT)
        self.projects_dir = self.workspace_root / "projects"
        self.uploads_dir = self.workspace_root / "uploads"
        self.deliveries_dir = self.workspace_root / "deliveries"
        
        # Create directories if they don't exist
        self._ensure_directories()
        logger.info(f"File storage initialized at: {self.workspace_root.absolute()}")
    
    def _ensure_directories(self):
        """Create workspace directories if they don't exist"""
        self.projects_dir.mkdir(parents=True, exist_ok=True)
        self.uploads_dir.mkdir(parents=True, exist_ok=True)
        self.deliveries_dir.mkdir(parents=True, exist_ok=True)
    
    def allocate_project_storage(self, project_id: int, user_id: int) -> Path:
        """
        Allocate storage for a new project
        
        Args:
            project_id: Project ID
            user_id: User ID who owns the project
            
        Returns:
            Path to project directory
        """
        project_path = self.projects_dir / str(user_id) / str(project_id)
        project_path.mkdir(parents=True, exist_ok=True)
        
        # Create subdirectories
        (project_path / "source").mkdir(exist_ok=True)
        (project_path / "analysis").mkdir(exist_ok=True)
        (project_path / "upgraded").mkdir(exist_ok=True)
        (project_path / "tests").mkdir(exist_ok=True)
        (project_path / "reports").mkdir(exist_ok=True)
        (project_path / "docs").mkdir(exist_ok=True)
        
        # Create metadata file
        metadata = {
            "project_id": project_id,
            "user_id": user_id,
            "created_at": datetime.utcnow().isoformat(),
            "status": "allocated",
            "storage_path": str(project_path)
        }
        self._write_json(project_path / "metadata.json", metadata)
        
        logger.info(f"Allocated storage for project {project_id} (user {user_id}) at {project_path}")
        return project_path
    
    def get_project_path(self, project_id: int, user_id: int) -> Path:
        """Get the project directory path"""
        return self.projects_dir / str(user_id) / str(project_id)
    
    def get_user_workspace(self, user_id: int) -> Path:
        """Get user's workspace directory"""
        return self.projects_dir / str(user_id)
    
    def get_source_path(self, project_id: int, user_id: int) -> Path:
        """Get source code directory path"""
        return self.get_project_path(project_id, user_id) / "source"
    
    def get_analysis_path(self, project_id: int, user_id: int) -> Path:
        """Get analysis results directory path"""
        return self.get_project_path(project_id, user_id) / "analysis"
    
    def get_upgraded_path(self, project_id: int, user_id: int) -> Path:
        """Get upgraded code directory path"""
        return self.get_project_path(project_id, user_id) / "upgraded"
    
    def get_reports_path(self, project_id: int, user_id: int) -> Path:
        """Get reports directory path"""
        return self.get_project_path(project_id, user_id) / "reports"
    
    def get_tests_path(self, project_id: int, user_id: int) -> Path:
        """Get tests directory path"""
        return self.get_project_path(project_id, user_id) / "tests"
    
    def get_docs_path(self, project_id: int, user_id: int) -> Path:
        """Get documentation directory path"""
        return self.get_project_path(project_id, user_id) / "docs"
    
    def save_file(self, project_id: int, user_id: int, relative_path: str, 
                  content: bytes, subdir: str = "source") -> Path:
        """
        Save a file to project storage
        
        Args:
            project_id: Project ID
            user_id: User ID
            relative_path: Relative path within subdirectory
            content: File content as bytes
            subdir: Subdirectory (source, analysis, upgraded, etc.)
            
        Returns:
            Path to saved file
        """
        project_path = self.get_project_path(project_id, user_id)
        file_path = project_path / subdir / relative_path
        
        # Create parent directories if needed
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Write file
        file_path.write_bytes(content)
        
        logger.debug(f"Saved file: {file_path}")
        return file_path
    
    def save_text_file(self, project_id: int, user_id: int, relative_path: str,
                       content: str, subdir: str = "source", encoding: str = "utf-8") -> Path:
        """Save a text file to project storage"""
        project_path = self.get_project_path(project_id, user_id)
        file_path = project_path / subdir / relative_path
        
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding=encoding)
        
        logger.debug(f"Saved text file: {file_path}")
        return file_path
    
    def read_file(self, project_id: int, user_id: int, relative_path: str, 
                  subdir: str = "source") -> bytes:
        """Read a file from project storage"""
        project_path = self.get_project_path(project_id, user_id)
        file_path = project_path / subdir / relative_path
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        return file_path.read_bytes()
    
    def read_text_file(self, project_id: int, user_id: int, relative_path: str,
                       subdir: str = "source", encoding: str = "utf-8") -> str:
        """Read a text file from project storage"""
        project_path = self.get_project_path(project_id, user_id)
        file_path = project_path / subdir / relative_path
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        return file_path.read_text(encoding=encoding)
    
    def file_exists(self, project_id: int, user_id: int, relative_path: str,
                    subdir: str = "source") -> bool:
        """Check if a file exists"""
        project_path = self.get_project_path(project_id, user_id)
        file_path = project_path / subdir / relative_path
        return file_path.exists()
    
    def list_files(self, project_id: int, user_id: int, subdir: str = "source", 
                   recursive: bool = True) -> List[str]:
        """
        List all files in a project subdirectory
        
        Args:
            project_id: Project ID
            user_id: User ID
            subdir: Subdirectory to list
            recursive: Whether to list recursively
            
        Returns:
            List of relative file paths
        """
        project_path = self.get_project_path(project_id, user_id)
        dir_path = project_path / subdir
        
        if not dir_path.exists():
            return []
        
        if recursive:
            files = [str(p.relative_to(project_path)) for p in dir_path.rglob("*") if p.is_file()]
        else:
            files = [str(p.relative_to(project_path)) for p in dir_path.iterdir() if p.is_file()]
        
        return sorted(files)
    
    def delete_project(self, project_id: int, user_id: int):
        """Delete project storage (cleanup)"""
        project_path = self.get_project_path(project_id, user_id)
        if project_path.exists():
            shutil.rmtree(project_path)
            logger.info(f"Deleted project storage: {project_path}")
    
    def delete_user_workspace(self, user_id: int):
        """Delete entire user workspace"""
        user_workspace = self.get_user_workspace(user_id)
        if user_workspace.exists():
            shutil.rmtree(user_workspace)
            logger.info(f"Deleted user workspace: {user_workspace}")
    
    def get_storage_size(self, project_id: int, user_id: int) -> int:
        """
        Get total storage size used by project in bytes
        
        Returns:
            Size in bytes
        """
        project_path = self.get_project_path(project_id, user_id)
        if not project_path.exists():
            return 0
        
        total_size = 0
        for file_path in project_path.rglob("*"):
            if file_path.is_file():
                try:
                    total_size += file_path.stat().st_size
                except (OSError, FileNotFoundError):
                    pass
        
        return total_size
    
    def get_user_storage_size(self, user_id: int) -> int:
        """Get total storage size used by user across all projects"""
        user_workspace = self.get_user_workspace(user_id)
        if not user_workspace.exists():
            return 0
        
        total_size = 0
        for file_path in user_workspace.rglob("*"):
            if file_path.is_file():
                try:
                    total_size += file_path.stat().st_size
                except (OSError, FileNotFoundError):
                    pass
        
        return total_size
    
    def create_delivery_package(self, project_id: int, user_id: int) -> Path:
        """
        Create ZIP package for final delivery
        
        Returns:
            Path to created ZIP file
        """
        project_path = self.get_project_path(project_id, user_id)
        if not project_path.exists():
            raise FileNotFoundError(f"Project path does not exist: {project_path}")
        
        zip_path = self.deliveries_dir / f"user_{user_id}_project_{project_id}_final.zip"
        
        # Remove existing ZIP if it exists
        if zip_path.exists():
            zip_path.unlink()
        
        shutil.make_archive(
            str(zip_path.with_suffix("")),
            "zip",
            project_path
        )
        
        logger.info(f"Created delivery package: {zip_path}")
        return zip_path
    
    def get_project_metadata(self, project_id: int, user_id: int) -> Dict:
        """Get project metadata"""
        project_path = self.get_project_path(project_id, user_id)
        metadata_path = project_path / "metadata.json"
        
        if not metadata_path.exists():
            return {}
        
        return self._read_json(metadata_path)
    
    def update_project_metadata(self, project_id: int, user_id: int, updates: Dict):
        """Update project metadata"""
        project_path = self.get_project_path(project_id, user_id)
        metadata_path = project_path / "metadata.json"
        
        metadata = self.get_project_metadata(project_id, user_id)
        metadata.update(updates)
        metadata["updated_at"] = datetime.utcnow().isoformat()
        
        self._write_json(metadata_path, metadata)
    
    def _write_json(self, file_path: Path, data: dict):
        """Helper to write JSON file"""
        file_path.write_text(json.dumps(data, indent=2))
    
    def _read_json(self, file_path: Path) -> dict:
        """Helper to read JSON file"""
        return json.loads(file_path.read_text())

