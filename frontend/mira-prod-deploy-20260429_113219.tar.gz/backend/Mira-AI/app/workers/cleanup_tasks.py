"""Cleanup tasks for Celery"""
from app.workers.celery_app import celery_app
from app.services.storage.file_storage import FileStorageService
from app.services.storage.cleanup_service import CleanupService
from app.core.logging import get_logger

logger = get_logger(__name__)


@celery_app.task(name="cleanup_expired_projects")
def cleanup_expired_projects():
    """
    Periodic task to clean up expired projects
    
    This task should be scheduled to run daily using Celery Beat
    """
    logger.info("Starting cleanup of expired projects")
    
    try:
        storage = FileStorageService()
        cleanup = CleanupService(storage)
        result = cleanup.cleanup_expired_projects()
        
        logger.info(f"Cleanup completed: {result['deleted_count']} projects deleted, "
                   f"{result['freed_mb']} MB freed")
        
        return result
    except Exception as e:
        logger.error(f"Error during cleanup: {e}", exc_info=True)
        raise

