"""Admin user initialization module"""
import logging
from datetime import datetime

from app.core.config import settings
from app.core.security import get_password_hash
from app.core.logging import get_logger
from app.db.mongodb_models import User, UserRole

logger = get_logger(__name__)


async def create_admin_user():
    """
    Create admin superuser if it doesn't exist and credentials are provided in .env
    This function is called on app startup
    Uses MongoDB (Beanie) for user storage
    """
    # Check if admin credentials are configured
    if not settings.ADMIN_SUPERUSER_EMAIL or not settings.ADMIN_SUPERUSER_PASSWORD:
        logger.info("Admin superuser credentials not configured in .env - skipping admin user creation")
        return
    
    try:
        # Check if admin user already exists (MongoDB)
        existing_admin = await User.find_one(User.email == settings.ADMIN_SUPERUSER_EMAIL)
        
        if existing_admin:
            logger.info(f"Admin user with email {settings.ADMIN_SUPERUSER_EMAIL} already exists - skipping creation")
            return
        
        # Create admin user
        # Bcrypt has a 72 byte limit, truncate if necessary
        password = settings.ADMIN_SUPERUSER_PASSWORD
        if len(password.encode('utf-8')) > 72:
            logger.warning(f"Admin password exceeds 72 bytes, truncating to fit bcrypt limit")
            password = password.encode('utf-8')[:72].decode('utf-8', errors='ignore')
        
        hashed_password = get_password_hash(password)
        
        admin_user = User(
            email=settings.ADMIN_SUPERUSER_EMAIL,
            username="admin",
            hashed_password=hashed_password,
            role=UserRole.ADMIN,
            is_active=True,
            is_superuser=True,
            is_email_verified=True,  # Auto-verify admin email
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        await admin_user.insert()
        
        logger.info(f"✅ Admin superuser created successfully with email: {settings.ADMIN_SUPERUSER_EMAIL}")
        
    except Exception as e:
        logger.error(f"❌ Failed to create admin superuser: {str(e)}", exc_info=True)
