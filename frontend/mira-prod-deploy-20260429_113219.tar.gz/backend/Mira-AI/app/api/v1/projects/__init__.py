"""Projects module"""
