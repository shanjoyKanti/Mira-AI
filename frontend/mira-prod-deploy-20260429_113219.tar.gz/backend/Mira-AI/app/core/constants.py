"""Application-wide constants"""
from enum import Enum


class UserRole(str, Enum):
    """User role types"""
    ADMIN = "admin"
    USER = "user"
    GUEST = "guest"


class ProjectStatus(str, Enum):
    """Project status types"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class ScanStatus(str, Enum):
    """Scan status types"""
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


# File upload constants
ALLOWED_EXTENSIONS = {'.py', '.js', '.ts', '.java', '.cpp', '.c', '.go', '.rs'}
MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB

# Pagination
DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100
