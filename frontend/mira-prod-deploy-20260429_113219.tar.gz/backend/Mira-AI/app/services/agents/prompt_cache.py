"""
Per-process prompt cache for migration agents.

Rationale: for a single multi-file migration, every file sent to the LLM
carries the same system prompt + migration-rules context. Re-rendering
these strings on every call wastes Python time AND, more importantly,
re-runs expensive operations like RAG fetches (web scraping +
embedding) if the caller doesn't explicitly memoize.

This cache is keyed by the tuple (language, from_version, to_version,
framework). Values are simple strings — the rendered system prompt
and the migration-rules context block. First call populates; subsequent
calls within the same process return instantly.

Scope:
  * In-memory, per-process (not Redis). Simpler, no infra, and a single
    pipeline run lives within one process anyway — the cache hits start
    from file #2 of file #1's language and ride through the rest of
    that language's files.
  * Thread-safe via a module-level lock (workers in the analyze
    ThreadPoolExecutor may call concurrently).
  * Bounded to 256 entries with LRU eviction to avoid unbounded growth
    across long-running deploys.

What this does NOT do:
  * Cache the LLM response. Each file is different; caching responses
    would require content hashing + careful eviction. We cache the
    INPUT SCAFFOLDING only.
  * Cross-process caching. If Mira is deployed with multiple API
    workers, each has its own cache. That's fine — cache misses just
    cost one RAG fetch per worker per (lang,from,to) pair.
"""

from __future__ import annotations

import logging
import os
import threading
from collections import OrderedDict
from typing import Any, Callable, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

_CACHE_MAX_ENTRIES = 256

# Value type — a dict so we can stash both the system prompt and the
# migration-rules context block under one key.
CacheEntry = Dict[str, Any]

_cache: "OrderedDict[Tuple[str, str, str, str], CacheEntry]" = OrderedDict()
_lock = threading.Lock()

# Metrics — bumped by the production code; surfaced on health endpoints.
_metrics = {"hits": 0, "misses": 0, "evictions": 0, "populates": 0}


def _make_key(language: str, from_version: str, to_version: str, framework: str = "") -> Tuple[str, str, str, str]:
    return (
        (language or "").strip().lower(),
        (from_version or "").strip(),
        (to_version or "").strip(),
        (framework or "").strip().lower(),
    )


# ---------------------------------------------------------------------------
# Optional Redis-backed tier — shares the cache across API workers and processes.
# The in-memory LRU remains the fast path; Redis is a fallback when a key is
# cold in THIS process but warm somewhere in the fleet. Disabled unless
# MIRA_PROMPT_CACHE_REDIS=true.
# ---------------------------------------------------------------------------

_REDIS_ENABLED = os.environ.get("MIRA_PROMPT_CACHE_REDIS", "false").lower() == "true"
_REDIS_PREFIX = os.environ.get("MIRA_PROMPT_CACHE_REDIS_PREFIX", "mira:prompt_cache:")
_REDIS_TTL_SEC = int(os.environ.get("MIRA_PROMPT_CACHE_REDIS_TTL", str(24 * 3600)))  # 1 day
_redis_client = None  # lazy-initialised


def _get_redis():
    global _redis_client
    if not _REDIS_ENABLED:
        return None
    if _redis_client is not None:
        return _redis_client
    try:
        import redis as _redis_lib
        from app.core.config import settings as _settings
        _redis_client = _redis_lib.Redis.from_url(_settings.REDIS_URL, decode_responses=False)
        _redis_client.ping()
        logger.info("prompt_cache: Redis tier enabled (%s)", _settings.REDIS_URL)
        return _redis_client
    except Exception as e:
        logger.warning("prompt_cache: Redis tier unavailable (%s) — falling back to in-memory only", e)
        _redis_client = None
        return None


def _redis_key(key: Tuple[str, str, str, str]) -> str:
    return _REDIS_PREFIX + ":".join(key)


def _redis_get(key: Tuple[str, str, str, str]) -> Optional[CacheEntry]:
    r = _get_redis()
    if r is None:
        return None
    try:
        import pickle
        raw = r.get(_redis_key(key))
        if raw is None:
            return None
        return pickle.loads(raw)
    except Exception as e:
        logger.debug("prompt_cache: redis_get %s failed: %s", key, e)
        return None


def _redis_set(key: Tuple[str, str, str, str], value: CacheEntry) -> None:
    r = _get_redis()
    if r is None:
        return
    try:
        import pickle
        r.set(_redis_key(key), pickle.dumps(value), ex=_REDIS_TTL_SEC)
    except Exception as e:
        logger.debug("prompt_cache: redis_set %s failed: %s", key, e)


def get_or_populate(
    language: str,
    from_version: str,
    to_version: str,
    framework: str = "",
    populate_fn: Optional[Callable[[], CacheEntry]] = None,
) -> CacheEntry:
    """
    Return the cached entry for this key, or call populate_fn(), store the
    result, and return it.

    If populate_fn is None and the key is absent, returns an empty dict.

    `populate_fn` must be idempotent — under contention two threads may
    race to populate the same key, but the final value stored is the
    winning thread's (the other's result is discarded). That's fine
    because the computed value should be deterministic for the same key.
    """
    key = _make_key(language, from_version, to_version, framework)
    with _lock:
        entry = _cache.get(key)
        if entry is not None:
            # LRU: move to end
            _cache.move_to_end(key)
            _metrics["hits"] += 1
            return entry
        _metrics["misses"] += 1

    # Miss in this process — try Redis if enabled. A cross-worker hit avoids
    # re-running expensive RAG web scrapes.
    redis_hit = _redis_get(key)
    if redis_hit is not None:
        with _lock:
            _cache[key] = redis_hit
            _cache.move_to_end(key)
            _metrics["hits"] += 1
            while len(_cache) > _CACHE_MAX_ENTRIES:
                _cache.popitem(last=False)
                _metrics["evictions"] += 1
        return redis_hit

    if populate_fn is None:
        return {}

    # Compute outside the lock — population can do web scraping and we
    # don't want to serialize all callers.
    try:
        new_entry = populate_fn() or {}
    except Exception as e:
        logger.warning("prompt_cache populate_fn crashed for %s: %s", key, e)
        return {}

    with _lock:
        # Another thread may have populated while we were computing; take
        # theirs if so (deterministic result either way).
        existing = _cache.get(key)
        if existing is not None:
            _cache.move_to_end(key)
            return existing
        _cache[key] = new_entry
        _cache.move_to_end(key)
        _metrics["populates"] += 1
        # LRU eviction
        while len(_cache) > _CACHE_MAX_ENTRIES:
            _cache.popitem(last=False)
            _metrics["evictions"] += 1
    # Share with the fleet through Redis (if enabled). Failures here are logged
    # but never raise — the in-process cache is authoritative for this worker.
    _redis_set(key, new_entry)
    logger.info(
        "prompt_cache: populated %s (size=%d, hits=%d, misses=%d)",
        key, len(_cache), _metrics["hits"], _metrics["misses"],
    )
    return new_entry


def clear() -> None:
    """Used in tests."""
    with _lock:
        _cache.clear()


def stats() -> Dict[str, Any]:
    """For /health diagnostics."""
    with _lock:
        return {**_metrics, "size": len(_cache), "max_size": _CACHE_MAX_ENTRIES}
