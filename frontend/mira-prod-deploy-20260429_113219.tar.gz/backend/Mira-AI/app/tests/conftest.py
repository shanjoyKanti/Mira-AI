"""Minimal conftest — shared fixtures for all tests under app/tests/."""
import pytest
