"""
Contract Validation Agent — Phase 2 of full-stack migration.

Diffs the migrated codebase's API surface against the locked Contract
Registry produced in Phase 0 (by Contract Extraction Agent) and classifies
every difference as Safe, Additive, or Breaking. Breaking changes pause
deployment until a human reviews them.

Solves doc Issues I-01 and I-04:
    "Without a classification layer, Mira's agents would treat all API
    differences as equivalent, either blocking migration unnecessarily on
    safe changes or silently allowing breaking changes through."

Classification rules:

    Endpoint added (path or method new in post)
        → ADDITIVE   — backwards-compatible
    Endpoint removed (path or method missing post)
        → BREAKING   — old callers will 404
    Endpoint renamed (no exact match but similar path/handler)
        → BREAKING   — surfaced explicitly so humans can confirm

    Path parameter added (required)
        → BREAKING
    Path parameter removed
        → BREAKING (caller now sends a literal segment that no route matches)
    Optional query parameter added
        → ADDITIVE

    Auth scheme changed (e.g. session → jwt)
        → BREAKING   — every authenticated client request will fail until
                       the frontend is updated in lock-step
    Auth scheme removed
        → BREAKING

    Response schema field added
        → ADDITIVE
    Response schema field removed
        → BREAKING
    Internal tags / summary / x-mira-* metadata changed
        → SAFE

The output is both a machine-readable JSON report AND a Markdown summary
suitable for posting in PR descriptions / Slack channels. Breaking changes
sit at the top of both.

This agent is **deterministic** (no LLM) so the diff is reproducible and
audit-friendly.
"""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


_DEFAULT_VALIDATION_DIR = Path(
    os.environ.get("MIRA_CONTRACT_VALIDATION_DIR", "/app/app/data/contracts")
)


def validation_dir_for(project_name: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", project_name or "unknown")
    return _DEFAULT_VALIDATION_DIR / safe / "validation"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class Severity(str, Enum):
    SAFE = "safe"
    ADDITIVE = "additive"
    BREAKING = "breaking"


@dataclass
class Finding:
    """One classified diff entry."""
    code: str                  # e.g. "ENDPOINT_REMOVED", "AUTH_SCHEME_CHANGED"
    severity: Severity
    path: Optional[str] = None
    method: Optional[str] = None
    message: str = ""
    before: Optional[Any] = None
    after: Optional[Any] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["severity"] = self.severity.value
        return d


@dataclass
class ValidationReport:
    project_name: str
    generated_at: str
    before_endpoint_count: int = 0
    after_endpoint_count: int = 0
    findings: List[Finding] = field(default_factory=list)
    overall_breaking: int = 0
    overall_additive: int = 0
    overall_safe: int = 0
    deployment_blocked: bool = False
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "project_name": self.project_name,
            "generated_at": self.generated_at,
            "before_endpoint_count": self.before_endpoint_count,
            "after_endpoint_count": self.after_endpoint_count,
            "findings": [f.to_dict() for f in self.findings],
            "totals": {
                "breaking": self.overall_breaking,
                "additive": self.overall_additive,
                "safe": self.overall_safe,
            },
            "deployment_blocked": self.deployment_blocked,
            "notes": self.notes,
        }

    def add(self, f: Finding) -> None:
        self.findings.append(f)
        if f.severity is Severity.BREAKING:
            self.overall_breaking += 1
        elif f.severity is Severity.ADDITIVE:
            self.overall_additive += 1
        else:
            self.overall_safe += 1


# ---------------------------------------------------------------------------
# Comparison primitives
# ---------------------------------------------------------------------------

def _endpoints_index(spec: Dict[str, Any]) -> Dict[Tuple[str, str], Dict[str, Any]]:
    """Flatten an OpenAPI doc into a {(path, method): operation} dict for diffing."""
    out: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for raw_path, methods in (spec.get("paths") or {}).items():
        if not isinstance(methods, dict):
            continue
        for method, op in methods.items():
            m = method.upper()
            if m not in ("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"):
                continue
            out[(raw_path, m)] = op or {}
    return out


def _security_schemes(spec: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    return ((spec.get("components") or {}).get("securitySchemes") or {})


def _op_security(op: Dict[str, Any]) -> List[str]:
    """Return a flat list of security scheme names this operation requires."""
    sec = op.get("security") or []
    out: List[str] = []
    for entry in sec:
        if isinstance(entry, dict):
            out.extend(entry.keys())
    return out


def _op_path_params(op: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [p for p in (op.get("parameters") or []) if (p or {}).get("in") == "path"]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_contracts(
    project_name: str,
    before_spec: Dict[str, Any],
    after_spec: Dict[str, Any],
    *,
    save: bool = True,
) -> ValidationReport:
    """Diff two OpenAPI specs and produce a classified validation report.

    Args:
        project_name: For storage path + report header.
        before_spec: The locked Phase-0 Contract Registry (pre-migration).
        after_spec: The post-migration spec, freshly extracted from the
            modernized code.
        save: If True, persist a JSON + Markdown report under
            ``{VALIDATION_DIR}/<project>/validation/report-<ts>.{json,md}``.

    Returns:
        A ValidationReport with all findings classified. ``deployment_blocked``
        is True iff there are any Breaking findings.
    """
    report = ValidationReport(
        project_name=project_name,
        generated_at=datetime.utcnow().isoformat() + "Z",
    )

    before_eps = _endpoints_index(before_spec or {})
    after_eps = _endpoints_index(after_spec or {})
    report.before_endpoint_count = len(before_eps)
    report.after_endpoint_count = len(after_eps)

    if not before_eps:
        report.notes.append(
            "Pre-migration Contract Registry is empty — there are no endpoints to validate against. "
            "Skipping breaking-change detection (every post-migration endpoint counts as additive)."
        )
    if not after_eps:
        report.notes.append(
            "Post-migration spec is empty — the Contract Extraction Agent didn't find any routes "
            "in the migrated code. Manual review recommended before deploying."
        )

    # Removed endpoints — appear in BEFORE but not in AFTER.
    for key, before_op in before_eps.items():
        if key in after_eps:
            continue
        path, method = key
        report.add(Finding(
            code="ENDPOINT_REMOVED",
            severity=Severity.BREAKING,
            path=path, method=method,
            message=f"Endpoint {method} {path} present in pre-migration registry but missing after migration. Existing callers will receive 404.",
            before=before_op.get("operationId") or before_op.get("summary"),
            after=None,
        ))

    # Added endpoints.
    for key in after_eps.keys() - before_eps.keys():
        path, method = key
        report.add(Finding(
            code="ENDPOINT_ADDED",
            severity=Severity.ADDITIVE,
            path=path, method=method,
            message=f"New endpoint {method} {path} added during migration. Backwards compatible.",
            before=None,
            after=after_eps[key].get("operationId") or after_eps[key].get("summary"),
        ))

    # Compare overlapping endpoints.
    for key in before_eps.keys() & after_eps.keys():
        path, method = key
        before_op = before_eps[key]
        after_op = after_eps[key]

        # Auth scheme drift — top priority since this kills every authenticated request.
        before_sec = sorted(_op_security(before_op))
        after_sec = sorted(_op_security(after_op))
        if before_sec != after_sec:
            severity = Severity.BREAKING if before_sec or after_sec else Severity.SAFE
            report.add(Finding(
                code="AUTH_SCHEME_CHANGED",
                severity=severity,
                path=path, method=method,
                message=f"Auth requirements for {method} {path} changed: {before_sec or 'none'} → {after_sec or 'none'}. Frontend must be updated in lock-step.",
                before=before_sec, after=after_sec,
            ))

        # Path parameters
        before_pp = {(p.get("name") or "").strip(): p for p in _op_path_params(before_op)}
        after_pp = {(p.get("name") or "").strip(): p for p in _op_path_params(after_op)}
        for missing in before_pp.keys() - after_pp.keys():
            report.add(Finding(
                code="PATH_PARAM_REMOVED",
                severity=Severity.BREAKING,
                path=path, method=method,
                message=f"Path parameter {{{missing}}} removed from {method} {path}. URLs from old callers will not match.",
                before=missing, after=None,
            ))
        for added in after_pp.keys() - before_pp.keys():
            req = (after_pp[added] or {}).get("required", True)
            severity = Severity.BREAKING if req else Severity.ADDITIVE
            report.add(Finding(
                code="PATH_PARAM_ADDED",
                severity=severity,
                path=path, method=method,
                message=f"Path parameter {{{added}}} added to {method} {path} (required={req}). Old caller URLs no longer match.",
                before=None, after=added,
            ))

        # Operation rename / handler swap (informational — usually harmless)
        before_id = before_op.get("operationId")
        after_id = after_op.get("operationId")
        if before_id and after_id and before_id != after_id:
            report.add(Finding(
                code="HANDLER_RENAMED",
                severity=Severity.SAFE,
                path=path, method=method,
                message=f"Handler renamed: {before_id} → {after_id}. Path is unchanged so callers are unaffected.",
                before=before_id, after=after_id,
            ))

    # Cross-spec auth scheme catalogue change (e.g. session → jwt globally).
    before_schemes = sorted(_security_schemes(before_spec).keys())
    after_schemes = sorted(_security_schemes(after_spec).keys())
    if before_schemes and after_schemes and set(before_schemes) != set(after_schemes):
        added_sch = set(after_schemes) - set(before_schemes)
        removed_sch = set(before_schemes) - set(after_schemes)
        if removed_sch:
            report.add(Finding(
                code="GLOBAL_AUTH_SCHEME_REMOVED",
                severity=Severity.BREAKING,
                message=f"Auth scheme(s) {sorted(removed_sch)} removed from registry — clients still using them will fail.",
                before=sorted(removed_sch), after=None,
            ))
        if added_sch:
            report.add(Finding(
                code="GLOBAL_AUTH_SCHEME_ADDED",
                severity=Severity.ADDITIVE,
                message=f"New auth scheme(s) {sorted(added_sch)} added — backwards compatible if existing schemes are still supported.",
                before=None, after=sorted(added_sch),
            ))

    report.deployment_blocked = report.overall_breaking > 0

    if save:
        _save_report(project_name, report, before_spec, after_spec)

    return report


# ---------------------------------------------------------------------------
# Persistence + rendering
# ---------------------------------------------------------------------------

def _save_report(
    project_name: str,
    report: ValidationReport,
    before_spec: Dict[str, Any],
    after_spec: Dict[str, Any],
) -> Tuple[Path, Path]:
    out_dir = validation_dir_for(project_name)
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    json_path = out_dir / f"report-{ts}.json"
    md_path = out_dir / f"report-{ts}.md"
    json_path.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")
    md_path.write_text(_render_markdown(report), encoding="utf-8")
    # Stable "latest" pointers for other tooling.
    (out_dir / "report-latest.json").write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")
    (out_dir / "report-latest.md").write_text(_render_markdown(report), encoding="utf-8")
    logger.info(
        "Contract Validation Agent: project=%s breaking=%d additive=%d safe=%d → %s",
        project_name, report.overall_breaking, report.overall_additive, report.overall_safe, json_path,
    )
    return json_path, md_path


def _render_markdown(r: ValidationReport) -> str:
    lines: List[str] = []
    lines.append(f"# Contract Validation Report — {r.project_name}")
    lines.append("")
    lines.append(f"_Generated: {r.generated_at}_")
    lines.append("")
    lines.append(f"- Pre-migration endpoints: **{r.before_endpoint_count}**")
    lines.append(f"- Post-migration endpoints: **{r.after_endpoint_count}**")
    lines.append(f"- Breaking changes: **{r.overall_breaking}**")
    lines.append(f"- Additive changes: **{r.overall_additive}**")
    lines.append(f"- Safe / informational changes: **{r.overall_safe}**")
    lines.append("")
    if r.deployment_blocked:
        lines.append("## 🚨 Deployment blocked")
        lines.append("Breaking changes were detected. Resolve them or explicitly approve before deploying.")
        lines.append("")
    else:
        lines.append("## ✅ No breaking changes detected")
        lines.append("Contract diff is fully backwards-compatible.")
        lines.append("")
    if r.notes:
        lines.append("## Notes")
        for n in r.notes:
            lines.append(f"- {n}")
        lines.append("")
    # Group findings by severity
    by_sev: Dict[Severity, List[Finding]] = {Severity.BREAKING: [], Severity.ADDITIVE: [], Severity.SAFE: []}
    for f in r.findings:
        by_sev[f.severity].append(f)
    for sev, label in (
        (Severity.BREAKING, "🚨 Breaking"),
        (Severity.ADDITIVE, "➕ Additive"),
        (Severity.SAFE, "ℹ️ Safe / informational"),
    ):
        items = by_sev[sev]
        if not items:
            continue
        lines.append(f"## {label} ({len(items)})")
        lines.append("")
        for f in items:
            head_bits = [f"`{f.code}`"]
            if f.method and f.path:
                head_bits.append(f"`{f.method} {f.path}`")
            lines.append(f"- {' '.join(head_bits)} — {f.message}")
        lines.append("")
    return "\n".join(lines)


def load_latest_report(project_name: str) -> Optional[Dict[str, Any]]:
    p = validation_dir_for(project_name) / "report-latest.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("Failed to load validation report %s: %s", p, e)
        return None
