"""
Project-manifest version-constraint updater.

After source modernization, the upgraded code is PHP 8.3 / .NET 8 / Node 20 ready —
but the project's manifest file (composer.json, .csproj, package.json) still declares
the OLD version constraint. Running `composer install` / `dotnet restore` / `npm install`
on the upgraded codebase then fails because the constraint doesn't match the runtime.

This module patches the primary manifests so the upgraded project is actually installable.

Scope (in order of client priority):
  * PHP        → composer.json "require.php"
  * C# / .NET  → *.csproj <TargetFramework>
  * JavaScript → package.json "engines.node"
  * Python     → pyproject.toml requires-python

Design:
  * Read-modify-write only — never destructive. If the manifest doesn't exist, skip silently.
  * Returns a list of (path, before, after) tuples so the caller can surface a diff
    and log it on the ModernizationJob.
  * Only the version CONSTRAINT is touched. We never rewrite dependency lists.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import List, Tuple, Optional

logger = logging.getLogger(__name__)


ManifestChange = Tuple[str, str, str]  # (path, before, after)


def update_project_manifests(
    project_root: Path,
    language: str,
    to_version: str,
) -> List[ManifestChange]:
    """
    Walk the project tree and update the relevant manifest file(s) for the
    target language/version. Returns the list of changes made.

    Safe to call on any project — unknown or missing manifests are skipped.
    """
    lang = (language or "").strip().lower()
    tv = (to_version or "").strip()
    if not tv or not project_root.exists():
        return []

    changes: List[ManifestChange] = []

    try:
        if lang == "php":
            changes.extend(_update_composer_json(project_root, tv))
        elif lang in ("c#", "csharp", "dotnet", ".net"):
            changes.extend(_update_csproj_targetframework(project_root, tv))
        elif lang in ("javascript", "typescript", "node", "nodejs"):
            changes.extend(_update_package_json_engines(project_root, tv))
        elif lang == "python":
            changes.extend(_update_pyproject_requires_python(project_root, tv))
    except Exception as e:
        logger.warning("manifest update failed for %s %s: %s", lang, tv, e)

    if changes:
        logger.info("manifest_updater: %d change(s) across %s", len(changes), lang)
        try:
            from app.core.metrics import mira_manifest_updates_total
            mira_manifest_updates_total.labels(language=lang or "unknown").inc(len(changes))
        except Exception:
            pass
    return changes


# ---------------------------------------------------------------------------
# PHP — composer.json
# ---------------------------------------------------------------------------

def _update_composer_json(root: Path, tv: str) -> List[ManifestChange]:
    out: List[ManifestChange] = []
    for composer in root.rglob("composer.json"):
        # Skip vendored copies
        if "vendor" in composer.parts:
            continue
        try:
            raw = composer.read_text(encoding="utf-8")
            data = json.loads(raw)
        except Exception as e:
            logger.debug("composer.json unreadable at %s: %s", composer, e)
            continue
        if not isinstance(data, dict):
            continue
        req = data.get("require")
        if not isinstance(req, dict) or "php" not in req:
            continue
        before = str(req["php"])
        after = f"^{tv}"
        if before == after:
            continue
        req["php"] = after
        composer.write_text(json.dumps(data, indent=4) + "\n", encoding="utf-8")
        out.append((str(composer), before, after))
        logger.info("composer.json: require.php %s → %s  (%s)", before, after, composer)
    return out


# ---------------------------------------------------------------------------
# .NET — .csproj TargetFramework / TargetFrameworks
# ---------------------------------------------------------------------------

# Very small parser — we only replace the text between <TargetFramework> tags.
# Full XML parsing would preserve comments/attributes, but is heavier; since
# every .csproj's first element is <Project ...> and this is a trusted path,
# regex is safe enough.
_TF_SINGLE_RE = re.compile(r"(<TargetFramework>)([^<]+)(</TargetFramework>)")
_TF_MULTI_RE = re.compile(r"(<TargetFrameworks>)([^<]+)(</TargetFrameworks>)")


def _dotnet_target_token(tv: str) -> Optional[str]:
    """
    Map a version string to a TargetFramework moniker.
      8  → net8.0
      8.0 → net8.0
      7   → net7.0
      4.8 → net48   (Framework)
    """
    m = re.search(r"(\d+)(?:\.(\d+))?", tv or "")
    if not m:
        return None
    major = int(m.group(1))
    minor = int(m.group(2) or "0")
    if major >= 5:
        return f"net{major}.{minor}"
    # .NET Framework uses a different scheme: net48, net472, etc.
    return f"net{major}{minor}"


def _update_csproj_targetframework(root: Path, tv: str) -> List[ManifestChange]:
    out: List[ManifestChange] = []
    token = _dotnet_target_token(tv)
    if not token:
        return out
    for csproj in list(root.rglob("*.csproj")) + list(root.rglob("*.fsproj")) + list(root.rglob("*.vbproj")):
        # Skip build outputs
        if any(p in csproj.parts for p in ("bin", "obj", "packages")):
            continue
        try:
            raw = csproj.read_text(encoding="utf-8")
        except Exception as e:
            logger.debug(".csproj unreadable at %s: %s", csproj, e)
            continue
        original = raw
        m_single = _TF_SINGLE_RE.search(raw)
        if m_single and m_single.group(2).strip() != token:
            before = m_single.group(2)
            raw = _TF_SINGLE_RE.sub(rf"\g<1>{token}\g<3>", raw, count=1)
            out.append((str(csproj), before, token))
        else:
            m_multi = _TF_MULTI_RE.search(raw)
            if m_multi and token not in m_multi.group(2):
                before = m_multi.group(2)
                # Preserve other targets, just add the new one to the front
                new_targets = f"{token};{before}"
                raw = _TF_MULTI_RE.sub(rf"\g<1>{new_targets}\g<3>", raw, count=1)
                out.append((str(csproj), before, new_targets))
        if raw != original:
            csproj.write_text(raw, encoding="utf-8")
            logger.info("csproj: TargetFramework updated in %s", csproj)
    return out


# ---------------------------------------------------------------------------
# JS / Node — package.json engines.node
# ---------------------------------------------------------------------------

def _update_package_json_engines(root: Path, tv: str) -> List[ManifestChange]:
    out: List[ManifestChange] = []
    m = re.search(r"(\d+)", tv or "")
    if not m:
        return out
    major = int(m.group(1))
    target = f">={major}.0.0"
    for pkg in root.rglob("package.json"):
        if "node_modules" in pkg.parts:
            continue
        try:
            raw = pkg.read_text(encoding="utf-8")
            data = json.loads(raw)
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        engines = data.get("engines") or {}
        if not isinstance(engines, dict):
            engines = {}
        before = str(engines.get("node", ""))
        if before == target:
            continue
        engines["node"] = target
        data["engines"] = engines
        pkg.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        out.append((str(pkg), before or "(unset)", target))
        logger.info("package.json: engines.node %s → %s (%s)", before, target, pkg)
    return out


# ---------------------------------------------------------------------------
# Python — pyproject.toml requires-python
# ---------------------------------------------------------------------------

_REQ_PY_RE = re.compile(r'(requires-python\s*=\s*)"([^"]+)"')


def _update_pyproject_requires_python(root: Path, tv: str) -> List[ManifestChange]:
    out: List[ManifestChange] = []
    target = f">={tv}"
    for py in root.rglob("pyproject.toml"):
        if any(p in py.parts for p in (".venv", "venv", "site-packages")):
            continue
        try:
            raw = py.read_text(encoding="utf-8")
        except Exception:
            continue
        m = _REQ_PY_RE.search(raw)
        if not m:
            continue
        before = m.group(2)
        if before == target:
            continue
        new_raw = _REQ_PY_RE.sub(rf'\g<1>"{target}"', raw, count=1)
        py.write_text(new_raw, encoding="utf-8")
        out.append((str(py), before, target))
        logger.info("pyproject.toml: requires-python %s → %s (%s)", before, target, py)
    return out
