"""MongoDB connection and initialization using Beanie"""
from pymongo import AsyncMongoClient
from beanie import init_beanie
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# Global MongoDB client
mongodb_client: AsyncMongoClient | None = None


async def init_mongodb():
    """Initialize MongoDB connection and Beanie"""
    global mongodb_client

    try:
        # Beanie 2.x uses PyMongo's async client (not Motor)
        mongodb_client = AsyncMongoClient(
            settings.MONGO_DB_URL,
            serverSelectionTimeoutMS=5000,  # 5 second timeout
            maxPoolSize=50,  # Connection pool size
            minPoolSize=10,  # Minimum connections
        )

        # Test connection
        await mongodb_client.admin.command("ping")
        logger.info("✅ MongoDB connection established successfully")

        # Initialize Beanie with models
        from app.db.mongodb_models import (
            User,
            UserProject,
            AnalysisReport,
            RefreshToken,
            SonarQubeScanJob,
            SonarQubeReport,
            SonarQubeAuditLog,
            ModernizationJob,
            Transform,
        )

        await init_beanie(
            database=mongodb_client[settings.MONGODB_DATABASE],
            document_models=[
                User,
                UserProject,
                AnalysisReport,
                RefreshToken,
                SonarQubeScanJob,
                SonarQubeReport,
                SonarQubeAuditLog,
                ModernizationJob,
                Transform,
            ],
        )

        logger.info(f"✅ Beanie initialized with database: {settings.MONGODB_DATABASE}")

    except Exception as e:
        logger.error(f"❌ Failed to connect to MongoDB: {str(e)}", exc_info=True)
        raise


async def close_mongodb():
    """Close PyMongo async client and its background tasks."""
    global mongodb_client

    if mongodb_client:
        await mongodb_client.close()
        mongodb_client = None
        logger.info("MongoDB connection closed")


def get_mongodb_client() -> AsyncMongoClient:
    """Get MongoDB client instance"""
    if mongodb_client is None:
        raise RuntimeError("MongoDB client not initialized. Call init_mongodb() first.")
    return mongodb_client
