"""Agent API schemas - Request/response models for agent endpoints"""
from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field, field_validator


class SSHCredentials(BaseModel):
    """SSH credentials for connecting to the client VM."""

    hostname: str = Field(..., description="Server hostname or IP address (e.g. '10.240.92.4')")
    port: int = Field(22, description="SSH port number. Default is 22.")
    username: str = Field(..., description="SSH username on the remote server")
    password: Optional[str] = Field(None, description="SSH password. Provide either password or private_key.")
    private_key: Optional[str] = Field(
        None,
        description="PEM-encoded SSH private key content. Provide either this or password.",
        json_schema_extra={"exclude_from_schema": True},
    )
    private_key_password: Optional[str] = Field(
        None,
        description="Passphrase for the private key, if it is encrypted.",
        json_schema_extra={"exclude_from_schema": True},
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "hostname": "10.240.92.4",
                "port": 22,
                "username": "usama",
                "password": "your-password"
            }]
        }
    }


class StructureAnalysisRequest(BaseModel):
    """[DEPRECATED] Analyze project structure directly. Use `/run-structure-language-and-version-upgradation` instead."""

    ssh_credentials: SSHCredentials = Field(..., description="SSH credentials for the remote server")
    source_path: str = Field(..., description="Absolute path to the project directory on the remote server (e.g. '/home/usama/my-php-app')")
    project_name: Optional[str] = Field(None, description="Human-readable project name. Derived from source_path if omitted.")

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "ssh_credentials": {"hostname": "10.240.92.4", "port": 22, "username": "usama", "password": "your-password"},
                "source_path": "/home/usama/my-php-app",
                "project_name": "MyProject"
            }]
        }
    }


class StructureAnalysisResponse(BaseModel):
    """Directory structure of the remote project."""

    success: bool = Field(..., description="Whether the analysis completed without error")
    project_name: str = Field(..., description="Project name used for this analysis")
    source_path: str = Field(..., description="Resolved path scanned on the remote server")
    server_hostname: str = Field(..., description="Hostname of the remote server")
    structure_tree: str = Field(..., description="Human-readable directory/file tree of the project")
    total_files: int = Field(..., description="Total number of source files found")
    total_directories: int = Field(..., description="Total number of directories found")
    analysis_time: float = Field(..., description="Time taken for the analysis in seconds")
    timestamp: datetime = Field(..., description="UTC timestamp when analysis completed")


class LanguageAnalysisRequest(BaseModel):
    """[DEPRECATED] Analyze languages and frameworks. Use `/run-structure-language-and-version-upgradation` instead."""

    ssh_credentials: SSHCredentials = Field(..., description="SSH credentials for the remote server")
    source_path: str = Field(..., description="Absolute path to the project on the remote server")
    project_name: Optional[str] = Field(None, description="Human-readable project name")

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "ssh_credentials": {"hostname": "10.240.92.4", "port": 22, "username": "usama", "password": "your-password"},
                "source_path": "/home/usama/my-php-app",
                "project_name": "MyProject"
            }]
        }
    }


class LanguageAnalysisResponse(BaseModel):
    """Detected languages, frameworks, and versions for the project."""

    success: bool = Field(..., description="Whether the analysis completed without error")
    project_name: str = Field(..., description="Project name")
    source_path: str = Field(..., description="Path scanned on the remote server")
    server_hostname: str = Field(..., description="Hostname of the remote server")
    languages: List[str] = Field(..., description="Detected programming languages (e.g. ['php'])")
    frameworks: List[str] = Field(..., description="Detected frameworks (e.g. ['Laravel'])")
    language_versions: Dict[str, str] = Field(
        ...,
        description="Detected version per language/framework key (e.g. {'php': '7.4', 'laravel': '9'})"
    )
    analysis_time: float = Field(..., description="Time taken in seconds")
    timestamp: datetime = Field(..., description="UTC timestamp when analysis completed")


class UpgradeAnalysisRequest(BaseModel):
    """[DEPRECATED] Generate an upgrade guide from a local SonarQube report file. Use the 4-step pipeline instead."""

    project_name: str = Field(..., description="Project name (used for output file naming)")
    from_version: str = Field(..., description="Current language version for context (e.g. '7.4')")
    to_version: str = Field(..., description="Target language version for context (e.g. '8.3')")
    sonarqube_report_path: str = Field(
        ...,
        description="Local path inside the container to a SonarQube report file (.html, .md, or .docx)"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "project_name": "my-php-app",
                "from_version": "7.4",
                "to_version": "8.3",
                "sonarqube_report_path": "reports/sonarqube_report.html",
            }]
        }
    }


class UpgradeAnalysisResponse(BaseModel):
    """Result of the SonarQube-derived upgrade guide generation."""

    success: bool = Field(..., description="Whether the guide was generated successfully")
    from_version: str = Field(..., description="Source version provided in the request")
    to_version: str = Field(..., description="Target version provided in the request")
    from_laravel: Optional[str] = Field(None, description="Current Laravel version (reserved; not set by Sonar-only analysis)")
    to_laravel: Optional[str] = Field(None, description="Target Laravel guide major (not set by this endpoint)")
    sonarqube_analysis_path: Optional[str] = Field(None, description="Container-local path to the generated upgrade guide (.txt)")
    upgrade_guide_path: Optional[str] = Field(None, description="Same as sonarqube_analysis_path")
    laravel_upgrade_guide_path: Optional[str] = Field(None, description="Always null for Sonar-only analysis")
    message: str = Field("", description="Human-readable status message")
    timestamp: datetime = Field(..., description="UTC timestamp when the guide was generated")


class CodeModernizationRequest(BaseModel):
    """[DEPRECATED] Modernize code over SSH using an upgrade guide. Use `/run-code-modernization` instead."""

    ssh_credentials: SSHCredentials = Field(..., description="SSH credentials for the remote server")
    source_path: str = Field(..., description="Absolute path to the project on the remote server")
    output_path: Optional[str] = Field(
        None,
        description=(
            "Remote directory where modernized code will be saved. "
            "Files land under `{output_path}/upgraded_{project}_{timestamp}/`. "
            "Defaults to `/home/{ssh_username}/upgraded-codes`."
        ),
    )
    project_name: str = Field(..., description="Project name (used in output folder naming and logs)")
    to_version: str = Field(..., description="Target language version (e.g. '8.3' for PHP 8.3)")
    sonarqube_report_path: Optional[str] = Field(
        None,
        description="Container-local path to the SonarQube upgrade guide (.txt) produced by the upgrade analysis step"
    )
    php_upgrade_guide_path: Optional[str] = Field(None, description="Ignored — modernization uses the SonarQube guide only")
    laravel_upgrade_guide_path: Optional[str] = Field(None, description="Ignored — modernization uses the SonarQube guide only")

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "ssh_credentials": {"hostname": "10.240.92.4", "port": 22, "username": "usama", "password": "your-password"},
                "source_path": "/home/usama/my-php-app",
                "output_path": "/home/usama/upgraded-codes",
                "project_name": "my-php-app",
                "to_version": "8.3",
                "sonarqube_report_path": "app/data/upgrade-guide/my-php-app_sonarqube_analysis.txt",
            }]
        }
    }


class CodeModernizationResponse(BaseModel):
    """Result of the code modernization step."""

    success: bool = Field(..., description="Whether modernization completed without error")
    source_path: str = Field(..., description="Path of the source project that was modernized")
    output_path: str = Field(..., description="Full remote path where modernized code was saved")
    server_hostname: str = Field(..., description="Hostname of the remote server")
    project_name: str = Field(..., description="Project name")
    to_version: str = Field(..., description="Target version the code was modernized to")
    total_files: int = Field(..., description="Total source files processed")
    files_upgraded: int = Field(..., description="Files that were modified by the LLM")
    files_unchanged: int = Field(..., description="Files that required no changes")
    files_with_errors: int = Field(..., description="Files that encountered an error during modernization")
    message: str = Field(..., description="Human-readable summary")
    timestamp: datetime = Field(..., description="UTC timestamp when modernization completed")


class RunModernizationRequest(BaseModel):
    """
    Legacy single-shot full pipeline (structure + language + upgrade + modernize in one call).

    Prefer the individual Step 1–4 endpoints for better observability and retry capability.
    Uses SSH credentials saved via `POST /analyze/test/ssh` — only `project_name` is required.
    """

    project_name: str = Field(..., description="Project name. Used to locate source code via saved SSH source_path.")
    source_path: Optional[str] = Field(None, description="Override: absolute path to project on the server")
    output_path: Optional[str] = Field(None, description="Override: directory for upgraded code on the server")
    to_version: Optional[str] = Field(
        "8.3",
        description="Target version to modernize to (e.g. '8.3' for PHP, '3.12' for Python). Defaults to latest stable."
    )
    sonarqube_report_type: Optional[str] = Field(
        "generic_security",
        description=(
            "SonarQube quality profile to activate during the scan. "
            "Allowed values: `generic_security` (default), `owasp_top_10`, `pci_dss`, `iso_27001`."
        ),
    )
    php_documentation_path: Optional[str] = Field(
        None,
        description="Deprecated — ignored. PHP migration docs are fetched on-demand via RAG."
    )
    laravel_documentation_path: Optional[str] = Field(
        None,
        description="Deprecated — ignored. Laravel upgrade guides are fetched on-demand via RAG."
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{"project_name": "my_php_app"}]
        }
    }


class RunModernizationResponse(BaseModel):
    """Result of the legacy single-shot full pipeline."""

    success: bool = Field(..., description="Whether the full pipeline completed without error")
    project_name: str = Field(..., description="Project name")
    source_path: str = Field(..., description="Source path on the remote server")
    output_path: str = Field(..., description="Full path where modernized code was saved on the remote server")
    server_hostname: str = Field(..., description="Hostname of the remote server")
    project_structure: Optional[str] = Field(None, description="Directory/file tree from the structure analysis phase")
    from_version: str = Field(..., description="Detected source version (e.g. '7.4')")
    to_version: str = Field(..., description="Target version code was modernized to")
    from_laravel: Optional[str] = Field(None, description="Detected current Laravel version (null if not a Laravel project)")
    to_laravel: Optional[str] = Field(None, description="Target Laravel guide major derived from target PHP version")
    steps_completed: List[str] = Field(..., description="List of pipeline steps that completed successfully")
    sonarqube_report_path: Optional[str] = Field(None, description="Path to the SonarQube upgrade guide (.txt)")
    php_upgrade_guide_path: Optional[str] = Field(None, description="Always null in Sonar-only flow (legacy field)")
    laravel_upgrade_guide_path: Optional[str] = Field(None, description="Always null in Sonar-only flow (legacy field)")
    total_files: int = Field(..., description="Total source files processed")
    files_upgraded: int = Field(..., description="Files modified by the LLM")
    files_unchanged: int = Field(..., description="Files that required no changes")
    files_with_errors: int = Field(..., description="Files that encountered errors")
    message: str = Field(..., description="Human-readable summary")
    timestamp: datetime = Field(..., description="UTC timestamp when pipeline completed")


class RunStructureLanguageRequest(BaseModel):
    """
    **Migration Step 1** — Detect project structure, language, and version, then automatically
    run the staged migration (one version step at a time) and upload each stage snapshot to your VM.

    Uses SSH credentials saved via `POST /analyze/test/ssh`. Only `project_name` is required.
    Returns a `transform_id` that links all subsequent steps (2–4) together.
    """

    project_name: str = Field(
        ...,
        description=(
            "Project name. The source path on your VM is derived from the SSH credentials saved "
            "via `POST /analyze/test/ssh` (`ssh_source_path`). "
            "If that path already ends with the project name it is used as-is; "
            "otherwise `project_name` is appended as a subdirectory."
        ),
    )
    to_version: Optional[str] = Field(
        None,
        description=(
            "Target version to migrate to. Examples: `'8.3'` for PHP 8.3, `'3.12'` for Python 3.12, "
            "`'21'` for Java 21. If omitted the system uses the latest known stable version for the detected language."
        ),
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{"project_name": "php_test", "to_version": "8.3"}]
        }
    }


class RunUpgradeAnalysisRequest(BaseModel):
    """
    **Migration Step 3** — Run upgrade analysis with optional custom user requirements.
    Runs a SonarQube scan on the migrated code and produces an LLM upgrade guide.

    Only `project_name` is required — `transform_id` is auto-fetched from the DB
    (uses the most recent transform for the project).
    """

    project_name: str = Field(..., description="Project name (same value used in Step 1)")
    transform_id: Optional[str] = Field(
        None,
        description="Transform ID from Step 1. Auto-fetched from DB if omitted."
    )
    user_input: Optional[str] = Field(
        None,
        description=(
            "Optional free-text requirements to incorporate into the upgrade guide "
            "(e.g. 'Focus on OWASP Top 10 issues' or 'We use AWS Lambda, optimize accordingly'). "
            "Leave null to run a standard analysis."
        ),
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{"project_name": "php_test"}]
        }
    }


class RunUpgradeAnalysisSimpleRequest(BaseModel):
    """
    **Migration Step 2** — Run upgrade analysis without user input (standard mode).
    Runs a SonarQube scan on the migrated code and produces an LLM upgrade guide.

    Only `project_name` is required — `transform_id` is auto-fetched from the DB.
    """

    project_name: str = Field(..., description="Project name (same value used in Step 1)")
    transform_id: Optional[str] = Field(
        None,
        description="Transform ID from Step 1. Auto-fetched from DB if omitted."
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{"project_name": "php_test"}]
        }
    }


class RunCodeModernizationRequest(BaseModel):
    """
    **Migration Step 4** — Apply LLM-driven code modernization guided by the SonarQube upgrade guide
    produced in Steps 2/3. Saves the final modernized code to your VM under
    `upgraded-codes/{project}/upgraded_{project}_{timestamp}/`.

    Only `project_name` is required — `transform_id` is auto-fetched from the DB.
    """

    project_name: str = Field(..., description="Project name (same value used in Steps 1–3)")
    transform_id: Optional[str] = Field(
        None,
        description="Transform ID from Step 1. Auto-fetched from DB if omitted."
    )
    languages: Optional[List[str]] = Field(
        None,
        description=(
            "List of language keys to migrate (e.g. ['php', 'javascript']). "
            "Use POST /agents/migration/estimate first to discover available languages. "
            "If omitted, defaults to the project's primary detected language "
            "(backward compatible with single-language PHP migrations)."
        ),
    )
    target_versions: Optional[Dict[str, str]] = Field(
        None,
        description=(
            "Per-language target version map, e.g. {'php': '8.3', 'javascript': 'es2024'}. "
            "If a language's target is missing, the backend falls back to the latest stable "
            "version for that language. For single-language migrations, the Step 1 to_version "
            "is still honored if this field is omitted."
        ),
    )

    # Internal per-language fanout fields. The fanout endpoint
    # (POST /run-code-modernization) copies the incoming request once per
    # detected language and sets these before dispatching the background worker
    # so each worker processes exactly its own language and version. Callers
    # should NOT set these directly — use ``languages`` / ``target_versions``.
    language: Optional[str] = Field(
        None,
        description="Internal: single-language name used by per-language background workers (set by the fanout dispatcher).",
    )
    target_version: Optional[str] = Field(
        None,
        description="Internal: single target version for the language above (set by the fanout dispatcher).",
    )
    from_version: Optional[str] = Field(
        None,
        description="Internal: source version read from Step 1 for the per-language worker.",
    )
    framework: Optional[str] = Field(
        None,
        description="Internal: framework (e.g. 'React', 'Django') detected in Step 1 for the per-language worker.",
    )
    # Pre-flight metadata captured by the modal so the start-of-migration email can
    # tell the user which stacks they enabled, the file count, and the estimated
    # runtime/cost. None of these affect the migration itself — purely for audit
    # and email content. Optional so existing callers keep working unchanged.
    stacks: Optional[Dict[str, bool]] = Field(
        None,
        description="Per-stack toggles from the pre-flight modal: {frontend: bool, backend: bool, api: bool}.",
    )
    estimate_summary: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "Compact estimate snapshot from /migration/estimate. Recommended keys: "
            "{total_files: int, wall_clock_human: str, estimated_cost_usd: float}."
        ),
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {"project_name": "php_test"},
                {
                    "project_name": "my-app",
                    "languages": ["php", "javascript"],
                    "target_versions": {"php": "8.3", "javascript": "es2024"},
                },
            ]
        }
    }


class TransformListItem(BaseModel):
    """Status summary for one complete migration transform (Steps 1–4)."""

    transform_id: str = Field(..., description="Unique identifier for this transform run")
    project_name: str = Field(..., description="Project name")
    step_1_job_id: Optional[str] = Field(None, description="Job ID for Step 1 (structure + language + staged migration)")
    step_1_status: Optional[str] = Field(None, description="Step 1 status: running | completed | failed")
    step_2_job_id: Optional[str] = Field(None, description="Job ID for Step 2 (upgrade analysis — simple)")
    step_2_status: Optional[str] = Field(None, description="Step 2 status: running | completed | failed")
    step_3_job_id: Optional[str] = Field(None, description="Job ID for Step 3 (upgrade analysis — with user input)")
    step_3_status: Optional[str] = Field(None, description="Step 3 status: running | completed | failed")
    step_4_job_id: Optional[str] = Field(None, description="Job ID for Step 4 (code modernization)")
    step_4_status: Optional[str] = Field(None, description="Step 4 status: running | completed | failed")
    current_step: int = Field(0, description="Highest step that has been started (1–4). 0 means not started.")
    updated_project_name: Optional[str] = Field(None, description="Project name if it was renamed during the pipeline")
    created_at: Optional[datetime] = Field(None, description="UTC timestamp when this transform was created")
    updated_at: Optional[datetime] = Field(None, description="UTC timestamp of last update")


class SecurityTestRequest(BaseModel):
    """
    **Post-migration security verification.**

    Cross-checks the modernized code against the original SonarQube security findings
    and reports which issues were resolved and which remain.

    Send just `project_name` — the API auto-resolves the upgraded folder from the DB
    (set when Step 4 polling returns `completed`).
    """

    project_name: str = Field(
        ...,
        min_length=1,
        description="Project name (same as Steps 1–4). The latest upgraded folder is auto-resolved from DB.",
    )
    upgrade_project_name: Optional[str] = Field(
        None,
        description=(
            "Override: name of the upgraded folder on the remote server "
            "(e.g. `'upgraded_php_test_20260416_213105'`). "
            "Auto-resolved from DB if omitted."
        ),
    )
    security_report_path: Optional[str] = Field(
        None,
        description="Path to the generic security report (.md). Auto-discovered from reports/ if omitted."
    )

    @field_validator("upgrade_project_name")
    @classmethod
    def upgrade_project_name_non_empty(cls, v: str) -> str:
        if v is None or (isinstance(v, str) and not v.strip()):
            raise ValueError("upgrade_project_name cannot be empty or whitespace-only")
        return v

    model_config = {
        "json_schema_extra": {
            "examples": [{"project_name": "php_test"}]
        }
    }


class MigrationPlanRequest(BaseModel):
    """Compute the version-step ladder between two versions (utility endpoint)."""

    from_version: str = Field(..., description="Starting version (e.g. '7.0')")
    to_version: str = Field(..., description="Target version (e.g. '8.3')")
    docs_txt_root: Optional[str] = Field(
        None,
        description="Override path to php_documentation_txt parent folder (rarely needed)"
    )
    load_file_contents: bool = Field(
        True,
        description="If true, count documentation chars per stage. If false, only list stage paths."
    )
    max_chars_per_stage: Optional[int] = Field(
        None,
        description="Optional cap on combined documentation characters per stage"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{"from_version": "7.0", "to_version": "8.3"}]
        }
    }


class MigrationPlanStageItem(BaseModel):
    stage_index: int = Field(..., description="Stage number (1-based)")
    folder_num: int = Field(..., description="PHP minor version number (e.g. 80 for PHP 8.0)")
    folder_name: str = Field(..., description="Documentation folder name (e.g. 'php_migration_80_txt')")
    from_version: str = Field(..., description="Source version for this stage (e.g. '7.4')")
    to_version: str = Field(..., description="Target version for this stage (e.g. '8.0')")
    label_from: str = Field(..., description="Human-readable source label (e.g. '7.4.x')")
    label_to: str = Field(..., description="Human-readable target label (e.g. '8.0.x')")
    doc_dir: str = Field(..., description="Documentation directory path (or RAG reference)")
    doc_file_count: int = Field(..., description="Number of documentation files for this stage")
    documentation_chars: int = Field(..., description="Total character count of documentation loaded for this stage")


class MigrationPlanResponse(BaseModel):
    success: bool = Field(..., description="Whether the plan was computed successfully")
    from_version: str = Field(..., description="Starting version")
    to_version: str = Field(..., description="Target version")
    stage_count: int = Field(..., description="Number of migration stages")
    stages: List[MigrationPlanStageItem] = Field(..., description="Ordered list of migration stages")
    message: str = Field("", description="Status message")
    timestamp: datetime = Field(..., description="UTC timestamp")


class StagedModernizationRequest(BaseModel):
    """
    Run the staged migration directly (internal/advanced use).
    Prefer `POST /run-structure-language-and-version-upgradation` which calls this automatically.
    """

    ssh_credentials: SSHCredentials = Field(..., description="SSH credentials for the client server")
    source_path: str = Field(..., description="Absolute path to the project on the client server")
    output_path: Optional[str] = Field(
        None,
        description=(
            "Base directory on the client server for per-stage snapshots. "
            "Defaults to `/home/{ssh_username}/migrated-codes`. "
            "Each stage is saved under `{base}/{project_name}/stage_XX_{lang}{VV}/`."
        ),
    )
    project_name: str = Field(..., description="Project name (used in folder names, reports, and logs)")
    from_version: str = Field(..., description="Current detected version (e.g. '7.4')")
    to_version: str = Field(..., description="Target version (e.g. '8.3')")
    docs_txt_root: Optional[str] = Field(None, description="Rarely needed — override for documentation root path")
    max_chars_per_stage: Optional[int] = Field(None, description="Optional cap on documentation chars per stage")
    laravel_upgrade_guide_path: Optional[str] = Field(None, description="Legacy — ignored. RAG handles Laravel docs.")
    from_laravel: Optional[str] = Field(
        None,
        description="Detected current Laravel major version (e.g. '9'). Used as context for synthesis."
    )
    to_laravel: Optional[str] = Field(
        None,
        description="Target Laravel major version (e.g. '11'). Informational; used in per-stage guide synthesis."
    )
    laravel_documentation_path: Optional[str] = Field(
        None,
        description="Deprecated — ignored. Laravel upgrade guides are fetched on-demand via RAG."
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{
                "ssh_credentials": {"hostname": "10.240.92.4", "port": 22, "username": "usama", "password": "your-password"},
                "source_path": "/home/usama/my-app",
                "output_path": "/home/usama/migrated-codes",
                "project_name": "my-app",
                "from_version": "7.4",
                "to_version": "8.3",
            }]
        }
    }


class StagedModernizationResponse(BaseModel):
    success: bool = Field(..., description="Whether all migration stages completed successfully")
    project_name: str = Field(..., description="Project name")
    source_path: str = Field("", description="Source path on the remote server")
    remote_migrated_versions_base: str = Field("", description="Base directory where stage snapshots were saved")
    final_php_version: Optional[str] = Field(None, description="Final version reached after all stages")
    stages: List[Dict[str, Any]] = Field(default_factory=list, description="Per-stage result details")
    log_path: Optional[str] = Field(None, description="Path to the staged migration log file")
    message: str = Field("", description="Human-readable summary")
    timestamp: datetime = Field(..., description="UTC timestamp when migration completed")


class StagedModernizationJobStartResponse(BaseModel):
    job_id: str = Field(..., description="Job ID — use with GET …/status/{job_id} to poll progress")
    status: str = Field("running", description="Always 'running' immediately after submission")
    message: str = Field(..., description="Human-readable start confirmation")
    project_name: str = Field(..., description="Project name")


class FixSonarIssuesRequest(BaseModel):
    """
    **Post-Migration SonarQube Issue Fixer** — automatically applies LLM-generated fixes
    to the remaining SonarQube issues in the migrated code.

    Only `project_name` is required. The API auto-resolves the latest migrated stage path
    and SonarQube project key from the DB (set after Steps 2/3 and Step 4 complete).
    """

    project_name: str = Field(
        ...,
        description="Project name (same value used in Steps 1–4).",
        examples=["php_test"],
    )
    stage_path: Optional[str] = Field(
        None,
        description=(
            "Override: absolute path to the migrated code on the client server "
            "(e.g. `/home/ubuntu/migrated-codes/php_test/stage_03_php83`). "
            "Auto-resolved from DB if omitted."
        ),
    )
    sonar_project_key: Optional[str] = Field(
        None,
        description=(
            "SonarQube project key. Auto-resolved from `UserProject.last_sonar_project_key` "
            "in DB if omitted; falls back to `project_name`."
        ),
    )
    dry_run: bool = Field(
        False,
        description="When true, returns what would be fixed without writing any files back to the server.",
    )

    model_config = {
        "json_schema_extra": {
            "examples": [{"project_name": "php_test"}]
        }
    }


class SecurityTestResponse(BaseModel):
    """Result of post-migration security verification."""

    success: bool = Field(..., description="Whether the security check completed without error")
    project_name: str = Field(..., description="Project name that was checked")
    total_issues: int = Field(0, description="Total security issues found in the original SonarQube report")
    resolved_count: int = Field(0, description="Number of issues that are no longer present in the modernized code")
    remaining_count: int = Field(0, description="Number of issues still present in the modernized code")
    resolution_percentage: float = Field(0.0, description="Percentage of issues resolved (0–100)")
    resolved_issues: List[Dict[str, Any]] = Field(default_factory=list, description="Details of resolved issues")
    remaining_issues: List[Dict[str, Any]] = Field(default_factory=list, description="Details of remaining issues")
    summary: str = Field("", description="Human-readable verification summary")
    timestamp: datetime = Field(..., description="UTC timestamp when verification completed")
