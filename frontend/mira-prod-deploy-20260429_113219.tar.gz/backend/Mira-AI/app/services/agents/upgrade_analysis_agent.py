"""
PHP Upgrade Analyzer for MIRA-AI (SonarQube only)

1. Resolves the code directory to scan: under ``{ssh_base}/migrated-codes/{project}/`` the folder
   whose name matches ``stage_*_php{MAJ}{MIN}`` for the target PHP version (e.g. 8.3 → ``stage_06_php83``).
   If resolution fails, falls back to ``{ssh_base}/{project}`` (legacy).
2. Downloads SonarQube report via ``sonarqube_report.run_download_workflow`` (login → scan → download)
   using that remote path.
3. Reads the latest report, analyzes it with the LLM, and saves the upgrade guide under
   ``app/data/upgrade-guide/``.

Stage discovery and Sonar download use SSH credentials passed from the API (typically the logged-in
user's saved profile from the database). If credentials are omitted, ``sonarqube_report`` falls back to
its module defaults (legacy dev worker).

No PHP manual or Laravel documentation analysis is performed in this module.
"""

import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
from datetime import datetime

from app.services.agents.base_agent import BaseAgent, AgentState, GroqClient
from app.services.agents.sonarqube_report import run_download_workflow
from app.services.ssh.ssh_service import SSHService
from app.core.logging import get_logger

try:
    from app.core.config import settings as _app_settings
except Exception:
    _app_settings = None

logger = get_logger(__name__)

_AGENT_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _AGENT_DIR.parent.parent.parent
_REPORTS_DIR = _PROJECT_ROOT / "reports"
_UPGRADE_GUIDE_DIR = _PROJECT_ROOT / "app" / "data" / "upgrade-guide"
_SONARQUBE_REPORT_EXTENSIONS = (".html", ".docx", ".md")
# Must match routes ``DEFAULT_REMOTE_STAGED_MIGRATION_DIR`` / staged upload layout.
_MIGRATED_CODES_SEGMENT = "migrated-codes"
# Stage dirs are named stage_NN_<lang><ver> e.g. stage_01_php73, stage_03_py312, stage_02_java21
_STAGE_DIR_RE = re.compile(r"^stage_(\d+)_([a-z]+\d+.*)$", re.IGNORECASE)

# Language prefix used in stage directory names (e.g. php → "php", python → "py", java → "java")
_LANG_STAGE_PREFIX: Dict[str, str] = {
    "php":        "php",
    "python":     "py",
    "javascript": "js",
    "typescript": "ts",
    "java":       "java",
    "kotlin":     "kt",
    "go":         "go",
    "ruby":       "rb",
    "rust":       "rs",
    "csharp":     "cs",
    "cpp":        "cpp",
    "c":          "c",
}


def _delete_existing_upgrade_guides(project_name: str) -> int:
    """Delete existing ``.txt`` upgrade outputs for this project under ``upgrade-guide/`` (clean regenerate)."""
    if not _UPGRADE_GUIDE_DIR.exists():
        return 0
    prefix = project_name.replace("-", "_")
    deleted = 0
    for path in list(_UPGRADE_GUIDE_DIR.glob("*.txt")):
        stem = path.stem
        if stem.startswith(project_name) or stem.startswith(prefix):
            try:
                path.unlink()
                deleted += 1
                logger.info("Deleted existing upgrade guide file: %s", path.name)
            except OSError as e:
                logger.warning("Could not delete %s: %s", path, e)
    return deleted


REPORT_TIMESTAMP_PATTERN = re.compile(r"_(\d{8}_\d{6})$")


def _target_stage_token(to_version: str, language: str = "php") -> Optional[str]:
    """
    Build the version suffix used in stage directory names.

    Examples:
      php  8.3  → ``php83``
      php  7.2  → ``php72``
      py   3.12 → ``py312``
      java 21   → ``java21``
      js   20   → ``js20``
    """
    s = (to_version or "").strip()
    if not s:
        return None
    lang = (language or "php").lower().strip()
    prefix = _LANG_STAGE_PREFIX.get(lang, lang)
    # Compact version: strip dots → "8.3" → "83", "3.12" → "312", "21" → "21"
    compact = s.replace(".", "")
    return f"{prefix}{compact}"


# Keep old name as an alias for backward compatibility (callers outside this module may use it)
def _target_php_stage_token(to_version: str) -> Optional[str]:
    """Backward-compat alias for PHP; prefer _target_stage_token(version, language)."""
    return _target_stage_token(to_version, language="php")


def _pick_stage_dir_name(dir_names: List[str], version_token: str) -> Optional[str]:
    """
    Choose the ``stage_NN_<token>`` directory with the largest NN when multiple match.

    ``version_token`` is the compact suffix, e.g. ``php83``, ``py312``, ``java21``.
    """
    want = version_token.lower()
    candidates: List[Tuple[int, str]] = []
    for raw in dir_names:
        name = raw.strip()
        m = _STAGE_DIR_RE.match(name)
        if not m or m.group(2).lower() != want:
            continue
        candidates.append((int(m.group(1)), name))
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def _ssh_home_base(ssh_username: Optional[str], ssh_source_path: Optional[str]) -> str:
    """
    Derive the client home/workspace directory from the saved source path.

    Strategy (in priority order):
    1. If ssh_source_path's last segment equals ssh_username, the path IS the home
       directory (e.g. ``/home/usama`` with username ``usama``). Return it directly.
    2. If ssh_source_path is a path with ≥ 3 parts (e.g. ``/home/usama/app2``),
       the home is the parent of the last segment → ``/home/usama``.
    3. Fallback: ``/home/{username}`` if username is known.
    4. Last resort: ``/home``.
    """
    sp = (ssh_source_path or "").strip().rstrip("/")
    u = (ssh_username or "").strip()
    if sp:
        try:
            p = Path(sp)
            # If the last segment IS the username, this is already the home directory
            if u and p.name.lower() == u.lower():
                return sp
            parts = p.parts
            if len(parts) >= 3:
                # Parent of the last segment is the workspace/home root
                return str(Path(*parts[:-1]))
            if len(parts) >= 2:
                # Two-segment path like /home/usama — return as-is (it's likely the home)
                return sp
        except (ValueError, OSError):
            pass
    return f"/home/{u}" if u else "/home"


def _discover_migrated_stage_remote_path(
    project_name: str,
    to_version: str,
    *,
    ssh_credentials: Dict[str, Any],
    ssh_home_base: str,
    language: str = "php",
) -> Optional[str]:
    """
    Return absolute remote path such as ``/home/usama/migrated-codes/app2/stage_06_php83``,
    or ``None`` if listing fails or no matching stage folder exists.

    Works for any language: PHP (``stage_*_php83``), Python (``stage_*_py312``),
    Java (``stage_*_java21``), etc.
    """
    version_token = _target_stage_token(to_version, language=language)
    if not version_token:
        return None
    folder = (project_name or "").strip().lower().replace(" ", "-")
    if not folder:
        return None
    base = (ssh_home_base or "").strip().rstrip("/") or "/home"
    parent = f"{base}/{_MIGRATED_CODES_SEGMENT}/{folder}"
    host = (ssh_credentials.get("hostname") or "").strip()
    user = (ssh_credentials.get("username") or "").strip()
    port = int(ssh_credentials.get("port") or 22)
    if not host or not user:
        logger.warning("_discover_migrated_stage_remote_path: missing hostname or username in ssh_credentials")
        return None
    ssh_conn = SSHService.create_connection(
        hostname=host,
        port=port,
        username=user,
        password=ssh_credentials.get("password"),
        private_key=ssh_credentials.get("private_key"),
        private_key_password=ssh_credentials.get("private_key_password"),
    )
    if not ssh_conn.connect():
        logger.warning(
            "_discover_migrated_stage_remote_path: SSH connect failed for %s@%s (cannot list %s)",
            user,
            host,
            parent,
        )
        return None
    try:
        res = ssh_conn.execute_command(f"ls -1 '{parent}' 2>/dev/null || true")
        if not res.get("success"):
            logger.warning("_discover_migrated_stage_remote_path: ls failed for %s — %s", parent, res.get("stderr"))
            return None
        names = [ln.strip() for ln in (res.get("stdout") or "").splitlines() if ln.strip()]
        picked = _pick_stage_dir_name(names, version_token)
        if not picked:
            logger.warning(
                "_discover_migrated_stage_remote_path: no stage_*_%s under %s (entries=%s)",
                version_token,
                parent,
                names[:20],
            )
            return None
        full = f"{parent}/{picked}"
        logger.info(
            "_discover_migrated_stage_remote_path: project=%s lang=%s to_version=%s → %s",
            project_name,
            language,
            to_version,
            full,
        )
        return full
    finally:
        ssh_conn.disconnect()


def _run_sonarqube_download(
    project_name: str,
    reports_dir: Optional[Path] = None,
    remote_source_path: Optional[str] = None,
    ssh_credentials: Optional[Dict[str, Any]] = None,
    report_type: Optional[str] = None,
) -> bool:
    """Run ``run_download_workflow``; saves html, docx, md to ``reports_dir``.

    Args:
        report_type: One of "generic_security" (default), "owasp_top_10", "pci_dss", "iso_27001".
    """
    output_dir = str(reports_dir) if reports_dir else str(_REPORTS_DIR)
    sonar_token = None
    if _app_settings:
        sonar_token = getattr(_app_settings, "SONAR_TOKEN", None)
    sonar_token = (sonar_token or os.environ.get("SONAR_TOKEN") or "").strip() or None
    sonar_host_url = None
    if _app_settings:
        sonar_host_url = getattr(_app_settings, "SONAR_HOST_URL", None)
    sonar_host_url = (sonar_host_url or os.environ.get("SONAR_HOST_URL") or "").strip() or None
    try:
        ok = run_download_workflow(
            project_name,
            output_directory=output_dir,
            sonar_token=sonar_token,
            sonar_host_url=sonar_host_url,
            remote_source_path=remote_source_path,
            ssh_credentials=ssh_credentials,
            report_type=report_type,
        )
        if ok:
            logger.info("SonarQube report download completed for project %s", project_name)
        else:
            logger.warning("SonarQube report download workflow failed for project %s", project_name)
        return ok
    except Exception as e:
        logger.warning("SonarQube report download failed: %s", e)
        return False


def _find_latest_report_by_ext(project_name: str, ext: str, reports_dir: Path) -> Optional[Path]:
    pattern = f"*{ext}" if ext.startswith(".") else f"*.{ext}"
    candidates: List[Path] = []
    for p in reports_dir.glob(pattern):
        if project_name in p.stem or bool(p.stem.startswith(project_name.replace("-", "_"))):
            candidates.append(p)
    if not candidates:
        for p in reports_dir.glob(pattern):
            candidates.append(p)
    if not candidates:
        return None
    return max(candidates, key=lambda x: x.stat().st_mtime)


def _read_report_content(report_path: str) -> Optional[str]:
    path = Path(report_path)
    if not path.exists():
        return None
    ext = path.suffix.lower()
    try:
        if ext == ".html":
            raw = path.read_text(encoding="utf-8", errors="replace")
            return _text_from_html(raw).strip() or None
        if ext == ".md":
            raw = path.read_text(encoding="utf-8", errors="replace")
            return raw.strip() or None
        if ext == ".docx":
            try:
                from docx import Document
                doc = Document(path)
                parts = [p.text for p in doc.paragraphs]
                for table in doc.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            if cell.text.strip():
                                parts.append(cell.text)
                return "\n".join(parts).strip() or None
            except Exception as e:
                logger.warning("Failed to read DOCX %s: %s", report_path, e)
                return None
    except Exception as e:
        logger.warning("Failed to read report %s: %s", report_path, e)
        return None
    return None


def _find_latest_sonarqube_report(project_name: str, reports_dir: Optional[Path] = None) -> Optional[str]:
    directory = Path(reports_dir) if reports_dir else _REPORTS_DIR
    if not directory.exists():
        return None
    for ext in _SONARQUBE_REPORT_EXTENSIONS:
        candidate = _find_latest_report_by_ext(project_name, ext, directory)
        if not candidate:
            continue
        content = _read_report_content(str(candidate))
        if content and len(content.strip()) > 0:
            logger.info("Using SonarQube report: %s (format=%s, project=%s)", candidate.name, ext, project_name)
            return str(candidate)
        logger.info("SonarQube report %s has no content, trying next format", candidate.name)
    logger.warning(
        "No SonarQube report with content found in %s for project %s (tried %s)",
        directory,
        project_name,
        ", ".join(_SONARQUBE_REPORT_EXTENSIONS),
    )
    return None


def _text_from_html(html: str) -> str:
    html = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)
    html = re.sub(r"</(tr|p|div|li|h[1-6])>", "\n", html, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", html)
    text = re.sub(r"&nbsp;", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"&lt;", "<", text, flags=re.IGNORECASE)
    text = re.sub(r"&gt;", ">", text, flags=re.IGNORECASE)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n", "\n\n", text)
    return text.strip()


class PHPUpgradeAnalyzer(BaseAgent):
    """Downloads/analyzes SonarQube reports and writes the upgrade guide to ``app/data/upgrade-guide/``."""

    def __init__(self, groq_client: Optional[GroqClient] = None):
        super().__init__(
            name="php_upgrade_analyzer",
            description="SonarQube report download and LLM upgrade guide generation",
            groq_client=groq_client,
        )
        self._output_timestamp = None

    @staticmethod
    def _timestamp_from_report_path(report_path: str) -> Optional[str]:
        stem = Path(report_path).stem
        m = REPORT_TIMESTAMP_PATTERN.search(stem)
        return m.group(1) if m else None

    def analyze_sonarqube_report(
        self, report_path: str, project_name: str, report_requirements: Optional[str] = None
    ) -> Optional[str]:
        """
        Chunk the Sonar report, extract issues, synthesize one markdown report, save under
        ``app/data/upgrade-guide/{project}_sonarqube_analysis_{timestamp}.txt``.

        Returns:
            Absolute path to the saved ``.txt`` upgrade guide, or ``None`` on failure.
        """
        report_file = Path(report_path)
        if not report_file.exists():
            logger.error("SonarQube report not found: %s", report_path)
            return None
        ext = report_file.suffix.lower()
        if ext not in (".html", ".md", ".docx"):
            logger.error("SonarQube report must be .html, .md, or .docx: %s", report_path)
            return None
        logger.info("Analyzing SonarQube report: %s (format=%s)", report_file.name, ext)
        self._output_timestamp = self._timestamp_from_report_path(report_path) or datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )
        logger.info("Using report timestamp for output names: %s", self._output_timestamp)

        full_text = _read_report_content(report_path)
        if not full_text or len(full_text.strip()) == 0:
            logger.error("SonarQube report has no content: %s", report_path)
            return None
        logger.info("Loaded SonarQube report: %s characters", len(full_text))
        chunk_size = 15000
        chunks = [full_text[i : i + chunk_size] for i in range(0, len(full_text), chunk_size)]
        logger.info("Processing %s chunks", len(chunks))
        sonar_user_block = ""
        if report_requirements and report_requirements.strip():
            sonar_user_block = f"""
USER REQUIREMENTS FOR THIS REPORT (apply when extracting and when synthesizing; prioritize or emphasize as relevant):
{report_requirements.strip()}

"""
        chunk_extractions = []
        for i, chunk in enumerate(chunks, 1):
            logger.info("Processing chunk %s/%s", i, len(chunks))
            prompt = f"""You are extracting issues from a SonarQube security/quality report. This extraction will be used by an automated code modernization tool, so every issue must be complete and actionable.
{sonar_user_block}
RULES:
- Process every finding in this section: every table row, every bullet, every listed issue. Do not skip or merge any.
- For each finding output ALL of the following. If the report omits a field, infer a concrete value so the tool can act (e.g. infer a typical code snippet or remediation from the rule type).

1. **File:** Relative path of the file (e.g. api.php, crypto_utils.php, src/login.php). Use exact path from report.
2. **Line:** Exact line number from report, or "N/A" if not given (then add a note like "likely near the switch/table/function mentioned").
3. **Rule:** SonarQube rule key if present (e.g. php:S2068), or issue type (Bug, Vulnerability, Code Smell), or CWE/OWASP if applicable.
4. **Severity:** BLOCKER, CRITICAL, MAJOR, MINOR, or INFO.
5. **Message:** Exact SonarQube message. Keep full text, do not truncate.
6. **Code:** The problematic code. If the report includes a snippet, copy it. If not, write a SHORT typical example of the vulnerable/bad pattern (e.g. for "Remove deprecated bgcolor" write: <td bgcolor="yellow">; for "Add default case" write: switch ($x) {{ case 1: ... }} ).
7. **Remediation:** CONCRETE fix with actual code or exact steps. Never say "Address the finding" alone. Examples:
   - "Remove deprecated bgcolor" → Remediation: Replace with <td style="background-color: #fff;"> or a CSS class. Example: <td class="highlight">.
   - "Add default case to switch" → Remediation: Add default: break; or default: throw new InvalidArgumentException('Unexpected value'); before the closing }}.
   - "Use prepared statements" → Remediation: $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?'); $stmt->execute([$id]);
   - "Rename function to match regex" → Remediation: Rename insecure_hash_password to insecureHashPassword (camelCase).

Output exactly one block per finding. Use the labels: File:, Line:, Rule:, Severity:, Message:, Code:, Remediation:. Preserve file paths exactly as in the report. Never leave Code or Remediation empty—infer from the rule or message if needed.

Report section:
{chunk}

Structured list (one block per finding):"""

            sonar_chunk_system = (
                "You are a senior code quality analyst. Your extraction is used by an automated modernization tool. "
                "For every finding in the report section: output File, Line, Rule, Severity, Message, Code (problematic snippet or typical example), "
                "and Remediation (exact fix or step-by-step with code). Do not skip any finding. Do not summarize. "
                "When the report omits code or remediation, infer a concrete example so the tool can apply it."
            )
            if report_requirements and report_requirements.strip():
                sonar_chunk_system += (
                    " When USER REQUIREMENTS FOR THIS REPORT are present, prioritize or emphasize those aspects "
                    "in your extraction while still including every finding."
                )
            summary = self.groq_client.generate(
                system_prompt=sonar_chunk_system,
                user_content=prompt,
                temperature=0.7,
            )
            chunk_extractions.append(summary)

        logger.info("Synthesizing final SonarQube upgrade guide")
        sonar_synthesis_user_block = ""
        if report_requirements and report_requirements.strip():
            sonar_synthesis_user_block = f"""
USER REQUIREMENTS FOR THIS REPORT (you must apply these when producing the SonarQube report; emphasize, include, or structure content as requested):
{report_requirements.strip()}

"""
        synthesis_prompt = f"""Synthesize the following chunk extractions into ONE SonarQube report. The report will be consumed by an automated code modernization tool that looks up issues by file path and applies Remediation. Therefore: include every finding from the chunks; preserve file paths exactly; ensure every issue has non-empty Code and Remediation.
{sonar_synthesis_user_block}
Chunk extractions:
{chr(10).join([f"=== CHUNK {i} ==={chr(10)}{s}" for i, s in enumerate(chunk_extractions, 1)])}

REQUIRED STRUCTURE:

1) **## ISSUES BY FILE**
   For each file that has at least one finding, add:
   ### <exact_file_path_from_extraction>
   Then for each issue in that file:
   - **Line <number or N/A>** [<SEVERITY>] **Rule:** <rule> — <full message>
     **Code:** <problematic code or typical example>
     **Remediation:** <exact fix with code>
   Do not add, drop, or merge findings. Use only data from the chunks. If a chunk has "N/A" for line, write "N/A". Every issue must have Code and Remediation filled.

2) **## SUMMARY**
   Counts by severity (BLOCKER, CRITICAL, MAJOR, MINOR, INFO) and total files affected. Derive from the issues you listed.

3) **## REMEDIATION REFERENCE**
   Short reference: prepared statements, password_hash(), htmlspecialchars(), deprecated HTML→CSS, switch default, naming (camelCase), with one-line examples.

Do not invent findings. Include every finding that appears in the chunk extractions. Preserve file paths exactly as in the extractions."""

        sonar_system = (
            "You synthesize SonarQube chunk extractions into one report for an automated modernization tool. "
            "Output MUST have '## ISSUES BY FILE' with '### <file_path>' per file and every issue with Line, Rule, Severity, Message, Code, and Remediation. "
            "Include every finding from the chunks; do not add or drop. Preserve file paths exactly. "
            "Never output 'No extractable findings'—use the chunk data. Every issue must have concrete Code and Remediation."
        )
        if report_requirements and report_requirements.strip():
            sonar_system += (
                " When USER REQUIREMENTS FOR THIS REPORT are present, apply them: tailor the report (emphasis, structure, or content) "
                "to satisfy those requirements while keeping every finding and full technical accuracy."
            )
        final_report = self.groq_client.generate(
            system_prompt=sonar_system,
            user_content=synthesis_prompt,
            temperature=0.7,
        )

        _UPGRADE_GUIDE_DIR.mkdir(parents=True, exist_ok=True)
        output_path = _UPGRADE_GUIDE_DIR / f"{project_name}_sonarqube_analysis_{self._output_timestamp}.txt"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("# SonarQube Analysis Report\n\n")
            f.write(f"**Project:** {project_name}\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write("---\n\n")
            f.write(final_report or "")
        self._sonarqube_report_path = str(output_path.resolve())
        logger.info("Upgrade guide saved: %s", output_path)
        return self._sonarqube_report_path

    def _analyze_user_report_requirements(self, user_input: str) -> str:
        """Summarize user input into requirements for the Sonar-derived upgrade guide."""
        prompt = f"""The user has provided the following input about how they want the SonarQube upgrade guide to be generated or changed.

USER INPUT:
{user_input}

Analyze this and output a concise "Report requirements" summary that the report generator must follow. Include:
- What the user wants changed, added, or emphasized in the SonarQube-oriented upgrade guide (e.g. focus on security, performance, certain rules).
- Any specific areas to prioritize or expand.
- Any format or structure preferences.

Keep the summary short so it can be injected into the report generation prompt. Write in clear, actionable language."""
        try:
            out = self.groq_client.generate(
                system_prompt="You analyze user requests and produce a concise, actionable summary of report requirements for a SonarQube upgrade guide generator. Output only the requirements summary, no preamble.",
                user_content=prompt,
                temperature=0.7,
            )
            return (out or "").strip()
        except Exception as e:
            logger.warning("Failed to analyze user report requirements: %s; using raw user input", e)
            return user_input

    def run_full_upgrade_analysis(
        self,
        project_name: str,
        from_version: str = "",
        to_version: str = "",
        php_doc_path: Optional[str] = None,
        from_laravel: Optional[str] = None,
        laravel_documentation_path: Optional[Union[str, Path]] = None,
        reports_dir: Optional[Path] = None,
        user_input: Optional[str] = None,
        ssh_credentials: Optional[Dict[str, Any]] = None,
        ssh_source_path: Optional[str] = None,
        report_type: Optional[str] = None,
    ) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
        """
        Download SonarQube report (when needed), analyze it, save upgrade guide under ``app/data/upgrade-guide/``.

        ``php_doc_path``, ``from_laravel``, and ``laravel_documentation_path`` are ignored (reserved for API compatibility).
        Pass ``ssh_credentials`` (hostname, port, username, password, private_key, …) and optional
        ``ssh_source_path`` from the user's DB record so stage discovery and Sonar use that VM.

        Returns:
            ``(sonarqube_upgrade_guide_txt_path, None, None, None)``. Only the first path is set (same ``.txt`` as
            before). Second–fourth slots are reserved for backward compatibility with older tuple unpacking; they are
            always ``None`` in the Sonar-only flow. Target Laravel comes from the language agent, not here.
        """
        logger.info(
            "run_full_upgrade_analysis (Sonar-only): project_name=%s, to_version=%s, user_input=%s",
            project_name,
            to_version or "",
            "yes" if (user_input and user_input.strip()) else "no",
        )
        _ = (from_version, php_doc_path, from_laravel, laravel_documentation_path)

        remote_source_path: Optional[str] = None
        if (to_version or "").strip() and ssh_credentials and ssh_credentials.get("hostname"):
            home = _ssh_home_base(str(ssh_credentials.get("username") or ""), ssh_source_path)
            remote_source_path = _discover_migrated_stage_remote_path(
                project_name,
                to_version,
                ssh_credentials=ssh_credentials,
                ssh_home_base=home,
            )
            if not remote_source_path:
                logger.info(
                    "run_full_upgrade_analysis: no migrated stage path for PHP %s; Sonar uses default path / request source for project %s",
                    to_version,
                    project_name,
                )
        elif (to_version or "").strip() and not ssh_credentials:
            logger.warning(
                "run_full_upgrade_analysis: no ssh_credentials — skipping migrated-codes discovery (legacy Sonar path)",
            )

        n_deleted = _delete_existing_upgrade_guides(project_name)
        if n_deleted:
            logger.info("Deleted %s existing upgrade-guide .txt file(s) for project %s", n_deleted, project_name)

        report_requirements = ""
        if user_input and user_input.strip():
            logger.info("User input provided (%s chars); analyzing requirements for Sonar guide", len(user_input.strip()))
            report_requirements = self._analyze_user_report_requirements(user_input.strip())
            if report_requirements:
                logger.info("User report requirements summarized (%s chars)", len(report_requirements))

        reports_dir_resolved = reports_dir or _REPORTS_DIR
        _run_sonarqube_download(
            project_name,
            reports_dir=reports_dir_resolved,
            remote_source_path=remote_source_path,
            ssh_credentials=ssh_credentials,
            report_type=report_type,
        )
        report_path = _find_latest_sonarqube_report(project_name, reports_dir_resolved)
        if not report_path or not Path(report_path).exists():
            logger.error(
                "No SonarQube report (.html/.md/.docx) with content found for project %s after download",
                project_name,
            )
            return None, None, None, None

        guide_path = self.analyze_sonarqube_report(report_path, project_name, report_requirements=report_requirements)
        if not guide_path:
            return None, None, None, None

        gp = str(Path(guide_path).resolve())
        return gp, None, None, None

    def execute(self, state: AgentState) -> AgentState:
        state.add_error(
            "PHPUpgradeAnalyzer.execute is not used; call run_full_upgrade_analysis or analyze_sonarqube_report from routes."
        )
        return state
