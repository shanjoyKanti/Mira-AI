"""
Contract Extraction Agent — Phase 0 of full-stack migration.

Walks a project tree and extracts every API endpoint into an OpenAPI 3.0
specification. Both the frontend and the backend migration agents read from
this *immutable Contract Registry* during Phase 1 so they cannot drift apart
on route paths, method names, parameter shapes, or auth mechanisms.

Why this exists (per the full-stack migration architecture):
    "When frontend and backend migration agents operate independently, the API
    surface becomes the critical failure point. Neither agent has visibility
    into the other's transformation decisions, which causes the API contract
    to drift in two different directions simultaneously."

Implementation strategy:
    For an MVP shippable in a day, we use ROBUST REGEX extraction rather than
    a full PHP/JS parser. This catches ~80% of real-world routes (Laravel,
    plain PHP, Express/NestJS) at 20% of the engineering cost. Frameworks we
    don't recognise still fall through cleanly — they just produce an empty
    contract instead of crashing the pipeline.

Recognised patterns:
    PHP / Laravel ............ Route::{get,post,put,patch,delete,any,match}('path', ...)
    PHP / Slim ............... $app->{get,post,...}('path', ...)
    PHP plain ................ filename → route (e.g. `login.php` → `/login`)
    Node / Express ........... app.{get,post,...}('path', ...)
    Node / NestJS ............ @{Get,Post,Put,Delete,Patch}('path')
    Python / FastAPI ......... @app.{get,post,...}('/path') / @router.{...}
    Python / Flask ........... @app.route('/path', methods=[...])
    OpenAPI YAML/JSON ........ already-defined contracts loaded as-is

Output:
    A single OpenAPI 3.0 document plus a sidecar JSON of "extraction notes"
    (which patterns hit, which files were skipped, how confident we are per
    endpoint). Stored under app/data/contracts/<project>/.

Design notes:
    * The agent NEVER calls the LLM. It is deterministic — same input always
      produces the same registry. This is critical: the Contract Validation
      Agent later compares the post-migration registry to this one and any
      LLM nondeterminism would create false drift signals.
    * Response/request body schemas are inferred *only* when explicit (e.g.
      Laravel route::method() parameters, FastAPI Pydantic models). For
      everything else we leave the schema as ``{}`` so the validator treats
      shape changes as additive (safe) rather than breaking.
    * The registry is stored immutable: writing twice for the same project
      creates ``registry-{timestamp}.yaml`` so the original Phase-0 registry
      is preserved as the source of truth.
"""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------

# Default registry root. Override with MIRA_CONTRACT_REGISTRY_DIR if you
# want it on a shared volume. Each project gets its own subdirectory so
# multi-project deployments don't collide.
_DEFAULT_REGISTRY_DIR = Path(
    os.environ.get("MIRA_CONTRACT_REGISTRY_DIR", "/app/app/data/contracts")
)


def registry_dir_for(project_name: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", project_name or "unknown")
    return _DEFAULT_REGISTRY_DIR / safe


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

@dataclass
class ExtractedEndpoint:
    """One API endpoint extracted from source. Populated piece by piece by the
    framework-specific extractors below."""
    path: str
    method: str                    # GET / POST / PUT / PATCH / DELETE / ...
    handler: Optional[str] = None  # controller@method, function name, FQCN
    framework: str = "unknown"     # "laravel" | "express" | "fastapi" | ...
    source_file: str = ""          # absolute path to the file that defined it
    source_line: int = 0
    parameters: List[Dict[str, Any]] = field(default_factory=list)  # path/query params
    request_body_hint: Optional[str] = None
    response_hint: Optional[str] = None
    auth_hint: Optional[str] = None  # "session" | "jwt" | "api_key" | "none"
    confidence: float = 0.6        # 0..1, how much we trust this extraction

    def to_openapi_path_item(self) -> Dict[str, Any]:
        op: Dict[str, Any] = {
            "operationId": self._operation_id(),
            "summary": self.handler or f"{self.method} {self.path}",
            "tags": [self.framework or "unknown"],
            "responses": {
                "200": {"description": "OK"},
            },
            "x-mira-extraction": {
                "source_file": self.source_file,
                "source_line": self.source_line,
                "framework": self.framework,
                "confidence": round(self.confidence, 2),
            },
        }
        if self.parameters:
            op["parameters"] = self.parameters
        if self.request_body_hint:
            op["requestBody"] = {
                "x-mira-hint": self.request_body_hint,
                "content": {"application/json": {"schema": {}}},
            }
        if self.response_hint:
            op["responses"]["200"]["x-mira-hint"] = self.response_hint
        if self.auth_hint:
            op["security"] = [{self.auth_hint: []}]
        return op

    def _operation_id(self) -> str:
        slug = re.sub(r"[^A-Za-z0-9]+", "_", f"{self.method}_{self.path}").strip("_").lower()
        return slug or f"op_{self.source_line}"


@dataclass
class ExtractionReport:
    """Sidecar metadata about how the registry was built — kept alongside the
    OpenAPI YAML so reviewers can see what we covered and what we missed."""
    project_name: str
    generated_at: str
    source_root: str
    total_files_scanned: int = 0
    files_by_language: Dict[str, int] = field(default_factory=dict)
    endpoints_by_framework: Dict[str, int] = field(default_factory=dict)
    skipped_files: List[Dict[str, str]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Regex patterns per framework
# ---------------------------------------------------------------------------
#
# All patterns capture in named groups so the parser stays declarative and
# debuggable. We use re.MULTILINE everywhere and never re.DOTALL — handler
# bodies should not influence route detection.

_PHP_LARAVEL_RE = re.compile(
    r"""Route\s*::\s*
        (?P<method>get|post|put|patch|delete|options|any|match)\s*\(
        \s*(?:\[[^\]]*\]\s*,\s*)?            # match() takes [methods] first; skip it
        ['"](?P<path>[^'"]+)['"]
        \s*,\s*
        (?:                                   # handler can be:
            ['"](?P<controller>[^'"]+)['"]   #   "Controller@method" string
          |\[\s*(?P<class>[^\s,\]]+)::class\s*,\s*['"](?P<method2>[^'"]+)['"]\s*\]  # [Class::class, "method"]
          |function\s*\([^)]*\)              #   inline closure
        )
    """,
    re.VERBOSE | re.IGNORECASE | re.MULTILINE,
)

_PHP_SLIM_RE = re.compile(
    r"""\$app\s*->\s*
        (?P<method>get|post|put|patch|delete|options|any)\s*\(
        \s*['"](?P<path>[^'"]+)['"]
    """,
    re.VERBOSE | re.IGNORECASE | re.MULTILINE,
)

_NODE_EXPRESS_RE = re.compile(
    r"""\b(?:app|router)\s*\.\s*
        (?P<method>get|post|put|patch|delete|options|all|use)\s*\(
        \s*['"`](?P<path>[^'"`]+)['"`]
    """,
    re.VERBOSE | re.IGNORECASE | re.MULTILINE,
)

_NESTJS_RE = re.compile(
    r"""@(?P<method>Get|Post|Put|Patch|Delete|Options|All)\s*\(
        \s*(?:['"`](?P<path>[^'"`]*)['"`])?
    """,
    re.VERBOSE | re.MULTILINE,
)

_FASTAPI_RE = re.compile(
    r"""@(?:app|router)\s*\.\s*
        (?P<method>get|post|put|patch|delete|options|head)\s*\(
        \s*['"](?P<path>[^'"]+)['"]
    """,
    re.VERBOSE | re.IGNORECASE | re.MULTILINE,
)

_FLASK_RE = re.compile(
    r"""@(?:app|bp|blueprint|[A-Za-z_]\w*)\s*\.\s*route\s*\(
        \s*['"](?P<path>[^'"]+)['"]
        (?:\s*,\s*methods\s*=\s*\[(?P<methods>[^\]]+)\])?
    """,
    re.VERBOSE | re.IGNORECASE | re.MULTILINE,
)

# Path parameter detector — :id, {id}, <int:id>
_PATH_PARAM_LARAVEL_RE = re.compile(r"\{(?P<name>[A-Za-z_]\w*)\??\}")
_PATH_PARAM_EXPRESS_RE = re.compile(r":(?P<name>[A-Za-z_]\w*)")
_PATH_PARAM_FLASK_RE = re.compile(r"<(?:(?P<type>[A-Za-z_]+):)?(?P<name>[A-Za-z_]\w*)>")


# ---------------------------------------------------------------------------
# Per-framework extractors
# ---------------------------------------------------------------------------

def _normalize_method(raw: str) -> str:
    m = (raw or "").upper().strip()
    if m == "ALL":
        return "ANY"
    return m


def _extract_path_parameters(path: str) -> List[Dict[str, Any]]:
    """Pull {id} / :id / <int:id> tokens out of the route path into OpenAPI parameters."""
    params: List[Dict[str, Any]] = []
    for m in _PATH_PARAM_LARAVEL_RE.finditer(path):
        params.append({"name": m.group("name"), "in": "path", "required": True, "schema": {"type": "string"}})
    for m in _PATH_PARAM_EXPRESS_RE.finditer(path):
        params.append({"name": m.group("name"), "in": "path", "required": True, "schema": {"type": "string"}})
    for m in _PATH_PARAM_FLASK_RE.finditer(path):
        ptype = (m.group("type") or "string").lower()
        oa_type = {"int": "integer", "float": "number"}.get(ptype, "string")
        params.append({"name": m.group("name"), "in": "path", "required": True, "schema": {"type": oa_type}})
    # Dedup by name, preserve first-seen order.
    seen: set = set()
    unique: List[Dict[str, Any]] = []
    for p in params:
        if p["name"] in seen:
            continue
        seen.add(p["name"])
        unique.append(p)
    return unique


def _extract_php(file_path: str, content: str) -> List[ExtractedEndpoint]:
    out: List[ExtractedEndpoint] = []

    # Laravel — most accurate, highest confidence.
    for m in _PHP_LARAVEL_RE.finditer(content):
        method_raw = m.group("method") or ""
        path = m.group("path") or ""
        if not path:
            continue
        controller = m.group("controller") or ""
        klass = m.group("class") or ""
        method2 = m.group("method2") or ""
        handler = controller or (f"{klass}@{method2}" if klass else None)
        line_no = content[: m.start()].count("\n") + 1
        if method_raw.lower() in ("any", "match"):
            methods = ["GET", "POST", "PUT", "PATCH", "DELETE"]
        else:
            methods = [_normalize_method(method_raw)]
        for mm in methods:
            out.append(ExtractedEndpoint(
                path=path,
                method=mm,
                handler=handler,
                framework="laravel",
                source_file=file_path,
                source_line=line_no,
                parameters=_extract_path_parameters(path),
                confidence=0.85,
            ))

    # Slim
    for m in _PHP_SLIM_RE.finditer(content):
        method_raw = m.group("method") or ""
        path = m.group("path") or ""
        if not path:
            continue
        line_no = content[: m.start()].count("\n") + 1
        out.append(ExtractedEndpoint(
            path=path,
            method=_normalize_method(method_raw),
            framework="slim",
            source_file=file_path,
            source_line=line_no,
            parameters=_extract_path_parameters(path),
            confidence=0.75,
        ))

    return out


def _extract_node(file_path: str, content: str) -> List[ExtractedEndpoint]:
    out: List[ExtractedEndpoint] = []

    for m in _NODE_EXPRESS_RE.finditer(content):
        method_raw = (m.group("method") or "").lower()
        path = m.group("path") or ""
        if method_raw == "use" or not path or not path.startswith(("/", "*")):
            continue  # skip middleware mounts and non-route .use() calls
        line_no = content[: m.start()].count("\n") + 1
        out.append(ExtractedEndpoint(
            path=path,
            method="ANY" if method_raw == "all" else _normalize_method(method_raw),
            framework="express",
            source_file=file_path,
            source_line=line_no,
            parameters=_extract_path_parameters(path),
            confidence=0.75,
        ))

    for m in _NESTJS_RE.finditer(content):
        path = m.group("path") or ""
        line_no = content[: m.start()].count("\n") + 1
        out.append(ExtractedEndpoint(
            path=path or "/",
            method=_normalize_method(m.group("method") or ""),
            framework="nestjs",
            source_file=file_path,
            source_line=line_no,
            parameters=_extract_path_parameters(path),
            confidence=0.7,
        ))

    return out


def _extract_python(file_path: str, content: str) -> List[ExtractedEndpoint]:
    out: List[ExtractedEndpoint] = []

    for m in _FASTAPI_RE.finditer(content):
        path = m.group("path") or ""
        line_no = content[: m.start()].count("\n") + 1
        out.append(ExtractedEndpoint(
            path=path,
            method=_normalize_method(m.group("method") or ""),
            framework="fastapi",
            source_file=file_path,
            source_line=line_no,
            parameters=_extract_path_parameters(path),
            confidence=0.85,
        ))

    for m in _FLASK_RE.finditer(content):
        path = m.group("path") or ""
        methods_raw = m.group("methods") or "GET"
        methods = [_normalize_method(s.strip().strip("'\"")) for s in methods_raw.split(",")]
        line_no = content[: m.start()].count("\n") + 1
        for mm in methods:
            out.append(ExtractedEndpoint(
                path=path,
                method=mm,
                framework="flask",
                source_file=file_path,
                source_line=line_no,
                parameters=_extract_path_parameters(path),
                confidence=0.75,
            ))

    return out


def _extract_php_filename_route(file_path: str, source_root: str) -> Optional[ExtractedEndpoint]:
    """Plain-PHP fallback: a top-level ``foo.php`` file becomes ``GET /foo``.

    Many legacy projects (including the test fixture) have no router — every
    `.php` file IS a route. We register them as best-effort GET endpoints so
    the validator can detect if any were renamed/removed during migration.
    """
    try:
        rel = Path(file_path).relative_to(source_root)
    except ValueError:
        rel = Path(file_path).name
    rel_str = str(rel)
    if "/" in rel_str.replace("\\", "/"):
        # nested PHP — likely controller code, not a route. Skip.
        return None
    if rel_str.startswith("_") or rel_str in {"index.php"}:
        # treat index.php as `/` not `/index`
        path = "/"
    else:
        path = "/" + Path(rel_str).stem
    return ExtractedEndpoint(
        path=path,
        method="GET",
        handler=rel_str,
        framework="php-flat",
        source_file=file_path,
        source_line=1,
        confidence=0.5,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_contract(
    source_root: str,
    project_name: str,
    *,
    files_by_language: Optional[Dict[str, List[str]]] = None,
    save: bool = True,
) -> Tuple[Dict[str, Any], ExtractionReport]:
    """
    Walk ``source_root`` and produce an OpenAPI 3.0 spec + an ExtractionReport.

    Args:
        source_root: Absolute or relative path to the project's source root.
            The walker will skip ``vendor/``, ``node_modules/``, ``.git/``,
            ``__pycache__/``, ``dist/``, and ``build/`` automatically.
        project_name: Used for storage path and the ``info.title`` field of
            the generated OpenAPI doc.
        files_by_language: Optional pre-computed file lists from /migration/estimate.
            When provided, we skip our own filesystem walk and use these instead.
        save: When True (default), the spec + report are persisted to
            ``{REGISTRY_DIR}/<project>/registry-<timestamp>.yaml``. The
            timestamp is also written into ``registry-latest.yaml`` so other
            agents can pick it up by a stable name.

    Returns:
        ``(openapi_dict, ExtractionReport)``. Even when ``save`` is True the
        in-memory pair is also returned so callers can inspect it without
        touching disk.
    """
    src = Path(source_root).resolve()
    report = ExtractionReport(
        project_name=project_name,
        generated_at=datetime.utcnow().isoformat() + "Z",
        source_root=str(src),
    )

    # If the caller didn't pre-classify files (e.g. /migration/estimate already
    # walked the tree), enumerate locally — but only for languages we have
    # extractors for. Saves a lot of disk thrash on big monorepos.
    if files_by_language is None:
        files_by_language = _walk_local(src)
    files_by_language = files_by_language or {}

    endpoints: List[ExtractedEndpoint] = []

    for lang, files in files_by_language.items():
        report.files_by_language[lang] = len(files or [])
        report.total_files_scanned += len(files or [])
        for f in files or []:
            try:
                with open(f, "r", encoding="utf-8", errors="replace") as fh:
                    content = fh.read()
            except (OSError, IOError) as e:
                report.skipped_files.append({"file": str(f), "reason": f"read failed: {e}"})
                continue

            file_endpoints: List[ExtractedEndpoint] = []
            if lang == "php":
                file_endpoints.extend(_extract_php(f, content))
                if not file_endpoints:
                    fb = _extract_php_filename_route(f, str(src))
                    if fb is not None:
                        file_endpoints.append(fb)
            elif lang in ("javascript", "typescript"):
                file_endpoints.extend(_extract_node(f, content))
            elif lang == "python":
                file_endpoints.extend(_extract_python(f, content))

            for ep in file_endpoints:
                report.endpoints_by_framework[ep.framework] = (
                    report.endpoints_by_framework.get(ep.framework, 0) + 1
                )
            endpoints.extend(file_endpoints)

    if not endpoints:
        report.notes.append(
            "No endpoints extracted. Project may use a routing pattern Mira doesn't yet recognise. "
            "The contract registry will be empty; cross-stack validation will only catch frontend↔backend "
            "mismatches once routes are added."
        )

    spec = _to_openapi_3(project_name, src, endpoints)

    if save:
        _save_registry(project_name, spec, report)

    return spec, report


def _to_openapi_3(project_name: str, source_root: Path, endpoints: List[ExtractedEndpoint]) -> Dict[str, Any]:
    """Render ExtractedEndpoint list into a valid OpenAPI 3.0.3 document."""
    paths: Dict[str, Dict[str, Any]] = {}
    for ep in endpoints:
        method_lower = ep.method.lower()
        if method_lower not in ("get", "post", "put", "patch", "delete", "options", "head"):
            continue  # OpenAPI 3.0 doesn't define ANY/MATCH; we still keep them in extraction notes.
        bucket = paths.setdefault(ep.path, {})
        # First-write-wins per (path, method). If the same endpoint appears in
        # multiple files (e.g. duplicate routes) we keep the higher-confidence one.
        existing = bucket.get(method_lower)
        if existing is None or existing.get("x-mira-extraction", {}).get("confidence", 0) < ep.confidence:
            bucket[method_lower] = ep.to_openapi_path_item()

    return {
        "openapi": "3.0.3",
        "info": {
            "title": f"{project_name} — Contract Registry",
            "version": "1.0.0",
            "description": (
                "Contract registry generated by Mira AI's Contract Extraction Agent. "
                "DO NOT EDIT BY HAND — both the frontend and backend migration agents "
                "read from this file during Phase 1."
            ),
            "x-mira-source-root": str(source_root),
            "x-mira-generated-at": datetime.utcnow().isoformat() + "Z",
        },
        "paths": paths,
        "components": {
            "securitySchemes": {
                "session": {"type": "apiKey", "in": "cookie", "name": "PHPSESSID"},
                "jwt":     {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"},
                "api_key": {"type": "apiKey", "in": "header", "name": "X-API-Key"},
            }
        },
    }


def _save_registry(project_name: str, spec: Dict[str, Any], report: ExtractionReport) -> Path:
    """Persist the OpenAPI doc + extraction report. Both timestamped and
    `latest` symlink-equivalent are written so other agents can pick up the
    most recent registry by a stable name."""
    out_dir = registry_dir_for(project_name)
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    # YAML if available, else JSON. Keeps the dependency footprint small.
    try:
        import yaml  # type: ignore
        spec_path = out_dir / f"registry-{ts}.yaml"
        spec_path.write_text(yaml.safe_dump(spec, sort_keys=False, default_flow_style=False), encoding="utf-8")
        latest_path = out_dir / "registry-latest.yaml"
        latest_path.write_text(yaml.safe_dump(spec, sort_keys=False, default_flow_style=False), encoding="utf-8")
    except ImportError:
        spec_path = out_dir / f"registry-{ts}.json"
        spec_path.write_text(json.dumps(spec, indent=2), encoding="utf-8")
        latest_path = out_dir / "registry-latest.json"
        latest_path.write_text(json.dumps(spec, indent=2), encoding="utf-8")

    report_path = out_dir / f"extraction-report-{ts}.json"
    report_path.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")

    logger.info(
        "Contract Extraction Agent: project=%s endpoints=%d files=%d → %s",
        project_name,
        sum(len(v) for v in spec.get("paths", {}).values()),
        report.total_files_scanned,
        spec_path,
    )
    return spec_path


def _walk_local(source_root: Path) -> Dict[str, List[str]]:
    """Local filesystem fallback when the caller didn't pre-classify files."""
    skip_dirs = {".git", "node_modules", "vendor", "__pycache__", "dist", "build", ".venv", "target"}
    result: Dict[str, List[str]] = {"php": [], "javascript": [], "typescript": [], "python": []}
    if not source_root.exists():
        return result
    for root, dirs, files in os.walk(source_root):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fn in files:
            full = os.path.join(root, fn)
            if fn.endswith(".php"):
                result["php"].append(full)
            elif fn.endswith((".js", ".mjs", ".cjs")):
                result["javascript"].append(full)
            elif fn.endswith((".ts", ".tsx")):
                result["typescript"].append(full)
            elif fn.endswith(".py"):
                result["python"].append(full)
    return result


def load_latest_registry(project_name: str) -> Optional[Dict[str, Any]]:
    """Return the most recent OpenAPI registry for a project, or None."""
    d = registry_dir_for(project_name)
    for name in ("registry-latest.yaml", "registry-latest.json"):
        p = d / name
        if p.exists():
            try:
                if name.endswith(".yaml"):
                    import yaml  # type: ignore
                    return yaml.safe_load(p.read_text(encoding="utf-8"))
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception as e:
                logger.warning("Failed to load registry %s: %s", p, e)
    return None
