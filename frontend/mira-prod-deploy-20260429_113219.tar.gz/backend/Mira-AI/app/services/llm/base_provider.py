"""Base LLM provider interface"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, AsyncIterator
from pydantic import BaseModel


class LLMMessage(BaseModel):
    """LLM message model"""
    role: str  # system, user, assistant
    content: str


class LLMResponse(BaseModel):
    """LLM response model"""
    content: str
    model: str
    usage: Optional[Dict[str, Any]] = None
    finish_reason: Optional[str] = None


class BaseLLMProvider(ABC):
    """Base class for all LLM providers"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize LLM provider
        
        Args:
            config: Provider-specific configuration
        """
        self.config = config
        self.model = config.get("model", "default")
        self.temperature = config.get("temperature", 0.7)
        self.max_tokens = config.get("max_tokens", 4096)
    
    @abstractmethod
    def generate(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """
        Generate a response from the LLM
        
        Args:
            messages: List of messages in conversation
            **kwargs: Additional provider-specific parameters
            
        Returns:
            LLMResponse with generated content
        """
        pass
    
    @abstractmethod
    async def agenerate(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """
        Async generate a response from the LLM
        
        Args:
            messages: List of messages in conversation
            **kwargs: Additional provider-specific parameters
            
        Returns:
            LLMResponse with generated content
        """
        pass
    
    @abstractmethod
    def stream(self, messages: List[LLMMessage], **kwargs) -> AsyncIterator[str]:
        """
        Stream responses from the LLM
        
        Args:
            messages: List of messages in conversation
            **kwargs: Additional provider-specific parameters
            
        Yields:
            Chunks of generated content
        """
        pass
    
    @abstractmethod
    def validate_config(self) -> bool:
        """
        Validate provider configuration
        
        Returns:
            True if configuration is valid
        """
        pass

