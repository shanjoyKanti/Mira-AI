"""Utility functions package"""
