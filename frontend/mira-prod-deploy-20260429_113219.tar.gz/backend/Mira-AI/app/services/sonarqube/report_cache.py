"""Redis caching for SonarQube reports"""
import json
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import redis
from app.core.logging import get_logger
from app.core.config import settings

logger = get_logger(__name__)


class SonarQubeReportCache:
    """Redis-based caching for SonarQube reports"""
    
    def __init__(self, redis_client: Optional[redis.Redis] = None):
        """
        Initialize report cache
        
        Args:
            redis_client: Redis client instance (optional, creates new if not provided)
        """
        if redis_client:
            self.redis = redis_client
        else:
            # Create Redis client from settings
            redis_url = getattr(settings, 'REDIS_URL', 'redis://localhost:6379/0')
            self.redis = redis.from_url(redis_url, decode_responses=True)
        
        self.default_ttl = 3600  # 1 hour default
    
    def _make_cache_key(self, project_key: str, analysis_date: Optional[str] = None) -> str:
        """Generate cache key for report"""
        if analysis_date:
            return f"sonarqube:report:{project_key}:{analysis_date}"
        return f"sonarqube:report:{project_key}:latest"
    
    def get_report(self, project_key: str, analysis_date: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Get cached report
        
        Args:
            project_key: SonarQube project key
            analysis_date: Optional specific analysis date (ISO format)
        
        Returns:
            Cached report dict or None if not found
        """
        try:
            cache_key = self._make_cache_key(project_key, analysis_date)
            cached_data = self.redis.get(cache_key)
            
            if cached_data:
                report = json.loads(cached_data)
                logger.info(f"Cache HIT for {project_key}")
                
                # Add cache metadata
                report["_cached"] = True
                report["_cached_at"] = report.get("_cached_at", datetime.utcnow().isoformat())
                
                return report
            else:
                logger.info(f"Cache MISS for {project_key}")
                return None
                
        except Exception as e:
            logger.error(f"Failed to get cached report: {e}", exc_info=True)
            return None
    
    def set_report(self, project_key: str, report: Dict[str, Any], 
                   ttl: Optional[int] = None, analysis_date: Optional[str] = None) -> bool:
        """
        Cache report
        
        Args:
            project_key: SonarQube project key
            report: Report data to cache
            ttl: Time to live in seconds (default: 1 hour)
            analysis_date: Optional specific analysis date
        
        Returns:
            True if successfully cached, False otherwise
        """
        try:
            cache_key = self._make_cache_key(project_key, analysis_date)
            ttl_seconds = ttl if ttl is not None else self.default_ttl
            
            # Add cache metadata
            report_copy = report.copy()
            report_copy["_cached"] = True
            report_copy["_cached_at"] = datetime.utcnow().isoformat()
            report_copy["_cache_expires_at"] = (datetime.utcnow() + timedelta(seconds=ttl_seconds)).isoformat()
            
            # Store in Redis
            self.redis.setex(
                cache_key,
                ttl_seconds,
                json.dumps(report_copy, default=str)
            )
            
            logger.info(f"Cached report for {project_key} (TTL: {ttl_seconds}s)")
            return True
            
        except Exception as e:
            logger.error(f"Failed to cache report: {e}", exc_info=True)
            return False
    
    def invalidate_report(self, project_key: str, analysis_date: Optional[str] = None) -> bool:
        """
        Invalidate (delete) cached report
        
        Args:
            project_key: SonarQube project key
            analysis_date: Optional specific analysis date
        
        Returns:
            True if successfully deleted, False otherwise
        """
        try:
            cache_key = self._make_cache_key(project_key, analysis_date)
            deleted = self.redis.delete(cache_key)
            
            if deleted:
                logger.info(f"Invalidated cache for {project_key}")
                return True
            else:
                logger.info(f"No cache to invalidate for {project_key}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to invalidate cache: {e}", exc_info=True)
            return False
    
    def invalidate_project(self, project_key: str) -> int:
        """
        Invalidate all cached reports for a project
        
        Args:
            project_key: SonarQube project key
        
        Returns:
            Number of keys deleted
        """
        try:
            pattern = f"sonarqube:report:{project_key}:*"
            keys = list(self.redis.scan_iter(match=pattern))
            
            if keys:
                deleted = self.redis.delete(*keys)
                logger.info(f"Invalidated {deleted} cache entries for {project_key}")
                return deleted
            else:
                logger.info(f"No cache entries found for {project_key}")
                return 0
                
        except Exception as e:
            logger.error(f"Failed to invalidate project cache: {e}", exc_info=True)
            return 0
    
    def get_ttl(self, project_key: str, analysis_date: Optional[str] = None) -> Optional[int]:
        """
        Get remaining TTL for cached report
        
        Args:
            project_key: SonarQube project key
            analysis_date: Optional specific analysis date
        
        Returns:
            Remaining TTL in seconds, or None if not cached
        """
        try:
            cache_key = self._make_cache_key(project_key, analysis_date)
            ttl = self.redis.ttl(cache_key)
            
            if ttl > 0:
                return ttl
            else:
                return None
                
        except Exception as e:
            logger.error(f"Failed to get TTL: {e}", exc_info=True)
            return None
    
    def exists(self, project_key: str, analysis_date: Optional[str] = None) -> bool:
        """
        Check if report is cached
        
        Args:
            project_key: SonarQube project key
            analysis_date: Optional specific analysis date
        
        Returns:
            True if cached, False otherwise
        """
        try:
            cache_key = self._make_cache_key(project_key, analysis_date)
            return self.redis.exists(cache_key) > 0
        except Exception as e:
            logger.error(f"Failed to check cache existence: {e}", exc_info=True)
            return False
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics
        
        Returns:
            Dict with cache statistics
        """
        try:
            pattern = "sonarqube:report:*"
            keys = list(self.redis.scan_iter(match=pattern))
            
            total_keys = len(keys)
            total_memory = 0
            
            # Sample memory usage from first 100 keys
            for key in keys[:100]:
                memory = self.redis.memory_usage(key) or 0
                total_memory += memory
            
            # Estimate total memory
            if total_keys > 100:
                avg_memory_per_key = total_memory / min(100, total_keys)
                total_memory = int(avg_memory_per_key * total_keys)
            
            return {
                "total_cached_reports": total_keys,
                "estimated_memory_bytes": total_memory,
                "estimated_memory_mb": round(total_memory / (1024 * 1024), 2)
            }
            
        except Exception as e:
            logger.error(f"Failed to get cache stats: {e}", exc_info=True)
            return {
                "total_cached_reports": 0,
                "estimated_memory_bytes": 0,
                "estimated_memory_mb": 0,
                "error": str(e)
            }


# Global cache instance
_cache_instance: Optional[SonarQubeReportCache] = None


def get_report_cache() -> SonarQubeReportCache:
    """Get global report cache instance"""
    global _cache_instance
    if _cache_instance is None:
        _cache_instance = SonarQubeReportCache()
    return _cache_instance

