"""
Prometheus metrics for Mira AI.

Exposes a /metrics endpoint that SRE can scrape for SLO dashboards + alerts.
Everything is gauge/counter style; no histograms yet (would bloat the cardinality).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import os
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST
from fastapi import APIRouter, Response

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

router = APIRouter()

# ─── Counters ─────────────────────────────────────────────────────────────────
mira_jobs_created_total = Counter(
    "mira_jobs_created_total",
    "Total ModernizationJob records created, by job_type",
    labelnames=("job_type",),
)
mira_jobs_completed_total = Counter(
    "mira_jobs_completed_total",
    "Total jobs finishing with status=completed, by job_type",
    labelnames=("job_type",),
)
mira_jobs_failed_total = Counter(
    "mira_jobs_failed_total",
    "Total jobs finishing with status=failed, by job_type",
    labelnames=("job_type",),
)
mira_files_processed_total = Counter(
    "mira_files_processed_total",
    "Total per-file modernizations completed successfully",
    labelnames=("language",),
)
mira_files_failed_total = Counter(
    "mira_files_failed_total",
    "Total per-file modernizations that failed validation after retries",
    labelnames=("language",),
)
mira_llm_tokens_total = Counter(
    "mira_llm_tokens_total",
    "Total LLM tokens consumed, split by kind (prompt/completion/total)",
    labelnames=("kind",),
)
mira_rate_limit_rejections_total = Counter(
    "mira_rate_limit_rejections_total",
    "Requests rejected by the per-user or per-IP rate limiter",
)

# Validation layer outcomes — how many files passed/failed each validation layer.
mira_validation_outcome_total = Counter(
    "mira_validation_outcome_total",
    "Per-file validation results, split by layer (tree_sitter / native_linter) and outcome (pass/fail/skip/timeout)",
    labelnames=("layer", "outcome"),
)

# RAG layer — how often we actually fetched upstream docs vs hit the in-process cache.
mira_rag_fetches_total = Counter(
    "mira_rag_fetches_total",
    "RAG migration-doc fetches attempted",
    labelnames=("source",),  # "qdrant_cache" | "web_scrape" | "error"
)

# Manifest auto-updater — counts composer.json / .csproj / package.json / pyproject patches.
mira_manifest_updates_total = Counter(
    "mira_manifest_updates_total",
    "Project manifest files patched by the manifest_updater (composer.json, .csproj, etc.)",
    labelnames=("language",),
)

# Scope-gate rejections — how many projects hit the server-side ceiling.
mira_scope_rejections_total = Counter(
    "mira_scope_rejections_total",
    "Projects blocked by PipelineValidator.check_project_scope (hard size gate)",
    labelnames=("reason",),  # "files" | "bytes" | "runtime"
)

# Heartbeat recovery — how many orphaned jobs the startup scan recovered.
mira_orphaned_jobs_recovered_total = Counter(
    "mira_orphaned_jobs_recovered_total",
    "ModernizationJob records auto-interrupted by the startup recovery scan (no heartbeat)",
)

# SSH operations — distribution of per-file upload latency.
mira_ssh_upload_seconds = Histogram(
    "mira_ssh_upload_seconds",
    "Per-file SSH/SFTP upload latency",
    buckets=(0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0),
)
mira_ssh_upload_failures_total = Counter(
    "mira_ssh_upload_failures_total",
    "SSH upload failures (pre-check fail / stat mismatch / SFTP exception)",
    labelnames=("reason",),
)

# Per-file LLM call latency (single request round trip, after throttle).
mira_llm_call_seconds = Histogram(
    "mira_llm_call_seconds",
    "Groq LLM call latency per request",
    buckets=(0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 20.0, 60.0, 120.0),
)

# Whole-job durations — the big-picture view. p50/p95/p99 from these panels.
mira_job_duration_seconds = Histogram(
    "mira_job_duration_seconds",
    "End-to-end job duration from creation to terminal status",
    labelnames=("job_type", "status"),
    buckets=(5, 30, 60, 300, 900, 1800, 3600, 7200, 14400, 28800, 86400),
)

# USD cost — computed live from token counters and env-configurable pricing.
# Groq Qwen3-32B default prices as of 2026-04 ($ per 1M tokens):
#   input  $0.29  (MIRA_USD_PER_MTOK_INPUT)
#   output $0.39  (MIRA_USD_PER_MTOK_OUTPUT)
# Override via env for other providers (OpenAI, Anthropic, etc.).
mira_llm_usd_total = Gauge(
    "mira_llm_usd_total",
    "Estimated total LLM cost in USD (computed from mira_llm_tokens_total × configured per-M-token prices)",
)

# Running-job progress — aggregate percentage of files processed across all active jobs.
# Useful for a "how loaded is the system right now" top-of-dashboard tile.
mira_active_files_processed = Gauge(
    "mira_active_files_processed",
    "Sum of files_processed across all status=running jobs",
)
mira_active_files_total = Gauge(
    "mira_active_files_total",
    "Sum of files_total across all status=running jobs",
)

# ─── Gauges ──────────────────────────────────────────────────────────────────
mira_jobs_running = Gauge(
    "mira_jobs_running",
    "Number of jobs with status=running (snapshot by the /metrics handler)",
    labelnames=("job_type",),
)
mira_prompt_cache_size = Gauge(
    "mira_prompt_cache_size",
    "Number of entries currently in the in-process prompt cache",
)
mira_prompt_cache_hits_total = Counter(
    "mira_prompt_cache_hits_total",
    "Cumulative prompt-cache hits",
)
mira_prompt_cache_misses_total = Counter(
    "mira_prompt_cache_misses_total",
    "Cumulative prompt-cache misses",
)


def _usd_per_mtok(kind: str, default: float) -> float:
    try:
        return float(os.environ.get(f"MIRA_USD_PER_MTOK_{kind.upper()}", str(default)))
    except (TypeError, ValueError):
        return default


def _refresh_cost_gauge() -> None:
    """
    Estimate total USD spent on LLM calls so far. Reads the Prometheus
    counters we already maintain and multiplies by configured prices.
    """
    try:
        p_samples = [s for s in mira_llm_tokens_total.collect()[0].samples if s.name == "mira_llm_tokens_total"]
        totals = {s.labels.get("kind"): s.value for s in p_samples}
        prompt = float(totals.get("prompt", 0))
        completion = float(totals.get("completion", 0))
        price_in = _usd_per_mtok("input", 0.29)
        price_out = _usd_per_mtok("output", 0.39)
        usd = (prompt * price_in + completion * price_out) / 1_000_000.0
        mira_llm_usd_total.set(round(usd, 6))
    except Exception as e:
        logger.debug("metrics: cost gauge refresh failed: %s", e)


@router.get("/metrics", include_in_schema=False)
async def metrics() -> Response:
    """Prometheus scrape target. Refreshes gauges on every scrape."""
    # Refresh 'jobs_running' gauge snapshot — counters are already live.
    try:
        from app.db.mongodb_models import ModernizationJob
        running = await ModernizationJob.find(
            ModernizationJob.status == "running",
        ).to_list()
        counts: dict = {}
        active_proc = 0
        active_total = 0
        for j in running:
            counts[j.job_type or "unknown"] = counts.get(j.job_type or "unknown", 0) + 1
            active_proc += int(getattr(j, "files_processed", 0) or 0)
            active_total += int(getattr(j, "files_total", 0) or 0)
        for jt, n in counts.items():
            mira_jobs_running.labels(job_type=jt).set(n)
        mira_active_files_processed.set(active_proc)
        mira_active_files_total.set(active_total)
    except Exception as e:
        logger.debug("metrics: jobs_running snapshot failed: %s", e)

    # Refresh prompt-cache gauges
    try:
        from app.services.agents.prompt_cache import stats as cache_stats
        s = cache_stats()
        if s:
            mira_prompt_cache_size.set(s.get("size", 0))
    except Exception as e:
        logger.debug("metrics: prompt_cache stats failed: %s", e)

    # Refresh USD cost gauge from token counters
    _refresh_cost_gauge()

    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)
