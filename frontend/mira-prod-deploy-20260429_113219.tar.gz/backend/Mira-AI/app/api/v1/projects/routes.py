"""Project routes - DISABLED"""
from fastapi import APIRouter

router = APIRouter()

# All project endpoints have been removed
