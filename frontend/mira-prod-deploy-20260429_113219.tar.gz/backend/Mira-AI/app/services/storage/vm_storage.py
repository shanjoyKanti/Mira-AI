"""VM-based storage service using SSH/Paramiko for remote file operations"""
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.core.logging import get_logger
from app.core.security import decrypt_data
from app.services.ssh.ssh_service import SSHConnection, SSHService
from app.db.mongodb_models import User

logger = get_logger(__name__)


class VMStorageService:
    """Storage service for working with user VMs via SSH"""
    
    def __init__(self, user: User):
        """
        Initialize VM storage service for a user
        
        Args:
            user: User model with SSH credentials
        """
        self.user = user
        self.ssh_conn: Optional[SSHConnection] = None
        
        if not user.ssh_hostname or not user.ssh_username:
            raise ValueError("User does not have SSH credentials configured")
    
    def get_ssh_connection(self) -> SSHConnection:
        """Get or create SSH connection"""
        if not self.ssh_conn:
            # Decrypt credentials
            password = decrypt_data(self.user.ssh_password_encrypted) if self.user.ssh_password_encrypted else None
            private_key = decrypt_data(self.user.ssh_private_key_encrypted) if self.user.ssh_private_key_encrypted else None
            private_key_password = decrypt_data(self.user.ssh_private_key_password_encrypted) if self.user.ssh_private_key_password_encrypted else None
            
            self.ssh_conn = SSHService.create_connection(
                hostname=self.user.ssh_hostname,
                port=self.user.ssh_port or 22,
                username=self.user.ssh_username,
                password=password if password else None,
                private_key=private_key if private_key else None,
                private_key_password=private_key_password if private_key_password else None
            )
            
            if not self.ssh_conn.connect():
                raise ConnectionError(f"Failed to connect to VM at {self.user.ssh_hostname}")
        
        return self.ssh_conn
    
    def get_project_base_path(self, project_id: int) -> str:
        """Get base path for project on VM"""
        return f"/mira-ai/projects/{self.user.id}/{project_id}"
    
    def get_source_path(self, project_id: int) -> str:
        """Get source code path on VM"""
        return f"{self.get_project_base_path(project_id)}/source"
    
    def get_analysis_path(self, project_id: int) -> str:
        """Get analysis results path on VM"""
        return f"{self.get_project_base_path(project_id)}/analysis"
    
    def get_upgraded_path(self, project_id: int) -> str:
        """Get upgraded code path on VM"""
        return f"{self.get_project_base_path(project_id)}/upgraded"
    
    def get_reports_path(self, project_id: int) -> str:
        """Get reports path on VM"""
        return f"{self.get_project_base_path(project_id)}/reports"
    
    def get_tests_path(self, project_id: int) -> str:
        """Get tests path on VM"""
        return f"{self.get_project_base_path(project_id)}/tests"
    
    def get_docs_path(self, project_id: int) -> str:
        """Get docs path on VM"""
        return f"{self.get_project_base_path(project_id)}/docs"
    
    def initialize_project_storage(self, project_id: int) -> Dict[str, Any]:
        """
        Initialize project directories on user VM
        
        Returns:
            Dict with project paths and status
        """
        conn = self.get_ssh_connection()
        
        base_path = self.get_project_base_path(project_id)
        paths = {
            "base": base_path,
            "source": self.get_source_path(project_id),
            "analysis": self.get_analysis_path(project_id),
            "upgraded": self.get_upgraded_path(project_id),
            "tests": self.get_tests_path(project_id),
            "reports": self.get_reports_path(project_id),
            "docs": self.get_docs_path(project_id)
        }
        
        # Create all directories
        for path in paths.values():
            conn.create_directory(path)
        
        # Create metadata file
        metadata = {
            "project_id": project_id,
            "user_id": self.user.id,
            "created_at": datetime.utcnow().isoformat(),
            "status": "initialized",
            "storage_type": "vm_ssh",
            "vm_hostname": self.user.ssh_hostname
        }
        
        metadata_path = f"{base_path}/metadata.json"
        import json
        conn.write_file(metadata_path, json.dumps(metadata, indent=2))
        
        logger.info(f"Initialized project {project_id} storage on VM {self.user.ssh_hostname}")
        return {
            "success": True,
            "paths": paths,
            "metadata": metadata
        }
    
    def read_file(self, project_id: int, file_path: str, subdir: str = "source") -> Optional[str]:
        """
        Read a file from VM
        
        Args:
            project_id: Project ID
            file_path: Relative file path
            subdir: Subdirectory (source, analysis, etc.)
        """
        conn = self.get_ssh_connection()
        
        if subdir == "source":
            base_path = self.get_source_path(project_id)
        elif subdir == "analysis":
            base_path = self.get_analysis_path(project_id)
        elif subdir == "upgraded":
            base_path = self.get_upgraded_path(project_id)
        elif subdir == "reports":
            base_path = self.get_reports_path(project_id)
        elif subdir == "tests":
            base_path = self.get_tests_path(project_id)
        elif subdir == "docs":
            base_path = self.get_docs_path(project_id)
        else:
            base_path = self.get_project_base_path(project_id)
        
        full_path = f"{base_path}/{file_path}" if file_path else base_path
        return conn.read_file(full_path)
    
    def write_file(self, project_id: int, file_path: str, content: str, subdir: str = "source") -> bool:
        """
        Write a file to VM
        
        Args:
            project_id: Project ID
            file_path: Relative file path
            content: File content
            subdir: Subdirectory (source, analysis, etc.)
        """
        conn = self.get_ssh_connection()
        
        if subdir == "source":
            base_path = self.get_source_path(project_id)
        elif subdir == "analysis":
            base_path = self.get_analysis_path(project_id)
        elif subdir == "upgraded":
            base_path = self.get_upgraded_path(project_id)
        elif subdir == "reports":
            base_path = self.get_reports_path(project_id)
        elif subdir == "tests":
            base_path = self.get_tests_path(project_id)
        elif subdir == "docs":
            base_path = self.get_docs_path(project_id)
        else:
            base_path = self.get_project_base_path(project_id)
        
        full_path = f"{base_path}/{file_path}"
        return conn.write_file(full_path, content)
    
    def list_files(self, project_id: int, subdir: str = "source", recursive: bool = True) -> List[str]:
        """List files in project directory on VM"""
        conn = self.get_ssh_connection()
        
        if subdir == "source":
            base_path = self.get_source_path(project_id)
        elif subdir == "analysis":
            base_path = self.get_analysis_path(project_id)
        elif subdir == "upgraded":
            base_path = self.get_upgraded_path(project_id)
        elif subdir == "reports":
            base_path = self.get_reports_path(project_id)
        elif subdir == "tests":
            base_path = self.get_tests_path(project_id)
        elif subdir == "docs":
            base_path = self.get_docs_path(project_id)
        else:
            base_path = self.get_project_base_path(project_id)
        
        return conn.list_files(base_path, recursive=recursive)
    
    def file_exists(self, project_id: int, file_path: str, subdir: str = "source") -> bool:
        """Check if file exists on VM"""
        conn = self.get_ssh_connection()
        
        if subdir == "source":
            base_path = self.get_source_path(project_id)
        elif subdir == "analysis":
            base_path = self.get_analysis_path(project_id)
        elif subdir == "upgraded":
            base_path = self.get_upgraded_path(project_id)
        elif subdir == "reports":
            base_path = self.get_reports_path(project_id)
        elif subdir == "tests":
            base_path = self.get_tests_path(project_id)
        elif subdir == "docs":
            base_path = self.get_docs_path(project_id)
        else:
            base_path = self.get_project_base_path(project_id)
        
        full_path = f"{base_path}/{file_path}"
        return conn.file_exists(full_path)
    
    def execute_command(self, command: str) -> Dict[str, Any]:
        """Execute a command on the user VM"""
        conn = self.get_ssh_connection()
        return conn.execute_command(command)
    
    def get_project_metadata(self, project_id: int) -> Dict[str, Any]:
        """Get project metadata from VM"""
        metadata_path = f"{self.get_project_base_path(project_id)}/metadata.json"
        metadata_content = self.get_ssh_connection().read_file(metadata_path)
        
        if metadata_content:
            import json
            return json.loads(metadata_content)
        return {}
    
    def close(self):
        """Close SSH connection"""
        if self.ssh_conn:
            self.ssh_conn.disconnect()
            self.ssh_conn = None

