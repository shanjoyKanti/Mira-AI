"""Agent API routes - Execute various code analysis agents"""
import asyncio
import logging
import os
import re
import tempfile
import shutil
import threading
import time
import uuid
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import PlainTextResponse, Response
from typing import Optional, Dict, Any, List, Callable, Tuple
from datetime import datetime

from beanie.operators import In

from app.core.config import settings
from app.core.dependencies import get_current_active_user
from app.core.security import decrypt_data
from app.db.mongodb_models import User, UserProject, ModernizationJob, Transform
from app.api.v1.accounts.service import get_user_by_id
from app.services.ssh.ssh_service import SSHService
from app.api.v1.agents.schemas import (
    SSHCredentials,
    StructureAnalysisRequest,
    StructureAnalysisResponse,
    LanguageAnalysisRequest,
    LanguageAnalysisResponse,
    UpgradeAnalysisRequest,
    UpgradeAnalysisResponse,
    CodeModernizationRequest,
    CodeModernizationResponse,
    RunModernizationRequest,
    RunModernizationResponse,
    RunStructureLanguageRequest,
    RunUpgradeAnalysisRequest,
    RunUpgradeAnalysisSimpleRequest,
    RunCodeModernizationRequest,
    TransformListItem,
    SecurityTestRequest,
    SecurityTestResponse,
    StagedModernizationRequest,
    FixSonarIssuesRequest,
)
from app.services.agents.structure_analysis_agent import StructureTreeAnalyzer
from app.services.agents.language_analysis_agent import FrameworkLanguageAnalyzer
from app.services.agents.upgrade_analysis_agent import (
    PHPUpgradeAnalyzer,
    _find_latest_sonarqube_report,
    _ssh_home_base,
    _target_stage_token,
)
from app.services.agents.code_modernization_agent import PHPModernizationAgent
from app.services.agents.generic_modernization_agent import GenericModernizationAgent


# Process-wide shared GroqClient. All language agents in a single pipeline
# (fanout across PHP + JS + Python + …) share THIS client so throttling and
# retry budget are coordinated globally, not per-language. Without this, N
# parallel language agents burst N concurrent requests past the 3-rps shared
# budget and trigger 429s immediately (audit finding #5).
_shared_groq_client_lock = threading.Lock()
_shared_groq_client: Optional["GroqClient"] = None  # type: ignore[name-defined]


def _get_shared_groq_client():
    """Lazily construct one GroqClient for the whole process."""
    global _shared_groq_client
    if _shared_groq_client is None:
        with _shared_groq_client_lock:
            if _shared_groq_client is None:
                from app.services.agents.base_agent import GroqClient as _GC
                _shared_groq_client = _GC()
    return _shared_groq_client


def _build_modernization_agent(language: Optional[str]):
    """Agent factory — returns the right modernization agent for a language.

    PHP gets the SonarQube-guide-tuned PHPModernizationAgent (highest accuracy).
    Every other language gets GenericModernizationAgent, which is pipeline
    plumbing (tree-sitter split + generic prompt + RAG migration context).

    Both agents expose the same `modernize_project(project_path, to_version,
    on_progress=?, already_completed=?)` interface so the calling pipeline
    doesn't need to branch.

    Both share the same GroqClient so rate-limit throttling is coordinated
    across all parallel language pipelines.
    """
    lang = (language or "php").strip().lower()
    shared_client = _get_shared_groq_client()
    if lang == "php":
        agent = PHPModernizationAgent()
        # PHPModernizationAgent already inherits a GroqClient via BaseAgent;
        # swap to the shared instance so it participates in global throttling.
        try:
            agent.groq_client = shared_client
        except Exception:
            pass
        return agent
    return GenericModernizationAgent(language=lang, groq_client=shared_client)
from app.services.agents.security_test_agent import SecurityTestAgent
from app.services.agents.new_version_upgradation_agent import NewVersionUpgradationAgent
from app.services.validation.pipeline_validator import PipelineValidator
from app.services.emails import (
    send_upgrade_analysis_complete,
    send_upgrade_analysis_regenerated_complete,
    send_code_modernization_complete,
    send_migration_started,
)
from app.core.logging import get_logger

logger = get_logger(__name__)
router = APIRouter()

# Reports directory (passed to upgrade agent for SonarQube report lookup)
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent
REPORTS_DIR = _PROJECT_ROOT / "reports"
UPGRADE_GUIDE_DIR = _PROJECT_ROOT / "app" / "data" / "upgrade-guide"
# Static documentation paths removed — all migration docs are now sourced via RAG.
# These constants are kept as None to avoid breaking any callers that reference them.
DEFAULT_PHP_DOC_PATH = None      # formerly "app/data/php-documentation/php_documentation.txt"
DEFAULT_LARAVEL_DOCS_PATH = None  # formerly "app/data/laravel-documentation"
# Use _latest_stable_version(language) for new code. This constant is kept for backward compat.
DEFAULT_TARGET_PHP_VERSION = "8.5"
# Single-shot full modernization (Sonar + PHPModernizationAgent) uses upgraded-codes by default.
DEFAULT_REMOTE_UPGRADED_CODES_DIR = "upgraded-codes"
# Staged migration (NewVersionUpgradationAgent) writes stage_XX folders under this base on the client.
DEFAULT_REMOTE_STAGED_MIGRATION_DIR = "migrated-codes"


# ---------------------------------------------------------------------------
# Concurrency controls
# ---------------------------------------------------------------------------

# Max simultaneous full migration pipeline runs (Steps 1-4 combined).
# Each pipeline is CPU + IO heavy; too many in parallel starves Groq and disk.
# Override via MIRA_MAX_CONCURRENT_PIPELINES env var.
_MAX_CONCURRENT_PIPELINES: int = int(os.environ.get("MIRA_MAX_CONCURRENT_PIPELINES", "3"))
_pipeline_semaphore: Optional[asyncio.Semaphore] = None  # lazy-init on first event loop use

# Max simultaneous Groq API calls across ALL pipeline jobs combined.
# Groq's rate limit is per-account, not per-thread — this enforces a global cap.
# Override via MIRA_MAX_CONCURRENT_LLM_CALLS env var.
_MAX_CONCURRENT_LLM_CALLS: int = int(os.environ.get("MIRA_MAX_CONCURRENT_LLM_CALLS", "3"))
_groq_semaphore: Optional[asyncio.Semaphore] = None  # lazy-init on first event loop use

# Shared MongoClient for sync DB updates from background threads (avoids creating a new
# connection per DB write, which is both slow and exhausts the connection pool).
_sync_mongo_client: Optional[Any] = None
_sync_mongo_lock = threading.Lock()


def _get_pipeline_semaphore() -> asyncio.Semaphore:
    """Return (or create) the global pipeline concurrency semaphore."""
    global _pipeline_semaphore
    if _pipeline_semaphore is None:
        _pipeline_semaphore = asyncio.Semaphore(_MAX_CONCURRENT_PIPELINES)
    return _pipeline_semaphore


def _get_groq_semaphore() -> asyncio.Semaphore:
    """Return (or create) the global Groq API concurrency semaphore."""
    global _groq_semaphore
    if _groq_semaphore is None:
        _groq_semaphore = asyncio.Semaphore(_MAX_CONCURRENT_LLM_CALLS)
    return _groq_semaphore


def _auto_scaled_job_timeout(
    file_count: Optional[int] = None,
    *,
    staged: bool = False,
    stages: Optional[int] = None,
) -> int:
    """
    Return a job timeout in seconds, auto-scaled to project size.

    Baseline: env ``MIRA_JOB_TIMEOUT_SECONDS`` (or ``settings.AGENT_TIMEOUT_SECONDS``,
    default 7200). When ``file_count`` is known we extend the timeout so each file
    has ~50 s of LLM+SSH budget (configurable via ``MIRA_JOB_TIMEOUT_PER_FILE_SECONDS``).

    Staged migrations (Step 1: structure + version upgradation) walk the same files
    once per version hop. Set ``staged=True`` and we multiply the per-file budget by
    the expected number of stages — default 12, override via ``MIRA_STAGED_DEFAULT_STAGES``.
    Without this multiplier a 130-file × 11-stage PHP migration hits the 2-hour cap
    even though it has ~18 h of real work.

    A user-set ``MIRA_JOB_TIMEOUT_SECONDS`` is always respected when it's already
    larger than the auto-scaled value (explicit > implicit). The cap is 24 h
    (overridable via ``MIRA_JOB_TIMEOUT_MAX_SECONDS``).
    """
    base = int(os.environ.get(
        "MIRA_JOB_TIMEOUT_SECONDS",
        str(getattr(settings, "AGENT_TIMEOUT_SECONDS", 7200)),
    ))
    cap = int(os.environ.get("MIRA_JOB_TIMEOUT_MAX_SECONDS", str(24 * 3600)))

    # Staged jobs without a known file count still need a generous baseline.
    # Per-stage doc analysis + per-file LLM upgrade + push-to-VM + php -l per stage.
    # Empirically ~1 hour per stage for a small-to-medium project.
    if staged and not file_count:
        stages_eff = stages or int(os.environ.get("MIRA_STAGED_DEFAULT_STAGES", "12"))
        per_stage_sec = int(os.environ.get("MIRA_STAGED_PER_STAGE_SECONDS", "3600"))
        return min(cap, max(base, stages_eff * per_stage_sec))

    if not file_count or file_count <= 0:
        return base

    per_file_sec = int(os.environ.get("MIRA_JOB_TIMEOUT_PER_FILE_SECONDS", "50"))
    if staged:
        stages_eff = stages or int(os.environ.get("MIRA_STAGED_DEFAULT_STAGES", "12"))
        per_file_sec = per_file_sec * stages_eff
    floor_total = max(600, file_count * per_file_sec)
    return min(cap, max(base, floor_total))


def _get_sync_mongo_db():
    """Return a shared sync PyMongo database handle (thread-safe, connection-pooled)."""
    global _sync_mongo_client
    if _sync_mongo_client is None:
        with _sync_mongo_lock:
            if _sync_mongo_client is None:
                from pymongo import MongoClient
                _sync_mongo_client = MongoClient(
                    settings.MONGO_DB_URL,
                    serverSelectionTimeoutMS=5000,
                    connectTimeoutMS=5000,
                    socketTimeoutMS=5000,
                    maxPoolSize=10,
                )
    return _sync_mongo_client[settings.MONGODB_DATABASE]


# Cap how many log lines are persisted on a ModernizationJob document, mirroring the
# $slice caps already in place on completed_files and failed_files_detail. On a 100K-file
# run the log list could otherwise grow unbounded and hit Mongo's 16 MB doc limit.
_JOB_LOGS_CAP: int = int(os.environ.get("MIRA_JOB_LOGS_CAP", "2000"))


def _trim_job_logs(logs: Optional[List[str]]) -> List[str]:
    """Keep only the most recent _JOB_LOGS_CAP lines; oldest get dropped first."""
    if not logs:
        return []
    if len(logs) <= _JOB_LOGS_CAP:
        return list(logs)
    # Preserve a marker so clients know older lines were trimmed.
    dropped = len(logs) - _JOB_LOGS_CAP
    return [f"[... {dropped} older log line(s) dropped to stay under Mongo doc limit ...]"] + list(logs[-_JOB_LOGS_CAP:])


def _record_job_progress(
    job_id: str,
    *,
    files_total: Optional[int] = None,
    current_file: Optional[str] = None,
    completed_file: Optional[str] = None,
    failed_file: Optional[Tuple[str, str]] = None,  # (file, error)
    current_chunk_index: Optional[int] = None,
    files_processed_delta: int = 0,
    files_failed_delta: int = 0,
    eta_seconds: Optional[int] = None,
    # Per-stage progress (staged version migrations: PHP 7.4 → 7.5 → 7.6 → ... → 8.5)
    current_stage_index: Optional[int] = None,
    total_stages: Optional[int] = None,
    current_stage_from: Optional[str] = None,
    current_stage_to: Optional[str] = None,
) -> None:
    """
    Sync, thread-safe progress writer for long-running migration jobs.

    Every worker loop should call this at least once per file. Writes are incremental
    (``$inc`` for counters, ``$push`` for completed/failed lists) so multiple threads
    updating the same job won't stomp each other. Safe to call from executor threads.

    If the job document doesn't exist yet, this is a no-op (migration setup creates it).
    """
    if not job_id:
        return
    # Heartbeat stamp — any progress call refreshes it so the startup scan can
    # detect jobs whose worker has died (see _recover_orphaned_jobs_on_startup).
    set_fields: Dict[str, Any] = {
        "updated_at": datetime.utcnow(),
        "last_progress_update_at": datetime.utcnow(),
    }
    if files_total is not None:
        set_fields["files_total"] = files_total
    if current_file is not None:
        set_fields["current_file"] = current_file
    if completed_file is not None:
        set_fields["last_completed_file"] = completed_file
    if current_chunk_index is not None:
        set_fields["current_chunk_index"] = current_chunk_index
    if eta_seconds is not None:
        set_fields["eta_seconds"] = int(eta_seconds)
    if current_stage_index is not None:
        set_fields["current_stage_index"] = int(current_stage_index)
    if total_stages is not None:
        set_fields["total_stages"] = int(total_stages)
    if current_stage_from is not None:
        set_fields["current_stage_from"] = str(current_stage_from)
    if current_stage_to is not None:
        set_fields["current_stage_to"] = str(current_stage_to)

    inc_fields: Dict[str, int] = {}
    if files_processed_delta:
        inc_fields["files_processed"] = int(files_processed_delta)
    if files_failed_delta:
        inc_fields["files_failed"] = int(files_failed_delta)

    push_fields: Dict[str, Any] = {}
    if completed_file is not None:
        # Cap the stored list with $slice to stay under Mongo's 16 MB doc
        # limit on 100K+ file migrations (audit finding #1). Resume logic
        # only needs a "recently completed" window for duplicate detection.
        push_fields["completed_files"] = {"$each": [completed_file], "$slice": -50000}
    if failed_file is not None:
        f_path, f_err = failed_file
        push_fields["failed_files_detail"] = {
            "$each": [{
                "file": f_path,
                "error": str(f_err)[:500],
                "ts": datetime.utcnow(),
            }],
            "$slice": -5000,  # cap at 5000 failure records too
        }

    update: Dict[str, Any] = {}
    if set_fields:
        update["$set"] = set_fields
    if inc_fields:
        update["$inc"] = inc_fields
    if push_fields:
        update["$push"] = push_fields

    if not update:
        return

    try:
        db = _get_sync_mongo_db()
        db.modernization_jobs.update_one({"job_id": job_id}, update)
    except Exception as e:  # never crash the worker over a progress write
        logger.debug("Progress write failed for job %s: %s", job_id, e)


def _load_completed_files(job_id: str) -> set:
    """Return the set of files already marked completed for this job — enables resume."""
    if not job_id:
        return set()
    try:
        db = _get_sync_mongo_db()
        doc = db.modernization_jobs.find_one(
            {"job_id": job_id},
            {"completed_files": 1},
        )
        if doc and isinstance(doc.get("completed_files"), list):
            return set(doc["completed_files"])
    except Exception as e:
        logger.debug("Completed-files load failed for job %s: %s", job_id, e)
    return set()


def _path_contains_migrated_codes_segment(path_str: str) -> bool:
    """True if ``path_str`` has a path segment equal to ``migrated-codes`` (case-insensitive)."""
    try:
        return any(
            p.lower() == DEFAULT_REMOTE_STAGED_MIGRATION_DIR
            for p in Path(path_str).parts
            if p and p != "/"
        )
    except (ValueError, OSError):
        return DEFAULT_REMOTE_STAGED_MIGRATION_DIR.lower() in (path_str or "").lower()


def _client_ssh_home(user: User) -> str:
    """Client base directory from saved profile (e.g. ``/home/usama`` or path inferred from ``ssh_source_path``)."""
    h = _ssh_home_base(
        str(user.ssh_username or "").strip() or None,
        user.ssh_source_path,
    ).rstrip("/")
    if not h:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Could not resolve client base path; set ssh_username and ssh_source_path via SSH test.",
        )
    return h


# ---------------------------------------------------------------------------
# Large-codebase helpers
# ---------------------------------------------------------------------------

# Maximum source files to process per pipeline run (any language). Override via env var.
# Using None means no limit — process all files, regardless of count.
SOURCE_FILE_LIMIT: Optional[int] = (
    int(os.environ.get("MIRA_SOURCE_FILE_LIMIT") or os.environ["MIRA_PHP_FILE_LIMIT"])
    if (os.environ.get("MIRA_SOURCE_FILE_LIMIT") or os.environ.get("MIRA_PHP_FILE_LIMIT"))
    else None  # unlimited by default
)

# Alias for backward compatibility with existing code that uses PHP_FILE_LIMIT
PHP_FILE_LIMIT: Optional[int] = SOURCE_FILE_LIMIT

# How many files to download from remote in a single SSH find+cat batch
_DOWNLOAD_BATCH_SIZE: int = int(os.environ.get("MIRA_DOWNLOAD_BATCH_SIZE", "100"))

# Max bytes per file when downloading. Text source files rarely exceed a few MB;
# 100 MB ceiling covers large legacy monoliths (e.g. 500K-line generated-code PHP)
# while still bounding memory. Files above this are logged + placeholder-stubbed.
_MAX_FILE_BYTES: int = int(os.environ.get("MIRA_MAX_FILE_BYTES", str(100 * 1024 * 1024)))  # 100 MB


# Language → source file extensions mapping for generic support
_LANGUAGE_EXTENSIONS: Dict[str, List[str]] = {
    "php":        ["*.php"],
    "python":     ["*.py"],
    "javascript": ["*.js", "*.mjs", "*.cjs"],
    "typescript": ["*.ts", "*.tsx"],
    "java":       ["*.java"],
    "kotlin":     ["*.kt", "*.kts"],
    "go":         ["*.go"],
    "ruby":       ["*.rb"],
    "rust":       ["*.rs"],
    "csharp":     ["*.cs"],
    "cpp":        ["*.cpp", "*.cc", "*.cxx", "*.h", "*.hpp"],
    "c":          ["*.c", "*.h"],
}


def _source_extensions_for_language(language: Optional[str]) -> List[str]:
    """Return glob patterns for the given language, defaulting to PHP."""
    lang = (language or "php").lower().strip()
    return _LANGUAGE_EXTENSIONS.get(lang, _LANGUAGE_EXTENSIONS["php"])


# Latest known stable version per language (used as default when user doesn't specify to_version).
# These are the current stable releases — the default migration target when the user doesn't
# explicitly pick a to_version. Keep in sync with the version ladders in
# app/services/rag/version_ladder.py; _latest_stable_version() below also falls back to the
# last entry of the PHP ladder if this map is ever ahead/behind.
_LATEST_STABLE_VERSIONS: Dict[str, str] = {
    "php":        "8.5",
    "python":     "3.13",
    "javascript": "22",    # Node.js LTS
    "typescript": "5.6",
    "java":       "21",    # LTS
    "kotlin":     "2.0",
    "go":         "1.23",
    "ruby":       "3.3",
    "rust":       "1.81",
    "csharp":     "13",
    "cpp":        "23",
    "c":          "17",
}


def _latest_stable_version(language: Optional[str]) -> str:
    """Return the latest known stable version string for *language* (e.g. 'php' → '8.5').

    Falls back to the last entry of the language's version ladder if the language is not in
    the static map, so we never go stale against the ladder (which is the source of truth).
    """
    lang = (language or "php").lower().strip()
    if lang in _LATEST_STABLE_VERSIONS:
        return _LATEST_STABLE_VERSIONS[lang]
    try:
        from app.services.rag.version_ladder import _get_ladder
        ladder = _get_ladder(lang, None)
        if ladder:
            return ladder[-1]
    except Exception:
        pass
    return _LATEST_STABLE_VERSIONS.get("php", "8.5")


def _list_remote_source_files(
    ssh_conn,
    source_path: str,
    language: Optional[str] = None,
    limit: Optional[int] = None,
) -> List[str]:
    """
    Return all source files for the given language under *source_path* on the remote SSH
    server, excluding vendor/, node_modules/, and .git/. No hardcoded head -N truncation.

    Args:
        ssh_conn:    Active SSHConnection.
        source_path: Absolute path on the remote server.
        language:    Language key (e.g. "php", "python", "java"). Defaults to "php".
        limit:       Optional hard cap (None = unlimited). Controlled by MIRA_SOURCE_FILE_LIMIT.
    """
    patterns = _source_extensions_for_language(language)
    all_files: List[str] = []

    for pattern in patterns:
        find_cmd = (
            f"find '{source_path}' -type f -name '{pattern}' "
            f"-not -path '*/vendor/*' -not -path '*/node_modules/*' "
            f"-not -path '*/.git/*' -not -path '*/target/*' -not -path '*/build/*'"
        )
        result = ssh_conn.execute_command(find_cmd, timeout=ssh_conn.CMD_TIMEOUT_LONG)
        all_files.extend(f.strip() for f in result.get("stdout", "").splitlines() if f.strip())

    all_files = sorted(set(all_files))  # dedup + deterministic order

    if limit and len(all_files) > limit:
        logger.warning(
            "_list_remote_source_files: project has %d %s files; MIRA_SOURCE_FILE_LIMIT caps at %d. "
            "Set MIRA_SOURCE_FILE_LIMIT= (empty) to process all files.",
            len(all_files), language or "php", limit,
        )
        all_files = all_files[:limit]

    return all_files


# Keep old name as alias for backwards compat inside this file
def _list_remote_php_files(ssh_conn, source_path: str, limit: Optional[int] = None) -> List[str]:
    return _list_remote_source_files(ssh_conn, source_path, language="php", limit=limit)


def _download_source_files_to_local(
    ssh_conn,
    remote_files: List[str],
    source_path: str,
    local_root: Path,
    language: Optional[str] = None,
    on_progress: Optional[callable] = None,
) -> Tuple[int, int]:
    """
    Download a list of remote source files to *local_root*, preserving relative paths.
    Files are downloaded one-by-one via SFTP (binary-safe).

    Skip policy:
      - File is run through should_skip_path() first (vendor/, minified, binary ext, etc.).
        Skipped paths are NOT written to the local tree at all.
      - If the remote file is larger than _MAX_FILE_BYTES, a placeholder stub is written
        so the pipeline can still see the path existed, but the content is omitted.
        Skipped sizes are logged so users can see which files blew the cap.

    Returns:
        Tuple (downloaded_count, skipped_count).
    """
    from app.api.v1.analyze.utils import should_skip_path  # unified skip filter

    lang = (language or "unknown").lower()
    downloaded = 0
    skipped = 0
    too_large: List[Tuple[str, int]] = []
    filtered_by_reason: Dict[str, int] = {}
    total = len(remote_files)

    for i, remote_file in enumerate(remote_files, 1):
        rel = remote_file.replace(source_path, "").lstrip("/")
        if not rel:
            skipped += 1
            continue

        skip, reason = should_skip_path(rel)
        if skip:
            filtered_by_reason[reason] = filtered_by_reason.get(reason, 0) + 1
            skipped += 1
            continue

        local_file = local_root / rel
        local_file.parent.mkdir(parents=True, exist_ok=True)

        content = ssh_conn.read_file(remote_file, max_bytes=_MAX_FILE_BYTES)
        if content is None:
            # Track so we can surface the real offenders back to the user.
            try:
                file_size = ssh_conn.sftp.stat(remote_file).st_size or 0
            except Exception:
                file_size = -1
            too_large.append((remote_file, file_size))
            local_file.write_text(
                f"# MIRA: file skipped (size {file_size} bytes exceeds cap "
                f"{_MAX_FILE_BYTES} bytes, or file not readable): {remote_file}\n",
                encoding="utf-8",
            )
            skipped += 1
        else:
            local_file.write_text(content, encoding="utf-8", errors="ignore")
            downloaded += 1

        if on_progress and i % 10 == 0:
            on_progress(i, total)

    if filtered_by_reason:
        top = sorted(filtered_by_reason.items(), key=lambda x: -x[1])[:5]
        logger.info(
            "Download filter dropped %d path(s) (%s)",
            sum(filtered_by_reason.values()),
            ", ".join(f"{r}={n}" for r, n in top),
        )
    if too_large:
        top_big = sorted(too_large, key=lambda x: -x[1])[:5]
        logger.warning(
            "%d file(s) exceeded _MAX_FILE_BYTES=%d and were stubbed out. "
            "Top offenders: %s",
            len(too_large),
            _MAX_FILE_BYTES,
            ", ".join(f"{p} ({s} bytes)" for p, s in top_big),
        )

    return downloaded, skipped


# Backward-compat alias (callers still using the PHP-specific name)
def _download_php_files_to_local(
    ssh_conn,
    remote_files: List[str],
    source_path: str,
    local_root: Path,
    on_progress: Optional[callable] = None,
) -> Tuple[int, int]:
    return _download_source_files_to_local(
        ssh_conn, remote_files, source_path, local_root, language="php", on_progress=on_progress
    )


def _resolve_project_source_path(user: User, project_name: str) -> str:
    """
    Resolve source path for any pipeline step.
    Priority: user_projects.vm_code_path → user.ssh_source_path (direct) → heuristic.
    This is the canonical resolver used by ALL pipeline steps.
    """
    try:
        _db = _get_sync_mongo_db()
        _doc = _db["user_projects"].find_one(
            {"user_id": str(user.id), "project_name": project_name},
            {"vm_code_path": 1},
        )
        if _doc and (_doc.get("vm_code_path") or "").strip():
            path = _doc["vm_code_path"].strip()
            logger.info("Source path: using UserProject.vm_code_path=%s for project '%s'", path, project_name)
            return path
    except Exception as _e:
        logger.warning("Source path: could not look up UserProject.vm_code_path: %s", _e)
    if (user.ssh_source_path or "").strip():
        path = user.ssh_source_path.strip().rstrip("/")
        logger.info("Source path: vm_code_path missing; using ssh_source_path=%s for project '%s'", path, project_name)
        return path
    return _resolve_original_project_source_path(user, project_name)


def _resolve_original_project_source_path(user: User, project_name: str) -> str:
    """
    **Step 1 only** — directory of the **original** project on the client.

    Rules (in order):
    1. If ssh_source_path is under ``migrated-codes`` → use ``{home}/{project_name}``
       (never read from migration output as source).
    2. If the last path segment of ssh_source_path matches project_name (case-insensitive)
       → ssh_source_path IS the project root; return it directly.
    3. Otherwise ssh_source_path is the parent workspace → return ``{ssh_source_path}/{project_name}``.

    ``ssh_source_path`` is saved when the user calls ``POST /analyze/test/ssh`` with
    ``source_path`` pointing to either the project root (e.g. ``/home/usama/app2``) or
    its parent (e.g. ``/home/usama``).  Both cases are handled correctly by rules 2 and 3.
    """
    pname = (project_name or "").strip()
    if not pname:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="project_name is required to resolve source path.",
        )
    saved = (user.ssh_source_path or "").strip().rstrip("/")
    if not saved:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "ssh_source_path is not set. Call POST /api/v1/analyze/test/ssh with "
                "source_path pointing to your project root (e.g. /home/usama/app2) "
                "or its parent directory (e.g. /home/usama)."
            ),
        )
    # Rule 1: never read from migration output
    if _path_contains_migrated_codes_segment(saved):
        home = _client_ssh_home(user)
        resolved = f"{home}/{pname}"
        logger.info(
            "Source path resolution: ssh_source_path is under migrated-codes (%s); redirecting to %s",
            saved, resolved,
        )
        return resolved
    # Rule 2: saved path IS the project root (last segment matches project_name)
    try:
        if Path(saved).name.lower() == pname.lower():
            logger.debug("Source path resolution: ssh_source_path ends with project_name → using %s", saved)
            return saved
    except (ValueError, OSError):
        pass
    # Rule 3: saved path is the parent workspace
    resolved = f"{saved}/{pname}"
    logger.debug("Source path resolution: treating ssh_source_path as parent → %s", resolved)
    return resolved


def _resolve_migrated_stage_source_path(
    user: User,
    project_name: str,
    to_version: str,
    language: str = "php",
) -> str:
    """
    **Steps 2–4** — remote tree under
    ``{client_home}/migrated-codes/{project}/stage_*_<lang><majmin>`` matching ``to_version``.

    Language-aware: PHP → ``stage_*_php83``, Python → ``stage_*_py312``, JS/TS →
    ``stage_*_js18``, Java → ``stage_*_java21``, etc. Requires step 1 to have
    produced migrated stages. No fallback to the original project path.
    """
    from app.services.agents.upgrade_analysis_agent import _discover_migrated_stage_remote_path

    pname = (project_name or "").strip()
    lang = (language or "php").strip().lower()
    tv = (to_version or "").strip() or (DEFAULT_TARGET_PHP_VERSION if lang == "php" else "")
    if not pname:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="project_name is required.",
        )
    if not tv:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"to_version is required for language={lang}.",
        )
    upgrade_ssh, upgrade_ssh_src = _upgrade_analysis_ssh_from_user(user)
    if not upgrade_ssh or not upgrade_ssh.get("hostname"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="SSH is not configured; cannot resolve migrated-codes stage path.",
        )
    home = _ssh_home_base(str(upgrade_ssh.get("username") or ""), upgrade_ssh_src).rstrip("/")
    discovered = _discover_migrated_stage_remote_path(
        pname,
        tv,
        ssh_credentials=upgrade_ssh,
        ssh_home_base=home,
        language=lang,
    )
    if not discovered:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"No migrated stage for {lang} {tv} under {home}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}/{pname}/. "
                "Complete step 1 (structure + language + version upgradation) first so stage_* folders exist."
            ),
        )
    return discovered


def _remote_upgraded_codes_project_base(user: User, project_name: str) -> str:
    """``{client_home}/upgraded-codes/{project_name}`` for code modernization output layout."""
    pname = (project_name or "").strip()
    if not pname:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="project_name is required.")
    home = _client_ssh_home(user)
    return f"{home}/{DEFAULT_REMOTE_UPGRADED_CODES_DIR}/{pname}"


def _laravel_core_version_from_language_versions(
    language_versions: Optional[Dict[str, Any]],
) -> Optional[str]:
    """
    Current Laravel application major (from_laravel), not laravel/ui or tinker.
    """
    if not language_versions:
        return None
    normalized: Dict[str, str] = {}
    for k, v in language_versions.items():
        if k is None or v is None:
            continue
        key = str(k).strip()
        if key:
            normalized[key] = str(v).strip()
    for key in (
        "from_laravel",
        "Laravel",
        "laravel",
        "laravel/framework",
        "framework_laravel",
        "laravel_version",
        "illuminate/support",
        "illuminate/contracts",
    ):
        val = normalized.get(key)
        if val:
            return val
    for k, val in normalized.items():
        if str(k).lower() in ("laravel", "laravel/framework"):
            return val
    return None


def _to_laravel_from_language_versions(
    language_versions: Optional[Dict[str, Any]],
) -> Optional[str]:
    """Laravel major for upgrade-guide selection (maps to TARGET_PHP); from language_versions or deterministic."""
    if not language_versions:
        return None
    for key in ("to_laravel", "laravel_upgrade_guide_major"):
        v = language_versions.get(key)
        if v:
            s = str(v).strip()
            if s:
                return s
    return None


def _read_upgrade_report_contents(
    sonarqube_report_path: Optional[str],
    php_upgrade_guide_path: Optional[str],
    laravel_upgrade_guide_path: Optional[str],
) -> Dict[str, Optional[str]]:
    """Read content of upgrade guide report files. Returns dict with sonarqube_report_content, php_upgrade_guide_content, laravel_upgrade_guide_content (None if path is None or file missing)."""
    out: Dict[str, Optional[str]] = {
        "sonarqube_report_content": None,
        "php_upgrade_guide_content": None,
        "laravel_upgrade_guide_content": None,
    }
    for path_key, path_val in [
        ("sonarqube_report_content", sonarqube_report_path),
        ("php_upgrade_guide_content", php_upgrade_guide_path),
        ("laravel_upgrade_guide_content", laravel_upgrade_guide_path),
    ]:
        if not path_val:
            continue
        p = Path(path_val)
        if not p.is_absolute():
            p = _PROJECT_ROOT / path_val
        try:
            if p.exists():
                out[path_key] = p.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            logger.warning("Could not read upgrade report %s: %s", path_val, e)
    return out


def _upgrade_analysis_ssh_from_user(user: User) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Decrypt the user's saved SSH profile for Sonar download and migrated-codes stage discovery."""
    if not user.ssh_hostname or not user.ssh_username:
        return None, user.ssh_source_path
    password = decrypt_data(user.ssh_password_encrypted) if user.ssh_password_encrypted else None
    private_key = decrypt_data(user.ssh_private_key_encrypted) if user.ssh_private_key_encrypted else None
    private_key_password = (
        decrypt_data(user.ssh_private_key_password_encrypted)
        if user.ssh_private_key_password_encrypted
        else None
    )
    creds: Dict[str, Any] = {
        "hostname": user.ssh_hostname,
        "port": int(user.ssh_port or 22),
        "username": user.ssh_username,
    }
    if password:
        creds["password"] = password
    if private_key:
        creds["private_key"] = private_key
    if private_key_password:
        creds["private_key_password"] = private_key_password
    return creds, user.ssh_source_path


def _code_modernization_remote_source(
    user: User, project_name: str, to_version: str, language: str = "php"
) -> str:
    """``migrated-codes/{project}/stage_*_<lang><majmin>`` matching ``to_version`` (no original-tree fallback)."""
    p = _resolve_migrated_stage_source_path(user, project_name, to_version, language=language)
    logger.info("Code modernization: using migrated stage path %s (language=%s)", p, language)
    return p


def _code_modernization_remote_source_from_request(request: CodeModernizationRequest) -> str:
    """Migrated stage path using request SSH + ``source_path`` for home inference (same rules as saved user profile)."""
    from app.services.agents.upgrade_analysis_agent import (
        _discover_migrated_stage_remote_path,
        _ssh_home_base,
    )

    sc = request.ssh_credentials
    creds: Dict[str, Any] = {
        "hostname": sc.hostname,
        "port": int(sc.port or 22),
        "username": sc.username,
    }
    if sc.password:
        creds["password"] = sc.password
    if sc.private_key:
        creds["private_key"] = sc.private_key
    if sc.private_key_password:
        creds["private_key_password"] = sc.private_key_password
    home = _ssh_home_base(sc.username, request.source_path)
    discovered = _discover_migrated_stage_remote_path(
        request.project_name,
        request.to_version,
        ssh_credentials=creds,
        ssh_home_base=home,
    )
    if discovered:
        logger.info("Code modernization (API): migrated stage path %s", discovered)
        return discovered
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=(
            f"No migrated stage for PHP {request.to_version} under "
            f"{home}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}/{request.project_name}/. "
            "Complete step 1 first, or pass a matching to_version."
        ),
    )


def _resolve_docs_txt_root(docs_txt_root: Optional[str]) -> Optional[Path]:
    """No-op — static docs directories have been removed. RAG is always used."""
    return None


def _staged_remote_output_base(request: StagedModernizationRequest) -> str:
    """
    Base directory on the client for per-stage snapshots (``stage_XX_phpYY``).

    Always uses *migrated-codes* as the leaf directory. If the client omits
    ``output_path`` or sends the legacy *upgraded-codes* base (meant for single-shot
    modernization), we map it to *migrated-codes* so staged output never lands under
    ``upgraded-codes``.
    """
    username = (request.ssh_credentials.username or "").strip() or "user"
    default_migrated = f"/home/{username}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}"
    raw = (request.output_path or "").strip().rstrip("/")
    if not raw:
        return default_migrated.rstrip("/")
    p = Path(raw)
    if p.name.lower() == DEFAULT_REMOTE_UPGRADED_CODES_DIR.lower():
        remapped = str(p.with_name(DEFAULT_REMOTE_STAGED_MIGRATION_DIR)).rstrip("/")
        logger.info(
            "Staged migration: output_path ended with upgraded-codes; using migrated-codes base (%s → %s)",
            raw,
            remapped,
        )
        return remapped
    return raw


def _count_unresolved_high_severity_issues(
    sonarqube_report_path: Optional[str],
    fixes_applied: int,
) -> int:
    """
    Parse the SonarQube analysis report and return the number of BLOCKER or CRITICAL
    issues that were NOT resolved by the automatic fix pass.

    The heuristic: count total BLOCKER/CRITICAL issues in the report, then subtract
    fixes_applied (capped at that count). If the report cannot be read, returns 0 so
    the pipeline is not blocked by a missing/unreadable report.
    """
    if not sonarqube_report_path:
        return 0
    try:
        report_text = Path(sonarqube_report_path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return 0

    import re as _re
    # Count explicit BLOCKER / CRITICAL mentions in the structured issue list
    blocker_count = len(_re.findall(r"\bBLOCKER\b", report_text, _re.IGNORECASE))
    critical_count = len(_re.findall(r"\bCRITICAL\b", report_text, _re.IGNORECASE))
    total_high = blocker_count + critical_count
    # Each fix_applied addresses at most one issue; cannot fix more than exist
    remaining = max(0, total_high - fixes_applied)
    return remaining


def _run_final_validation(ssh_conn, remote_path: str, project_name: str) -> Dict[str, Any]:
    """
    Run a final validation sweep on the fully-migrated remote codebase.
    Called once after ALL staged migration steps complete.

    Checks:
      1. PHP syntax (php -l on all .php files)
      2. PHPUnit (if available)
      3. Composer autoload (if composer.json present)
      4. Laravel artisan --version (if artisan present)
      5. Python: pytest --tb=no -q (if setup.py / requirements.txt / pyproject.toml present)
      6. Java: mvn test -q (if pom.xml present) or gradle test (if build.gradle present)
      7. JavaScript/Node: npm test (if package.json with "test" script present)

    Returns dict with "passed", "errors", "checks_run".
    """
    errors: List[str] = []
    checks_run: List[str] = []

    def _run(cmd: str):
        return ssh_conn.execute_command(cmd)

    def _has(path: str) -> bool:
        r = _run(f"test -e '{path}' && echo yes || echo no")
        return "yes" in (r.get("stdout") or "")

    # 1. PHP syntax
    syn = _run(
        f"find '{remote_path}' -name '*.php' -not -path '*/vendor/*' "
        f"-not -path '*/node_modules/*' -print0 | "
        f"xargs -0 -r php -l 2>&1 | grep -v 'No syntax errors detected'"
    )
    checks_run.append("php -l")
    syn_out = (syn.get("stdout") or "").strip()
    if syn_out:
        parse_errors = [ln for ln in syn_out.splitlines() if ln.strip() and "No syntax errors" not in ln]
        errors.extend(parse_errors)
    elif (syn.get("exit_code") or 0) not in (0, None):
        errors.append(f"[php -l] exit={syn.get('exit_code')}")

    # 2. PHPUnit
    if _has(f"{remote_path}/vendor/bin/phpunit"):
        pu = _run(f"cd '{remote_path}' && vendor/bin/phpunit --no-coverage 2>&1 | tail -40")
        checks_run.append("phpunit --no-coverage")
        pu_out = (pu.get("stdout") or "").strip()
        if (pu.get("exit_code") or 0) != 0 or "FAILURES!" in pu_out or "ERRORS!" in pu_out:
            errors.append(f"[PHPUnit] {pu_out[-2000:]}")

    # 3. Composer autoload
    if _has(f"{remote_path}/composer.json"):
        ca = _run(f"cd '{remote_path}' && composer dump-autoload --no-dev --quiet 2>&1")
        checks_run.append("composer dump-autoload")
        ca_out = (ca.get("stdout") or "").strip()
        if (ca.get("exit_code") or 0) != 0:
            errors.append(f"[Composer autoload] {ca_out[:1000]}")

    # 4. Laravel artisan
    if _has(f"{remote_path}/artisan"):
        ar = _run(f"cd '{remote_path}' && php artisan --version 2>&1")
        checks_run.append("php artisan --version")
        if (ar.get("exit_code") or 0) != 0:
            errors.append(f"[Artisan] {(ar.get('stdout') or '')[:500]}")

    # 5. Python (pytest)
    py_marker = next(
        (m for m in ["setup.py", "pyproject.toml", "requirements.txt"] if _has(f"{remote_path}/{m}")),
        None,
    )
    if py_marker:
        py = _run(f"cd '{remote_path}' && python -m pytest --tb=short -q 2>&1 | tail -30")
        checks_run.append("pytest")
        py_out = (py.get("stdout") or "").strip()
        if (py.get("exit_code") or 0) != 0 and "no tests ran" not in py_out.lower():
            errors.append(f"[pytest] {py_out[-1500:]}")

    # 6. Java (Maven or Gradle)
    if _has(f"{remote_path}/pom.xml"):
        mvn = _run(f"cd '{remote_path}' && mvn test -q 2>&1 | tail -30")
        checks_run.append("mvn test")
        mvn_out = (mvn.get("stdout") or "").strip()
        if (mvn.get("exit_code") or 0) != 0:
            errors.append(f"[Maven] {mvn_out[-1500:]}")
    elif _has(f"{remote_path}/build.gradle") or _has(f"{remote_path}/build.gradle.kts"):
        gr = _run(f"cd '{remote_path}' && gradle test 2>&1 | tail -30")
        checks_run.append("gradle test")
        gr_out = (gr.get("stdout") or "").strip()
        if (gr.get("exit_code") or 0) != 0:
            errors.append(f"[Gradle] {gr_out[-1500:]}")

    # 7. JavaScript / Node (npm test)
    if _has(f"{remote_path}/package.json"):
        # Only run if a "test" script is defined — avoid spurious failures
        pkg_chk = _run(
            f"node -e \"const p=require('{remote_path}/package.json'); "
            f"process.exit(p.scripts && p.scripts.test ? 0 : 1);\" 2>/dev/null && echo yes || echo no"
        )
        if "yes" in (pkg_chk.get("stdout") or ""):
            npm = _run(f"cd '{remote_path}' && npm test -- --passWithNoTests 2>&1 | tail -30")
            checks_run.append("npm test")
            npm_out = (npm.get("stdout") or "").strip()
            if (npm.get("exit_code") or 0) != 0:
                errors.append(f"[npm test] {npm_out[-1500:]}")

    passed = len(errors) == 0
    logger.info(
        "[final_validation] project=%s path=%s passed=%s checks=%s errors=%d",
        project_name, remote_path, passed, checks_run, len(errors),
    )
    return {"passed": passed, "errors": errors, "checks_run": checks_run}


def _run_staged_modernization_api_sync(
    _user: User,
    request: StagedModernizationRequest,
    *,
    on_stage_started: Optional[Callable[[Any, int, int], None]] = None,
) -> Dict[str, Any]:
    """
    Download PHP project via SSH, run NewVersionUpgradationAgent staged pipeline,
    upload each stage under {output_base}/{project}/stage_XX_phpYY.

    SSH host/user/key and paths come from the request body (same pattern as
    /structure-analysis, /language-analysis, /code-modernization).
    """
    source_path = request.source_path.rstrip("/")
    if not source_path:
        raise ValueError("source_path is required.")
    project_name = (request.project_name or "").strip()
    if not project_name:
        raise ValueError("project_name is required.")

    output_base = _staged_remote_output_base(request)

    ssh_conn = SSHService.create_connection(
        hostname=request.ssh_credentials.hostname,
        port=request.ssh_credentials.port,
        username=request.ssh_credentials.username,
        password=request.ssh_credentials.password,
        private_key=request.ssh_credentials.private_key,
        private_key_password=request.ssh_credentials.private_key_password,
    )
    if not ssh_conn.connect():
        raise RuntimeError(
            f"Failed to connect to SSH server {request.ssh_credentials.hostname}:{request.ssh_credentials.port}."
        )

    laravel_upgrade_guide_path = request.laravel_upgrade_guide_path
    if not laravel_upgrade_guide_path and UPGRADE_GUIDE_DIR.exists():
        # Planning agent writes per-stage guides named:
        #   {project}_stage{N:02d}_{folder_name}_laravel_upgrade_guide_{ts}.txt
        # Also accept legacy pattern: {project}_laravel_upgrade_guide_*.txt
        candidates = sorted(
            list(UPGRADE_GUIDE_DIR.glob(f"{request.project_name}_stage*_laravel_upgrade_guide_*.txt"))
            + list(UPGRADE_GUIDE_DIR.glob(f"{request.project_name}_laravel_upgrade_guide_*.txt")),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if candidates:
            laravel_upgrade_guide_path = str(candidates[0])

    try:
        # Ensure we only modernize the intended project directory.
        project_source_path = source_path
        if Path(source_path).name != project_name:
            candidate = f"{source_path}/{project_name}".rstrip("/")
            check = ssh_conn.execute_command(f"test -d '{candidate}' && echo 'exists' || echo 'missing'")
            if check.get("success") and "exists" in (check.get("stdout") or ""):
                project_source_path = candidate
            else:
                logger.warning(
                    "source_path '%s' does not end with project_name '%s' and '%s' does not exist. "
                    "Proceeding with source_path as-is.",
                    source_path,
                    project_name,
                    candidate,
                )

        # --- Pre-flight validation ---
        preflight = PipelineValidator.run_all(
            ssh_conn=ssh_conn,
            source_path=project_source_path,
            from_version=request.from_version,
            to_version=request.to_version,
            project_name=project_name,
            force_scope=bool(getattr(request, "force", False)),
        )
        if preflight.has_errors():
            raise ValueError(
                f"Pipeline pre-flight validation failed: {preflight.error_summary()}"
            )
        for warn in preflight.warnings():
            logger.warning("[pre-flight] %s: %s", warn.code, warn.message)

        with tempfile.TemporaryDirectory() as temp_dir:
            local_project_path = Path(temp_dir) / request.project_name
            local_project_path.mkdir(parents=True, exist_ok=True)

            # List ALL PHP files — no hardcoded head -N truncation.
            # MIRA_PHP_FILE_LIMIT env var (default: unlimited) is the only cap.
            php_files = _list_remote_php_files(
                ssh_conn, project_source_path, limit=PHP_FILE_LIMIT
            )
            if not php_files:
                raise ValueError(
                    f"No PHP files found in '{project_source_path}'. "
                    "Verify the source_path points to the PHP project root on the remote server."
                )

            logger.info(
                "Downloading %d PHP file(s) from '%s' to container staging area...",
                len(php_files), project_source_path,
            )

            def _log_download_progress(done: int, total: int) -> None:
                logger.info("Download progress: %d/%d files", done, total)

            downloaded_count, skipped_count = _download_php_files_to_local(
                ssh_conn,
                php_files,
                project_source_path,
                local_project_path,
                on_progress=_log_download_progress,
            )

            if skipped_count:
                logger.warning(
                    "%d file(s) were skipped (too large / unreadable). "
                    "Set MIRA_MAX_FILE_BYTES to raise the per-file limit.",
                    skipped_count,
                )
            if downloaded_count == 0:
                raise ValueError(
                    f"All {len(php_files)} PHP files failed to download from '{project_source_path}'. "
                    "Check SSH permissions and file readability."
                )

            # composer.json enables Laravel detection; required when the app uses Laravel and a guide must be enforced.
            _composer_remote = f"{project_source_path.rstrip('/')}/composer.json"
            _cchk = ssh_conn.execute_command(f"test -f '{_composer_remote}' && echo ok || echo no")
            if _cchk.get("success") and "ok" in (_cchk.get("stdout") or ""):
                _ccat = ssh_conn.execute_command(f"cat '{_composer_remote}'")
                if _ccat.get("success"):
                    (local_project_path / "composer.json").write_text(
                        _ccat.get("stdout", ""),
                        encoding="utf-8",
                        errors="replace",
                    )

            agent = NewVersionUpgradationAgent()
            if not agent.load_reports(
                request.project_name,
                laravel_upgrade_guide_path=laravel_upgrade_guide_path,
                project_local_path=str(local_project_path),
                skip_initial_report_requirements=True,
            ):
                raise ValueError(
                    "Failed to initialize staged modernization agent (load_reports returned False)."
                )

            docs_root = _resolve_docs_txt_root(request.docs_txt_root)
            out = agent.run_pipeline_with_remote_snapshots(
                str(local_project_path),
                request.from_version,
                request.to_version,
                request.project_name,
                ssh_conn,
                output_base,
                docs_txt_root=docs_root,
                max_chars_per_stage=request.max_chars_per_stage,
                from_laravel=request.from_laravel,
                laravel_documentation_path=request.laravel_documentation_path,
                regenerate_reports_per_stage=True,
                reports_dir=REPORTS_DIR,
                on_stage_started=on_stage_started,
            )
            if not out.get("success"):
                raise RuntimeError(out.get("error", "Staged modernization failed"))

            out["source_path"] = project_source_path
            out["project_name"] = request.project_name
            return out
    finally:
        ssh_conn.disconnect()


# In-memory logs: single list of (job_id, line) so we always return/persist only that job's lines (no cross-job append).
_job_logs_list: List[Tuple[str, str]] = []
_job_logs_lock = threading.Lock()
_thread_local = threading.local()

# ---------------------------------------------------------------------------
# Per-job .txt log files
# ---------------------------------------------------------------------------
# Every running job writes its log lines live to ``/app/logs/jobs/<job_id>.txt``
# in addition to the in-memory store. Operators can stream/download the file at
# any time via GET /jobs/{job_id}/logs.txt — useful for sharing complete logs
# of long-running migrations with stakeholders.
#
# Override the directory with ``MIRA_JOB_LOG_DIR`` (defaults to /app/logs/jobs).
# We don't ship a volume mount by default; if you need logs to survive container
# restarts, mount the host path on this directory in docker-compose.yml.
JOB_LOG_DIR = Path(os.environ.get("MIRA_JOB_LOG_DIR", "/app/logs/jobs"))
try:
    JOB_LOG_DIR.mkdir(parents=True, exist_ok=True)
except Exception as _e:
    logger.warning("Could not create JOB_LOG_DIR %s: %s", JOB_LOG_DIR, _e)

# Per-job locks so concurrent threads writing the same file don't garble lines.
_job_log_file_locks: Dict[str, threading.Lock] = {}
_job_log_file_locks_lock = threading.Lock()


def _job_log_file_path(job_id: str) -> Path:
    """Absolute path of the .txt log file for a given job."""
    return JOB_LOG_DIR / f"{job_id}.txt"


def _get_job_log_lock(job_id: str) -> threading.Lock:
    with _job_log_file_locks_lock:
        lk = _job_log_file_locks.get(job_id)
        if lk is None:
            lk = threading.Lock()
            _job_log_file_locks[job_id] = lk
    return lk


def _append_job_log_line(job_id: str, line: str) -> None:
    """Append one log line to the per-job .txt file. Never raises."""
    if not job_id or not line:
        return
    try:
        lk = _get_job_log_lock(job_id)
        with lk:
            with open(_job_log_file_path(job_id), "a", encoding="utf-8") as fh:
                fh.write(line.rstrip("\n") + "\n")
    except Exception:
        # Log capture is best-effort — never crash the worker over a log-write failure.
        pass

# Only capture logs from these modules for the job-logs API (excludes middleware, httpx, etc.)
_JOB_LOG_LOGGERS = frozenset({
    "app.services.agents.structure_analysis_agent",
    "app.services.agents.language_analysis_agent",
    "app.services.agents.upgrade_analysis_agent",
    "app.services.agents.code_modernization_agent",
    "app.services.agents.new_version_upgradation_agent",
    "app.services.agents.planning_agent",
    "app.api.v1.agents.routes",
})


def _get_logs_for_job(job_id: str) -> List[str]:
    """Return only log lines tagged with this job_id (no other jobs)."""
    with _job_logs_lock:
        return [line for jid, line in _job_logs_list if jid == job_id]


def _pop_logs_for_job(job_id: str) -> List[str]:
    """Return log lines for this job_id and remove them from in-memory store (for persistence on completion)."""
    with _job_logs_lock:
        logs = [line for jid, line in _job_logs_list if jid == job_id]
        _job_logs_list[:] = [(j, l) for j, l in _job_logs_list if j != job_id]
        return logs


def _result_with_step_after_project_name(job_result: Any, step: str) -> Dict[str, Any]:
    """Build result dict with 'step' inserted right after 'project_name'. Preserves key order."""
    result = dict(job_result) if isinstance(job_result, dict) else {}
    out: Dict[str, Any] = {}
    for k, v in result.items():
        out[k] = v
        if k == "project_name":
            out["step"] = step
    if "step" not in out:
        out["step"] = step
    return out


class _JobCaptureHandler(logging.Handler):
    """Captures log records for the current thread's job_id.

    Every captured line is stored in two places:
      1. ``_job_logs_list`` (in-memory) — so the JSON ``/logs`` endpoint can
         tail logs while a job is running.
      2. ``/app/logs/jobs/<job_id>.txt`` (on disk) — so operators can download
         a full text log via GET /jobs/{job_id}/logs.txt at any point during or
         after the job. Persists past process restarts as long as the directory
         is mounted (see JOB_LOG_DIR).
    """

    def emit(self, record: logging.LogRecord) -> None:
        job_id = getattr(_thread_local, "current_job_id", None)
        if not job_id:
            return
        if record.name not in _JOB_LOG_LOGGERS:
            return
        try:
            msg = self.format(record)
            with _job_logs_lock:
                _job_logs_list.append((job_id, msg))
            # Best-effort live file write — failures here must not affect the worker.
            _append_job_log_line(job_id, msg)
        except Exception:
            self.handleError(record)


def _ensure_job_log_handler() -> None:
    """Add JobCaptureHandler to root logger once."""
    root = logging.getLogger()
    for h in root.handlers:
        if isinstance(h, _JobCaptureHandler):
            return
    h = _JobCaptureHandler()
    h.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
    root.addHandler(h)


def _is_job_cancelled(job_id: str) -> bool:
    """Check DB synchronously (from background thread) whether this job was cancelled by the user."""
    if not job_id or not settings.MONGO_DB_URL:
        return False
    try:
        db = _get_sync_mongo_db()
        doc = db.modernization_jobs.find_one({"job_id": job_id}, {"status": 1})
        return (doc or {}).get("status") == "cancelled"
    except Exception:
        return False  # Don't interrupt on DB error


@router.post(
    "/structure-analysis",
    response_model=StructureAnalysisResponse,
    tags=["DEPRECATED — use 4-step pipeline"],
    summary="[DEPRECATED] Analyze project structure — use /run-structure-language-and-version-upgradation instead",
    deprecated=True,
)
async def analyze_structure(
    request: StructureAnalysisRequest,
    current_user: User = Depends(get_current_active_user)
):
    ssh_conn = None
    try:
        logger.info(f"User {current_user.email} starting structure analysis")
        
        # Step 1: Connect to remote server via SSH
        ssh_conn = SSHService.create_connection(
            hostname=request.ssh_credentials.hostname,
            port=request.ssh_credentials.port,
            username=request.ssh_credentials.username,
            password=request.ssh_credentials.password,
            private_key=request.ssh_credentials.private_key,
            private_key_password=request.ssh_credentials.private_key_password
        )
        
        if not ssh_conn.connect():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to connect to SSH server {request.ssh_credentials.hostname}:{request.ssh_credentials.port}"
            )
        
        # Step 2: Verify source path exists on remote server
        result = ssh_conn.execute_command(f"test -d {request.source_path} && echo 'exists' || echo 'not_found'")
        if not result.get("success") or result.get("stdout", "").strip() != "exists":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Source path does not exist on remote server: {request.source_path}"
            )
        
        # Step 3: Create temporary local directory for analysis
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            # temp_path already exists from TemporaryDirectory(), no need to mkdir()
            
            # Step 4: Download project structure (files only, for analysis)
            # Use rsync for efficient transfer
            rsync_cmd = f"rsync -avz --exclude='.*' --exclude='__pycache__' --exclude='node_modules' {request.ssh_credentials.username}@{request.ssh_credentials.hostname}:{request.source_path}/ {temp_path}/"
            
            # For now, use a simple file listing approach
            result = ssh_conn.execute_command(f"find {request.source_path} -type f | head -1000")
            file_list = result.get("stdout", "").strip().split("\n") if result.get("success") else []
            
            # Create representative structure locally
            for file_path in file_list:
                if file_path.strip():
                    rel_path = file_path.replace(request.source_path, "").lstrip("/")
                    if rel_path:
                        local_file = temp_path / rel_path
                        local_file.parent.mkdir(parents=True, exist_ok=True)
                        local_file.touch()  # Create empty file for structure analysis
            
            # Step 5: Initialize and run agent on local structure
            agent = StructureTreeAnalyzer()
            result = agent.run(
                project_path=str(temp_path),
                project_name=request.project_name or Path(request.source_path).name
            )
            
            if not result["success"]:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Structure analysis failed: {result.get('error', 'Unknown error')}"
                )
        
        logger.info(f"Structure analysis completed successfully for {request.project_name}")
        
        return StructureAnalysisResponse(
            success=True,
            project_name=request.project_name or Path(request.source_path).name,
            source_path=request.source_path,
            server_hostname=request.ssh_credentials.hostname,
            structure_tree=result["results"].get("structure_tree", ""),
            total_files=result["results"].get("project_stats", {}).get("total_files", 0),
            total_directories=result["results"].get("project_stats", {}).get("total_directories", 0),
            analysis_time=result.get("execution_time", 0),
            timestamp=datetime.now()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Structure analysis failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


@router.post(
    "/language-analysis",
    response_model=LanguageAnalysisResponse,
    tags=["DEPRECATED — use 4-step pipeline"],
    summary="[DEPRECATED] Analyze project languages — use /run-structure-language-and-version-upgradation instead",
    deprecated=True,
)
async def analyze_languages(
    request: LanguageAnalysisRequest,
    current_user: User = Depends(get_current_active_user)
):
    ssh_conn = None
    try:
        logger.info(f"User {current_user.email} starting language analysis")
        
        # Step 1: Connect to remote server via SSH
        ssh_conn = SSHService.create_connection(
            hostname=request.ssh_credentials.hostname,
            port=request.ssh_credentials.port,
            username=request.ssh_credentials.username,
            password=request.ssh_credentials.password,
            private_key=request.ssh_credentials.private_key,
            private_key_password=request.ssh_credentials.private_key_password
        )
        
        if not ssh_conn.connect():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to connect to SSH server {request.ssh_credentials.hostname}:{request.ssh_credentials.port}"
            )
        
        # Step 2: Verify source path exists
        result = ssh_conn.execute_command(f"test -d {request.source_path} && echo 'exists' || echo 'not_found'")
        if not result.get("success") or result.get("stdout", "").strip() != "exists":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Source path does not exist on remote server: {request.source_path}"
            )
        
        # Step 3: Create temporary local directory and download key files for analysis
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir) / "project"
            temp_path.mkdir(exist_ok=True)
            
            # Download key configuration files and samples for language detection
            key_files = [
                "composer.json", "package.json", "requirements.txt", "Gemfile", "pom.xml",
                "*.py", "*.php", "*.js", "*.java", "*.cpp", "*.cs", "*.go", "*.rb", "*.rs"
            ]
            
            # Get file listing and download samples
            for pattern in key_files:
                result = ssh_conn.execute_command(f"find {request.source_path} -name '{pattern}' -type f | head -20")
                if result.get("success") and result.get("stdout", "").strip():
                    files = result["stdout"].strip().split("\n")
                    for remote_file in files[:5]:  # Limit to first 5 files per type
                        if remote_file.strip():
                            rel_path = remote_file.replace(request.source_path, "").lstrip("/")
                            local_file = temp_path / rel_path
                            local_file.parent.mkdir(parents=True, exist_ok=True)
                            
                            # Download file content
                            content_result = ssh_conn.execute_command(f"cat {remote_file}")
                            if content_result.get("success"):
                                local_file.write_text(content_result.get("stdout", ""), encoding="utf-8", errors="ignore")
            
            # Step 4: Run language analysis agent (no target version hint — detect first)
            agent = FrameworkLanguageAnalyzer()
            result = agent.run(
                project_path=str(temp_path),
                project_name=request.project_name or Path(request.source_path).name
            )
            
            if not result["success"]:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Language analysis failed: {result.get('error', 'Unknown error')}"
                )
            
            frameworks_data = result["results"].get("frameworks_languages", {})
        
        logger.info(f"Language analysis completed successfully for {request.project_name}")
        
        return LanguageAnalysisResponse(
            success=True,
            project_name=request.project_name or Path(request.source_path).name,
            source_path=request.source_path,
            server_hostname=request.ssh_credentials.hostname,
            languages=frameworks_data.get("languages", []),
            frameworks=frameworks_data.get("frameworks", []),
            language_versions=frameworks_data.get("language_versions", {}),
            analysis_time=result.get("execution_time", 0),
            timestamp=datetime.now()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Language analysis failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


@router.post(
    "/upgrade-analysis",
    response_model=UpgradeAnalysisResponse,
    tags=["DEPRECATED — use 4-step pipeline"],
    summary="[DEPRECATED] Generate upgrade analysis — use /run-upgrade-analysis instead",
    deprecated=True,
)
async def analyze_upgrade(
    request: UpgradeAnalysisRequest,
    current_user: User = Depends(get_current_active_user)
):
    try:
        logger.info(f"User {current_user.email} starting upgrade analysis: {request.from_version} → {request.to_version}")
        
        # Validate local SonarQube report exists and is .html, .md, or .docx
        sonarqube_report = Path(request.sonarqube_report_path)
        if not sonarqube_report.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"SonarQube report does not exist locally: {request.sonarqube_report_path}",
            )
        if sonarqube_report.suffix.lower() not in (".html", ".md", ".docx"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SonarQube report must be .html, .md, or .docx.",
            )
        agent = PHPUpgradeAnalyzer()
        guide_path = agent.analyze_sonarqube_report(str(sonarqube_report), request.project_name)
        if not guide_path:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to generate SonarQube upgrade guide.",
            )
        logger.info(
            "Upgrade analysis completed: %s → %s (SonarQube guide only)",
            request.from_version,
            request.to_version,
        )
        return UpgradeAnalysisResponse(
            success=True,
            from_version=request.from_version,
            to_version=request.to_version,
            from_laravel=None,
            to_laravel=None,
            sonarqube_analysis_path=guide_path,
            upgrade_guide_path=guide_path,
            laravel_upgrade_guide_path=None,
            message="SonarQube upgrade guide generated and saved to app/data/upgrade-guide/",
            timestamp=datetime.now(),
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upgrade analysis failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )


@router.post(
    "/code-modernization",
    response_model=CodeModernizationResponse,
    tags=["DEPRECATED — use 4-step pipeline"],
    summary="[DEPRECATED] Modernize code — use /run-code-modernization instead",
    deprecated=True,
)
async def modernize_code(
    request: CodeModernizationRequest,
    current_user: User = Depends(get_current_active_user)
):
    ssh_conn = None
    try:
        logger.info(f"User {current_user.email} starting code modernization for {request.project_name}")
        
        # Step 1: Connect to client server via SSH
        ssh_conn = SSHService.create_connection(
            hostname=request.ssh_credentials.hostname,
            port=request.ssh_credentials.port,
            username=request.ssh_credentials.username,
            password=request.ssh_credentials.password,
            private_key=request.ssh_credentials.private_key,
            private_key_password=request.ssh_credentials.private_key_password
        )
        
        if not ssh_conn.connect():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to connect to SSH server {request.ssh_credentials.hostname}:{request.ssh_credentials.port}"
            )
        
        # Step 2: Resolve remote tree (migrated-codes stage for target PHP, else request.source_path)
        mod_fetch = _code_modernization_remote_source_from_request(request)
        result = ssh_conn.execute_command(f"test -d '{mod_fetch}' && echo 'exists' || echo 'not_found'")
        if not result.get("success") or result.get("stdout", "").strip() != "exists":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Project path does not exist on client server: {mod_fetch}",
            )

        # Step 3: SonarQube upgrade guide only
        sonar_report_path: Path
        if request.sonarqube_report_path:
            sonar_report_path = Path(request.sonarqube_report_path)
            if not sonar_report_path.is_absolute():
                sonar_report_path = _PROJECT_ROOT / sonar_report_path
        else:
            sonar_report_path = UPGRADE_GUIDE_DIR / f"{request.project_name}_sonarqube_analysis_latest.txt"
        if not sonar_report_path.exists() and UPGRADE_GUIDE_DIR.exists():
            candidates = sorted(
                UPGRADE_GUIDE_DIR.glob(f"{request.project_name}_sonarqube_analysis_*.txt"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if candidates:
                sonar_report_path = candidates[0]
        if not sonar_report_path.exists():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"SonarQube upgrade guide not found: {sonar_report_path}. Run /agents/upgrade-analysis first or provide sonarqube_report_path.",
            )

        out_base = (request.output_path or "").strip().rstrip("/")
        if not out_base:
            out_base = f"/home/{request.ssh_credentials.username}/{DEFAULT_REMOTE_UPGRADED_CODES_DIR}"
        # Unique output folder under upgraded-codes base (e.g. .../upgraded-codes/upgraded_my_php_app_20260305_143022)
        unique_suffix = datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid.uuid4().hex[:6]
        output_folder_name = f"upgraded_{request.project_name}_{unique_suffix}"
        remote_output_base = f"{out_base}/{output_folder_name}"
        saved_output_path = None

        # Step 4: Download project from client (reports will be loaded by agent from app/data/upgrade-guide/)
        with tempfile.TemporaryDirectory() as temp_dir:
            local_project_path = Path(temp_dir) / request.project_name
            local_project_path.mkdir(parents=True, exist_ok=True)
            
            # Download all PHP files from client (migrated stage tree when available)
            result = ssh_conn.execute_command(f"find '{mod_fetch}' -type f -name '*.php' | head -500")
            php_files = [f.strip() for f in result.get("stdout", "").strip().split("\n") if f.strip()]

            if not php_files:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"No PHP files found in source path: {mod_fetch}",
                )

            # Download each PHP file
            for remote_file in php_files:
                rel_path = remote_file.replace(mod_fetch, "").lstrip("/")
                local_file = local_project_path / rel_path
                local_file.parent.mkdir(parents=True, exist_ok=True)
                
                content_result = ssh_conn.execute_command(f"cat '{remote_file}'")
                if content_result.get("success"):
                    local_file.write_text(content_result.get("stdout", ""), encoding="utf-8", errors="ignore")
            
            logger.info(f"Downloaded {len(php_files)} PHP files from client server")
            
            # Step 5: Agent loads SonarQube guide only, then modernizes
            agent = PHPModernizationAgent()
            if not agent.load_reports(
                request.project_name,
                sonarqube_report_path=str(sonar_report_path),
            ):
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Failed to load SonarQube upgrade guide.",
                )
            agent.analyze_structure(str(local_project_path))
            results = agent.modernize_project(str(local_project_path), request.to_version)
            
            stats = results.get('stats', {})
            files = results.get('files', [])
            
            # Step 6: Save upgraded code on client server under unique folder (upgraded_{project_name}_{timestamp})
            ssh_conn.execute_command(f"mkdir -p '{remote_output_base}'")
            saved_output_path = remote_output_base
            
            uploaded_count = 0
            for file_info in files:
                remote_output_file = f"{remote_output_base}/{file_info['path']}"
                
                remote_dir = str(Path(remote_output_file).parent)
                ssh_conn.execute_command(f"mkdir -p '{remote_dir}'")
                
                upload_result = ssh_conn.execute_command(f"cat > '{remote_output_file}' << 'EOFPHP'\n{file_info['code']}\nEOFPHP")
                
                if upload_result.get("success", True):
                    uploaded_count += 1
            
            logger.info(f"Uploaded {uploaded_count} modernized files to {remote_output_base}")
        
        logger.info(f"Code modernization completed successfully for {request.project_name}")
        
        return CodeModernizationResponse(
            success=True,
            source_path=request.source_path,
            output_path=saved_output_path or f"{out_base}/{output_folder_name}",
            server_hostname=request.ssh_credentials.hostname,
            project_name=request.project_name,
            to_version=request.to_version,
            total_files=stats.get('total', 0),
            files_upgraded=stats.get('upgraded', 0),
            files_unchanged=stats.get('unchanged', 0),
            files_with_errors=stats.get('errors', 0),
            message=f"Code modernization completed. Upgraded code saved to {saved_output_path or remote_output_base}",
            timestamp=datetime.now()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Code modernization failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error: {str(e)}"
        )
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


def _run_modernization_pipeline_sync(
    user: User,
    request: RunModernizationRequest,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]] = None,
    on_step_completed: Optional[Callable[[str, float], None]] = None,
) -> Tuple[Optional[RunModernizationResponse], Dict[str, float]]:
    """Run full pipeline in a thread (for background job). Returns (response, step_durations_sec). Captures logs tagged with job_id."""
    _ensure_job_log_handler()
    _thread_local.current_job_id = job_id
    try:
        return _run_modernization_pipeline_sync_impl(user, request, job_id, on_step_started, on_step_completed)
    finally:
        _thread_local.current_job_id = None


def _run_modernization_pipeline_sync_impl(
    user: User,
    request: RunModernizationRequest,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]] = None,
    on_step_completed: Optional[Callable[[str, float], None]] = None,
) -> Tuple[RunModernizationResponse, Dict[str, float]]:
    """Inner pipeline implementation (no log context). Updates job result in DB after each task."""
    ssh_conn = None
    step_timings: Dict[str, float] = {}
    password = decrypt_data(user.ssh_password_encrypted) if user.ssh_password_encrypted else None
    private_key = decrypt_data(user.ssh_private_key_encrypted) if user.ssh_private_key_encrypted else None
    private_key_password = decrypt_data(user.ssh_private_key_password_encrypted) if user.ssh_private_key_password_encrypted else None
    source_path = request.source_path or _resolve_project_source_path(user, request.project_name)
    output_path = request.output_path or _remote_upgraded_codes_project_base(user, request.project_name)
    steps_completed: List[str] = []
    from_version: Optional[str] = None
    from_laravel: Optional[str] = None
    to_laravel: Optional[str] = None
    # to_version resolved after language detection below; placeholder for now
    _requested_to_version = (request.to_version or "").strip()
    to_version = _requested_to_version or DEFAULT_TARGET_PHP_VERSION
    stats = {"total": 0, "upgraded": 0, "unchanged": 0, "errors": 0}
    project_structure: Optional[str] = None
    if on_step_started:
        on_step_started("structure_analysis")
    try:
        ssh_conn = SSHService.create_connection(
            hostname=user.ssh_hostname,
            port=user.ssh_port or 22,
            username=user.ssh_username,
            password=password,
            private_key=private_key,
            private_key_password=private_key_password,
        )
        if not ssh_conn.connect():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Failed to connect to SSH server {user.ssh_hostname}:{user.ssh_port}. Re-test SSH to update saved credentials.")
        result = ssh_conn.execute_command(f"test -d {source_path} && echo 'exists' || echo 'not_found'")
        if not result.get("success") or result.get("stdout", "").strip() != "exists":
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Source path does not exist on client server: {source_path}")
        t0 = time.perf_counter()
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            # Structure analysis only needs the file tree (no content) — list ALL files
            # but exclude vendor/node_modules to keep the tree manageable.
            result = ssh_conn.execute_command(
                f"find '{source_path}' -type f "
                f"-not -path '*/vendor/*' -not -path '*/node_modules/*' "
                f"-not -path '*/.git/*'",
                timeout=ssh_conn.CMD_TIMEOUT_LONG,
            )
            file_list = result.get("stdout", "").strip().split("\n") if result.get("success") else []
            for file_path in file_list:
                if file_path.strip():
                    rel_path = file_path.replace(source_path, "").lstrip("/")
                    if rel_path:
                        (temp_path / rel_path).parent.mkdir(parents=True, exist_ok=True)
                        (temp_path / rel_path).touch()
            agent = StructureTreeAnalyzer()
            run_result = agent.run(project_path=str(temp_path), project_name=request.project_name)
            if not run_result["success"]:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Structure analysis failed: {run_result.get('error', 'Unknown error')}")
            project_structure = run_result.get("results", {}).get("structure_tree") or ""
        step_timings["structure_analysis"] = time.perf_counter() - t0
        if on_step_completed:
            on_step_completed("structure_analysis", step_timings["structure_analysis"])
        steps_completed.append("structure_analysis")
        _sync_update_job_result(job_id, {
            "success": True,
            "project_name": request.project_name,
            "source_path": source_path,
            "output_path": "",
            "server_hostname": user.ssh_hostname,
            "project_structure": project_structure or "",
            "from_version": "",
            "to_version": to_version,
            "from_laravel": None,
            "to_laravel": None,
            "steps_completed": list(steps_completed),
            "sonarqube_report_path": None,
            "php_upgrade_guide_path": None,
            "laravel_upgrade_guide_path": None,
            "total_files": 0,
            "files_upgraded": 0,
            "files_unchanged": 0,
            "files_with_errors": 0,
            "message": "Structure analysis completed.",
            "timestamp": datetime.utcnow(),
        })
        if on_step_started:
            on_step_started("language_analysis")
        t0 = time.perf_counter()
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir) / "project"
            temp_path.mkdir(exist_ok=True)
            # Language analysis only needs a sample of config/source files — fetch up to 5
            # per pattern so the detector has representative data without huge downloads.
            for pattern in ["composer.json", "package.json", "*.php", "*.py", "*.js", "*.json", "*.xml"]:
                result = ssh_conn.execute_command(
                    f"find '{source_path}' -name '{pattern}' -type f "
                    f"-not -path '*/vendor/*' -not -path '*/node_modules/*' | head -5"
                )
                if result.get("success") and result.get("stdout", "").strip():
                    for remote_file in result["stdout"].strip().split("\n")[:5]:
                        if remote_file.strip():
                            rel_path = remote_file.replace(source_path, "").lstrip("/")
                            local_file = temp_path / rel_path
                            local_file.parent.mkdir(parents=True, exist_ok=True)
                            content = ssh_conn.read_file(remote_file)
                            if content is not None:
                                local_file.write_text(content, encoding="utf-8", errors="ignore")
            agent = FrameworkLanguageAnalyzer()
            run_result = agent.run(project_path=str(temp_path), project_name=request.project_name)
            if not run_result["success"]:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Language analysis failed: {run_result.get('error', 'Unknown error')}")
            lang_vers = run_result["results"].get("language_versions", {}) or {}
            detected_langs = run_result["results"].get("detected_languages", []) or []
            # Detect primary language for version resolution
            primary_lang_mod = (detected_langs[0] if detected_langs else "").lower()
            for lang, ver in lang_vers.items():
                if lang.lower() == primary_lang_mod and ver:
                    from_version = str(ver).strip()
                    break
            if not from_version:
                # fallback: pick first version entry
                for lang, ver in lang_vers.items():
                    if ver and lang.lower() not in ("laravel", "to_laravel", "node"):
                        from_version = str(ver).strip()
                        primary_lang_mod = lang.lower()
                        break
            from_laravel = _laravel_core_version_from_language_versions(lang_vers)
            if not from_laravel:
                for k, v in lang_vers.items():
                    if k and "laravel" in str(k).lower() and v:
                        from_laravel = str(v).strip()
                        break
            to_laravel = _to_laravel_from_language_versions(lang_vers)
            # Now that we know the language, resolve target version
            if not _requested_to_version:
                to_version = _latest_stable_version(primary_lang_mod)
        step_timings["language_analysis"] = time.perf_counter() - t0
        if on_step_completed:
            on_step_completed("language_analysis", step_timings["language_analysis"])
        steps_completed.append("language_analysis")
        _sync_update_job_result(job_id, {
            "success": True,
            "project_name": request.project_name,
            "source_path": source_path,
            "output_path": "",
            "server_hostname": user.ssh_hostname,
            "project_structure": project_structure or "",
            "from_version": from_version or "",
            "to_version": to_version,
            "from_laravel": from_laravel,
            "to_laravel": to_laravel,
            "steps_completed": list(steps_completed),
            "sonarqube_report_path": None,
            "php_upgrade_guide_path": None,
            "laravel_upgrade_guide_path": None,
            "total_files": 0,
            "files_upgraded": 0,
            "files_unchanged": 0,
            "files_with_errors": 0,
            "message": "Language analysis completed.",
            "timestamp": datetime.utcnow(),
        })
        if from_version is None:
            from_version = "5.6"
        logger.info(
            "Language analysis result: detected PHP version=%s, from_laravel=%s, to_laravel (guide major)=%s",
            from_version,
            from_laravel or "none",
            to_laravel or "none",
        )
        # ── STEP 3: SonarQube scan + security fix (MUST complete before migration) ──
        # Spec order: security-harden first, then version-migrate.
        if on_step_started:
            on_step_started("upgrade_analysis")
        t0 = time.perf_counter()
        logger.info(
            "Upgrade analysis (SonarQube): PHP %s → %s, from_laravel=%s, to_laravel=%s",
            from_version, to_version, from_laravel or "none", to_laravel or "none",
        )
        upgrade_ssh, upgrade_ssh_src = _upgrade_analysis_ssh_from_user(user)
        if not upgrade_ssh:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SSH is not configured on your account. Run /api/v1/analyze/test/ssh first.",
            )
        upgrade_agent = PHPUpgradeAnalyzer()
        sonarqube_report_path, php_upgrade_guide_path, _, laravel_upgrade_guide_path = (
            upgrade_agent.run_full_upgrade_analysis(
                project_name=request.project_name,
                from_version=from_version,
                to_version=to_version,
                reports_dir=REPORTS_DIR,
                ssh_credentials=upgrade_ssh,
                ssh_source_path=upgrade_ssh_src,
                report_type=getattr(request, "sonarqube_report_type", None) or "generic_security",
            )
        )
        steps_completed.append("upgrade_analysis")
        if not sonarqube_report_path or not Path(sonarqube_report_path).exists():
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Upgrade analysis failed: SonarQube report could not be generated.",
            )
        step_timings["upgrade_analysis"] = time.perf_counter() - t0
        if on_step_completed:
            on_step_completed("upgrade_analysis", step_timings["upgrade_analysis"])
        upgrade_contents = _read_upgrade_report_contents(
            sonarqube_report_path, php_upgrade_guide_path, laravel_upgrade_guide_path
        )

        # ── STEP 4: Apply SonarQube fixes to source (with .bak backup, severity order) ──
        if on_step_started:
            on_step_started("code_modernization")
        t0 = time.perf_counter()
        unique_suffix = datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid.uuid4().hex[:6]
        output_folder_name = f"upgraded_{request.project_name}_{unique_suffix}"
        remote_output_base = f"{output_path}/{output_folder_name}"
        sonarqube_fixes_applied = 0
        sonarqube_fixes_failed = 0
        sonarqube_bak_count = 0
        with tempfile.TemporaryDirectory() as temp_dir:
            local_project_path = Path(temp_dir) / request.project_name
            local_project_path.mkdir(parents=True, exist_ok=True)
            php_files = _list_remote_php_files(ssh_conn, source_path, limit=PHP_FILE_LIMIT)
            if not php_files:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"No PHP files found in {source_path}",
                )
            _download_php_files_to_local(ssh_conn, php_files, source_path, local_project_path)
            logger.info("Code modernization (SonarQube fixes): PHP=%s src=%s", to_version, source_path)
            sonar_agent = PHPModernizationAgent()
            if sonar_agent.load_reports(request.project_name, sonarqube_report_path=sonarqube_report_path):
                sonar_agent.analyze_structure(str(local_project_path))

                # Wire checkpoint/resume + progress events to Mongo so the frontend
                # can show live counters and so this job can be resumed after a crash.
                completed_set = _load_completed_files(job_id)
                if completed_set:
                    logger.info(
                        "Resuming job %s: %d files already completed in prior run will be skipped",
                        job_id, len(completed_set),
                    )

                _progress_start_time = time.time()

                def _progress_cb(i: int, total: int, rel_path: str, status_event: str) -> None:
                    # Update running counters. 'start' events set current_file; 'done'
                    # events increment files_processed. NOTE: completed_file is written
                    # only AFTER the SSH upload succeeds (see loop below), so a crash
                    # between modernization and upload does not falsely mark files
                    # completed for resume purposes.
                    kw: Dict[str, Any] = {"files_total": total}
                    if status_event == "start":
                        kw["current_file"] = rel_path
                    elif status_event == "done":
                        kw["files_processed_delta"] = 1
                        # Rolling ETA based on wall-clock progress
                        elapsed = max(1.0, time.time() - _progress_start_time)
                        avg = elapsed / max(1, i)
                        remaining = max(0, total - i)
                        kw["eta_seconds"] = int(avg * remaining)
                    elif status_event == "skipped_resume":
                        # count toward processed so UI reflects total progress
                        kw["files_processed_delta"] = 1
                    elif status_event.startswith("error"):
                        err_msg = status_event[len("error:"):].strip() or "unknown"
                        kw["failed_file"] = (rel_path, err_msg)
                        kw["files_failed_delta"] = 1
                    _record_job_progress(job_id, **kw)

                results = sonar_agent.modernize_project(
                    str(local_project_path),
                    to_version,
                    on_progress=_progress_cb,
                    already_completed=completed_set,
                )
                stats = results.get("stats", stats)
                files = results.get("files", [])
                ssh_conn.execute_command(f"mkdir -p '{remote_output_base}'")
                for file_info in files:
                    remote_output_file = f"{remote_output_base}/{file_info['path']}"
                    ssh_conn.execute_command(f"mkdir -p '{str(Path(remote_output_file).parent)}'")
                    # Write with .bak backup so originals are preserved on the remote server
                    ok = ssh_conn.write_file(remote_output_file, file_info["code"], backup=True)
                    if ok:
                        sonarqube_fixes_applied += 1
                        sonarqube_bak_count += 1
                        # Only NOW mark the file completed for resume purposes —
                        # modernization + upload both succeeded.
                        _record_job_progress(job_id, completed_file=file_info["path"])
                    else:
                        sonarqube_fixes_failed += 1
            else:
                logger.warning("SonarQube guide could not be loaded — skipping SonarQube fix pass.")
        step_timings["code_modernization"] = time.perf_counter() - t0
        if on_step_completed:
            on_step_completed("code_modernization", step_timings["code_modernization"])
        steps_completed.append("code_modernization")

        # ── Completion gate: block migration if BLOCKER/CRITICAL issues remain unfixed ──
        unresolved_blockers = _count_unresolved_high_severity_issues(
            sonarqube_report_path, sonarqube_fixes_applied
        )
        if unresolved_blockers > 0:
            logger.error(
                "Pipeline halted: %d BLOCKER/CRITICAL SonarQube issue(s) remain unresolved. "
                "Fix them before re-running migration.",
                unresolved_blockers,
            )
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=(
                    f"{unresolved_blockers} BLOCKER or CRITICAL SonarQube issue(s) could not be "
                    "auto-fixed. Resolve them manually and re-run the pipeline."
                ),
            )

        _sync_update_job_result(job_id, {
            "success": True,
            "project_name": request.project_name,
            "source_path": source_path,
            "output_path": remote_output_base,
            "server_hostname": user.ssh_hostname,
            "project_structure": project_structure or "",
            "from_version": from_version or "",
            "to_version": to_version,
            "from_laravel": from_laravel,
            "to_laravel": to_laravel,
            "steps_completed": list(steps_completed),
            "sonarqube_report_path": sonarqube_report_path,
            "php_upgrade_guide_path": php_upgrade_guide_path,
            "laravel_upgrade_guide_path": laravel_upgrade_guide_path,
            "sonarqube_report_content": upgrade_contents["sonarqube_report_content"],
            "php_upgrade_guide_content": upgrade_contents["php_upgrade_guide_content"],
            "laravel_upgrade_guide_content": upgrade_contents["laravel_upgrade_guide_content"],
            "total_files": stats.get("total", 0),
            "files_upgraded": sonarqube_fixes_applied,
            "files_unchanged": stats.get("unchanged", 0),
            "files_with_errors": sonarqube_fixes_failed,
            "message": (
                f"SonarQube fixes applied: {sonarqube_fixes_applied} files fixed, "
                f"{sonarqube_bak_count} .bak backups created. "
                "Starting version migration."
            ),
            "timestamp": datetime.utcnow(),
        })
        logger.info(
            "SonarQube fix pass done: PHP %s → %s, fixes=%d baks=%d failed=%d. "
            "Proceeding to version migration.",
            from_version, to_version,
            sonarqube_fixes_applied, sonarqube_bak_count, sonarqube_fixes_failed,
        )

        # ── STEP 5: Version migration (staged, AFTER SonarQube fixes confirmed) ──
        migrated_output_base = f"{_client_ssh_home(user)}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}"
        if on_step_started:
            on_step_started("new_version_upgradation")
        t0_staged = time.perf_counter()
        # Migration source is the SonarQube-fixed output, not the raw source
        migration_source = remote_output_base if sonarqube_fixes_applied > 0 else source_path
        staged_request = StagedModernizationRequest(
            ssh_credentials=SSHCredentials(
                hostname=user.ssh_hostname or "",
                port=user.ssh_port or 22,
                username=user.ssh_username or "",
                password=password,
                private_key=private_key,
                private_key_password=private_key_password,
            ),
            source_path=migration_source,
            output_path=migrated_output_base,
            project_name=request.project_name,
            from_version=from_version or "5.6",
            to_version=to_version,
            docs_txt_root=None,
            max_chars_per_stage=None,
            laravel_upgrade_guide_path=None,
            from_laravel=from_laravel,
            to_laravel=to_laravel,
            laravel_documentation_path=None,  # RAG handles Laravel docs per-stage
        )
        def _emit_stage_progress(_stage, _idx: int, _total: int) -> None:
            try:
                _record_job_progress(
                    job_id,
                    current_stage_index=_idx,
                    total_stages=_total,
                    current_stage_from=getattr(_stage, "from_version", None),
                    current_stage_to=getattr(_stage, "to_version", None),
                )
            except Exception:
                pass
        staged_result = _run_staged_modernization_api_sync(
            user, staged_request, on_stage_started=_emit_stage_progress,
        )
        step_timings["new_version_upgradation"] = time.perf_counter() - t0_staged
        if on_step_completed:
            on_step_completed("new_version_upgradation", step_timings["new_version_upgradation"])
        steps_completed.append("new_version_upgradation")

        # ── STEP 6: Final validation pass on complete migrated codebase ──
        final_validation = _run_final_validation(ssh_conn, migrated_output_base, request.project_name)

        # ── Final combined report ──
        migration_stages = []
        migration_files_upgraded = 0
        migration_files_errors = 0
        if isinstance(staged_result, dict):
            for s in staged_result.get("stages", []):
                st = s.get("stage", {})
                migration_stages.append(
                    f"PHP {st.get('from_version')}→{st.get('to_version')}: "
                    f"upgraded={s.get('stats', {}).get('upgraded', 0)} "
                    f"errors={s.get('stats', {}).get('errors', 0)} "
                    f"tests={'passed' if s.get('test_results', {}).get('passed') else 'failed'}"
                )
                migration_files_upgraded += s.get("stats", {}).get("upgraded", 0)
                migration_files_errors += s.get("stats", {}).get("errors", 0)

        final_message = (
            f"Pipeline complete. "
            f"SonarQube: {sonarqube_fixes_applied} files fixed, {sonarqube_bak_count} .bak backups on remote. "
            f"Migration: {len(migration_stages)} stage(s), {migration_files_upgraded} files upgraded, "
            f"{migration_files_errors} errors. "
            f"Final validation: {'PASSED' if final_validation.get('passed') else 'FAILED — ' + str(final_validation.get('errors', [])[:3])}. "
            f"Output: {migrated_output_base}"
        )
        logger.info(final_message)

        response = RunModernizationResponse(
            success=True,
            project_name=request.project_name,
            source_path=source_path,
            output_path=migrated_output_base,
            server_hostname=user.ssh_hostname,
            from_version=from_version,
            to_version=to_version,
            from_laravel=from_laravel,
            to_laravel=to_laravel,
            steps_completed=steps_completed,
            total_files=stats.get("total", 0),
            files_upgraded=sonarqube_fixes_applied + migration_files_upgraded,
            files_unchanged=stats.get("unchanged", 0),
            files_with_errors=sonarqube_fixes_failed + migration_files_errors,
            message=final_message,
            timestamp=datetime.now(),
            project_structure=project_structure,
            sonarqube_report_path=sonarqube_report_path,
            php_upgrade_guide_path=php_upgrade_guide_path,
            laravel_upgrade_guide_path=laravel_upgrade_guide_path,
        )
        _sync_update_job_result(job_id, response.model_dump() if hasattr(response, "model_dump") else response.dict())
        return (response, step_timings)
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


async def _update_job_step(job_id: str, step: str) -> None:
    """Update job current_task and tasks_completed in DB."""
    job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
    if job:
        job.current_task = step
        if step not in job.tasks_completed:
            job.tasks_completed.append(step)
        job.updated_at = datetime.utcnow()
        await job.save()


# Map step name to DB field for atomic duration updates (avoids read-modify-write race)
_STEP_DURATION_FIELDS = {
    "structure_analysis": "structure_analysis_duration_sec",
    "language_analysis": "language_analysis_duration_sec",
    "upgrade_analysis": "upgrade_analysis_duration_sec",
    "code_modernization": "code_modernization_duration_sec",
    "staged_modernization": "staged_modernization_duration_sec",
    "new_version_upgradation": "staged_modernization_duration_sec",
}


def _sync_update_job_step_duration(job_id: str, step: str, duration_sec: float) -> None:
    """Update job step duration from pipeline thread using the shared pooled MongoClient."""
    field = _STEP_DURATION_FIELDS.get(step)
    if not field or not settings.MONGO_DB_URL:
        return
    for attempt in range(3):
        try:
            db = _get_sync_mongo_db()
            db.modernization_jobs.update_one(
                {"job_id": job_id},
                {"$set": {field: duration_sec, "updated_at": datetime.utcnow()}},
            )
            return
        except Exception as e:
            if attempt == 2:
                logger.warning("Failed to persist step duration %s after 3 attempts: %s", step, e)
            else:
                time.sleep(0.5)


def _sync_update_job_result(job_id: str, result_dict: Dict[str, Any]) -> None:
    """Update job result from pipeline thread using the shared pooled MongoClient."""
    if not settings.MONGO_DB_URL:
        return
    # Serialize datetime values for JSON storage
    payload = {}
    for k, v in result_dict.items():
        if isinstance(v, datetime):
            payload[k] = v.isoformat()
        else:
            payload[k] = v
    for attempt in range(3):
        try:
            db = _get_sync_mongo_db()
            db.modernization_jobs.update_one(
                {"job_id": job_id},
                {"$set": {"result": payload, "updated_at": datetime.utcnow()}},
            )
            return
        except Exception as e:
            if attempt == 2:
                logger.warning("Failed to persist job result after 3 attempts: %s", e)
            else:
                time.sleep(0.5)


def _run_structure_language_only(
    user: User,
    source_path: str,
    project_name: str,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]],
    on_step_completed: Optional[Callable[[str, float], None]],
) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str], Dict[str, float], str]:
    """Run structure + language analysis.
    Returns (project_structure, from_version, from_laravel, to_laravel, step_timings, primary_language).
    primary_language is e.g. 'php', 'python', 'java' — used to pick target version defaults.
    """
    step_timings: Dict[str, float] = {}
    password = decrypt_data(user.ssh_password_encrypted) if user.ssh_password_encrypted else None
    private_key = decrypt_data(user.ssh_private_key_encrypted) if user.ssh_private_key_encrypted else None
    private_key_password = decrypt_data(user.ssh_private_key_password_encrypted) if user.ssh_private_key_password_encrypted else None
    ssh_conn = SSHService.create_connection(
        hostname=user.ssh_hostname,
        port=user.ssh_port or 22,
        username=user.ssh_username,
        password=password,
        private_key=private_key,
        private_key_password=private_key_password,
    )
    if not ssh_conn.connect():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Failed to connect to SSH server {user.ssh_hostname}:{user.ssh_port}.")
    result = ssh_conn.execute_command(f"test -d {source_path} && echo 'exists' || echo 'not_found'")
    if not result.get("success") or result.get("stdout", "").strip() != "exists":
        ssh_conn.disconnect()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Source path does not exist on client server: {source_path}")
    project_structure: Optional[str] = None
    from_version: Optional[str] = None
    from_laravel: Optional[str] = None
    to_laravel: Optional[str] = None
    try:
        if on_step_started:
            on_step_started("structure_analysis")
        t0 = time.perf_counter()
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            # Structure analysis only needs the file tree (no content) — list ALL files
            # but exclude vendor/node_modules to keep the tree manageable.
            result = ssh_conn.execute_command(
                f"find '{source_path}' -type f "
                f"-not -path '*/vendor/*' -not -path '*/node_modules/*' "
                f"-not -path '*/.git/*'",
                timeout=ssh_conn.CMD_TIMEOUT_LONG,
            )
            file_list = result.get("stdout", "").strip().split("\n") if result.get("success") else []
            for file_path in file_list:
                if file_path.strip():
                    rel_path = file_path.replace(source_path, "").lstrip("/")
                    if rel_path:
                        (temp_path / rel_path).parent.mkdir(parents=True, exist_ok=True)
                        (temp_path / rel_path).touch()
            agent = StructureTreeAnalyzer()
            run_result = agent.run(project_path=str(temp_path), project_name=project_name)
            if not run_result["success"]:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=run_result.get("error", "Structure analysis failed"))
            project_structure = run_result.get("results", {}).get("structure_tree") or ""
        step_timings["structure_analysis"] = time.perf_counter() - t0
        if on_step_completed:
            on_step_completed("structure_analysis", step_timings["structure_analysis"])
        if on_step_started:
            on_step_started("language_analysis")
        t0 = time.perf_counter()
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir) / "project"
            temp_path.mkdir(exist_ok=True)
            for pattern in ["composer.json", "package.json", "*.php", "*.py", "*.js", "*.json", "*.xml"]:
                result = ssh_conn.execute_command(f"find {source_path} -name '{pattern}' -type f | head -20")
                if result.get("success") and result.get("stdout", "").strip():
                    for remote_file in result["stdout"].strip().split("\n")[:5]:
                        if remote_file.strip():
                            rel_path = remote_file.replace(source_path, "").lstrip("/")
                            local_file = temp_path / rel_path
                            local_file.parent.mkdir(parents=True, exist_ok=True)
                            content_result = ssh_conn.execute_command(f"cat '{remote_file}'")
                            if content_result.get("success"):
                                local_file.write_text(content_result.get("stdout", ""), encoding="utf-8", errors="ignore")
            # Pass no fixed target version — let the LLM detect from evidence only.
            # to_laravel is derived later from the request's to_version once we know it.
            agent = FrameworkLanguageAnalyzer()
            run_result = agent.run(project_path=str(temp_path), project_name=project_name)
            if not run_result["success"]:
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=run_result.get("error", "Language analysis failed"))
            lang_results = run_result.get("results", {}) or {}
            language_versions = lang_results.get("language_versions", {}) or {}
            frameworks = lang_results.get("frameworks", []) or []
            detected_languages = lang_results.get("detected_languages", []) or []

            # Detect primary language (first non-framework entry) and its current version
            _LANG_PRIORITY = ["php", "python", "javascript", "typescript", "java", "kotlin",
                               "go", "ruby", "rust", "csharp", "cpp", "c"]
            detected_primary_lang: Optional[str] = None
            for lang_key in _LANG_PRIORITY:
                for lv_key, lv_ver in language_versions.items():
                    if lang_key in str(lv_key).lower() and lv_ver and lv_ver not in ("unknown", ""):
                        if detected_primary_lang is None:
                            detected_primary_lang = lang_key
                        if "php" in lang_key:
                            from_version = str(lv_ver).strip()
                        break
                if detected_primary_lang:
                    break

            # Fallback: check languages list for primary language
            if not detected_primary_lang:
                for lang_name in (detected_languages or []):
                    ln = str(lang_name).lower()
                    for lk in _LANG_PRIORITY:
                        if lk in ln:
                            detected_primary_lang = lk
                            break
                    if detected_primary_lang:
                        break

            from_laravel = _laravel_core_version_from_language_versions(language_versions)
            if not from_laravel and any("laravel" in str(f).lower() for f in frameworks):
                for candidate in ("laravel/framework", "illuminate/support", "Laravel", "laravel"):
                    vv = language_versions.get(candidate)
                    if vv:
                        from_laravel = str(vv).strip()
                        break
            to_laravel = _to_laravel_from_language_versions(language_versions)
        step_timings["language_analysis"] = time.perf_counter() - t0
        if on_step_completed:
            on_step_completed("language_analysis", step_timings["language_analysis"])
        return (
            project_structure,
            from_version or "5.6",
            from_laravel,
            to_laravel,
            step_timings,
            detected_primary_lang or "php",
        )
    finally:
        ssh_conn.disconnect()


def _run_structure_language_pipeline_sync(
    user: User,
    request: RunStructureLanguageRequest,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]] = None,
    on_step_completed: Optional[Callable[[str, float], None]] = None,
    transform_id: Optional[str] = None,
) -> Tuple[Dict[str, Any], Dict[str, float]]:
    """Run structure + language, then automatic new version upgradation (single API orchestration)."""
    # Prefer source_path stored in UserProject (set at project creation).
    # Fallback order: vm_code_path → ssh_source_path (direct, no appending) → heuristic.
    _project_source_path = None
    try:
        _db = _get_sync_mongo_db()
        _doc = _db["user_projects"].find_one(
            {"user_id": str(user.id), "project_name": request.project_name},
            {"vm_code_path": 1},
        )
        if _doc and (_doc.get("vm_code_path") or "").strip():
            _project_source_path = _doc["vm_code_path"].strip()
    except Exception as _e:
        logger.warning("Step 1: could not look up UserProject.vm_code_path: %s", _e)
    if _project_source_path:
        source_path = _project_source_path
        logger.info("Step 1: using UserProject.vm_code_path=%s for project '%s'", source_path, request.project_name)
    elif (user.ssh_source_path or "").strip():
        # ssh_source_path is the path the user typed when setting up SSH — use it directly.
        source_path = user.ssh_source_path.strip().rstrip("/")
        logger.info("Step 1: vm_code_path missing; falling back to ssh_source_path=%s for project '%s'", source_path, request.project_name)
    else:
        source_path = _resolve_project_source_path(user, request.project_name)
    migrated_output_base = f"{_client_ssh_home(user)}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}"
    project_structure, from_version, from_laravel, to_laravel, step_timings, primary_lang = (
        _run_structure_language_only(
            user, source_path, request.project_name, job_id, on_step_started, on_step_completed
        )
    )

    # Determine effective target version:
    # 1. Explicit request.to_version (user supplied)
    # 2. Latest known stable for detected language (fallback)
    effective_to_version = (request.to_version or "").strip() or _latest_stable_version(primary_lang)

    result = {
        "success": True,
        "project_name": request.project_name,
        "source_path": source_path,
        "server_hostname": user.ssh_hostname,
        "project_structure": project_structure or "",
        "from_version": from_version or "unknown",
        "to_version": effective_to_version,
        "language": primary_lang,
        "from_laravel": from_laravel,
        "to_laravel": to_laravel,
        "message": "Structure and language analysis completed.",
        "timestamp": datetime.utcnow(),
    }
    _sync_update_job_result(job_id, result)

    # Auto-run the new staged version upgradation agent using detected versions.
    if on_step_started:
        on_step_started("new_version_upgradation")
    t0 = time.perf_counter()
    password = decrypt_data(user.ssh_password_encrypted) if user.ssh_password_encrypted else None
    private_key = decrypt_data(user.ssh_private_key_encrypted) if user.ssh_private_key_encrypted else None
    private_key_password = (
        decrypt_data(user.ssh_private_key_password_encrypted)
        if user.ssh_private_key_password_encrypted
        else None
    )
    staged_request = StagedModernizationRequest(
        ssh_credentials=SSHCredentials(
            hostname=user.ssh_hostname or "",
            port=user.ssh_port or 22,
            username=user.ssh_username or "",
            password=password,
            private_key=private_key,
            private_key_password=private_key_password,
        ),
        source_path=source_path,
        output_path=migrated_output_base,
        project_name=request.project_name,
        from_version=from_version or "unknown",
        to_version=effective_to_version,
        docs_txt_root=None,
        max_chars_per_stage=None,
        laravel_upgrade_guide_path=None,
        from_laravel=from_laravel,
        to_laravel=to_laravel,
        laravel_documentation_path=None,  # RAG handles docs per-stage
    )
    staged_result = _run_staged_modernization_api_sync(user, staged_request)
    step_timings["new_version_upgradation"] = time.perf_counter() - t0
    if on_step_completed:
        on_step_completed("new_version_upgradation", step_timings["new_version_upgradation"])

    result["new_version_upgradation"] = staged_result
    result["message"] = "Structure + language completed, and new version upgradation completed automatically."
    result["timestamp"] = datetime.utcnow()
    if transform_id:
        result["transform_id"] = transform_id
    return (result, step_timings)


def _run_upgrade_analysis_pipeline_sync(
    user: User,
    request: RunUpgradeAnalysisRequest,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]] = None,
    on_step_completed: Optional[Callable[[str, float], None]] = None,
    from_version: Optional[str] = None,
    from_laravel: Optional[str] = None,
    to_laravel: Optional[str] = None,
) -> Tuple[Dict[str, Any], Dict[str, float]]:
    """Run upgrade analysis only. With step 1 context (from_version/from_laravel/to_laravel), skips structure+language. Otherwise runs structure+language first. Target Laravel (to_laravel) always comes from the language agent output, not from Sonar upgrade analysis."""
    original_project_path = _resolve_project_source_path(user, request.project_name)
    step_timings: Dict[str, float] = {}
    primary_lang = "php"
    # When from_version from step 1 is provided, skip structure+language and run only upgrade analysis
    if from_version is None:
        _, from_version_resolved, from_laravel_resolved, to_laravel_resolved, lang_timings, primary_lang = (
            _run_structure_language_only(
                user,
                original_project_path,
                request.project_name,
                job_id,
                on_step_started,
                on_step_completed,
            )
        )
        from_version = from_version_resolved
        from_laravel = from_laravel if from_laravel is not None else from_laravel_resolved
        to_laravel = to_laravel_resolved
        step_timings.update(lang_timings)
    to_version = _latest_stable_version(primary_lang)
    pwd = decrypt_data(user.ssh_password_encrypted) if user.ssh_password_encrypted else None
    pk = decrypt_data(user.ssh_private_key_encrypted) if user.ssh_private_key_encrypted else None
    pk_pw = (
        decrypt_data(user.ssh_private_key_password_encrypted)
        if user.ssh_private_key_password_encrypted
        else None
    )
    mig_out = f"{_client_ssh_home(user)}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}"
    if on_step_started:
        on_step_started("new_version_upgradation")
    t0_stg = time.perf_counter()

    # Skip the staged migration if Step 1 already produced all stages on the VM.
    # Without this guard, re-running Step 2 (or running it after a frontend logout
    # that paused the auto-progression) would redo every PHP version hop a second
    # time — wasting hours of LLM work. We probe for the final stage folder; if
    # it exists, Step 1's output is already in place and we proceed directly to
    # the SonarQube scan / upgrade-guide generation.
    final_stage_token = _target_stage_token(to_version, language=primary_lang)
    final_stage_present = False
    if final_stage_token and user.ssh_hostname and user.ssh_username:
        try:
            home_for_check = _client_ssh_home(user)
            project_folder = (request.project_name or "").strip().lower().replace(" ", "-")
            check_parent = f"{home_for_check}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}/{project_folder}"
            _ssh_probe = SSHService.create_connection(
                hostname=user.ssh_hostname,
                port=user.ssh_port or 22,
                username=user.ssh_username,
                password=pwd,
                private_key=pk,
                private_key_password=pk_pw,
            )
            if _ssh_probe.connect():
                try:
                    res = _ssh_probe.execute_command(f"ls -1 '{check_parent}' 2>/dev/null || true")
                    names = [ln.strip() for ln in (res.get("stdout") or "").splitlines() if ln.strip()]
                    final_stage_present = any(n.endswith(f"_{final_stage_token}") for n in names)
                finally:
                    _ssh_probe.disconnect()
        except Exception as _probe_err:
            logger.debug("Stage-presence probe failed for %s: %s", request.project_name, _probe_err)

    if final_stage_present:
        logger.info(
            "_run_upgrade_analysis_pipeline_sync: skipping staged migration — final stage_*_%s "
            "already exists on VM for project %s (Step 1 output preserved).",
            final_stage_token, request.project_name,
        )
    else:
        st_req = StagedModernizationRequest(
            ssh_credentials=SSHCredentials(
                hostname=user.ssh_hostname or "",
                port=user.ssh_port or 22,
                username=user.ssh_username or "",
                password=pwd,
                private_key=pk,
                private_key_password=pk_pw,
            ),
            source_path=original_project_path,
            output_path=mig_out,
            project_name=request.project_name,
            from_version=from_version or "5.6",
            to_version=to_version,
            docs_txt_root=None,
            max_chars_per_stage=None,
            laravel_upgrade_guide_path=None,
            from_laravel=from_laravel,
            to_laravel=to_laravel,
            laravel_documentation_path=None,  # RAG handles Laravel docs per-stage
        )
        def _emit_stage_progress_st(_stage, _idx: int, _total: int) -> None:
            try:
                _record_job_progress(
                    job_id,
                    current_stage_index=_idx,
                    total_stages=_total,
                    current_stage_from=getattr(_stage, "from_version", None),
                    current_stage_to=getattr(_stage, "to_version", None),
                )
            except Exception:
                pass
        _run_staged_modernization_api_sync(user, st_req, on_stage_started=_emit_stage_progress_st)

    step_timings["new_version_upgradation"] = time.perf_counter() - t0_stg
    if on_step_completed:
        on_step_completed("new_version_upgradation", step_timings["new_version_upgradation"])
    if on_step_started:
        on_step_started("upgrade_analysis")
    t0 = time.perf_counter()
    upgrade_ssh, upgrade_ssh_src = _upgrade_analysis_ssh_from_user(user)
    if not upgrade_ssh:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="SSH is not configured on your account. Run /api/v1/analyze/test/ssh to save host, user, and source path before upgrade analysis.",
        )
    upgrade_agent = PHPUpgradeAnalyzer()
    user_input_val = getattr(request, "user_input", None)
    if isinstance(user_input_val, str) and not user_input_val.strip():
        user_input_val = None
    migrated_src = _resolve_migrated_stage_source_path(user, request.project_name, to_version)
    sonarqube_report_path, php_upgrade_guide_path, _, laravel_upgrade_guide_path = (
        upgrade_agent.run_full_upgrade_analysis(
            project_name=request.project_name,
            from_version=from_version or "5.6",
            to_version=to_version,
            reports_dir=REPORTS_DIR,
            user_input=user_input_val,
            ssh_credentials=upgrade_ssh,
            ssh_source_path=upgrade_ssh_src,
        )
    )
    step_timings["upgrade_analysis"] = time.perf_counter() - t0
    if on_step_completed:
        on_step_completed("upgrade_analysis", step_timings["upgrade_analysis"])
    if not sonarqube_report_path or not Path(sonarqube_report_path).exists():
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Upgrade analysis failed: SonarQube report could not be downloaded or generated.")
    contents = _read_upgrade_report_contents(
        sonarqube_report_path, php_upgrade_guide_path, laravel_upgrade_guide_path
    )
    result = {
        "success": True,
        "project_name": request.project_name,
        "source_path": migrated_src,
        "original_project_path": original_project_path,
        "server_hostname": user.ssh_hostname,
        "from_version": from_version or "5.6",
        "to_version": to_version,
        "from_laravel": from_laravel,
        "to_laravel": to_laravel,
        "user_input": request.user_input,
        "sonarqube_report_path": sonarqube_report_path,
        "php_upgrade_guide_path": php_upgrade_guide_path,
        "laravel_upgrade_guide_path": laravel_upgrade_guide_path,
        "sonarqube_report_content": contents["sonarqube_report_content"],
        "php_upgrade_guide_content": contents["php_upgrade_guide_content"],
        "laravel_upgrade_guide_content": contents["laravel_upgrade_guide_content"],
        "message": "Upgrade analysis completed.",
        "timestamp": datetime.utcnow(),
    }
    if getattr(request, "transform_id", None):
        result["transform_id"] = request.transform_id
    return (result, step_timings)


def _run_code_modernization_pipeline_sync(
    user: User,
    request: RunCodeModernizationRequest,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]] = None,
    on_step_completed: Optional[Callable[[str, float], None]] = None,
    to_version: Optional[str] = None,
) -> Tuple[Dict[str, Any], Dict[str, float]]:
    """Run code modernization only. Input from migrated-codes stage for ``tv``;
    output under ``upgraded-codes/{project}/``. Language-aware: PHP runs through
    PHPModernizationAgent (SonarQube-guide-tuned); everything else runs through
    GenericModernizationAgent (tree-sitter + generic prompt + RAG context)."""
    language = (getattr(request, "language", None) or "php").strip().lower()
    tv = (to_version or "").strip() or _latest_stable_version(language)
    output_path = _remote_upgraded_codes_project_base(user, request.project_name)

    # SonarQube guide is PHP-specific. Load it only when we're actually running PHP.
    sonarqube_report_path = None
    if language == "php":
        candidates = sorted(
            UPGRADE_GUIDE_DIR.glob(f"{request.project_name}_sonarqube_analysis_*.txt"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if candidates:
            sonarqube_report_path = str(candidates[0])

    mod_src = _code_modernization_remote_source(user, request.project_name, tv, language=language)
    logger.info(
        "Code modernization pipeline: project=%s job_id=%s language=%s target=%s remote_source=%s sonarqube_guide=%s",
        request.project_name, job_id, language, tv, mod_src,
        sonarqube_report_path or "(n/a)",
    )
    password = decrypt_data(user.ssh_password_encrypted) if user.ssh_password_encrypted else None
    private_key = decrypt_data(user.ssh_private_key_encrypted) if user.ssh_private_key_encrypted else None
    private_key_password = decrypt_data(user.ssh_private_key_password_encrypted) if user.ssh_private_key_password_encrypted else None
    ssh_conn = SSHService.create_connection(
        hostname=user.ssh_hostname,
        port=user.ssh_port or 22,
        username=user.ssh_username,
        password=password,
        private_key=private_key,
        private_key_password=private_key_password,
    )
    if not ssh_conn.connect():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Failed to connect to SSH server {user.ssh_hostname}:{user.ssh_port}.")
    if on_step_started:
        on_step_started("code_modernization")
    t0 = time.perf_counter()
    stats = {"total": 0, "upgraded": 0, "unchanged": 0, "errors": 0}
    try:
        unique_suffix = datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid.uuid4().hex[:6]
        output_folder_name = f"upgraded_{request.project_name}_{unique_suffix}"
        remote_output_base = f"{output_path}/{output_folder_name}"
        with tempfile.TemporaryDirectory() as temp_dir:
            local_project_path = Path(temp_dir) / request.project_name
            local_project_path.mkdir(parents=True, exist_ok=True)

            # Enumerate source files for the *requested* language (not always PHP)
            lang_files = _list_remote_source_files(ssh_conn, mod_src, language=language, limit=PHP_FILE_LIMIT)
            if not lang_files:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"No {language} files found in {mod_src}",
                )
            _download_source_files_to_local(ssh_conn, lang_files, mod_src, local_project_path, language=language)

            # Build the right agent for this language
            agent = _build_modernization_agent(language)

            # PHPModernizationAgent needs extra context (SonarQube guide + structure analysis)
            if language == "php":
                if not agent.load_reports(request.project_name, sonarqube_report_path=sonarqube_report_path):
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail="Failed to load SonarQube upgrade guide.",
                    )
                agent.analyze_structure(str(local_project_path))
            else:
                # GenericModernizationAgent: pull migration rules via RAG. If Step 1
                # detected a framework (e.g. "React", "Django"), pass it through so
                # RAG fetches framework-specific migration docs rather than just the
                # base-language docs.
                from_v = getattr(request, "from_version", None) or ""
                framework = getattr(request, "framework", None)
                agent.load_migration_context(
                    from_version=from_v,
                    to_version=tv,
                    framework=framework,
                )

            results = agent.modernize_project(str(local_project_path), tv)
            stats = results.get("stats", stats)
            files = results.get("files", [])
            # Manifest version-constraint update BEFORE upload so the upgraded tree's
            # composer.json / .csproj / package.json / pyproject.toml matches the target
            # runtime. Otherwise `composer install` / `dotnet restore` on the upgraded code
            # fails because the manifest still points at the old version.
            manifest_changes: List[Tuple[str, str, str]] = []
            try:
                from app.services.agents.manifest_updater import update_project_manifests
                manifest_changes = update_project_manifests(
                    project_root=Path(local_project_path),
                    language=language,
                    to_version=tv,
                )
                if manifest_changes:
                    logger.info(
                        "manifest_updater: patched %d manifest(s) for %s %s",
                        len(manifest_changes), language, tv,
                    )
                    # Re-scan: any modified manifest file should be re-added to the upload set.
                    manifest_paths = {str(Path(c[0]).resolve()) for c in manifest_changes}
                    proj_root = Path(local_project_path).resolve()
                    for mpath in manifest_paths:
                        try:
                            rel = str(Path(mpath).resolve().relative_to(proj_root))
                        except Exception:
                            continue
                        # Replace any existing entry for this relative path, or append.
                        new_code = Path(mpath).read_text(encoding="utf-8", errors="replace")
                        replaced = False
                        for f in files:
                            if f.get("path") == rel:
                                f["code"] = new_code
                                replaced = True
                                break
                        if not replaced:
                            files.append({"path": rel, "code": new_code, "changes": ["manifest-version-update"]})
            except Exception as e:
                logger.warning("manifest update skipped for job=%s: %s", job_id, e)

            ssh_conn.execute_command(f"mkdir -p '{remote_output_base}'")
            for file_info in files:
                remote_output_file = f"{remote_output_base}/{file_info['path']}"
                ssh_conn.execute_command(f"mkdir -p '{str(Path(remote_output_file).parent)}'")
                ssh_conn.execute_command(f"cat > '{remote_output_file}' << 'EOFPHP'\n{file_info['code']}\nEOFPHP")

            # Persist migration-state snapshot FIRST so it survives even if the
            # validation pass below fails or times out.
            try:
                mig_state = getattr(agent, "migration_state", None)
                if mig_state is not None:
                    snap = mig_state.snapshot()
                    _db_pre = _get_sync_mongo_db()
                    _db_pre.modernization_jobs.update_one(
                        {"job_id": job_id},
                        {"$set": {"migration_state_snapshot": snap, "updated_at": datetime.utcnow()}},
                    )
            except Exception as e:
                logger.debug("Migration-state snapshot persist skipped for job=%s: %s", job_id, e)

            # Token-usage snapshot — attribute this job's share of the shared GroqClient's
            # cumulative counters to the ModernizationJob. Ops can use this to attribute
            # cost per project, detect runaway token spend, or bill per migration.
            try:
                shared = _get_shared_groq_client()
                usage = shared.snapshot_token_usage() if hasattr(shared, "snapshot_token_usage") else None
                if usage:
                    _db_tok = _get_sync_mongo_db()
                    _db_tok.modernization_jobs.update_one(
                        {"job_id": job_id},
                        {"$set": {"token_usage": usage, "updated_at": datetime.utcnow()}},
                    )
            except Exception as e:
                logger.debug("Token-usage snapshot skipped for job=%s: %s", job_id, e)

            # Post-migration validation: tree-sitter parse + native linter over SSH.
            # Never crashes the pipeline — on failure we log and skip so the upgrade
            # result still returns. Report is persisted on ModernizationJob.validation_report.
            validation_dict: Optional[Dict[str, Any]] = None
            try:
                from app.services.validation_pipeline import validate_upgraded_files
                report = validate_upgraded_files(
                    ssh_conn=ssh_conn,
                    remote_output_dir=remote_output_base,
                    upgraded_files=files,
                    language=language,
                )
                validation_dict = report.to_dict(include_per_file=True)
                logger.info(
                    "Validation[%s] job=%s: %s",
                    language, job_id, report.overall_summary,
                )
            except Exception as e:
                logger.warning("Validation pipeline failed for job=%s: %s", job_id, e)

            # Persist validation report on the job doc (separate write so the snapshot
            # above is durable even if this fails).
            if validation_dict is not None:
                try:
                    _db = _get_sync_mongo_db()
                    _db.modernization_jobs.update_one(
                        {"job_id": job_id},
                        {"$set": {"validation_report": validation_dict, "updated_at": datetime.utcnow()}},
                    )
                except Exception as e:
                    logger.debug("Validation report persist skipped for job=%s: %s", job_id, e)
        step_timings = {"code_modernization": time.perf_counter() - t0}
        if on_step_completed:
            on_step_completed("code_modernization", step_timings["code_modernization"])
        result_dict = {
            "success": True,
            "project_name": request.project_name,
            "source_path": mod_src,
            "to_version": tv,
            "language": language,
            "framework": getattr(request, "framework", None),
            "output_path": remote_output_base,
            "server_hostname": user.ssh_hostname,
            "total_files": stats.get("total", 0),
            "files_upgraded": stats.get("upgraded", 0),
            "files_unchanged": stats.get("unchanged", 0),
            "files_with_errors": stats.get("errors", 0),
            # Syntax-validation counters (populated by GenericModernizationAgent;
            # zero for PHPModernizationAgent which doesn't yet validate).
            "validated_clean":     stats.get("validated_clean", 0),
            "validation_retried":  stats.get("validation_retried", 0),
            "validation_failed":   stats.get("validation_failed", 0),
            "validation_summary": (
                {
                    "overall_ok": validation_dict.get("overall_ok"),
                    "overall_summary": validation_dict.get("overall_summary"),
                    "tree_sitter_passed": validation_dict.get("tree_sitter_passed"),
                    "tree_sitter_failed": validation_dict.get("tree_sitter_failed"),
                    "native_passed": validation_dict.get("native_passed"),
                    "native_failed": validation_dict.get("native_failed"),
                    "native_skipped": validation_dict.get("native_skipped"),
                    "native_timed_out": validation_dict.get("native_timed_out"),
                }
                if validation_dict
                else None
            ),
            "message": f"Code modernization completed. Upgraded code saved to {remote_output_base}",
            "timestamp": datetime.utcnow(),
        }
        if getattr(request, "transform_id", None):
            result_dict["transform_id"] = request.transform_id
        return (result_dict, step_timings)
    finally:
        ssh_conn.disconnect()


def _run_structure_language_sync(
    user: User,
    request: RunStructureLanguageRequest,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]] = None,
    on_step_completed: Optional[Callable[[str, float], None]] = None,
    transform_id: Optional[str] = None,
) -> Tuple[Dict[str, Any], Dict[str, float]]:
    _ensure_job_log_handler()
    _thread_local.current_job_id = job_id
    try:
        return _run_structure_language_pipeline_sync(
            user, request, job_id, on_step_started, on_step_completed, transform_id=transform_id
        )
    finally:
        _thread_local.current_job_id = None


def _run_upgrade_analysis_sync(
    user: User,
    request: RunUpgradeAnalysisRequest,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]] = None,
    on_step_completed: Optional[Callable[[str, float], None]] = None,
    from_version: Optional[str] = None,
    from_laravel: Optional[str] = None,
    to_laravel: Optional[str] = None,
) -> Tuple[Dict[str, Any], Dict[str, float]]:
    _ensure_job_log_handler()
    _thread_local.current_job_id = job_id
    try:
        return _run_upgrade_analysis_pipeline_sync(
            user, request, job_id, on_step_started, on_step_completed,
            from_version=from_version, from_laravel=from_laravel, to_laravel=to_laravel,
        )
    finally:
        _thread_local.current_job_id = None


def _run_code_modernization_sync(
    user: User,
    request: RunCodeModernizationRequest,
    job_id: str,
    on_step_started: Optional[Callable[[str], None]] = None,
    on_step_completed: Optional[Callable[[str, float], None]] = None,
    to_version: Optional[str] = None,
) -> Tuple[Dict[str, Any], Dict[str, float]]:
    _ensure_job_log_handler()
    _thread_local.current_job_id = job_id
    try:
        tv_eff = (to_version or "").strip() or _latest_stable_version(getattr(request, "language", None) or "php")
        logger.info(
            "Code modernization sync start: job_id=%s project=%s target_version=%s transform_id=%s",
            job_id,
            request.project_name,
            tv_eff,
            getattr(request, "transform_id", None) or "",
        )
        return _run_code_modernization_pipeline_sync(
            user, request, job_id, on_step_started, on_step_completed, to_version=to_version
        )
    finally:
        _thread_local.current_job_id = None


async def _background_run_structure_language(
    job_id: str, user_id: str, request: RunStructureLanguageRequest, transform_id: Optional[str] = None
) -> None:
    loop = asyncio.get_event_loop()
    # Step 1 walks every file once per version hop (the staged migration). With
    # ~12 PHP version hops on a medium project this is ~10–18 h of real work,
    # well past the 2-h baseline. Use the staged-aware budget so the job has
    # room to finish; explicit MIRA_JOB_TIMEOUT_SECONDS still wins if set higher.
    _job_timeout = _auto_scaled_job_timeout(None, staged=True)
    logger.info(
        "Structure+language job %s: timeout=%ds (staged migration baseline)",
        job_id, _job_timeout,
    )

    def on_step_started(step: str) -> None:
        asyncio.run_coroutine_threadsafe(_update_job_step(job_id, step), loop)

    def on_step_completed(step: str, duration_sec: float) -> None:
        _sync_update_job_step_duration(job_id, step, duration_sec)

    try:
        user = await get_user_by_id(user_id)
        if not user:
            job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
            if job:
                job.status = "failed"
                job.error_message = "User not found"
                job.completed_at = datetime.utcnow()
                job.updated_at = datetime.utcnow()
                await job.save()
            return
        async with _get_pipeline_semaphore():
            result = await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: _run_structure_language_sync(
                        user, request, job_id, on_step_started, on_step_completed, transform_id=transform_id
                    ),
                ),
                timeout=_job_timeout,
            )
        result_dict, step_timings = result
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "completed"
            job.result = result_dict
            job.logs = _trim_job_logs(logs)
            job.structure_analysis_duration_sec = step_timings.get("structure_analysis")
            job.language_analysis_duration_sec = step_timings.get("language_analysis")
            job.staged_modernization_duration_sec = step_timings.get("new_version_upgradation")
            job.source_path = result_dict.get("source_path")
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            job.error_message = None
            await job.save()
    except asyncio.TimeoutError:
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = f"Job timed out after {_job_timeout}s. The project may be too large. Try setting MIRA_SOURCE_FILE_LIMIT to reduce file count, or increase MIRA_JOB_TIMEOUT_SECONDS."
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()
        logger.error("Structure+language job %s timed out after %ds", job_id, _job_timeout)
    except (HTTPException, Exception) as e:
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = e.detail if isinstance(e, HTTPException) else str(e)
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()
        if not isinstance(e, HTTPException):
            logger.exception("Structure+language job %s failed", job_id)


async def _background_run_upgrade_analysis(job_id: str, user_id: str, request: RunUpgradeAnalysisRequest) -> None:
    loop = asyncio.get_event_loop()
    # Auto-scale based on file count from Step-1 — large projects need more headroom for the
    # per-file LLM analysis pass.
    _file_count_hint: Optional[int] = None
    try:
        _tid = getattr(request, "transform_id", None)
        if _tid:
            _tr = await Transform.find_one(Transform.transform_id == _tid)
            if _tr is not None and _tr.step_1_job_id:
                _step1 = await ModernizationJob.find_one(ModernizationJob.job_id == _tr.step_1_job_id)
                if _step1 is not None:
                    _file_count_hint = int(
                        getattr(_step1, "total_files", 0)
                        or getattr(_step1, "files_total", 0)
                        or 0
                    ) or None
    except Exception:
        _file_count_hint = None
    _job_timeout = _auto_scaled_job_timeout(_file_count_hint)

    def on_step_started(step: str) -> None:
        asyncio.run_coroutine_threadsafe(_update_job_step(job_id, step), loop)

    def on_step_completed(step: str, duration_sec: float) -> None:
        _sync_update_job_step_duration(job_id, step, duration_sec)

    try:
        user = await get_user_by_id(user_id)
        if not user:
            job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
            if job:
                job.status = "failed"
                job.error_message = "User not found"
                job.completed_at = datetime.utcnow()
                job.updated_at = datetime.utcnow()
                await job.save()
            return
        # Step 2/3 require step 1 result (from_version, from_laravel). Load from Transform's step_1_job_id so we run only upgrade analysis.
        from_version: Optional[str] = None
        from_laravel: Optional[str] = None
        to_laravel: Optional[str] = None
        transform_id = getattr(request, "transform_id", None)
        if transform_id:
            transform = await Transform.find_one(
                Transform.transform_id == transform_id,
                Transform.user_id == user_id,
            )
            if transform and transform.step_1_job_id:
                step1_job = await ModernizationJob.find_one(ModernizationJob.job_id == transform.step_1_job_id)
                if step1_job and step1_job.status == "completed" and step1_job.result:
                    r = step1_job.result or {}
                    from_version = (r.get("from_version") or "").strip() or None
                    from_laravel = r.get("from_laravel")  # may be None for non-Laravel
                    tv = r.get("to_laravel")
                    to_laravel = str(tv).strip() if tv is not None and str(tv).strip() else None
                if from_version is None and step1_job and step1_job.status != "completed":
                    job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
                    if job:
                        job.status = "failed"
                        job.error_message = "Step 1 (structure + language) is not completed yet. Complete step 1 first, then run this step."
                        job.completed_at = datetime.utcnow()
                        job.updated_at = datetime.utcnow()
                        await job.save()
                    return
                if from_version is None:
                    job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
                    if job:
                        job.status = "failed"
                        job.error_message = "Run step 1 (structure + language) first to get PHP/Laravel versions, then run this step."
                        job.completed_at = datetime.utcnow()
                        job.updated_at = datetime.utcnow()
                        await job.save()
                    return
        async with _get_pipeline_semaphore():
            result = await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: _run_upgrade_analysis_sync(
                        user, request, job_id, on_step_started, on_step_completed,
                        from_version=from_version, from_laravel=from_laravel, to_laravel=to_laravel,
                    ),
                ),
                timeout=_job_timeout,
            )
        result_dict, step_timings = result
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "completed"
            job.result = result_dict
            job.logs = _trim_job_logs(logs)
            job.structure_analysis_duration_sec = step_timings.get("structure_analysis")
            job.language_analysis_duration_sec = step_timings.get("language_analysis")
            job.upgrade_analysis_duration_sec = step_timings.get("upgrade_analysis")
            job.source_path = result_dict.get("source_path")
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            job.error_message = None
            await job.save()
        try:
            to_email = getattr(user, "email", None) or ""
            if to_email and request.project_name:
                user_input_val = getattr(request, "user_input", None) or ""
                if user_input_val and str(user_input_val).strip():
                    await loop.run_in_executor(
                        None,
                        lambda: send_upgrade_analysis_regenerated_complete(
                            to_email, request.project_name, job_id
                        ),
                    )
                else:
                    await loop.run_in_executor(
                        None,
                        lambda: send_upgrade_analysis_complete(
                            to_email, request.project_name, job_id
                        ),
                    )
        except Exception as mail_err:
            logger.warning("Upgrade analysis complete email failed for job %s: %s", job_id, mail_err)
    except asyncio.TimeoutError:
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = f"Job timed out after {_job_timeout}s."
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()
        logger.error("Upgrade analysis job %s timed out after %ds", job_id, _job_timeout)
    except (HTTPException, Exception) as e:
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = e.detail if isinstance(e, HTTPException) else str(e)
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()
        if not isinstance(e, HTTPException):
            logger.exception("Upgrade analysis job %s failed", job_id)


async def _background_run_code_modernization(job_id: str, user_id: str, request: RunCodeModernizationRequest) -> None:
    loop = asyncio.get_event_loop()
    # Auto-scale the job timeout based on the expected file count recorded by Step 1.
    _file_count_hint: Optional[int] = None
    try:
        _tid = getattr(request, "transform_id", None)
        if _tid:
            _tr = await Transform.find_one(Transform.transform_id == _tid)
            if _tr is not None and _tr.step_1_job_id:
                _step1 = await ModernizationJob.find_one(ModernizationJob.job_id == _tr.step_1_job_id)
                if _step1 is not None:
                    _file_count_hint = int(
                        getattr(_step1, "total_files", 0)
                        or getattr(_step1, "files_total", 0)
                        or 0
                    ) or None
    except Exception:
        _file_count_hint = None
    _job_timeout = _auto_scaled_job_timeout(_file_count_hint)
    if _file_count_hint:
        logger.info(
            "Code modernization job %s: auto-scaled timeout to %ds (for %d files)",
            job_id, _job_timeout, _file_count_hint,
        )

    def on_step_started(step: str) -> None:
        asyncio.run_coroutine_threadsafe(_update_job_step(job_id, step), loop)

    def on_step_completed(step: str, duration_sec: float) -> None:
        _sync_update_job_step_duration(job_id, step, duration_sec)

    try:
        user = await get_user_by_id(user_id)
        if not user:
            job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
            if job:
                job.status = "failed"
                job.error_message = "User not found"
                job.completed_at = datetime.utcnow()
                job.updated_at = datetime.utcnow()
                await job.save()
            return
        # Step 4 needs target PHP (to_version) for migrated-codes path and LLM context; take from step 1 job result.
        tv: Optional[str] = None
        transform_id = getattr(request, "transform_id", None)
        if transform_id:
            transform = await Transform.find_one(
                Transform.transform_id == transform_id,
                Transform.user_id == user_id,
            )
            if not transform or not transform.step_1_job_id:
                job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
                if job:
                    job.status = "failed"
                    job.error_message = "Run step 1 (structure + language) first, then run code modernization."
                    job.completed_at = datetime.utcnow()
                    job.updated_at = datetime.utcnow()
                    await job.save()
                return
            step1_job = await ModernizationJob.find_one(ModernizationJob.job_id == transform.step_1_job_id)
            if not step1_job or step1_job.status != "completed":
                job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
                if job:
                    job.status = "failed"
                    job.error_message = "Step 1 (structure + language) is not completed yet. Complete step 1 first, then run this step."
                    job.completed_at = datetime.utcnow()
                    job.updated_at = datetime.utcnow()
                    await job.save()
                return
            r = (step1_job.result or {}) if step1_job else {}
            tv = (r.get("to_version") or "").strip() or None
        _lang_for_tv = (r.get("language") or getattr(request, "language", None) or "php") if "r" in dir() else "php"
        # Precedence for the target version:
        #   1. Per-language target explicitly passed by the user (request.target_version)
        #   2. Step 1's detected to_version (from the transform's step-1 job result)
        #   3. Fallback to latest stable for the language
        explicit_target = (getattr(request, "target_version", None) or "").strip() if getattr(request, "target_version", None) else ""
        resolved_tv = explicit_target or (tv or "").strip() or _latest_stable_version(_lang_for_tv)
        # Stash Step 1's detected framework + from_version on the request so the
        # Generic agent can pass them to the RAG layer for framework-specific
        # migration docs (e.g. React 17 → 18, Django 4 → 5, Laravel 9 → 10).
        step1_r = r if "r" in dir() else {}
        if step1_r.get("framework") and not getattr(request, "framework", None):
            setattr(request, "framework", step1_r.get("framework"))
        if step1_r.get("from_version") and not getattr(request, "from_version", None):
            setattr(request, "from_version", step1_r.get("from_version"))
        async with _get_pipeline_semaphore():
            result = await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda resolved_tv=resolved_tv: _run_code_modernization_sync(
                        user, request, job_id, on_step_started, on_step_completed, to_version=resolved_tv
                    ),
                ),
                timeout=_job_timeout,
            )
        result_dict, step_timings = result
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "completed"
            job.result = result_dict
            job.logs = _trim_job_logs(logs)
            job.output_path = result_dict.get("output_path")
            job.source_path = result_dict.get("source_path")
            job.code_modernization_duration_sec = step_timings.get("code_modernization")
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            job.error_message = None
            await job.save()
        try:
            to_email = getattr(user, "email", None) or ""
            if to_email and request.project_name:
                output_path = result_dict.get("output_path") if result_dict else None
                await loop.run_in_executor(
                    None,
                    lambda: send_code_modernization_complete(
                        to_email, request.project_name, job_id, output_path
                    ),
                )
        except Exception as mail_err:
            logger.warning("Code modernization complete email failed for job %s: %s", job_id, mail_err)
    except asyncio.TimeoutError:
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = f"Job timed out after {_job_timeout}s. Set MIRA_SOURCE_FILE_LIMIT to reduce scope, or increase MIRA_JOB_TIMEOUT_SECONDS."
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()
        logger.error("Code modernization job %s timed out after %ds", job_id, _job_timeout)
    except (HTTPException, Exception) as e:
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = e.detail if isinstance(e, HTTPException) else str(e)
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()
        if not isinstance(e, HTTPException):
            logger.exception("Code modernization job %s failed", job_id)


async def _background_run_staged_modernization(
    job_id: str,
    user_id: str,
    request: StagedModernizationRequest,
) -> None:
    """Run staged PHP modernization in a thread pool; persist result and logs on ModernizationJob."""
    loop = asyncio.get_event_loop()

    def on_step_started(step: str) -> None:
        asyncio.run_coroutine_threadsafe(_update_job_step(job_id, step), loop)

    def on_step_completed(step: str, duration_sec: float) -> None:
        _sync_update_job_step_duration(job_id, step, duration_sec)

    try:
        user = await get_user_by_id(user_id)
        if not user:
            job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
            if job:
                job.status = "failed"
                job.error_message = "User not found"
                job.completed_at = datetime.utcnow()
                job.updated_at = datetime.utcnow()
                await job.save()
            return

        def run_wrapped() -> Tuple[Dict[str, Any], float]:
            _ensure_job_log_handler()
            _thread_local.current_job_id = job_id
            try:
                on_step_started("staged_modernization")
                t0 = time.perf_counter()
                def _emit_stage_progress_bg(_stage, _idx: int, _total: int) -> None:
                    try:
                        _record_job_progress(
                            job_id,
                            current_stage_index=_idx,
                            total_stages=_total,
                            current_stage_from=getattr(_stage, "from_version", None),
                            current_stage_to=getattr(_stage, "to_version", None),
                        )
                    except Exception:
                        pass
                out = _run_staged_modernization_api_sync(
                    user, request, on_stage_started=_emit_stage_progress_bg,
                )
                elapsed = time.perf_counter() - t0
                on_step_completed("staged_modernization", elapsed)
                return out, elapsed
            finally:
                _thread_local.current_job_id = None

        result_dict, elapsed = await loop.run_in_executor(None, run_wrapped)
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "completed"
            job.result = {
                "success": True,
                "project_name": result_dict.get("project_name", request.project_name),
                "source_path": result_dict.get("source_path", ""),
                "remote_migrated_versions_base": result_dict.get(
                    "remote_migrated_versions_base", ""
                ),
                "final_php_version": result_dict.get("final_php_version"),
                "stages": result_dict.get("stages", []),
                "log_path": result_dict.get("log_path"),
                "message": "Staged modernization completed.",
                "timestamp": datetime.utcnow().isoformat(),
            }
            job.logs = _trim_job_logs(logs)
            job.output_path = result_dict.get("remote_migrated_versions_base")
            job.source_path = result_dict.get("source_path")
            job.staged_modernization_duration_sec = elapsed
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            job.error_message = None
            await job.save()
    except (HTTPException, Exception) as e:
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = e.detail if isinstance(e, HTTPException) else str(e)
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()
        if not isinstance(e, HTTPException):
            logger.exception("Staged modernization job %s failed", job_id)


async def _background_run_modernization(job_id: str, user_id: str, request: RunModernizationRequest) -> None:
    """Run pipeline in executor; persist status, current_task and per-step duration in DB."""
    loop = asyncio.get_event_loop()

    async def update_step(step: str) -> None:
        await _update_job_step(job_id, step)

    def on_step_started(step: str) -> None:
        asyncio.run_coroutine_threadsafe(update_step(step), loop)

    def on_step_completed(step: str, duration_sec: float) -> None:
        _sync_update_job_step_duration(job_id, step, duration_sec)

    try:
        user = await get_user_by_id(user_id)
        if not user:
            job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
            if job:
                job.status = "failed"
                job.error_message = "User not found"
                job.completed_at = datetime.utcnow()
                job.updated_at = datetime.utcnow()
                await job.save()
            return
        result = await loop.run_in_executor(
            None,
            lambda: _run_modernization_pipeline_sync(user, request, job_id, on_step_started=on_step_started, on_step_completed=on_step_completed),
        )
        response, step_timings = result
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "completed"
            job.current_task = "code_modernization"
            job.tasks_completed = getattr(response, "steps_completed", job.tasks_completed)
            job.result = response.model_dump() if hasattr(response, "model_dump") else response.dict()
            job.output_path = getattr(response, "output_path", None)
            job.source_path = getattr(response, "source_path", None)
            job.logs = _trim_job_logs(logs)
            job.structure_analysis_duration_sec = step_timings.get("structure_analysis")
            job.language_analysis_duration_sec = step_timings.get("language_analysis")
            job.upgrade_analysis_duration_sec = step_timings.get("upgrade_analysis")
            job.code_modernization_duration_sec = step_timings.get("code_modernization")
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            job.error_message = None
            await job.save()
    except HTTPException as e:
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = e.detail
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()
    except Exception as e:
        logger.exception("Run-modernization job %s failed", job_id)
        logs = _pop_logs_for_job(job_id)
        job = await ModernizationJob.find_one(ModernizationJob.job_id == job_id)
        if job:
            job.status = "failed"
            job.error_message = str(e)
            job.logs = _trim_job_logs(logs)
            job.completed_at = datetime.utcnow()
            job.updated_at = datetime.utcnow()
            await job.save()


@router.post(
    "/run-modernization",
    tags=["Utilities — Full Pipeline (legacy single-shot)"],
    summary="Full modernization pipeline — single-shot (structure + language + upgrade + modernize)",
)
async def run_modernization(
    request: RunModernizationRequest,
    current_user: User = Depends(get_current_active_user),
):
    """Starts modernization in background. Returns 202 with job_id. Poll GET /run-modernization/status/{job_id} for result. Job stored in DB."""
    if not current_user.ssh_hostname or not current_user.ssh_username or not current_user.ssh_source_path:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No saved SSH credentials or source path. Test SSH first via POST /api/v1/analyze/test/ssh (or /api/v1/ssh) to save credentials.",
        )
    job_id = str(uuid.uuid4())
    source_path = request.source_path or _resolve_project_source_path(current_user, request.project_name)
    job_doc = ModernizationJob(
        user_id=str(current_user.id),
        job_id=job_id,
        job_type="run_modernization",
        project_name=request.project_name,
        source_path=source_path,
        status="running",
        current_task=None,
        tasks_completed=[],
        started_at=datetime.utcnow(),
    )
    await job_doc.insert()
    asyncio.create_task(_background_run_modernization(job_id, str(current_user.id), request))
    return {"job_id": job_id, "message": "Modernization started. Poll GET /api/v1/agents/run-modernization/status/{job_id} for result.", "status": "running"}


@router.get(
    "/run-modernization/status/{job_id}",
    tags=["Utilities — Full Pipeline (legacy single-shot)"],
    summary="Get full-pipeline job status and result",
)
async def run_modernization_status(
    job_id: str,
    current_user: User = Depends(get_current_active_user),
):
    """Returns job status (running|completed|failed), current_task if running, and result when completed. Fetched from DB."""
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        ModernizationJob.user_id == str(current_user.id),
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found or expired.")
    task_durations = {
        "structure_analysis_sec": job.structure_analysis_duration_sec,
        "language_analysis_sec": job.language_analysis_duration_sec,
        "upgrade_analysis_sec": job.upgrade_analysis_duration_sec,
        "code_modernization_sec": job.code_modernization_duration_sec,
    }
    if job.status == "completed" and job.result:
        return {"job_id": job_id, "status": "completed", "result": job.result, "current_step": job.current_step, "current_task": job.current_task, "tasks_completed": job.tasks_completed, "task_durations_sec": task_durations}
    if job.status == "failed":
        return {"job_id": job_id, "status": "failed", "error": job.error_message or "Unknown error", "current_step": job.current_step, "current_task": job.current_task, "tasks_completed": job.tasks_completed, "task_durations_sec": task_durations, "result": job.result}
    return {
        "job_id": job_id,
        "status": "running",
        "current_step": job.current_step,
        "current_task": job.current_task,
        "tasks_completed": job.tasks_completed,
        "task_durations_sec": task_durations,
        "result": job.result,
        "message": "Job still running. Poll again in a few seconds.",
    }


@router.get(
    "/run-modernization/status/{job_id}/logs",
    tags=["Utilities — Full Pipeline (legacy single-shot)"],
    summary="Get logs for any job (modernization, migration, upgrade-analysis, code-modernization)",
)
async def run_modernization_job_logs(
    job_id: str,
    current_user: User = Depends(get_current_active_user),
):
    """Returns log lines for the given job (any type: run-modernization, structure+language, upgrade-analysis, code-modernization). For running jobs returns in-memory logs; for completed/failed returns persisted logs."""
    user_ids_match = list({str(current_user.id), current_user.id})
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        In(ModernizationJob.user_id, user_ids_match),
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found or expired.")
    if job.status == "running":
        logs = _get_logs_for_job(job_id)
    else:
        logs = job.logs or []
    return {"job_id": job_id, "status": job.status, "logs": logs}


@router.get(
    "/jobs/{job_id}/logs.txt",
    tags=["Utilities — Projects & Reports"],
    summary="Download the complete .txt log file for a job (live during run, full archive after completion)",
    response_class=PlainTextResponse,
)
async def download_job_logs_txt(
    job_id: str,
    inline: bool = False,
    current_user: User = Depends(get_current_active_user),
):
    """
    Serve the complete log file for a job as ``text/plain``.

    During a running job this streams the live ``.txt`` file written by the
    log-capture handler — every new agent log line is appended in real time.
    After a job finishes the same file remains on disk for download/archive,
    and as a fallback we also serve the persisted ``job.logs`` from MongoDB
    if the on-disk file isn't available (e.g. after a container restart that
    didn't have a volume mount).

    Add ``?inline=true`` if you want the browser to display the log inline
    instead of triggering a "Save As…" dialog.
    """
    user_ids_match = list({str(current_user.id), current_user.id})
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        In(ModernizationJob.user_id, user_ids_match),
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found or expired.")

    # Prefer on-disk file (always up-to-date, full content).
    txt_path = _job_log_file_path(job_id)
    body: Optional[str] = None
    if txt_path.exists():
        try:
            body = txt_path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            logger.warning("Could not read job log file %s: %s", txt_path, e)

    # Fallback: persisted in-DB logs (running → in-memory; finished → job.logs).
    if body is None:
        if job.status == "running":
            lines = _get_logs_for_job(job_id)
        else:
            lines = job.logs or []
        body = "\n".join(lines) + ("\n" if lines else "")

    headers = {}
    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in job_id)
    project = (getattr(job, "project_name", None) or "job").replace(" ", "_")
    filename = f"mira_{project}_{safe_name}.txt"
    disposition = "inline" if inline else "attachment"
    headers["Content-Disposition"] = f'{disposition}; filename="{filename}"'
    headers["Cache-Control"] = "no-store"
    return Response(content=body, media_type="text/plain; charset=utf-8", headers=headers)


@router.get(
    "/run-modernization/jobs",
    tags=["Utilities — Full Pipeline (legacy single-shot)"],
    summary="List all full-pipeline jobs for current user",
)
async def list_modernization_jobs(
    current_user: User = Depends(get_current_active_user),
):
    """Fetch all run-modernization (full pipeline) job records. Returns project name, status, current_step, tasks completed, timestamps."""
    user_id_str = str(current_user.id)
    user_ids_match = list({user_id_str, current_user.id})
    jobs = await (
        ModernizationJob.find(In(ModernizationJob.user_id, user_ids_match), ModernizationJob.job_type == "run_modernization")
        .sort(-ModernizationJob.created_at)
        .to_list(10000)
    )
    return [
        {
            "job_id": j.job_id,
            "project_name": j.project_name,
            "status": j.status,
            "current_step": j.current_step,
            "current_task": j.current_task,
            "tasks_completed": j.tasks_completed,
            "task_durations_sec": {
                "structure_analysis_sec": j.structure_analysis_duration_sec,
                "language_analysis_sec": j.language_analysis_duration_sec,
                "upgrade_analysis_sec": j.upgrade_analysis_duration_sec,
                "code_modernization_sec": j.code_modernization_duration_sec,
            },
            "source_path": j.source_path,
            "output_path": j.output_path,
            "error_message": j.error_message,
            "created_at": j.created_at,
            "updated_at": j.updated_at,
            "started_at": j.started_at,
            "completed_at": j.completed_at,
            "result": j.result,
        }
        for j in jobs
    ]


# ---------- API 1: Structure + Language ----------

@router.post(
    "/run-structure-language-and-version-upgradation",
    tags=["Step 3 — Migration (4-step pipeline)"],
    summary="Migration Step 1: Detect structure, language, version (start here — returns transform_id)",
)
async def run_structure_and_language(
    request: RunStructureLanguageRequest,
    current_user: User = Depends(get_current_active_user),
):
    """Single-entry orchestration: structure + language, then auto run new version upgradation. Returns transform_id for same transform workflow."""
    if not current_user.ssh_hostname or not current_user.ssh_username or not current_user.ssh_source_path:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No saved SSH credentials or source path. Test SSH first.",
        )
    job_id = str(uuid.uuid4())
    transform_id = str(uuid.uuid4())
    source_path = _resolve_project_source_path(current_user, request.project_name)
    job_doc = ModernizationJob(
        user_id=str(current_user.id),
        job_id=job_id,
        job_type="structure_language",
        transform_id=transform_id,
        project_name=request.project_name,
        source_path=source_path,
        status="running",
        current_step="step_1",
        current_task=None,
        tasks_completed=[],
        started_at=datetime.utcnow(),
    )
    await job_doc.insert()
    transform_doc = Transform(
        transform_id=transform_id,
        user_id=str(current_user.id),
        project_name=request.project_name,
        step_1_job_id=job_id,
    )
    await transform_doc.insert()
    asyncio.create_task(_background_run_structure_language(job_id, str(current_user.id), request, transform_id))
    return {
        "transform_id": transform_id,
        "job_id": job_id,
        "message": "Poll GET /api/v1/agents/run-structure-language-and-version-upgradation/status/{job_id}",
        "status": "running",
    }


@router.get(
    "/run-structure-language-and-version-upgradation/status/{job_id}",
    tags=["Step 3 — Migration (4-step pipeline)"],
    summary="Migration Step 1: Get job status (returns transform_id when completed)",
)
async def run_structure_and_language_status(job_id: str, current_user: User = Depends(get_current_active_user)):
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        ModernizationJob.user_id == str(current_user.id),
        ModernizationJob.job_type == "structure_language",
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    task_durations = {
        "structure_analysis_sec": job.structure_analysis_duration_sec,
        "language_analysis_sec": job.language_analysis_duration_sec,
        "new_version_upgradation_sec": job.staged_modernization_duration_sec,
    }
    step = job.current_step  # step_1 for this API
    result = _result_with_step_after_project_name(job.result, step)
    # Stage progress (per-version-hop) — surfaced on every status poll so the UI
    # can log each new "7.4 → 7.5", "7.5 → 7.6", ... transition as it happens.
    stage_block = {
        "current_stage_index": getattr(job, "current_stage_index", None),
        "total_stages": getattr(job, "total_stages", None),
        "current_stage_from": getattr(job, "current_stage_from", None),
        "current_stage_to": getattr(job, "current_stage_to", None),
    }
    if job.status == "completed":
        # Persist transform_id to UserProject so Steps 2/3/4 can auto-fetch it
        if job.transform_id:
            asyncio.create_task(
                _save_project_pipeline_state(
                    str(current_user.id),
                    job.project_name,
                    last_transform_id=job.transform_id,
                )
            )
        return {"job_id": job_id, "status": "completed", "transform_id": job.transform_id, "result": result, "task_durations_sec": task_durations, "stage_progress": stage_block}
    if job.status == "failed":
        return {"job_id": job_id, "status": "failed", "error": job.error_message or "Unknown error", "result": result, "task_durations_sec": task_durations, "stage_progress": stage_block}
    return {"job_id": job_id, "status": "running", "current_task": job.current_task, "result": result, "task_durations_sec": task_durations, "stage_progress": stage_block}


async def _get_transform_to_version(transform: "Transform") -> str:
    """Get the target version from a transform's step 1 job result, or return latest stable."""
    if transform.step_1_job_id:
        j1 = await ModernizationJob.find_one(ModernizationJob.job_id == transform.step_1_job_id)
        if j1 and j1.result:
            tv = j1.result.get("to_version", "")
            lang = j1.result.get("language", "php")
            if tv:
                return tv
            return _latest_stable_version(lang)
    return _latest_stable_version("php")


async def _get_transform_language(transform: "Transform") -> str:
    """Return the language recorded by Step 1 for this transform, defaulting to ``php``.

    Used by upgrade-analysis routes that resolve ``migrated-codes/.../stage_*_<lang><ver>``
    so a Python or Java migration doesn't accidentally try to find ``stage_*_phpXX``.
    """
    if transform and transform.step_1_job_id:
        j1 = await ModernizationJob.find_one(ModernizationJob.job_id == transform.step_1_job_id)
        if j1 and j1.result:
            lang = (j1.result.get("language") or "").strip().lower()
            if lang:
                return lang
    return "php"


async def _resolve_transform_id(user_id: str, project_name: str, provided_transform_id: Optional[str]) -> str:
    """Return provided_transform_id if given, else fetch the most recent transform for this user+project from DB."""
    if provided_transform_id:
        return provided_transform_id
    transform = await Transform.find_one(
        Transform.user_id == user_id,
        Transform.project_name == project_name,
        sort=[("created_at", -1)],
    )
    if not transform:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"No transform found for project '{project_name}'. "
                "Run Step 1 (run-structure-language-and-version-upgradation) first, "
                "or pass transform_id explicitly."
            ),
        )
    return transform.transform_id


async def _resolve_upgraded_folder_name(user: User, project_name: str, provided_folder: Optional[str]) -> str:
    """Return provided_folder if given, else look up UserProject.last_upgraded_path in DB."""
    if provided_folder:
        return provided_folder
    user_project = await UserProject.find_one(
        UserProject.user_id == str(user.id),
        UserProject.project_name == project_name,
    )
    last_path = user_project.last_upgraded_path if user_project else None
    if last_path:
        # last_upgraded_path is the full remote path — extract just the folder name
        return last_path.rstrip("/").split("/")[-1]
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail=(
            f"No upgraded output found for project '{project_name}' in DB. "
            "Run Step 4 (run-code-modernization) first, or pass upgrade_project_name explicitly."
        ),
    )


async def _save_project_pipeline_state(
    user_id: str,
    project_name: str,
    *,
    last_transform_id: Optional[str] = None,
    last_upgraded_path: Optional[str] = None,
    last_sonar_scan_job_id: Optional[str] = None,
    last_sonar_project_key: Optional[str] = None,
    sonar_project_key_for_language: Optional[Tuple[str, str]] = None,
) -> None:
    """Upsert pipeline state fields on UserProject so subsequent steps can auto-fetch them.

    ``sonar_project_key_for_language`` is a ``(language, key)`` tuple that updates the
    multi-language ``last_sonar_project_keys`` dict. Call this in multi-language fanouts
    so each language gets its own Sonar report.
    """
    user_project = await UserProject.find_one(
        UserProject.user_id == user_id,
        UserProject.project_name == project_name,
    )
    if not user_project:
        return  # project not registered — skip silently
    changed = False
    if last_transform_id is not None:
        user_project.last_transform_id = last_transform_id
        changed = True
    if last_upgraded_path is not None:
        user_project.last_upgraded_path = last_upgraded_path
        changed = True
    if last_sonar_scan_job_id is not None:
        user_project.last_sonar_scan_job_id = last_sonar_scan_job_id
        changed = True
    if last_sonar_project_key is not None:
        user_project.last_sonar_project_key = last_sonar_project_key
        changed = True
    if sonar_project_key_for_language is not None:
        lang, key = sonar_project_key_for_language
        lang = (lang or "").strip().lower()
        key = (key or "").strip()
        if lang and key:
            keys = dict(getattr(user_project, "last_sonar_project_keys", {}) or {})
            keys[lang] = key
            user_project.last_sonar_project_keys = keys
            changed = True
    if changed:
        user_project.updated_at = datetime.utcnow()
        await user_project.save()


def _resolve_sonar_key_for_language(
    user_project: Optional["UserProject"],
    language: Optional[str],
) -> Optional[str]:
    """Return the Sonar project key for a specific language, with graceful fallback.

    Tries ``last_sonar_project_keys[language]`` first, then falls back to the legacy
    single-key ``last_sonar_project_key``. Returns None when neither exists.
    """
    if user_project is None:
        return None
    lang = (language or "").strip().lower()
    keys = getattr(user_project, "last_sonar_project_keys", None) or {}
    if lang and isinstance(keys, dict) and keys.get(lang):
        return keys[lang]
    return getattr(user_project, "last_sonar_project_key", None)


# ---------- API 2: Simple upgrade analysis (step 2) ----------

@router.post(
    "/run-upgrade-analysis-simple",
    tags=["Step 3 — Migration (4-step pipeline)"],
    summary="Migration Step 2: Upgrade analysis — no user input (requires transform_id from Step 1)",
)
async def run_upgrade_analysis_simple(
    request: RunUpgradeAnalysisSimpleRequest,
    current_user: User = Depends(get_current_active_user),
):
    """Step 2: Starts upgrade analysis (no user_input). Only project_name is required — transform_id auto-fetched from DB. Poll GET /run-upgrade-analysis/status/{job_id}."""
    if not current_user.ssh_hostname or not current_user.ssh_username or not current_user.ssh_source_path:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No saved SSH credentials or source path. Test SSH first.")
    resolved_transform_id = await _resolve_transform_id(str(current_user.id), request.project_name, request.transform_id)
    transform = await Transform.find_one(
        Transform.transform_id == resolved_transform_id,
        Transform.user_id == str(current_user.id),
    )
    if not transform:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Transform not found.")
    job_id = str(uuid.uuid4())
    _tv2 = await _get_transform_to_version(transform)
    _lang2 = await _get_transform_language(transform)
    source_path = _resolve_migrated_stage_source_path(current_user, request.project_name, _tv2, language=_lang2)
    job_doc = ModernizationJob(
        user_id=str(current_user.id),
        job_id=job_id,
        job_type="upgrade_analysis",
        transform_id=resolved_transform_id,
        project_name=request.project_name,
        source_path=source_path,
        status="running",
        current_step="step_2",
        current_task=None,
        tasks_completed=[],
        started_at=datetime.utcnow(),
    )
    await job_doc.insert()
    transform.step_2_job_id = job_id
    transform.updated_at = datetime.utcnow()
    await transform.save()
    req_without_input = RunUpgradeAnalysisRequest(transform_id=resolved_transform_id, project_name=request.project_name, user_input=None)
    asyncio.create_task(_background_run_upgrade_analysis(job_id, str(current_user.id), req_without_input))
    return {
        "transform_id": resolved_transform_id,
        "job_id": job_id,
        "message": "Poll GET /api/v1/agents/run-upgrade-analysis/status/{job_id}",
        "status": "running",
    }


# ---------- API 3: Upgrade analysis with user_input (step 3) ----------

@router.post(
    "/run-upgrade-analysis",
    tags=["Step 3 — Migration (4-step pipeline)"],
    summary="Migration Step 3: Upgrade analysis with optional user input (requires transform_id from Step 1)",
)
async def run_upgrade_analysis(
    request: RunUpgradeAnalysisRequest,
    current_user: User = Depends(get_current_active_user),
):
    """Step 3: Starts upgrade analysis with optional user_input. Only project_name required — transform_id auto-fetched from DB. Poll GET /run-upgrade-analysis/status/{job_id}."""
    if not current_user.ssh_hostname or not current_user.ssh_username or not current_user.ssh_source_path:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No saved SSH credentials or source path. Test SSH first.")
    resolved_transform_id = await _resolve_transform_id(str(current_user.id), request.project_name, request.transform_id)
    transform = await Transform.find_one(
        Transform.transform_id == resolved_transform_id,
        Transform.user_id == str(current_user.id),
    )
    if not transform:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Transform not found.")
    job_id = str(uuid.uuid4())
    _tv3 = await _get_transform_to_version(transform)
    _lang3 = await _get_transform_language(transform)
    source_path = _resolve_migrated_stage_source_path(current_user, request.project_name, _tv3, language=_lang3)
    job_doc = ModernizationJob(
        user_id=str(current_user.id),
        job_id=job_id,
        job_type="upgrade_analysis",
        transform_id=resolved_transform_id,
        project_name=request.project_name,
        source_path=source_path,
        status="running",
        current_step="step_3",
        current_task=None,
        tasks_completed=[],
        started_at=datetime.utcnow(),
    )
    await job_doc.insert()
    transform.step_3_job_id = job_id
    transform.updated_at = datetime.utcnow()
    await transform.save()
    # Ensure request carries the resolved transform_id for background worker
    request.transform_id = resolved_transform_id
    asyncio.create_task(_background_run_upgrade_analysis(job_id, str(current_user.id), request))
    return {
        "transform_id": resolved_transform_id,
        "job_id": job_id,
        "message": "Poll GET /api/v1/agents/run-upgrade-analysis/status/{job_id}",
        "status": "running",
    }


@router.get("/run-upgrade-analysis/status/{job_id}", tags=["Step 3 — Migration (4-step pipeline)"], summary="Migration Step 2/3: Get upgrade-analysis job status")
async def run_upgrade_analysis_status(job_id: str, current_user: User = Depends(get_current_active_user)):
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        ModernizationJob.user_id == str(current_user.id),
        ModernizationJob.job_type == "upgrade_analysis",
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    task_durations = {
        "structure_analysis_sec": job.structure_analysis_duration_sec,
        "language_analysis_sec": job.language_analysis_duration_sec,
        "upgrade_analysis_sec": job.upgrade_analysis_duration_sec,
    }
    step = job.current_step  # step_2 or step_3 for upgrade-analysis jobs
    result = _result_with_step_after_project_name(job.result, step)
    if job.status == "completed":
        return {"job_id": job_id, "status": "completed", "result": result, "task_durations_sec": task_durations}
    if job.status == "failed":
        return {"job_id": job_id, "status": "failed", "error": job.error_message or "Unknown error", "result": result, "task_durations_sec": task_durations}
    return {"job_id": job_id, "status": "running", "current_task": job.current_task, "result": result, "task_durations_sec": task_durations}


# ---------- API 4: Code modernization (step 4) ----------

@router.post(
    "/run-code-modernization",
    tags=["Step 3 — Migration (4-step pipeline)"],
    summary="Migration Step 4: Code modernization — transforms code to target version (requires transform_id from Step 1)",
)
async def run_code_modernization(
    request: RunCodeModernizationRequest,
    current_user: User = Depends(get_current_active_user),
):
    """Step 4: Starts code modernization.

    **Single-language (default):** pass only `project_name`; migrates the
    project's primary detected language (historical behavior — PHP by default).

    **Multi-stack:** pass `languages: ["php", "javascript"]`. Creates one
    `ModernizationJob` per language and runs them in parallel. Poll each job
    individually via GET /run-code-modernization/status/{job_id}, or use
    GET /agents/transforms to see all jobs under one transform_id.
    """
    if not current_user.ssh_hostname or not current_user.ssh_username or not current_user.ssh_source_path:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No saved SSH credentials or source path. Test SSH first.")

    resolved_transform_id = await _resolve_transform_id(str(current_user.id), request.project_name, request.transform_id)
    transform = await Transform.find_one(
        Transform.transform_id == resolved_transform_id,
        Transform.user_id == str(current_user.id),
    )
    if not transform:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Transform not found.")

    # Determine which languages to fan out over. Default = [primary detected] for
    # backward compat (PHP-only migrations still work with no request changes).
    requested_langs = [l.strip().lower() for l in (request.languages or []) if l and l.strip()]
    if not requested_langs:
        requested_langs = ["php"]

    # Validate each language is supported
    unsupported = [l for l in requested_langs if l not in _LANGUAGE_EXTENSIONS]
    if unsupported:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Unsupported language(s): {', '.join(unsupported)}. "
                f"Supported: {', '.join(sorted(_LANGUAGE_EXTENSIONS.keys()))}"
            ),
        )

    _tv4 = await _get_transform_to_version(transform)
    # For multi-language fanout (requested_langs has >1), the staged-path resolver below
    # is only used to confirm the parent migrated-codes folder exists; each per-language
    # worker re-resolves its own stage path inside _run_code_modernization_pipeline_sync.
    # We pass the FIRST requested language here to avoid the legacy hardcoded "php" default.
    _lang4 = (requested_langs[0] if requested_langs else "php")
    source_path = _resolve_migrated_stage_source_path(current_user, request.project_name, _tv4, language=_lang4)

    # Normalize target_versions (map lang → target version string). If the caller
    # didn't pass one, each worker will fall back to _latest_stable_version(lang).
    target_versions_raw = request.target_versions or {}
    target_versions: Dict[str, str] = {}
    for k, v in target_versions_raw.items():
        if isinstance(k, str) and isinstance(v, str) and k.strip() and v.strip():
            target_versions[k.strip().lower()] = v.strip()

    # Create one job per language; kick off a background task for each.
    job_ids: List[Dict[str, str]] = []
    for lang in requested_langs:
        job_id = str(uuid.uuid4())
        lang_target_version = target_versions.get(lang)  # may be None → worker uses default

        job_doc = ModernizationJob(
            user_id=str(current_user.id),
            job_id=job_id,
            job_type="code_modernization",
            transform_id=resolved_transform_id,
            project_name=request.project_name,
            source_path=source_path,
            status="running",
            current_step="step_4",
            current_task=f"language={lang} target={lang_target_version or 'auto'}",
            tasks_completed=[],
            started_at=datetime.utcnow(),
        )
        await job_doc.insert()

        # Build a per-language request copy so each background worker sees its own
        # language and its own target version. These singular fields are declared
        # on RunCodeModernizationRequest specifically for this fanout handoff.
        per_lang_update: Dict[str, Any] = {
            "transform_id": resolved_transform_id,
            "languages": [lang],
            "language": lang,
        }
        if lang_target_version:
            per_lang_update["target_version"] = lang_target_version
        per_lang_req = request.model_copy(update=per_lang_update)

        asyncio.create_task(_background_run_code_modernization(job_id, str(current_user.id), per_lang_req))
        job_ids.append({
            "language": lang,
            "job_id": job_id,
            "target_version": lang_target_version,
        })

    # Point Transform.step_4_job_id at the first job for back-compat (most callers read one job).
    # The full list of per-language jobs is returned to the caller.
    transform.step_4_job_id = job_ids[0]["job_id"]
    transform.updated_at = datetime.utcnow()
    await transform.save()

    # Fire the start-of-migration email NOW so the user has confirmation that the
    # job is queued, plus a record of their stack choices and the estimate. Failure
    # to send email must not block the migration — log and move on. Wrapped in a
    # background executor so the response stays snappy.
    try:
        to_email = (getattr(current_user, "email", None) or "").strip()
        if to_email:
            stacks_in = getattr(request, "stacks", None) or {}
            est = getattr(request, "estimate_summary", None) or {}
            loop = asyncio.get_event_loop()
            loop.run_in_executor(
                None,
                lambda: send_migration_started(
                    to_email=to_email,
                    project_name=request.project_name,
                    job_id=job_ids[0]["job_id"],
                    stacks=stacks_in,
                    total_files=est.get("total_files"),
                    estimated_runtime=est.get("wall_clock_human"),
                    estimated_cost_usd=est.get("estimated_cost_usd"),
                ),
            )
    except Exception as mail_err:
        logger.warning("Migration-started email dispatch failed for %s: %s", request.project_name, mail_err)

    # Single-language callers get the old flat response shape; multi-language callers get the list.
    if len(job_ids) == 1:
        return {
            "transform_id": resolved_transform_id,
            "job_id": job_ids[0]["job_id"],
            "language": job_ids[0]["language"],
            "message": "Poll GET /api/v1/agents/run-code-modernization/status/{job_id}",
            "status": "running",
        }
    return {
        "transform_id": resolved_transform_id,
        "jobs": job_ids,
        "message": (
            f"Started {len(job_ids)} language pipelines. "
            "Poll each job individually via /api/v1/agents/run-code-modernization/status/{job_id}."
        ),
        "status": "running",
    }


def _progress_block(job: ModernizationJob) -> Dict[str, Any]:
    """Return the per-file progress block attached to a running job's status response."""
    total = job.files_total or 0
    processed = job.files_processed or 0
    failed = job.files_failed or 0
    percent = int((processed / total) * 100) if total else 0
    return {
        "files_total": total,
        "files_processed": processed,
        "files_failed": failed,
        "percent": percent,
        "current_file": job.current_file,
        "last_completed_file": job.last_completed_file,
        "current_chunk_index": job.current_chunk_index,
        "eta_seconds": job.eta_seconds,
        "resumed_from_job_id": job.resumed_from_job_id,
        # Per-stage version-migration progress (PHP 7.4 → 7.5 → 7.6 → ... → 8.5).
        # Frontend should log a new line each time current_stage_to changes.
        "current_stage_index": getattr(job, "current_stage_index", None),
        "total_stages": getattr(job, "total_stages", None),
        "current_stage_from": getattr(job, "current_stage_from", None),
        "current_stage_to": getattr(job, "current_stage_to", None),
    }


@router.get("/run-code-modernization/status/{job_id}", tags=["Step 3 — Migration (4-step pipeline)"], summary="Migration Step 4: Get code-modernization job status")
async def run_code_modernization_status(job_id: str, current_user: User = Depends(get_current_active_user)):
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        ModernizationJob.user_id == str(current_user.id),
        ModernizationJob.job_type == "code_modernization",
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    task_durations = {"code_modernization_sec": job.code_modernization_duration_sec}
    step = job.current_step  # step_4 for this API
    result = _result_with_step_after_project_name(job.result, step)
    progress = _progress_block(job)
    if job.status == "completed":
        upgrade_project_name = job.output_path.rstrip("/").split("/")[-1] if getattr(job, "output_path", None) else None
        if job.output_path:
            asyncio.create_task(
                _save_project_pipeline_state(
                    str(current_user.id),
                    job.project_name,
                    last_upgraded_path=job.output_path,
                )
            )
        return {"job_id": job_id, "status": "completed", "result": result, "task_durations_sec": task_durations, "upgrade_project_name": upgrade_project_name, "progress": progress}
    if job.status == "failed":
        return {"job_id": job_id, "status": "failed", "error": job.error_message or "Unknown error", "result": result, "task_durations_sec": task_durations, "progress": progress}
    return {"job_id": job_id, "status": "running", "current_task": job.current_task, "result": result, "task_durations_sec": task_durations, "progress": progress}


@router.get(
    "/migration/version-options",
    tags=["Step 3 — Migration (4-step pipeline)"],
    summary="Return valid target version ladder for each supported language (frontend picker source)",
)
async def get_migration_version_options(
    current_user: User = Depends(get_current_active_user),
):
    """Return `{language: [v1, v2, ...]}` so the estimate modal can render a version
    dropdown next to each language checkbox. Keys match the language names emitted
    by /migration/estimate."""
    from app.services.rag.version_ladder import (
        PHP_VERSION_LADDER, PYTHON_VERSION_LADDER, JAVASCRIPT_VERSION_LADDER,
        TYPESCRIPT_VERSION_LADDER, JAVA_VERSION_LADDER, CSHARP_VERSION_LADDER,
        GOLANG_VERSION_LADDER, RUST_VERSION_LADDER, KOTLIN_VERSION_LADDER,
        SCALA_VERSION_LADDER,
    )
    ladders: Dict[str, List[str]] = {
        "php":        list(PHP_VERSION_LADDER),
        "python":     list(PYTHON_VERSION_LADDER),
        "javascript": list(JAVASCRIPT_VERSION_LADDER),
        "typescript": list(TYPESCRIPT_VERSION_LADDER),
        "java":       list(JAVA_VERSION_LADDER),
        "csharp":     list(CSHARP_VERSION_LADDER),
        "c_sharp":    list(CSHARP_VERSION_LADDER),  # alt spelling used by tree-sitter
        "go":         list(GOLANG_VERSION_LADDER),
        "rust":       list(RUST_VERSION_LADDER),
        "kotlin":     list(KOTLIN_VERSION_LADDER),
        "scala":      list(SCALA_VERSION_LADDER),
        # Languages without a ladder get an empty list → UI falls back to free-text or "auto".
        "ruby":       [],
        "cpp":        [],
        "c":          [],
    }
    # Defaults = latest entry in each ladder (safe recommendation)
    defaults: Dict[str, Optional[str]] = {k: (v[-1] if v else None) for k, v in ladders.items()}
    return {"ladders": ladders, "defaults": defaults}


# ---------------------------------------------------------------------------
# Stack classification: split detected files into Frontend / Backend / API buckets.
# ---------------------------------------------------------------------------
# Why this exists: a single language (JS / TS) can be either frontend (React,
# Vue, Angular, Svelte) or backend (Node/Express/NestJS). To let the user pick
# *which streams to migrate* (per the full-stack migration spec), we group every
# detected file into one of three buckets using path + extension heuristics.
#
# Buckets:
#   - frontend: client-side code (React/Vue/Angular components, HTML, CSS, JSX/TSX)
#   - backend:  server-side code (PHP, Python, Java, Go, Ruby, Rust, C#, Node)
#   - api:      shared interface artefacts (OpenAPI specs, .proto, GraphQL schemas,
#               and route-definition files inside backend code)
#
# A file may belong to backend AND api at the same time (e.g. routes/api.php is
# both backend code and an API definition); the classifier returns a primary
# bucket plus an `is_api` flag so the UI can show the API count separately.

_FRONTEND_EXTENSIONS = {".jsx", ".tsx", ".vue", ".svelte", ".html", ".htm",
                        ".css", ".scss", ".sass", ".less", ".astro"}
_BACKEND_EXTENSIONS = {".php", ".py", ".java", ".kt", ".kts", ".go", ".rb",
                       ".rs", ".cs", ".cpp", ".cc", ".cxx", ".c", ".h", ".hpp"}
_FRONTEND_PATH_HINTS = ("/frontend/", "/client/", "/web/", "/ui/", "/static/",
                        "/public/", "/components/", "/pages/", "/views/",
                        "/screens/", "/src/components/", "/src/pages/",
                        "/src/views/", "/src/app/", "/src/screens/")
_BACKEND_PATH_HINTS = ("/backend/", "/server/", "/api/", "/controllers/",
                       "/routes/", "/services/", "/models/", "/repositories/",
                       "/src/main/", "/src/lib/", "/app/")
_API_FILENAME_HINTS = ("openapi.yaml", "openapi.yml", "openapi.json",
                       "swagger.yaml", "swagger.yml", "swagger.json")
_API_EXTENSIONS = {".proto", ".graphql", ".gql"}
_API_PATH_HINTS = ("/routes/api.", "/api/routes/", "/api/v1/", "/api/v2/",
                   "/controllers/api/", "/openapi/", "/swagger/")


def _classify_file_stack(rel_path: str, language: str) -> Tuple[str, bool]:
    """Return (bucket, is_api) for one source file path.

    Bucket is one of ``"frontend"``, ``"backend"``, or ``"api"`` (when the file is
    a pure-spec artefact like an OpenAPI yaml or .proto). ``is_api`` is set
    additionally when a backend file looks like a route/controller — it stays in
    the backend bucket but the count is also surfaced in the API total.
    """
    p = (rel_path or "").lower()
    lang = (language or "").lower()
    ext = "." + p.rsplit(".", 1)[-1] if "." in p else ""
    name = p.rsplit("/", 1)[-1]

    # Pure API spec files first — these have no other classification.
    if name in _API_FILENAME_HINTS or ext in _API_EXTENSIONS:
        return ("api", True)

    # Frontend-only extensions force the bucket regardless of path.
    if ext in _FRONTEND_EXTENSIONS:
        return ("frontend", False)

    # Backend extensions: PHP / Python / Java / Go / etc. are always server-side.
    if ext in _BACKEND_EXTENSIONS:
        is_api = any(h in p for h in _API_PATH_HINTS) or "controller" in name or "route" in name
        return ("backend", is_api)

    # JS/TS files: the ambiguous case. Split on path.
    if lang in ("javascript", "typescript"):
        if any(h in p for h in _FRONTEND_PATH_HINTS):
            return ("frontend", False)
        if any(h in p for h in _BACKEND_PATH_HINTS):
            is_api = any(h in p for h in _API_PATH_HINTS)
            return ("backend", is_api)
        # Default JS/TS without a clear path goes to frontend (more common for SPAs).
        return ("frontend", False)

    # Fallback: treat as backend.
    return ("backend", False)


def _summarize_stacks(
    languages_seen: List[Dict[str, Any]],
    files_by_language: Dict[str, List[str]],
) -> Dict[str, Any]:
    """Roll up per-language file lists into Frontend / Backend / API stack summaries.

    Returns a dict shaped for the /migration/estimate response:

        {
          "frontend": {"present": bool, "files": int, "languages": [...], "frameworks": [...]},
          "backend":  {...},
          "api":      {"present": bool, "files": int, "spec_files": int, "route_files": int},
        }
    """
    fe_files = 0
    be_files = 0
    api_pure = 0
    api_routes = 0
    fe_langs: Dict[str, int] = {}
    be_langs: Dict[str, int] = {}

    for lang_entry in languages_seen:
        lang = lang_entry.get("language", "")
        for f in files_by_language.get(lang, []):
            bucket, is_api = _classify_file_stack(f, lang)
            if bucket == "frontend":
                fe_files += 1
                fe_langs[lang] = fe_langs.get(lang, 0) + 1
            elif bucket == "backend":
                be_files += 1
                be_langs[lang] = be_langs.get(lang, 0) + 1
                if is_api:
                    api_routes += 1
            elif bucket == "api":
                api_pure += 1

    return {
        "frontend": {
            "present": fe_files > 0,
            "files": fe_files,
            "languages": sorted(fe_langs.keys(), key=lambda l: -fe_langs[l]),
        },
        "backend": {
            "present": be_files > 0,
            "files": be_files,
            "languages": sorted(be_langs.keys(), key=lambda l: -be_langs[l]),
        },
        "api": {
            "present": (api_pure + api_routes) > 0,
            "files": api_pure + api_routes,
            "spec_files": api_pure,
            "route_files": api_routes,
        },
    }


@router.post(
    "/migration/estimate",
    tags=["Step 3 — Migration (4-step pipeline)"],
    summary="Pre-flight: detect languages, count files, estimate runtime + cost, report limit breach",
)
async def estimate_migration(
    request: Dict[str, Any],
    current_user: User = Depends(get_current_active_user),
):
    """
    **Pre-flight check for a migration job.**

    Walks the project's remote tree, counts files per supported language, and
    returns a per-language breakdown plus an estimate of runtime and cost
    against the current env limits.

    Request body: `{"project_name": "my-app"}`

    Response:
    ```json
    {
      "project_name": "my-app",
      "source_path": "/home/user/my-app",
      "languages_detected": [
        {"language": "php", "files": 120, "bytes": 2400000, "supported": true},
        {"language": "javascript", "files": 45, "bytes": 900000, "supported": true}
      ],
      "total_files": 165,
      "total_bytes": 3300000,
      "limits": {
        "MIRA_SOURCE_FILE_LIMIT": null,
        "MIRA_MAX_LLM_FILE_BYTES": 500000,
        "MIRA_MAX_FILE_BYTES": 104857600
      },
      "within_limits": true,
      "warnings": [],
      "estimate": {
        "total_llm_calls": 165,
        "avg_seconds_per_file": 12.0,
        "wall_clock_seconds": 1980,
        "wall_clock_human": "33 minutes",
        "estimated_tokens_input": 6600000,
        "estimated_tokens_output": 6600000,
        "estimated_cost_usd": 5.82
      }
    }
    ```

    The frontend uses this to pop a confirmation modal:
    - if `within_limits == False` → show warning "project exceeds limits, may take
      X hours, continue anyway?"
    - if `within_limits == True` → show estimate + Continue button
    - user clicks Continue → frontend calls the real migration endpoint
    """
    project_name = (request or {}).get("project_name", "").strip()
    if not project_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="project_name is required",
        )

    # Resolve source path
    try:
        source_path = _resolve_project_source_path(current_user, project_name)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Could not resolve source path for '{project_name}': {e}",
        )

    # Decrypt SSH creds
    password = decrypt_data(current_user.ssh_password_encrypted) if current_user.ssh_password_encrypted else None
    private_key = decrypt_data(current_user.ssh_private_key_encrypted) if current_user.ssh_private_key_encrypted else None
    private_key_password = decrypt_data(current_user.ssh_private_key_password_encrypted) if current_user.ssh_private_key_password_encrypted else None

    ssh_conn = SSHService.create_connection(
        hostname=current_user.ssh_hostname,
        port=current_user.ssh_port or 22,
        username=current_user.ssh_username,
        password=password,
        private_key=private_key,
        private_key_password=private_key_password,
    )
    if not ssh_conn.connect():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SSH connection failed to {current_user.ssh_hostname}",
        )

    try:
        # Per-language file enumeration
        languages_seen: List[Dict[str, Any]] = []
        files_by_language: Dict[str, List[str]] = {}  # kept so we can split into stack buckets later
        total_files = 0
        total_bytes = 0
        for lang_key in _LANGUAGE_EXTENSIONS.keys():
            try:
                files = _list_remote_source_files(ssh_conn, source_path, language=lang_key, limit=None)
            except Exception as e:
                logger.warning("estimate: enumeration for %s failed: %s", lang_key, e)
                continue
            if not files:
                continue
            files_by_language[lang_key] = files
            # Batch stat for byte totals (cap at 2000 files per language for the estimate)
            sample = files[:2000]
            stat_cmd = "du -cb " + " ".join(f"'{f}'" for f in sample) + " 2>/dev/null | tail -1 | awk '{print $1}'"
            stat_res = ssh_conn.execute_command(stat_cmd, timeout=ssh_conn.CMD_TIMEOUT_LONG)
            try:
                sampled_bytes = int((stat_res.get("stdout") or "0").strip() or 0)
            except (ValueError, TypeError):
                sampled_bytes = 0
            # Extrapolate byte total for full set based on sample
            if sample:
                extrap_bytes = int(sampled_bytes * (len(files) / len(sample)))
            else:
                extrap_bytes = sampled_bytes
            languages_seen.append({
                "language": lang_key,
                "files": len(files),
                "bytes": extrap_bytes,
                "supported": True,  # all enumerated languages are supported by the splitter
            })
            total_files += len(files)
            total_bytes += extrap_bytes

        # Read env limits
        source_file_limit = os.environ.get("MIRA_SOURCE_FILE_LIMIT") or os.environ.get("MIRA_PHP_FILE_LIMIT")
        try:
            source_file_limit_int: Optional[int] = int(source_file_limit) if source_file_limit else None
        except (ValueError, TypeError):
            source_file_limit_int = None

        max_llm_file_bytes = int(os.environ.get("MIRA_MAX_LLM_FILE_BYTES", str(500_000)))
        max_file_bytes = int(os.environ.get("MIRA_MAX_FILE_BYTES", str(100 * 1024 * 1024)))
        max_concurrent_llm = int(os.environ.get("MIRA_MAX_CONCURRENT_LLM_CALLS", "3"))
        job_timeout_sec = int(os.environ.get("MIRA_JOB_TIMEOUT_SECONDS", "7200"))

        warnings: List[str] = []
        within_limits = True
        if source_file_limit_int and total_files > source_file_limit_int:
            within_limits = False
            warnings.append(
                f"Project has {total_files} files, exceeds MIRA_SOURCE_FILE_LIMIT={source_file_limit_int}. "
                f"Raise the env var (or unset for unlimited) to process all files."
            )

        # Cost estimate — rough-but-honest numbers
        avg_tokens_per_file_in = 8_000    # system + rules + file content + context
        avg_tokens_per_file_out = 8_000   # roughly equal for code-rewrite LLMs
        # Groq qwen3-32b: input $0.29/M, output $0.59/M
        input_usd_per_tok = 0.29 / 1_000_000
        output_usd_per_tok = 0.59 / 1_000_000
        est_tokens_in = total_files * avg_tokens_per_file_in
        est_tokens_out = total_files * avg_tokens_per_file_out
        est_cost = est_tokens_in * input_usd_per_tok + est_tokens_out * output_usd_per_tok

        # Wall-clock = (files / concurrency) * avg_sec_per_file + overhead
        avg_sec_per_file = 12.0  # ~400 tps output × 8000 tokens ≈ 20s max; practical ~12s
        wall_clock_sec = int((total_files / max(1, max_concurrent_llm)) * avg_sec_per_file + 60)

        if wall_clock_sec > job_timeout_sec:
            warnings.append(
                f"Estimated runtime {wall_clock_sec}s exceeds MIRA_JOB_TIMEOUT_SECONDS={job_timeout_sec}. "
                f"Raise the env var, split the project, or the job will time out."
            )
            within_limits = False

        def _humanize_seconds(s: int) -> str:
            h, rem = divmod(s, 3600)
            m, _ = divmod(rem, 60)
            if h:
                return f"{h}h {m}m"
            return f"{m}m"

        return {
            "project_name": project_name,
            "source_path": source_path,
            "languages_detected": sorted(languages_seen, key=lambda l: -l["files"]),
            # Stack split — Frontend / Backend / API — so the user can pick which
            # streams to migrate (full-stack migration spec). Each stack lists the
            # primary languages it covers and the file count.
            "stacks": _summarize_stacks(languages_seen, files_by_language),
            "total_files": total_files,
            "total_bytes": total_bytes,
            "limits": {
                "MIRA_SOURCE_FILE_LIMIT": source_file_limit_int,
                "MIRA_MAX_LLM_FILE_BYTES": max_llm_file_bytes,
                "MIRA_MAX_FILE_BYTES": max_file_bytes,
                "MIRA_MAX_CONCURRENT_LLM_CALLS": max_concurrent_llm,
                "MIRA_JOB_TIMEOUT_SECONDS": job_timeout_sec,
            },
            "within_limits": within_limits,
            "warnings": warnings,
            "estimate": {
                "total_llm_calls": total_files,
                "avg_seconds_per_file": avg_sec_per_file,
                "wall_clock_seconds": wall_clock_sec,
                "wall_clock_human": _humanize_seconds(wall_clock_sec),
                "estimated_tokens_input": est_tokens_in,
                "estimated_tokens_output": est_tokens_out,
                "estimated_cost_usd": round(est_cost, 2),
            },
        }
    finally:
        try:
            ssh_conn.disconnect()
        except Exception:
            pass


@router.get(
    "/jobs/{job_id}/progress",
    tags=["Utilities — Projects & Reports"],
    summary="Lightweight progress poll for any modernization job (for UI polling every 2-5s)",
)
async def get_job_progress(job_id: str, current_user: User = Depends(get_current_active_user)):
    """
    Returns just the progress block for a job — small payload suitable for polling
    every 2-5 seconds while a long migration is running. Works for any job_type.
    """
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        ModernizationJob.user_id == str(current_user.id),
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    return {
        "job_id": job_id,
        "status": job.status,
        "current_step": job.current_step,
        "current_task": job.current_task,
        "progress": _progress_block(job),
        "updated_at": job.updated_at.isoformat() if job.updated_at else None,
    }


@router.get(
    "/jobs/{job_id}/validation",
    tags=["Utilities — Projects & Reports"],
    summary="Post-migration validation report (tree-sitter + native linter + SonarQube delta)",
)
async def get_job_validation_report(
    job_id: str,
    include_per_file: bool = True,
    current_user: User = Depends(get_current_active_user),
):
    """
    Return the full validation report for a completed modernization job.

    Set ``include_per_file=false`` to receive only the summary counters (useful
    for dashboards). With ``include_per_file=true`` (default), the response
    includes up to 2000 per-file results; beyond that the list is truncated
    and ``files_truncated`` is set to true.
    """
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        ModernizationJob.user_id == str(current_user.id),
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    report = getattr(job, "validation_report", None)
    if not report:
        return {
            "job_id": job_id,
            "status": job.status,
            "validation_report": None,
            "message": (
                "Validation report not available yet — it is produced when a code-modernization "
                "job finishes. If the job is still running, poll /progress and retry."
            ),
        }
    if not include_per_file and isinstance(report, dict):
        report = {k: v for k, v in report.items() if k != "files"}
    return {
        "job_id": job_id,
        "status": job.status,
        "validation_report": report,
        "migration_state_snapshot": getattr(job, "migration_state_snapshot", None),
    }


# ---------- Job cancellation ----------

@router.post(
    "/jobs/{job_id}/resume",
    tags=["Utilities — Projects & Reports"],
    summary="Resume a failed/cancelled migration job — already-processed files are skipped",
)
async def resume_job(
    job_id: str,
    current_user: User = Depends(get_current_active_user),
):
    """
    Re-run a migration job that previously failed, was cancelled, or timed out.

    The new job inherits the *completed_files* list from the old one, so files already
    modernized in the prior run are skipped. Only remaining files are sent to the LLM.
    This avoids re-spending hours and tokens to redo work that's already done.

    The original job record is preserved (not deleted); the new job references it via
    ``resumed_from_job_id``. Inspect the new job's progress via ``/jobs/{new_job_id}/progress``.
    """
    old = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        ModernizationJob.user_id == str(current_user.id),
    )
    if not old:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    if old.status == "running":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Job is still running. Cancel it first, then resume.",
        )
    if old.job_type != "code_modernization":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Resume is only supported for code_modernization jobs; this one is '{old.job_type}'.",
        )

    new_job_id = f"{job_id}-resumed-{int(datetime.utcnow().timestamp())}"
    new_job = ModernizationJob(
        user_id=old.user_id,
        job_id=new_job_id,
        job_type=old.job_type,
        transform_id=old.transform_id,
        project_name=old.project_name,
        source_path=old.source_path,
        output_path=old.output_path,
        status="pending",  # background worker will flip to running
        current_step=old.current_step,
        files_total=old.files_total,
        files_processed=len(old.completed_files or []),
        completed_files=list(old.completed_files or []),
        resumed_from_job_id=old.job_id,
    )
    await new_job.insert()
    logger.info(
        "Created resume job %s from %s; %d files already done will be skipped",
        new_job_id, job_id, len(old.completed_files or []),
    )
    return {
        "job_id": new_job_id,
        "resumed_from_job_id": job_id,
        "status": "pending",
        "already_completed": len(old.completed_files or []),
        "message": (
            "Resume job created. The background worker will pick it up and skip "
            "files already completed in the prior run."
        ),
    }


@router.post(
    "/jobs/{job_id}/cancel",
    tags=["Utilities — Projects & Reports"],
    summary="Cancel a running migration job (marks as cancelled; background thread finishes current file then stops)",
)
async def cancel_job(
    job_id: str,
    current_user: User = Depends(get_current_active_user),
):
    """
    Mark a running job as **cancelled**.

    The background thread checks the DB status between files and stops processing when it
    sees the cancelled state. The current file being processed by the LLM completes normally
    (cannot interrupt mid-LLM-call), but no new files are started after cancellation.

    Already-uploaded stage snapshots on the client server remain in place — they are NOT
    deleted, so partial migration results are preserved.

    Returns the updated job status.
    """
    job = await ModernizationJob.find_one(
        ModernizationJob.job_id == job_id,
        ModernizationJob.user_id == str(current_user.id),
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found.")
    if job.status not in ("running",):
        return {
            "job_id": job_id,
            "status": job.status,
            "message": f"Job is already in state '{job.status}' — nothing to cancel.",
        }
    job.status = "cancelled"
    job.error_message = "Cancelled by user."
    job.completed_at = datetime.utcnow()
    job.updated_at = datetime.utcnow()
    await job.save()
    logger.info("Job %s cancelled by user %s", job_id, current_user.id)
    return {"job_id": job_id, "status": "cancelled", "message": "Job marked as cancelled."}


# ---------- List transforms (with step job IDs and statuses) ----------

@router.get(
    "/transforms",
    tags=["Utilities — Projects & Reports"],
    summary="List all migration transforms for current user (step job IDs and statuses)",
    response_model=List[TransformListItem],
)
async def list_transforms(current_user: User = Depends(get_current_active_user)):
    """Returns all transforms for the current user. Step job IDs and statuses are included only when the job exists and has status completed, running, or failed; steps with null job id or other status are omitted (null)."""
    user_ids_match = list({str(current_user.id), current_user.id})
    transforms = await (
        Transform.find(In(Transform.user_id, user_ids_match))
        .sort(-Transform.created_at)
        .to_list(10000)
    )
    VALID_STATUSES = frozenset({"completed", "running", "failed"})
    result: List[TransformListItem] = []
    for t in transforms:
        step_1_job_id, step_1_status = None, None
        step_2_job_id, step_2_status = None, None
        step_3_job_id, step_3_status = None, None
        step_4_job_id, step_4_status = None, None
        current_step = 0
        updated_project_name = None

        if t.step_1_job_id:
            current_step = max(current_step, 1)
            j1 = await ModernizationJob.find_one(ModernizationJob.job_id == t.step_1_job_id)
            if j1 and j1.status in VALID_STATUSES:
                step_1_job_id, step_1_status = t.step_1_job_id, j1.status
        if t.step_2_job_id:
            current_step = max(current_step, 2)
            j2 = await ModernizationJob.find_one(ModernizationJob.job_id == t.step_2_job_id)
            if j2 and j2.status in VALID_STATUSES:
                step_2_job_id, step_2_status = t.step_2_job_id, j2.status
        if t.step_3_job_id:
            current_step = max(current_step, 3)
            j3 = await ModernizationJob.find_one(ModernizationJob.job_id == t.step_3_job_id)
            if j3 and j3.status in VALID_STATUSES:
                step_3_job_id, step_3_status = t.step_3_job_id, j3.status
        if t.step_4_job_id:
            current_step = max(current_step, 4)
            j4 = await ModernizationJob.find_one(ModernizationJob.job_id == t.step_4_job_id)
            if j4 and j4.status in VALID_STATUSES:
                step_4_job_id, step_4_status = t.step_4_job_id, j4.status
                if getattr(j4, "output_path", None):
                    updated_project_name = j4.output_path.rstrip("/").split("/")[-1]

        result.append(
            TransformListItem(
                transform_id=t.transform_id,
                project_name=t.project_name,
                step_1_job_id=step_1_job_id,
                step_1_status=step_1_status,
                step_2_job_id=step_2_job_id,
                step_2_status=step_2_status,
                step_3_job_id=step_3_job_id,
                step_3_status=step_3_status,
                step_4_job_id=step_4_job_id,
                step_4_status=step_4_status,
                current_step=current_step,
                updated_project_name=updated_project_name,
                created_at=t.created_at,
                updated_at=t.updated_at,
            )
        )
    return result


def _job_summary(j: ModernizationJob) -> Dict[str, Any]:
    """Build a summary dict for list endpoints."""
    return {
        "job_id": j.job_id,
        "job_type": j.job_type,
        "project_name": j.project_name,
        "status": j.status,
        "current_step": j.current_step,
        "current_task": j.current_task,
        "tasks_completed": j.tasks_completed,
        "task_durations_sec": {
            "structure_analysis_sec": j.structure_analysis_duration_sec,
            "language_analysis_sec": j.language_analysis_duration_sec,
            "upgrade_analysis_sec": j.upgrade_analysis_duration_sec,
            "code_modernization_sec": j.code_modernization_duration_sec,
        },
        "source_path": j.source_path,
        "output_path": j.output_path,
        "error_message": j.error_message,
        "created_at": j.created_at,
        "updated_at": j.updated_at,
        "started_at": j.started_at,
        "completed_at": j.completed_at,
        "result": j.result,
    }


# =============================================================================
# SECURITY TEST AGENT — Post-Modernization Verification
# =============================================================================

REPORTS_DIR_AGENTS = Path("reports")


def _extract_base_project_name(upgraded_folder_name: str) -> str:
    """
    Extract the base project name from an upgraded folder name.
    
    Examples:
        'upgraded_calculatetotal_20260319_133022' -> 'calculatetotal'
        'upgraded_my_app_20260318_065344'         -> 'my_app'
    
    Strategy: strip 'upgraded_' prefix, then strip '_YYYYMMDD_HHMMSS' suffix.
    """
    import re
    name = upgraded_folder_name
    # Strip 'upgraded_' prefix
    if name.startswith("upgraded_"):
        name = name[len("upgraded_"):]
    # Strip '_YYYYMMDD_HHMMSS' suffix (underscore + 8 digits + underscore + 6 digits at end)
    name = re.sub(r"_\d{8}_\d{6}$", "", name)
    return name


@router.post(
    "/security-test",
    response_model=dict,
    tags=["Step 4 — Post-Migration Security Fix"],
    summary="Step 4: Security verification — cross-check modernized code against SonarQube findings",
)
async def security_test(
    request: SecurityTestRequest,
    current_user: User = Depends(get_current_active_user),
):
    """
    **Post-Modernization Security Verification**

    Cross-checks the **upgraded/migrated** code against the generic security report.

    Send just ``project_name`` — the API auto-resolves the upgraded folder from the DB
    (saved when Step 4 polling returns "completed"). You may still override with
    ``upgrade_project_name`` if you want to target a specific folder.

    The endpoint automatically:
    - Resolves upgraded folder from DB (UserProject.last_upgraded_path) if not provided
    - Constructs the SSH path on the **upgraded** code (not original source)
    - Finds the generic security report from ``reports/{base_name}_generic_security_*.md``

    **Output:** Resolved vs remaining issues with verification notes.
    """
    start_time = time.time()
    ssh_conn = None

    try:
        # --- Resolve upgraded folder name — from request override or DB ---
        upgraded_folder_name = await _resolve_upgraded_folder_name(
            current_user, request.project_name, request.upgrade_project_name
        )
        base_project_name = _extract_base_project_name(upgraded_folder_name)

        logger.info(
            "Security test: folder='%s', base_project='%s'",
            upgraded_folder_name,
            base_project_name,
        )

        # --- Fetch upgraded code from remote server via SSH ---
        if not current_user.ssh_hostname or not current_user.ssh_username:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No saved SSH credentials found. Test SSH connection first via /api/v1/analyze/test/ssh.",
            )

        # Construct the upgraded code path on the server
        upgraded_code_path = f"/home/{current_user.ssh_username}/upgraded-codes/{base_project_name}/{upgraded_folder_name}"

        password = decrypt_data(current_user.ssh_password_encrypted) if current_user.ssh_password_encrypted else None
        private_key = decrypt_data(current_user.ssh_private_key_encrypted) if current_user.ssh_private_key_encrypted else None
        private_key_password = decrypt_data(current_user.ssh_private_key_password_encrypted) if current_user.ssh_private_key_password_encrypted else None

        ssh_conn = SSHService.create_connection(
            hostname=current_user.ssh_hostname,
            port=current_user.ssh_port or 22,
            username=current_user.ssh_username,
            password=password,
            private_key=private_key,
            private_key_password=private_key_password,
        )
        if not ssh_conn.connect():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to connect to SSH server {current_user.ssh_hostname}:{current_user.ssh_port}.",
            )

        # Verify the upgraded code path exists on the server
        check_result = ssh_conn.execute_command(f"test -d '{upgraded_code_path}' && echo 'EXISTS'")
        if "EXISTS" not in check_result.get("stdout", ""):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Upgraded code folder not found on server: {upgraded_code_path}",
            )

        # Download upgraded PHP files to a temp directory
        import tempfile as _tempfile

        with _tempfile.TemporaryDirectory() as temp_dir:
            local_upgraded_path = Path(temp_dir) / upgraded_folder_name
            local_upgraded_path.mkdir(parents=True, exist_ok=True)

            result = ssh_conn.execute_command(
                f"find {upgraded_code_path} -type f -name '*.php' | head -500"
            )
            php_files = [
                f.strip()
                for f in result.get("stdout", "").strip().split("\n")
                if f.strip()
            ]

            if not php_files:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"No PHP files found in upgraded code path: {upgraded_code_path}",
                )

            for remote_file in php_files:
                rel_path = remote_file.replace(upgraded_code_path, "").lstrip("/")
                local_file = local_upgraded_path / rel_path
                local_file.parent.mkdir(parents=True, exist_ok=True)
                content_result = ssh_conn.execute_command(f"cat '{remote_file}'")
                if content_result.get("success"):
                    local_file.write_text(
                        content_result.get("stdout", ""),
                        encoding="utf-8",
                        errors="ignore",
                    )

            logger.info(
                "Downloaded %d PHP files from %s to %s",
                len(php_files),
                upgraded_code_path,
                local_upgraded_path,
            )

            # --- Run the Security Test Agent ---
            agent = SecurityTestAgent()
            run_result = agent.run(
                context={
                    "project_name": base_project_name,
                    "upgraded_code_path": str(local_upgraded_path),
                    "sonarqube_report_path": request.security_report_path,
                },
            )

        ssh_conn.disconnect()
        ssh_conn = None

        if not run_result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Security test failed: {run_result.get('errors', [])}",
            )

        results = run_result.get("results", {})
        sonarqube_verification = results.get("sonarqube_verification", {})
        php_guide_verification = results.get("php_guide_verification", {})

        elapsed = round(time.time() - start_time, 2)
        logger.info(
            "Security test for '%s' completed in %.2fs — SonarQube: %s/%s, PHP Guide: %s/%s",
            upgraded_folder_name,
            elapsed,
            sonarqube_verification.get("resolved_count", 0),
            sonarqube_verification.get("total_issues", 0),
            php_guide_verification.get("applied_count", 0),
            php_guide_verification.get("total_items", 0),
        )

        return {
            "success": True,
            "message": f"Security verification completed for '{upgraded_folder_name}'",
            "project_name": base_project_name,
            "base_project_name": base_project_name,
            "upgraded_folder_name": upgraded_folder_name,
            "upgraded_code_path": upgraded_code_path,
            "execution_time_seconds": elapsed,
            "sonarqube_verification": sonarqube_verification,
            "php_guide_verification": php_guide_verification,
            "timestamp": datetime.utcnow().isoformat(),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Security test failed: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Security test failed: {str(e)}",
        )
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


# ---------------------------------------------------------------------------
# Post-migration SonarQube issue fix endpoint (Llama 3.3 70B)
# ---------------------------------------------------------------------------


@router.post(
    "/fix-sonar-issues",
    response_model=dict,
    tags=["Step 4 — Post-Migration Security Fix"],
    summary="Step 4b: Fix remaining SonarQube issues in migrated code (LLM-assisted)",
)
async def fix_sonar_issues(
    request: FixSonarIssuesRequest,
    current_user: User = Depends(get_current_active_user),
):
    """
    **Post-Migration SonarQube Issue Fixer**

    Uses the SonarQube report from the Analyze step (Step 2) to automatically fix
    remaining issues in the migrated code using an LLM (code-fix tasks only).

    **Workflow:**
    1. Reads the SonarQube report (already fetched from Step 2)
    2. Downloads migrated code from the client SSH server
    3. For each issue: sends code + issue description to the LLM to fix
    4. Writes fixed files back to the client SSH server
    5. Returns summary of fixed vs remaining issues

    Only `project_name` is required — all paths are auto-resolved from DB.
    Set `dry_run: true` to preview fixes without writing files.
    """
    from app.services.sonarqube.report_fetcher import SonarQubeReportFetcher
    import os as _os

    start_time = time.time()
    ssh_conn = None

    try:
        project_name = request.project_name.strip()
        dry_run = request.dry_run

        if not current_user.ssh_hostname or not current_user.ssh_username:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No saved SSH credentials. Test SSH connection first via /api/v1/analyze/test/ssh.",
            )

        # Resolve sonar_project_key: request override → DB (per-language map → legacy single key) → project_name.
        # Per-language lookup uses ``last_sonar_project_keys[language]`` so multi-language fanouts
        # report against the right Sonar project; falls back to ``last_sonar_project_key`` and finally
        # the project name.
        sonar_project_key = (request.sonar_project_key or "").strip()
        if not sonar_project_key:
            user_project_for_sonar = await UserProject.find_one(
                UserProject.user_id == str(current_user.id),
                UserProject.project_name == project_name,
            )
            requested_lang = (getattr(request, "language", None) or "").strip().lower()
            sonar_project_key = (
                _resolve_sonar_key_for_language(user_project_for_sonar, requested_lang)
                or project_name
            )

        # Resolve stage path: request override → DB (UserProject.last_upgraded_path) → SSH probe
        stage_path = (request.stage_path or "").strip()
        if not stage_path:
            # Try DB first — avoids SSH round-trip
            _up = await UserProject.find_one(
                UserProject.user_id == str(current_user.id),
                UserProject.project_name == project_name,
            )
            if _up and _up.last_upgraded_path:
                stage_path = _up.last_upgraded_path.rstrip("/")
                logger.info("fix-sonar-issues: resolved stage_path from DB: %s", stage_path)
        if not stage_path:
            try:
                home = _client_ssh_home(current_user)
                # Find latest stage for this project
                password = decrypt_data(current_user.ssh_password_encrypted) if current_user.ssh_password_encrypted else None
                private_key = decrypt_data(current_user.ssh_private_key_encrypted) if current_user.ssh_private_key_encrypted else None
                private_key_password = decrypt_data(current_user.ssh_private_key_password_encrypted) if current_user.ssh_private_key_password_encrypted else None

                _ssh_probe = SSHService.create_connection(
                    hostname=current_user.ssh_hostname,
                    port=current_user.ssh_port or 22,
                    username=current_user.ssh_username,
                    password=password,
                    private_key=private_key,
                    private_key_password=private_key_password,
                )
                if _ssh_probe.connect():
                    migrated_base = f"{home}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}/{project_name}"
                    ls_result = _ssh_probe.execute_command(
                        f"ls -d '{migrated_base}/stage_'* 2>/dev/null | sort | tail -1"
                    )
                    _ssh_probe.disconnect()
                    last_stage = (ls_result.get("stdout") or "").strip()
                    if last_stage:
                        stage_path = last_stage
            except Exception as _path_err:
                logger.warning("fix-sonar-issues: could not auto-resolve stage_path: %s", _path_err)

        if not stage_path:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    "Could not resolve migrated code path. Either provide stage_path explicitly, "
                    "or run the migration pipeline first so stage folders exist on the client server."
                ),
            )

        # Fetch SonarQube report
        sonar_token = (_os.environ.get("SONAR_TOKEN") or getattr(settings, "SONAR_TOKEN", None) or "").strip()
        sonar_host_url = (_os.environ.get("SONAR_HOST_URL") or getattr(settings, "SONAR_HOST_URL", None) or "https://sonarqube.codsy.ai").strip()

        if not sonar_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="SONAR_TOKEN is not configured. Set it in the .env file.",
            )

        fetcher = SonarQubeReportFetcher(sonar_host_url=sonar_host_url, sonar_token=sonar_token)
        sonar_report = fetcher.get_full_report(sonar_project_key)
        if not sonar_report.get("success"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Could not fetch SonarQube report for '{sonar_project_key}': {sonar_report.get('error', 'unknown error')}. Run Step 2 (analyze) first.",
            )

        issues = sonar_report.get("issues", {}).get("items", [])
        if not issues:
            return {
                "success": True,
                "message": "No SonarQube issues found — nothing to fix.",
                "project_name": project_name,
                "stage_path": stage_path,
                "fixed_count": 0,
                "skipped_count": 0,
                "execution_time_seconds": round(time.time() - start_time, 2),
            }

        logger.info(
            "fix-sonar-issues: project=%s stage=%s issues=%d dry_run=%s",
            project_name, stage_path, len(issues), dry_run,
        )

        # Connect SSH
        password = decrypt_data(current_user.ssh_password_encrypted) if current_user.ssh_password_encrypted else None
        private_key = decrypt_data(current_user.ssh_private_key_encrypted) if current_user.ssh_private_key_encrypted else None
        private_key_password = decrypt_data(current_user.ssh_private_key_password_encrypted) if current_user.ssh_private_key_password_encrypted else None

        ssh_conn = SSHService.create_connection(
            hostname=current_user.ssh_hostname,
            port=current_user.ssh_port or 22,
            username=current_user.ssh_username,
            password=password,
            private_key=private_key,
            private_key_password=private_key_password,
        )
        if not ssh_conn.connect():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to connect to SSH server {current_user.ssh_hostname}.",
            )

        # Llama 3.3 70B client — specialized for pure code fixing (no migration guidance context)
        fix_client = GroqClient(model="llama-3.3-70b-versatile")

        # Group issues by file component
        from collections import defaultdict as _defaultdict
        issues_by_file: dict = _defaultdict(list)
        for issue in issues:
            component = issue.get("component", "")
            # component is like "project_key:path/to/file.php" — extract path
            file_path = component.split(":", 1)[-1] if ":" in component else component
            if file_path:
                issues_by_file[file_path].append(issue)

        fixed_count = 0
        skipped_count = 0
        fix_results = []

        for rel_path, file_issues in issues_by_file.items():
            remote_file = f"{stage_path.rstrip('/')}/{rel_path}"
            read_result = ssh_conn.execute_command(f"cat '{remote_file}' 2>/dev/null")
            if not read_result.get("success") or not read_result.get("stdout"):
                logger.warning("fix-sonar-issues: could not read %s — skipping", remote_file)
                skipped_count += 1
                fix_results.append({"file": rel_path, "status": "skipped", "reason": "file not readable"})
                continue

            original_code = read_result["stdout"]

            # Size-driven dispatch: small files in one shot, large files in line-aware chunks.
            # Previous behavior silently skipped files >60 KB; now we chunk and fix every chunk.
            _FIX_SONAR_MAX_FILE_CHARS = int(os.environ.get("MIRA_FIX_SONAR_MAX_FILE_CHARS", str(300_000)))

            def _fix_one_shot(code_text: str, issues_for_call: list) -> str:
                """Send the full file plus its issues to the LLM. Returns the fixed text
                or raises. Uses GroqClient.generate (which has built-in 429 retry + backoff).
                """
                issue_text = "\n".join(
                    f"- Line {iss.get('line', '?')}: [{iss.get('severity','?')}] {iss.get('message','')}"
                    for iss in issues_for_call[:30]
                )
                system_prompt = (
                    "You are a code quality engineer. Fix ONLY the listed SonarQube issues. "
                    "Preserve all functionality. Return ONLY the fixed code with no markdown fences, "
                    "no explanation, no commentary."
                )
                user_content = (
                    f"FILE: {rel_path}\n\n"
                    f"SONARQUBE ISSUES TO FIX:\n{issue_text}\n\n"
                    f"ORIGINAL CODE:\n```\n{code_text}\n```\n"
                )
                return fix_client.generate(
                    system_prompt=system_prompt,
                    user_content=user_content,
                    temperature=0.0,
                )

            def _fix_chunked(code_text: str, issues_list: list) -> tuple:
                """Split the file into sequential chunks of ~_FIX_SONAR_MAX_FILE_CHARS,
                route each issue to the chunk containing its line, fix chunks, concatenate.
                Returns (fixed_text, chunks_processed, chunks_failed)."""
                lines = code_text.splitlines(keepends=True)
                if not lines:
                    return code_text, 0, 0

                # Build chunks as (start_line_1based, end_line_1based, text)
                chunks = []
                cur_start = 1
                cur_bytes = 0
                cur_lines = []
                for i, line in enumerate(lines, start=1):
                    if cur_bytes + len(line) > _FIX_SONAR_MAX_FILE_CHARS and cur_lines:
                        chunks.append((cur_start, i - 1, "".join(cur_lines)))
                        cur_start = i
                        cur_lines = []
                        cur_bytes = 0
                    cur_lines.append(line)
                    cur_bytes += len(line)
                if cur_lines:
                    chunks.append((cur_start, len(lines), "".join(cur_lines)))

                # Bucket issues into the chunk whose line range contains them
                buckets = [[] for _ in chunks]
                for iss in issues_list:
                    try:
                        line_no = int(iss.get("line") or 0)
                    except (TypeError, ValueError):
                        line_no = 0
                    for idx, (s, e, _t) in enumerate(chunks):
                        if s <= line_no <= e:
                            buckets[idx].append(iss)
                            break
                    else:
                        # No line info — attach to the last chunk so it's not lost
                        if buckets:
                            buckets[-1].append(iss)

                fixed_parts = []
                chunks_ok = 0
                chunks_fail = 0
                for idx, ((s, e, text), bucket) in enumerate(zip(chunks, buckets), start=1):
                    if not bucket:
                        # No issues in this chunk — pass through unchanged
                        fixed_parts.append(text)
                        chunks_ok += 1
                        continue
                    logger.info(
                        "fix-sonar-issues: chunk %d/%d of %s (lines %d-%d, %d issues, %d chars)",
                        idx, len(chunks), rel_path, s, e, len(bucket), len(text),
                    )
                    try:
                        fixed_chunk = _fix_one_shot(text, bucket)
                        if not fixed_chunk or not fixed_chunk.strip():
                            # Empty LLM response for this chunk → keep original chunk to avoid data loss
                            logger.warning("chunk %d returned empty; keeping original", idx)
                            fixed_parts.append(text)
                            chunks_fail += 1
                        else:
                            fixed_parts.append(fixed_chunk)
                            chunks_ok += 1
                    except Exception as chunk_err:
                        logger.warning("chunk %d failed: %s — keeping original", idx, chunk_err)
                        fixed_parts.append(text)
                        chunks_fail += 1

                return "".join(fixed_parts), chunks_ok, chunks_fail

            try:
                if len(original_code) <= _FIX_SONAR_MAX_FILE_CHARS:
                    fixed_code = _fix_one_shot(original_code, file_issues)
                    chunks_ok, chunks_fail = 1, 0
                else:
                    logger.info(
                        "fix-sonar-issues: %s is %d chars (> %d limit) — chunking",
                        rel_path, len(original_code), _FIX_SONAR_MAX_FILE_CHARS,
                    )
                    fixed_code, chunks_ok, chunks_fail = _fix_chunked(original_code, file_issues)
            except Exception as llm_err:
                logger.error("fix-sonar-issues: LLM error for %s: %s", rel_path, llm_err)
                skipped_count += 1
                fix_results.append({"file": rel_path, "status": "skipped", "reason": f"LLM error: {llm_err}"})
                continue

            if not fixed_code or not fixed_code.strip():
                skipped_count += 1
                fix_results.append({"file": rel_path, "status": "skipped", "reason": "LLM returned empty response"})
                continue

            result_entry = {
                "file": rel_path,
                "issues_addressed": len(file_issues),
                "chunks_ok": chunks_ok,
                "chunks_failed": chunks_fail,
            }
            if not dry_run:
                write_ok = ssh_conn.write_file(remote_file, fixed_code, backup=True)
                if write_ok:
                    fixed_count += 1
                    result_entry["status"] = "fixed"
                    fix_results.append(result_entry)
                else:
                    skipped_count += 1
                    result_entry["status"] = "skipped"
                    result_entry["reason"] = "SFTP write failed"
                    fix_results.append(result_entry)
            else:
                fixed_count += 1
                result_entry["status"] = "would_fix"
                fix_results.append(result_entry)

        elapsed = round(time.time() - start_time, 2)
        return {
            "success": True,
            "message": f"{'[DRY RUN] Would fix' if dry_run else 'Fixed'} {fixed_count} file(s), skipped {skipped_count}",
            "project_name": project_name,
            "stage_path": stage_path,
            "sonar_project_key": sonar_project_key,
            "total_issues": len(issues),
            "files_processed": len(issues_by_file),
            "fixed_count": fixed_count,
            "skipped_count": skipped_count,
            "dry_run": dry_run,
            "llm_model": "llama-3.3-70b-versatile",
            "fix_results": fix_results,
            "execution_time_seconds": elapsed,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error("fix-sonar-issues failed: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"fix-sonar-issues failed: {str(e)}",
        )
    finally:
        if ssh_conn:
            ssh_conn.disconnect()


# ---------------------------------------------------------------------------
# Path resolution utility endpoint
# ---------------------------------------------------------------------------


@router.get(
    "/resolve-project-path/{project_name}",
    response_model=dict,
    tags=["Utilities — Projects & Reports"],
    summary="Resolve all project paths from project_name (no source_path needed by frontend)",
    description=(
        "Returns all auto-resolved paths for a project: original source path, "
        "migrated-codes base, and upgraded-codes base. Uses the saved ssh_source_path "
        "from the user profile so the frontend never needs to ask for source_path."
    ),
)
async def resolve_project_path(
    project_name: str,
    to_version: Optional[str] = None,
    language: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
):
    """
    Resolve all project paths from just the project name.

    Returns what paths the pipeline will use, so the frontend can display
    them without the user manually entering paths.
    """
    result: Dict[str, Any] = {
        "project_name": project_name,
        "ssh_source_path": current_user.ssh_source_path,
    }

    # Original project source path (Step 1 input)
    try:
        result["original_source_path"] = _resolve_original_project_source_path(
            current_user, project_name
        )
    except HTTPException as e:
        result["original_source_path"] = None
        result["original_source_path_error"] = e.detail

    # Migrated-codes base
    try:
        home = _client_ssh_home(current_user)
        result["migrated_codes_base"] = (
            f"{home}/{DEFAULT_REMOTE_STAGED_MIGRATION_DIR}/{project_name}"
        )
    except HTTPException:
        result["migrated_codes_base"] = None

    # Upgraded-codes base
    try:
        result["upgraded_codes_base"] = _remote_upgraded_codes_project_base(
            current_user, project_name
        )
    except HTTPException:
        result["upgraded_codes_base"] = None

    # If to_version provided, try to find the specific migrated stage.
    # Auto-resolve language from the most recent transform if not supplied.
    if to_version:
        lang = (language or "").strip().lower()
        if not lang:
            try:
                latest = await Transform.find_one(
                    Transform.user_id == str(current_user.id),
                    Transform.project_name == project_name,
                    sort=[("created_at", -1)],
                )
                if latest:
                    lang = await _get_transform_language(latest)
            except Exception:
                pass
            lang = lang or "php"
        try:
            result["migrated_stage_path"] = _resolve_migrated_stage_source_path(
                current_user, project_name, to_version, language=lang,
            )
            result["migrated_stage_language"] = lang
        except HTTPException as e:
            result["migrated_stage_path"] = None
            result["migrated_stage_path_note"] = e.detail

    return result


# ===========================================================================
# Phase 0 endpoints — Contract Registry, Dependency Graph, Validation, Proxy
#
# These four endpoints implement the Phase 0 / Phase 2 architecture from the
# full-stack migration spec. They are deterministic (no LLM), so they're safe
# to run multiple times against the same project — each call produces a fresh
# timestamped artifact under app/data/contracts/<project>/ or app/data/graphs/<project>/.
# ===========================================================================


async def _resolve_source_path_for_phase0(current_user: User, project_name: str) -> str:
    """Resolve the project's source path on the customer VM. Phase 0 always
    runs against the *original* (pre-migration) source — never the migrated
    stage — so the registry captures the legacy contract as-is.

    Resolution order:
        1. ``UserProject.vm_code_path`` if explicitly set on the project record
           (this is what the user told us during project setup).
        2. ``_resolve_original_project_source_path`` (legacy helper).
        3. ``_resolve_project_source_path`` (catch-all fallback).
    """
    try:
        up = await UserProject.find_one(
            UserProject.user_id == str(current_user.id),
            UserProject.project_name == project_name,
        )
        logger.info("phase0 resolver: project_name=%s user_id=%s found=%s vm_code_path=%s",
                    project_name, str(current_user.id), bool(up), (up.vm_code_path if up else None))
        if up and (up.vm_code_path or "").strip():
            return up.vm_code_path.strip().rstrip("/")
    except Exception as e:
        logger.warning("phase0 resolver: vm_code_path lookup failed: %s", e)
    try:
        return _resolve_original_project_source_path(current_user, project_name)
    except Exception:
        return _resolve_project_source_path(current_user, project_name)


def _enumerate_files_over_ssh(current_user: User, source_path: str) -> Tuple[Dict[str, List[str]], Any]:
    """Enumerate Python/PHP/JS/TS files under `source_path` on the user's VM
    and return both the file map and the open SSH connection (caller must
    disconnect). Reuses the existing _list_remote_source_files helper."""
    password = decrypt_data(current_user.ssh_password_encrypted) if current_user.ssh_password_encrypted else None
    private_key = decrypt_data(current_user.ssh_private_key_encrypted) if current_user.ssh_private_key_encrypted else None
    private_key_password = decrypt_data(current_user.ssh_private_key_password_encrypted) if current_user.ssh_private_key_password_encrypted else None
    ssh_conn = SSHService.create_connection(
        hostname=current_user.ssh_hostname,
        port=current_user.ssh_port or 22,
        username=current_user.ssh_username,
        password=password,
        private_key=private_key,
        private_key_password=private_key_password,
    )
    if not ssh_conn.connect():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SSH connection failed to {current_user.ssh_hostname}",
        )
    files_by_lang: Dict[str, List[str]] = {}
    for lang in ("php", "python", "javascript", "typescript"):
        try:
            files = _list_remote_source_files(ssh_conn, source_path, language=lang, limit=None)
            if files:
                files_by_lang[lang] = files
        except Exception as e:
            logger.warning("Phase 0 enumerate failed for %s: %s", lang, e)
    return files_by_lang, ssh_conn


def _phase0_local_mirror_dir(project_name: str) -> Path:
    """Where Phase 0 caches the source files locally for parsing. Reused
    across calls so we don't re-download on every contract refresh."""
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", project_name or "unknown")
    base = Path(os.environ.get("MIRA_PHASE0_CACHE_DIR", "/tmp/mira-phase0-cache"))
    return base / safe


def _download_for_phase0(ssh_conn, files_by_lang: Dict[str, List[str]], remote_root: str, project_name: str) -> Tuple[str, Dict[str, List[str]]]:
    """Download remote files to a local cache so the Phase 0 agents can
    parse them with the regular file APIs. Returns the local root and a
    files_by_lang dict where paths are now local."""
    local_root = _phase0_local_mirror_dir(project_name)
    local_root.mkdir(parents=True, exist_ok=True)
    flat_remote: List[str] = []
    for files in files_by_lang.values():
        flat_remote.extend(files)
    if not flat_remote:
        return str(local_root), {}
    _download_source_files_to_local(ssh_conn, flat_remote, remote_root, local_root, language=None)
    # Re-map per-language file lists to local paths.
    local_by_lang: Dict[str, List[str]] = {}
    for lang, remotes in files_by_lang.items():
        local_files: List[str] = []
        for r in remotes:
            try:
                rel = Path(r).relative_to(remote_root)
            except ValueError:
                rel = Path(r).name
            local_files.append(str(local_root / rel))
        local_by_lang[lang] = local_files
    return str(local_root), local_by_lang


@router.post(
    "/phase0/contract-extract",
    tags=["Phase 0 — Full-stack migration"],
    summary="Extract API contract registry (OpenAPI 3.0) from a project's source code",
)
async def phase0_contract_extract(
    request: Dict[str, Any],
    current_user: User = Depends(get_current_active_user),
):
    """
    Walk the project tree and extract every API endpoint into an OpenAPI 3.0
    spec — the **Contract Registry**. Both the frontend and backend migration
    agents read from this registry during Phase 1 so they cannot drift apart.

    Request body: ``{"project_name": "my-app"}``

    Returns:
        ``{"openapi_path": "...", "endpoints_total": N, "frameworks": {...},
           "skipped_files": [...], "report": {...}}``

    The registry is written to ``/app/app/data/contracts/<project>/registry-latest.yaml``
    plus a timestamped copy. The Contract Validation Agent later compares the
    post-migration extracted contract against this immutable baseline.
    """
    from app.services.agents.contract_extraction_agent import extract_contract, registry_dir_for

    project_name = (request or {}).get("project_name", "").strip()
    if not project_name:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="project_name is required")
    if not current_user.ssh_hostname:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No saved SSH credentials. Test SSH first.")

    source_path = await _resolve_source_path_for_phase0(current_user, project_name)
    files_remote, ssh_conn = _enumerate_files_over_ssh(current_user, source_path)
    try:
        local_root, files_local = _download_for_phase0(ssh_conn, files_remote, source_path, project_name)
    finally:
        try:
            ssh_conn.disconnect()
        except Exception:
            pass

    spec, report = extract_contract(local_root, project_name, files_by_language=files_local, save=True)
    return {
        "project_name": project_name,
        "openapi_path": str(registry_dir_for(project_name) / "registry-latest.yaml"),
        "endpoints_total": sum(len(v) for v in spec.get("paths", {}).values()),
        "endpoints_by_framework": report.endpoints_by_framework,
        "files_scanned": report.total_files_scanned,
        "skipped_files_count": len(report.skipped_files),
        "report": report.to_dict(),
    }


@router.post(
    "/phase0/dependency-graph",
    tags=["Phase 0 — Full-stack migration"],
    summary="Build a cross-stack dependency graph for a project",
)
async def phase0_dependency_graph(
    request: Dict[str, Any],
    current_user: User = Depends(get_current_active_user),
):
    """
    Build a directed file-level dependency graph: which file imports/requires/uses
    which other file. Used by the migration scheduler to decide migration order
    and by the Contract Validation Agent to surface cross-stack coupling.
    """
    from app.services.agents.dependency_graph_agent import build_graph, graph_dir_for

    project_name = (request or {}).get("project_name", "").strip()
    if not project_name:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="project_name is required")
    if not current_user.ssh_hostname:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No saved SSH credentials. Test SSH first.")

    source_path = await _resolve_source_path_for_phase0(current_user, project_name)
    files_remote, ssh_conn = _enumerate_files_over_ssh(current_user, source_path)
    try:
        local_root, files_local = _download_for_phase0(ssh_conn, files_remote, source_path, project_name)
    finally:
        try:
            ssh_conn.disconnect()
        except Exception:
            pass

    g = build_graph(local_root, project_name, files_by_language=files_local, save=True)
    return {
        "project_name": project_name,
        "graph_path": str(graph_dir_for(project_name) / "graph-latest.json"),
        "nodes": len(g.nodes),
        "edges": len(g.edges),
        "totals": g.metadata.get("totals", {}),
    }


@router.post(
    "/phase2/contract-validate",
    tags=["Phase 0 — Full-stack migration"],
    summary="Diff post-migration code against the locked Contract Registry; classify changes",
)
async def phase2_contract_validate(
    request: Dict[str, Any],
    current_user: User = Depends(get_current_active_user),
):
    """
    Re-extract the contract from the **migrated** code, diff it against the
    Phase-0 baseline, and classify every difference as Safe / Additive /
    Breaking. Returns a report and a markdown summary suitable for posting in
    PR descriptions or Slack.

    Request body:
        ``{"project_name": "my-app", "migrated_path": "/optional/override/path"}``

    By default, the migrated source is taken from the latest ``upgraded-codes``
    folder on the user's VM. If you want to validate a different snapshot,
    pass ``migrated_path``.
    """
    from app.services.agents.contract_extraction_agent import (
        extract_contract, load_latest_registry,
    )
    from app.services.agents.contract_validation_agent import (
        validate_contracts, validation_dir_for,
    )

    project_name = (request or {}).get("project_name", "").strip()
    if not project_name:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="project_name is required")

    before_spec = load_latest_registry(project_name)
    if before_spec is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "No Phase-0 Contract Registry found for this project. "
                "Run POST /phase0/contract-extract first."
            ),
        )

    # Resolve the migrated path. The spec calls for "after migration" code —
    # use upgraded-codes by default, allow caller override.
    migrated_path = (request or {}).get("migrated_path", "").strip()
    if not migrated_path:
        try:
            user_project = await UserProject.find_one(
                UserProject.user_id == str(current_user.id),
                UserProject.project_name == project_name,
            )
            if user_project and user_project.last_upgraded_path:
                migrated_path = user_project.last_upgraded_path.rstrip("/")
        except Exception:
            migrated_path = ""
        if not migrated_path:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    "Could not auto-resolve migrated path; pass migrated_path explicitly. "
                    "Step 4 must have produced an upgraded-codes folder first."
                ),
            )

    # Enumerate and download the migrated source for re-extraction.
    files_remote, ssh_conn = _enumerate_files_over_ssh(current_user, migrated_path)
    try:
        local_root, files_local = _download_for_phase0(
            ssh_conn, files_remote, migrated_path, f"{project_name}__post_migration"
        )
    finally:
        try:
            ssh_conn.disconnect()
        except Exception:
            pass

    after_spec, _after_report = extract_contract(
        local_root, f"{project_name}__post_migration",
        files_by_language=files_local, save=False,
    )

    report = validate_contracts(project_name, before_spec, after_spec, save=True)
    return {
        "project_name": project_name,
        "report_path": str(validation_dir_for(project_name) / "report-latest.json"),
        "deployment_blocked": report.deployment_blocked,
        "totals": {
            "breaking": report.overall_breaking,
            "additive": report.overall_additive,
            "safe": report.overall_safe,
        },
        "before_endpoint_count": report.before_endpoint_count,
        "after_endpoint_count": report.after_endpoint_count,
        "report": report.to_dict(),
    }


@router.post(
    "/phase1/strangler-fig",
    tags=["Phase 0 — Full-stack migration"],
    summary="Generate nginx Strangler Fig proxy config from the contract registry",
)
async def phase1_strangler_fig(
    request: Dict[str, Any],
    current_user: User = Depends(get_current_active_user),
):
    """
    Generate the nginx config + deploy runbook + route assignment table for
    the Strangler Fig proxy. The proxy itself is **deployed by the operator**
    during a maintenance window — Mira does not push it to the VM.

    Request body:
        ``{"project_name": "my-app",
           "legacy_upstream": "http://10.0.0.5:8080",
           "new_upstream": "http://10.0.0.6:8080",
           "migrated_routes": [{"path": "/api/users", "method": "GET"}, ...]}``

    Returns paths to the generated config files plus the route assignment
    table.
    """
    from app.services.agents.contract_extraction_agent import load_latest_registry
    from app.services.agents.strangler_fig_agent import generate_proxy_config

    project_name = (request or {}).get("project_name", "").strip()
    if not project_name:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="project_name is required")

    spec = load_latest_registry(project_name)
    if spec is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No Contract Registry — run POST /phase0/contract-extract first.",
        )

    legacy_upstream = (request or {}).get("legacy_upstream") or "http://legacy-backend:8080"
    new_upstream = (request or {}).get("new_upstream") or "http://new-backend:8080"
    migrated_routes = (request or {}).get("migrated_routes") or []

    out = generate_proxy_config(
        project_name,
        spec,
        legacy_upstream=legacy_upstream,
        new_upstream=new_upstream,
        migrated_routes=migrated_routes,
        save=True,
    )
    return {"project_name": project_name, **out}


@router.get(
    "/phase0/registry/{project_name}",
    tags=["Phase 0 — Full-stack migration"],
    summary="Fetch the latest Contract Registry for a project",
)
async def phase0_get_registry(
    project_name: str,
    current_user: User = Depends(get_current_active_user),
):
    """Return the latest OpenAPI 3.0 registry for a project. 404 if Phase 0 hasn't run yet."""
    from app.services.agents.contract_extraction_agent import load_latest_registry
    spec = load_latest_registry(project_name)
    if spec is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No registry found — run /phase0/contract-extract first.")
    return spec


@router.get(
    "/phase0/dependency-graph/{project_name}",
    tags=["Phase 0 — Full-stack migration"],
    summary="Fetch the latest dependency graph for a project",
)
async def phase0_get_graph(
    project_name: str,
    current_user: User = Depends(get_current_active_user),
):
    """Return the latest dependency graph JSON. 404 if not built yet."""
    from app.services.agents.dependency_graph_agent import load_latest_graph
    g = load_latest_graph(project_name)
    if g is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No graph found — run /phase0/dependency-graph first.")
    return g


@router.get(
    "/phase2/validation-report/{project_name}",
    tags=["Phase 0 — Full-stack migration"],
    summary="Fetch the latest contract validation report for a project",
)
async def phase2_get_report(
    project_name: str,
    current_user: User = Depends(get_current_active_user),
):
    """Return the latest Contract Validation report JSON. 404 if not run yet."""
    from app.services.agents.contract_validation_agent import load_latest_report
    r = load_latest_report(project_name)
    if r is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No validation report found — run /phase2/contract-validate first.")
    return r
