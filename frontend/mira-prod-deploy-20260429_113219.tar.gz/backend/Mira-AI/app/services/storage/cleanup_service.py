"""Cleanup service for expired projects"""
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict
from app.services.storage.file_storage import FileStorageService
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class CleanupService:
    """Handles automatic cleanup of old projects"""
    
    def __init__(self, storage_service: FileStorageService):
        self.storage = storage_service
        self.retention_days = settings.STORAGE_RETENTION_DAYS
    
    def cleanup_expired_projects(self) -> Dict:
        """
        Delete projects older than retention period
        
        Returns:
            Dictionary with cleanup statistics
        """
        projects_dir = self.storage.projects_dir
        cutoff_date = datetime.utcnow() - timedelta(days=self.retention_days)
        
        deleted_projects = []
        deleted_count = 0
        total_freed_bytes = 0
        
        if not projects_dir.exists():
            return {
                "deleted_count": 0,
                "freed_bytes": 0,
                "deleted_projects": []
            }
        
        # Iterate through user directories
        for user_dir in projects_dir.iterdir():
            if not user_dir.is_dir():
                continue
            
            try:
                user_id = int(user_dir.name)
            except ValueError:
                continue
            
            # Iterate through project directories
            for project_dir in user_dir.iterdir():
                if not project_dir.is_dir():
                    continue
                
                try:
                    project_id = int(project_dir.name)
                except ValueError:
                    continue
                
                metadata_path = project_dir / "metadata.json"
                if not metadata_path.exists():
                    # No metadata, check directory modification time
                    try:
                        dir_mtime = datetime.fromtimestamp(project_dir.stat().st_mtime)
                        created_at = dir_mtime
                    except OSError:
                        continue
                else:
                    try:
                        metadata = self.storage._read_json(metadata_path)
                        created_at_str = metadata.get("created_at")
                        if not created_at_str:
                            continue
                        created_at = datetime.fromisoformat(created_at_str.replace("Z", "+00:00"))
                    except (ValueError, KeyError) as e:
                        logger.warning(f"Error parsing metadata for {project_dir}: {e}")
                        continue
                
                if created_at.replace(tzinfo=None) < cutoff_date:
                    # Calculate size before deletion
                    try:
                        size = self.storage.get_storage_size(project_id, user_id)
                        total_freed_bytes += size
                    except Exception as e:
                        logger.warning(f"Error calculating size for {project_dir}: {e}")
                    
                    # Delete project
                    try:
                        self.storage.delete_project(project_id, user_id)
                        deleted_projects.append({
                            "project_id": project_id,
                            "user_id": user_id,
                            "created_at": created_at.isoformat(),
                            "size_bytes": size
                        })
                        deleted_count += 1
                        logger.info(f"Deleted expired project {project_id} (user {user_id})")
                    except Exception as e:
                        logger.error(f"Error deleting project {project_dir}: {e}")
        
        result = {
            "deleted_count": deleted_count,
            "freed_bytes": total_freed_bytes,
            "freed_mb": round(total_freed_bytes / (1024 * 1024), 2),
            "deleted_projects": deleted_projects
        }
        
        logger.info(f"Cleanup completed: {deleted_count} projects deleted, "
                   f"{result['freed_mb']} MB freed")
        
        return result
    
    def get_storage_statistics(self) -> Dict:
        """Get overall storage statistics"""
        projects_dir = self.storage.projects_dir
        
        if not projects_dir.exists():
            return {
                "total_projects": 0,
                "total_users": 0,
                "total_size_bytes": 0,
                "total_size_gb": 0
            }
        
        total_size = 0
        total_projects = 0
        user_count = 0
        
        for user_dir in projects_dir.iterdir():
            if not user_dir.is_dir():
                continue
            
            try:
                user_id = int(user_dir.name)
                user_count += 1
            except ValueError:
                continue
            
            for project_dir in user_dir.iterdir():
                if not project_dir.is_dir():
                    continue
                
                try:
                    project_id = int(project_dir.name)
                    total_projects += 1
                    
                    # Calculate size
                    for file_path in project_dir.rglob("*"):
                        if file_path.is_file():
                            try:
                                total_size += file_path.stat().st_size
                            except (OSError, FileNotFoundError):
                                pass
                except ValueError:
                    continue
        
        return {
            "total_projects": total_projects,
            "total_users": user_count,
            "total_size_bytes": total_size,
            "total_size_gb": round(total_size / (1024 * 1024 * 1024), 2),
            "workspace_path": str(self.storage.workspace_root.absolute())
        }

