"""Encryption utilities for sensitive data"""
from cryptography.fernet import Fernet
from app.core.config import settings
from app.core.logging import get_logger
import base64
import hashlib

logger = get_logger(__name__)


def get_encryption_key() -> bytes:
    """
    Get encryption key from settings
    
    Uses SECRET_KEY from settings to derive a Fernet-compatible key
    """
    secret_key = settings.SECRET_KEY
    # Use SHA256 to create a 32-byte key from SECRET_KEY
    key_hash = hashlib.sha256(secret_key.encode()).digest()
    # Fernet requires base64-encoded 32-byte key
    return base64.urlsafe_b64encode(key_hash)


def encrypt_data(data: str) -> str:
    """
    Encrypt string data
    
    Args:
        data: Plain text string to encrypt
    
    Returns:
        Encrypted string (base64 encoded)
    """
    try:
        key = get_encryption_key()
        fernet = Fernet(key)
        encrypted = fernet.encrypt(data.encode())
        return encrypted.decode()
    except Exception as e:
        logger.error(f"Encryption failed: {e}")
        raise


def decrypt_data(encrypted_data: str) -> str:
    """
    Decrypt encrypted string data
    
    Args:
        encrypted_data: Encrypted string (base64 encoded)
    
    Returns:
        Decrypted plain text string
    """
    try:
        key = get_encryption_key()
        fernet = Fernet(key)
        decrypted = fernet.decrypt(encrypted_data.encode())
        return decrypted.decode()
    except Exception as e:
        logger.error(f"Decryption failed: {e}")
        raise

