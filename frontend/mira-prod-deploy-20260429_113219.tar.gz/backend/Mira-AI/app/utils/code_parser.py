"""Code parsing utilities"""
import ast
from pathlib import Path
from typing import Dict, List, Optional
from app.core.logging import get_logger

logger = get_logger(__name__)


def parse_python_file(file_path: Path) -> Optional[ast.Module]:
    """
    Parse Python file into AST
    
    Args:
        file_path: Path to Python file
        
    Returns:
        AST Module or None if parsing fails
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            source = f.read()
        return ast.parse(source, filename=str(file_path))
    except Exception as e:
        logger.error(f"Failed to parse {file_path}: {str(e)}")
        return None


def extract_functions(tree: ast.Module) -> List[Dict]:
    """
    Extract function definitions from AST
    
    Args:
        tree: AST Module
        
    Returns:
        List of function information dictionaries
    """
    functions = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            func_info = {
                'name': node.name,
                'line_number': node.lineno,
                'args': [arg.arg for arg in node.args.args],
                'decorators': [d.id if isinstance(d, ast.Name) else str(d) for d in node.decorator_list]
            }
            functions.append(func_info)
    
    return functions


def extract_classes(tree: ast.Module) -> List[Dict]:
    """
    Extract class definitions from AST
    
    Args:
        tree: AST Module
        
    Returns:
        List of class information dictionaries
    """
    classes = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            methods = [n.name for n in node.body if isinstance(n, ast.FunctionDef)]
            class_info = {
                'name': node.name,
                'line_number': node.lineno,
                'bases': [b.id if isinstance(b, ast.Name) else str(b) for b in node.bases],
                'methods': methods
            }
            classes.append(class_info)
    
    return classes


def extract_imports(tree: ast.Module) -> List[str]:
    """
    Extract import statements from AST
    
    Args:
        tree: AST Module
        
    Returns:
        List of imported module names
    """
    imports = []
    
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.append(node.module)
    
    return imports


def count_lines_of_code(file_path: Path) -> Dict[str, int]:
    """
    Count lines of code (total, code, comments, blank)
    
    Args:
        file_path: Path to source file
        
    Returns:
        Dictionary with line counts
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        total = len(lines)
        blank = sum(1 for line in lines if line.strip() == '')
        comments = sum(1 for line in lines if line.strip().startswith('#'))
        code = total - blank - comments
        
        return {
            'total': total,
            'code': code,
            'comments': comments,
            'blank': blank
        }
    except Exception as e:
        logger.error(f"Failed to count lines in {file_path}: {str(e)}")
        return {'total': 0, 'code': 0, 'comments': 0, 'blank': 0}


def analyze_complexity(tree: ast.Module) -> int:
    """
    Calculate cyclomatic complexity (simplified)
    
    Args:
        tree: AST Module
        
    Returns:
        Complexity score
    """
    complexity = 1  # Base complexity
    
    for node in ast.walk(tree):
        if isinstance(node, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
            complexity += 1
        elif isinstance(node, ast.BoolOp):
            complexity += len(node.values) - 1
    
    return complexity
