"""MongoDB models using Beanie ODM"""
from beanie import Document, Indexed
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import EmailStr, Field
from enum import Enum


# ============================================================================
# Enums
# ============================================================================

class UserRole(str, Enum):
    USER = "user"
    ADMIN = "admin"
    SUPERUSER = "superuser"


class ProjectType(str, Enum):
    WEB = "web"
    MOBILE = "mobile"
    DESKTOP = "desktop"
    API = "api"
    MICROSERVICES = "microservices"
    OTHER = "other"


class Industry(str, Enum):
    HEALTHCARE = "healthcare"
    FINANCE = "finance"
    ECOMMERCE = "ecommerce"
    EDUCATION = "education"
    GOVERNMENT = "government"
    TECHNOLOGY = "technology"
    MANUFACTURING = "manufacturing"
    RETAIL = "retail"
    TELECOMMUNICATIONS = "telecommunications"
    ENERGY = "energy"
    TRANSPORTATION = "transportation"
    MEDIA = "media"
    OTHER = "other"


class ConversionEnvironment(str, Enum):
    MIRAAI_HOSTED_VM = "miraai_hosted_vm"
    ON_PREMISES_SERVER = "on_premises_server"


class CodeSourceType(str, Enum):
    EXISTS_ON_SERVER = "exists_on_server"
    NEEDS_UPLOAD = "needs_upload"


class LLMOption(str, Enum):
    ON_PREMISES = "on_premises"
    MIRAAI_HOSTED = "miraai_hosted"
    COMMERCIAL = "commercial"


class MonthlyTraffic(str, Enum):
    LOW = "low"  # < 10K monthly
    MEDIUM = "medium"  # 10K - 100K monthly
    HIGH = "high"  # 100K - 1M monthly
    ENTERPRISE = "enterprise"  # > 1M monthly


class ReportType(str, Enum):
    GENERIC_SECURITY = "generic_security"
    OWASP_TOP_10 = "owasp_top_10"
    PCI_DSS = "pci_dss"
    ISO_27001 = "iso_27001"


class ScanJobStatus(str, Enum):
    PENDING = "pending"
    VALIDATING = "validating"
    CONNECTING = "connecting"
    SCANNING = "scanning"
    PROCESSING = "processing"
    FETCHING_REPORT = "fetching_report"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


# ============================================================================
# User Model
# ============================================================================

class User(Document):
    """User model for MongoDB"""
    email: Indexed(EmailStr, unique=True)
    username: Optional[str] = None
    hashed_password: str
    
    # Role and permissions
    role: UserRole = UserRole.USER
    is_active: bool = True
    is_superuser: bool = False
    
    # Email verification
    is_email_verified: bool = False
    email_verification_token: Optional[str] = None
    email_verification_sent_at: Optional[datetime] = None
    
    # Password reset
    password_reset_token: Optional[str] = None
    password_reset_sent_at: Optional[datetime] = None
    
    # Security tracking
    last_login_at: Optional[datetime] = None
    failed_login_attempts: int = 0
    locked_until: Optional[datetime] = None
    
    # SSH Credentials (encrypted)
    ssh_hostname: Optional[str] = None
    ssh_port: int = 22
    ssh_username: Optional[str] = None
    ssh_password_encrypted: Optional[str] = None
    ssh_private_key_encrypted: Optional[str] = None
    ssh_private_key_password_encrypted: Optional[str] = None
    ssh_verified: bool = False
    ssh_verified_at: Optional[datetime] = None
    ssh_source_path: Optional[str] = None
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Settings:
        name = "users"
        indexes = [
            "email",
            "username",
            "email_verification_token",
            "password_reset_token",
        ]
    
    def __repr__(self):
        return f"<User(id={self.id}, email='{self.email}', role='{self.role}')>"


# ============================================================================
# Refresh Token Model
# ============================================================================

class RefreshToken(Document):
    """Refresh token model for token blacklisting"""
    user_id: Indexed(str)  # Changed to str for MongoDB ObjectId compatibility
    token: Indexed(str, unique=True)
    is_revoked: bool = False
    expires_at: datetime
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Settings:
        name = "refresh_tokens"
        indexes = ["user_id", "token", "expires_at"]
    
    def __repr__(self):
        return f"<RefreshToken(id={self.id}, user_id={self.user_id}, revoked={self.is_revoked})>"


# ============================================================================
# User Project Model
# ============================================================================

class UserProject(Document):
    """Store user project information for analysis"""
    user_id: Indexed(str)  # MongoDB ObjectId as string
    
    # Project Basic Info
    project_key: Optional[str] = None  # SonarQube project key
    project_name: str
    organization_name: str
    project_description: Optional[str] = None
    
    # Project Technical Details
    project_type: ProjectType = ProjectType.WEB
    legacy_technology: List[str] = Field(default_factory=list)  # ["COBOL", "Java EE", "Classic ASP"]
    frameworks: List[str] = Field(default_factory=list)  # ["fastapi", "react", "spring"]
    
    # Traffic Information
    deployment_regions: List[str] = Field(default_factory=list)  # ["north_america", "europe", "south_asia"]
    monthly_traffic: Optional[MonthlyTraffic] = None  # low, medium, high, enterprise
    peak_concurrent_users: Optional[int] = None  # estimated peak concurrent users
    
    # Industry & Compliance
    industry: Industry = Industry.TECHNOLOGY
    
    # Fetched Information (stored as nested documents)
    fetched_project_info: Dict[str, Any] = Field(default_factory=dict)
    fetched_compliance_rules: Dict[str, Any] = Field(default_factory=dict)
    
    # File paths for saved data
    project_info_file: Optional[str] = None
    compliance_file: Optional[str] = None
    
    # SSH/VM Connection
    vm_code_path: Optional[str] = None  # Path to code on VM

    # Pipeline state — auto-updated as the user progresses through the workflow
    last_transform_id: Optional[str] = None        # Most recent transform_id from Step 1 (migration pipeline)
    last_upgraded_path: Optional[str] = None       # Full remote path of latest migrated/upgraded output folder
    last_sonar_scan_job_id: Optional[str] = None   # Most recent SonarQube scan job ID (from Step 2 analyze)
    last_sonar_project_key: Optional[str] = None   # SonarQube project key used in last scan (single-language legacy)
    # Multi-language Sonar project keys, keyed by lowercased language: {"php": "...", "javascript": "..."}.
    # Enables per-language reports in fanout migrations; falls back to last_sonar_project_key when unset.
    last_sonar_project_keys: Dict[str, str] = Field(default_factory=dict)

    # Conversion Environment
    conversion_environment: ConversionEnvironment = ConversionEnvironment.ON_PREMISES_SERVER
    
    # Code Source Configuration
    code_source_type: CodeSourceType = CodeSourceType.EXISTS_ON_SERVER
    git_repo_url: Optional[str] = None  # Git repository URL for cloning
    git_access_token: Optional[str] = None  # Access token for private repos
    additional_files: List[str] = Field(default_factory=list)  # uploaded config file paths (.env, etc.)
    
    # LLM Option
    llm_option: LLMOption = LLMOption.MIRAAI_HOSTED
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Settings:
        name = "user_projects"
        indexes = ["user_id", "created_at", "project_name"]
    
    def __repr__(self):
        return f"<UserProject(id={self.id}, project_name='{self.project_name}', user_id={self.user_id})>"


# ============================================================================
# Analysis Report Model
# ============================================================================

class AnalysisReport(Document):
    """Store analysis reports generated by agents"""
    project_id: Indexed(str)  # Reference to UserProject.id (as string)
    
    # Report Type
    report_type: str = "full"  # "full", "security", "owasp", "compliance"
    
    # Enhancement type: "original" = SonarQube only, "llm_enhanced" = SonarQube + LLM analysis
    enhancement_type: str = "llm_enhanced"
    
    # Report Content (stored as nested documents/arrays)
    summary: Optional[str] = None
    security_issues: List[Dict[str, Any]] = Field(default_factory=list)
    compliance_violations: List[Dict[str, Any]] = Field(default_factory=list)
    owasp_findings: List[Dict[str, Any]] = Field(default_factory=list)
    code_quality_issues: List[Dict[str, Any]] = Field(default_factory=list)
    legacy_code_findings: List[Dict[str, Any]] = Field(default_factory=list)
    vulnerabilities: List[Dict[str, Any]] = Field(default_factory=list)
    recommendations: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Report Files
    report_file_local: Optional[str] = None  # Local HTML path
    report_file_pdf: Optional[str] = None    # Local PDF path
    report_file_docx: Optional[str] = None   # Local DOCX path
    report_file_md: Optional[str] = None     # Local Markdown path
    report_file_vm: Optional[str] = None     # Path on VM
    
    # Metadata
    files_analyzed: int = 0
    total_issues: int = 0
    critical_issues: int = 0
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Settings:
        name = "analysis_reports"
        indexes = ["project_id", "created_at", "report_type"]
    
    def __repr__(self):
        return f"<AnalysisReport(id={self.id}, project_id={self.project_id}, total_issues={self.total_issues})>"


# ============================================================================
# SonarQube Models
# ============================================================================

class SonarQubeScanJob(Document):
    """Store SonarQube scan job information"""
    user_id: Indexed(str)  # MongoDB ObjectId as string
    
    # Job Identification
    celery_task_id: Optional[str] = None
    
    # Project Information
    project_key: str
    project_name: str
    source_path: str
    exclusions: Optional[str] = None
    
    # SSH Connection (encrypted)
    ssh_hostname: str
    ssh_port: int = 22
    ssh_username: str
    ssh_credentials_encrypted: str  # JSON encrypted blob
    
    # SonarQube Configuration
    sonar_host_url: str
    sonar_token_encrypted: str  # Encrypted token
    
    # Job Status
    status: ScanJobStatus = ScanJobStatus.PENDING
    current_step: Optional[str] = None
    progress_percent: int = 0
    
    # Timing
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    
    # Results
    scan_output: Optional[str] = None
    scan_errors: Optional[str] = None
    error_message: Optional[str] = None
    
    # Retry Logic
    retry_count: int = 0
    max_retries: int = 3
    
    # Installation Attempts (if auto-install enabled)
    docker_installed: bool = False
    scanner_installed: bool = False
    installation_logs: Optional[str] = None
    
    # Report Reference
    report_id: Optional[str] = None  # Reference to SonarQubeReport.id
    
    class Settings:
        name = "sonarqube_scan_jobs"
        indexes = [
            "user_id",
            "project_key",
            "status",
            "celery_task_id",
            "created_at"
        ]
    
    def __repr__(self):
        return f"<SonarQubeScanJob(id={self.id}, project_key='{self.project_key}', status='{self.status}')>"


class SonarQubeReport(Document):
    """Store SonarQube analysis reports"""
    scan_job_id: Indexed(str)  # Reference to SonarQubeScanJob.id
    project_key: Indexed(str)
    user_id: Indexed(str)
    
    # Analysis Information
    analysis_date: datetime
    analysis_key: Optional[str] = None  # SonarQube's internal analysis key
    
    # Measures (key metrics)
    measures: Dict[str, Any] = Field(default_factory=dict)
    # Example: {"bugs": "5", "vulnerabilities": "2", "coverage": "78.5"}
    
    # Issues Summary
    total_issues: int = 0
    bugs_count: int = 0
    vulnerabilities_count: int = 0
    code_smells_count: int = 0
    security_hotspots_count: int = 0
    
    # Issues by Severity
    blocker_issues: int = 0
    critical_issues: int = 0
    major_issues: int = 0
    minor_issues: int = 0
    info_issues: int = 0
    
    # Quality Gate
    quality_gate_status: str = "NONE"  # OK, WARN, ERROR, NONE
    quality_gate_conditions: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Detailed Issues (paginated/limited)
    issues: List[Dict[str, Any]] = Field(default_factory=list)
    # Limited to top 100 critical issues by default
    
    # Full Report (for caching)
    full_report: Dict[str, Any] = Field(default_factory=dict)
    
    # Project Info
    project_info: Dict[str, Any] = Field(default_factory=dict)
    
    # Metadata
    lines_of_code: int = 0
    technical_debt_minutes: int = 0
    reliability_rating: Optional[str] = None  # A, B, C, D, E
    security_rating: Optional[str] = None
    maintainability_rating: Optional[str] = None
    
    # Caching
    cached: bool = True
    cache_expires_at: Optional[datetime] = None
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    fetched_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Settings:
        name = "sonarqube_reports"
        indexes = [
            "scan_job_id",
            "project_key",
            "user_id",
            "analysis_date",
            "created_at",
            "quality_gate_status"
        ]
    
    def __repr__(self):
        return f"<SonarQubeReport(id={self.id}, project_key='{self.project_key}', quality_gate='{self.quality_gate_status}')>"


class SonarQubeAuditLog(Document):
    """Audit log for SonarQube operations"""
    user_id: Indexed(str)
    
    # Action Information
    action: str  # "scan_triggered", "scan_completed", "scan_failed", "report_fetched", "report_cached"
    project_key: str
    
    # Target Information
    remote_server: Optional[str] = None  # SSH hostname
    source_path: Optional[str] = None
    
    # Result
    success: bool = True
    error_message: Optional[str] = None
    
    # Metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)
    # Can include: duration, file_count, issues_found, etc.
    
    # IP and User Agent
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    
    # Timestamp
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    class Settings:
        name = "sonarqube_audit_logs"
        indexes = [
            "user_id",
            "action",
            "project_key",
            "timestamp",
            "success"
        ]
    
    def __repr__(self):
        return f"<SonarQubeAuditLog(id={self.id}, action='{self.action}', project_key='{self.project_key}')>"


# ============================================================================
# Modernization Job Model (run-modernization API)
# ============================================================================

class ModernizationJob(Document):
    """Store run-modernization and staged pipeline job records: status, current step, result. transform_id links step 2–4 jobs to the Transform (step 1 creates it)."""
    user_id: Indexed(str)
    job_id: Indexed(str, unique=True)
    job_type: str = "run_modernization"  # run_modernization | structure_language | upgrade_analysis | code_modernization | staged_modernization

    transform_id: Optional[str] = None  # Set for all 4 steps; used to fetch related details from previous steps
    project_name: str
    source_path: Optional[str] = None
    output_path: Optional[str] = None

    status: str = "running"  # running | completed | failed
    current_step: str = "Step 2"  # step_1 | step_2 | step_3 | step_4 for 4-step APIs; "Step 2" for full run_modernization
    current_task: Optional[str] = None  # structure_analysis | language_analysis | upgrade_analysis | code_modernization (sub-task within step)
    tasks_completed: List[str] = Field(default_factory=list)

    result: Optional[Dict[str, Any]] = None  # RunModernizationResponse as dict when completed
    error_message: Optional[str] = None
    logs: Optional[List[str]] = None  # Log lines from pipeline run (for frontend display)

    # Per-task completion time in seconds
    structure_analysis_duration_sec: Optional[float] = None
    language_analysis_duration_sec: Optional[float] = None
    upgrade_analysis_duration_sec: Optional[float] = None
    code_modernization_duration_sec: Optional[float] = None
    staged_modernization_duration_sec: Optional[float] = None

    # Progress / checkpoint fields (support resume + live UI progress for long migrations).
    # Updated in-place by workers every N files; never rewrite history (append-only results).
    files_total: Optional[int] = None              # total files to process in current step
    files_processed: int = 0                        # how many have been LLM-processed successfully
    files_failed: int = 0                           # how many failed (recorded in failed_files_detail)
    current_file: Optional[str] = None              # the file currently being processed (for live UI)
    last_completed_file: Optional[str] = None       # for resume: skip files <= this one
    completed_files: List[str] = Field(default_factory=list)  # idempotency — don't re-process
    failed_files_detail: List[Dict[str, Any]] = Field(default_factory=list)  # [{file, error, ts}]
    current_chunk_index: Optional[int] = None       # if a single file is being chunked
    eta_seconds: Optional[int] = None               # rolling estimate from avg per-file time
    resumed_from_job_id: Optional[str] = None       # set when a job is resumed from an earlier one
    # Per-stage progress for staged version migrations (e.g. PHP 7.4 → 7.5 → 7.6 → ... → 8.5).
    # Updated by the agent at the start of every version hop so the UI can show "Stage 3/7: 7.6 → 7.7"
    # rather than just the start/end versions repeated forever.
    current_stage_index: Optional[int] = None       # 1-based index of the stage currently running
    total_stages: Optional[int] = None              # how many stages this run will execute
    current_stage_from: Optional[str] = None        # version this stage is migrating FROM
    current_stage_to: Optional[str] = None          # version this stage is migrating TO
    # Liveness heartbeat — updated on every _record_job_progress call. On API startup,
    # jobs with status=running and a heartbeat older than MIRA_JOB_STUCK_THRESHOLD_SECONDS
    # are marked "interrupted" so the existing resume endpoint can pick them up.
    last_progress_update_at: Optional[datetime] = None
    # Per-job token accounting (populated from Groq's usage field on every LLM response).
    token_usage: Dict[str, int] = Field(default_factory=dict)  # {"prompt": int, "completion": int, "total": int}
    # Post-migration validation pipeline report. Populated after Step 4 completes:
    # tree-sitter syntax parse, native linter via SSH (php -l, node --check, etc.),
    # and optional SonarQube rescan delta. See ValidationReport.to_dict() shape.
    validation_report: Optional[Dict[str, Any]] = None
    # Cross-file reasoning: contract-change summary accumulated across files in this run.
    # Tracks renamed symbols, changed signatures, replaced imports so subsequent files
    # in the same pipeline can stay consistent with earlier changes. See ProjectMigrationState.
    migration_state_snapshot: Optional[Dict[str, Any]] = None

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    class Settings:
        name = "modernization_jobs"
        indexes = ["user_id", "job_id", "job_type", "transform_id", "project_name", "status", "created_at"]

    def __repr__(self):
        return f"<ModernizationJob(id={self.id}, job_id='{self.job_id}', project_name='{self.project_name}', status='{self.status}')>"


# ============================================================================
# Transform Model (groups the 4 step jobs: structure+language, simple upgrade, user-input upgrade, code modernization)
# ============================================================================

class Transform(Document):
    """Groups job IDs for the 4-step pipeline. Step 1 creates the transform; steps 2–4 take transform_id and set step_N_job_id."""
    transform_id: Indexed(str, unique=True)
    user_id: Indexed(str)
    project_name: str

    step_1_job_id: Optional[str] = None  # structure + language
    step_2_job_id: Optional[str] = None  # simple upgrade analysis
    step_3_job_id: Optional[str] = None  # upgrade analysis with user_input
    step_4_job_id: Optional[str] = None  # code modernization
    step_5_job_id: Optional[str] = None  # security test post-modernization verification

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Settings:
        name = "transforms"
        indexes = ["user_id", "transform_id", "project_name", "created_at"]

    def __repr__(self):
        return f"<Transform(transform_id='{self.transform_id}', project_name='{self.project_name}')>"

