"""Groq LLM provider"""
from typing import List, Dict, Any, AsyncIterator
from groq import Groq
from app.services.llm.base_provider import BaseLLMProvider, LLMMessage, LLMResponse
from app.core.logging import get_logger

logger = get_logger(__name__)


class GroqProvider(BaseLLMProvider):
    """Groq LLM provider"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        api_key = config.get("api_key")
        if not api_key:
            raise ValueError("Groq API key is required")
        
        self.client = Groq(api_key=api_key)
        self.model = config.get("model", "openai/gpt-oss-120b")
        self.reasoning_effort = config.get("reasoning_effort", "low")
        self.top_p = config.get("top_p", 1.0)
    
    def generate(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Generate response using Groq"""
        try:
            formatted_messages = [
                {"role": msg.role, "content": msg.content}
                for msg in messages
            ]
            
            # Groq-specific parameters
            groq_params = {
                "model": kwargs.get("model", self.model),
                "messages": formatted_messages,
                "temperature": kwargs.get("temperature", self.temperature),
                "max_completion_tokens": kwargs.get("max_tokens", self.max_tokens),
                "top_p": kwargs.get("top_p", self.top_p),
                "stream": False
            }
            
            # Only add reasoning_effort for models that support it (like gpt-oss)
            model_name = groq_params["model"].lower()
            if "gpt-oss" in model_name or "o1" in model_name or "o3" in model_name:
                groq_params["reasoning_effort"] = kwargs.get("reasoning_effort", self.reasoning_effort)
            
            # Add optional tools if provided
            if "tools" in kwargs:
                groq_params["tools"] = kwargs["tools"]
            
            # Add stop sequences if provided
            if "stop" in kwargs:
                groq_params["stop"] = kwargs["stop"]
            
            response = self.client.chat.completions.create(**groq_params)
            
            return LLMResponse(
                content=response.choices[0].message.content or "",
                model=response.model,
                usage={
                    "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                    "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                    "total_tokens": response.usage.total_tokens if response.usage else 0
                } if response.usage else None,
                finish_reason=response.choices[0].finish_reason
            )
        except Exception as e:
            logger.error(f"Groq generation failed: {str(e)}", exc_info=True)
            raise
    
    async def agenerate(self, messages: List[LLMMessage], **kwargs) -> LLMResponse:
        """Async generate response using Groq"""
        import asyncio
        return await asyncio.to_thread(self.generate, messages, **kwargs)
    
    async def stream(self, messages: List[LLMMessage], **kwargs) -> AsyncIterator[str]:
        """Stream responses from Groq"""
        formatted_messages = [
            {"role": msg.role, "content": msg.content}
            for msg in messages
        ]
        
        try:
            groq_params = {
                "model": kwargs.get("model", self.model),
                "messages": formatted_messages,
                "temperature": kwargs.get("temperature", self.temperature),
                "max_completion_tokens": kwargs.get("max_tokens", self.max_tokens),
                "top_p": kwargs.get("top_p", self.top_p),
                "stream": True
            }
            
            # Only add reasoning_effort for models that support it (like gpt-oss)
            model_name = groq_params["model"].lower()
            if "gpt-oss" in model_name or "o1" in model_name or "o3" in model_name:
                groq_params["reasoning_effort"] = kwargs.get("reasoning_effort", self.reasoning_effort)
            
            # Add optional tools if provided
            if "tools" in kwargs:
                groq_params["tools"] = kwargs["tools"]
            
            # Add stop sequences if provided
            if "stop" in kwargs:
                groq_params["stop"] = kwargs["stop"]
            
            stream = self.client.chat.completions.create(**groq_params)
            
            for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta
                    if delta and delta.content:
                        yield delta.content
        except Exception as e:
            logger.error(f"Groq streaming failed: {str(e)}", exc_info=True)
            raise
    
    def validate_config(self) -> bool:
        """Validate Groq configuration"""
        return bool(self.config.get("api_key"))

