"""Celery tasks for SonarQube remote scanning"""
import time
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from app.workers.celery_app import celery_app
from app.services.sonarqube.remote_scanner import RemoteSonarScanner
from app.services.sonarqube.report_fetcher import SonarQubeReportFetcher
from app.services.ssh.ssh_service import SSHService
from app.db.mongodb_models import SonarQubeScanJob, SonarQubeReport, SonarQubeAuditLog, ScanJobStatus
from app.core.logging import get_logger
from app.core.encryption import decrypt_data, encrypt_data
import json
import asyncio

logger = get_logger(__name__)

# Initialize MongoDB connection for Celery tasks
_mongodb_initialized = False


def get_or_create_event_loop():
    """Get or create an event loop for Celery worker"""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError("Loop is closed")
        return loop
    except RuntimeError:
        # No event loop exists or it's closed, create a new one
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop


async def ensure_mongodb_initialized():
    """Ensure MongoDB is initialized in Celery worker context"""
    global _mongodb_initialized
    if not _mongodb_initialized:
        try:
            from app.db.mongodb import init_mongodb
            await init_mongodb()
            _mongodb_initialized = True
            logger.info("MongoDB initialized in Celery worker")
        except Exception as e:
            logger.error(f"Failed to initialize MongoDB in Celery worker: {e}", exc_info=True)
            raise


async def update_job_status(job_id: str, status: ScanJobStatus, current_step: Optional[str] = None, 
                           progress: Optional[int] = None, error: Optional[str] = None):
    """Update scan job status in database"""
    try:
        job = await SonarQubeScanJob.get(job_id)
        if job:
            job.status = status
            if current_step:
                job.current_step = current_step
            if progress is not None:
                job.progress_percent = progress
            if error:
                job.error_message = error
            
            if status == ScanJobStatus.SCANNING and not job.started_at:
                job.started_at = datetime.utcnow()
            elif status in [ScanJobStatus.COMPLETED, ScanJobStatus.FAILED, ScanJobStatus.CANCELLED]:
                job.completed_at = datetime.utcnow()
                if job.started_at:
                    job.duration_seconds = int((job.completed_at - job.started_at).total_seconds())
            
            await job.save()
            logger.info(f"Job {job_id} status updated: {status} - {current_step}")
    except Exception as e:
        logger.error(f"Failed to update job status: {e}", exc_info=True)


async def wait_for_ce_completion(project_key: str, sonar_host_url: str, 
                                sonar_token: str, job_id: str, timeout: int = 300) -> bool:
    """
    Wait for SonarQube Compute Engine to complete analysis processing
    
    Args:
        project_key: SonarQube project key
        sonar_host_url: SonarQube server URL
        sonar_token: Authentication token
        job_id: Scan job ID for progress updates
        timeout: Maximum wait time in seconds (default: 5 minutes)
    
    Returns:
        True if analysis completed successfully, False if timeout or error
    """
    try:
        fetcher = SonarQubeReportFetcher(sonar_host_url, sonar_token)
        start_time = time.time()
        poll_count = 0
        
        logger.info(f"Waiting for Compute Engine to process analysis for {project_key}")
        
        while time.time() - start_time < timeout:
            poll_count += 1
            
            # Check CE task status
            result = fetcher._make_request(
                "/api/ce/activity",
                params={
                    "component": project_key,
                    "status": "IN_PROGRESS,PENDING",
                    "type": "REPORT"
                }
            )
            
            if result:
                tasks = result.get("tasks", [])
                
                if not tasks:
                    # No pending/running tasks, analysis should be complete
                    logger.info(f"CE processing complete for {project_key} after {poll_count} polls")
                    return True
                
                # Log task status
                task = tasks[0]  # Most recent task
                task_status = task.get("status", "UNKNOWN")
                task_type = task.get("type", "UNKNOWN")
                
                logger.debug(f"CE task status: {task_status}, type: {task_type}, poll #{poll_count}")
                
                # Update job progress
                elapsed = int(time.time() - start_time)
                progress = min(90, 70 + int((elapsed / timeout) * 20))  # 70-90%
                await update_job_status(
                    job_id,
                    ScanJobStatus.PROCESSING,
                    f"Processing analysis (poll #{poll_count})...",
                    progress
                )
            
            # Wait before next poll (exponential backoff, max 10s)
            wait_time = min(10, 2 + (poll_count * 0.5))
            time.sleep(wait_time)
        
        # Timeout reached
        logger.warning(f"CE processing timeout for {project_key} after {timeout}s")
        return False
        
    except Exception as e:
        logger.error(f"Error waiting for CE completion: {e}", exc_info=True)
        return False


async def pre_flight_validation(ssh_conn, source_path: str, sonar_host_url: str, job_id: str) -> Dict[str, Any]:
    """
    Perform pre-flight checks before starting scan
    
    Returns dict with:
        - success: bool
        - errors: list of error messages
        - warnings: list of warning messages
        - estimated_files: int (if available)
    """
    errors = []
    warnings = []
    estimated_files = 0
    
    try:
        # Check if source path exists
        await update_job_status(job_id, ScanJobStatus.VALIDATING, "Checking source path...", 5)
        result = ssh_conn.execute_command(f"test -d {source_path} && echo 'EXISTS' || echo 'NOT_FOUND'")
        if "NOT_FOUND" in result.get("stdout", ""):
            errors.append(f"Source path does not exist: {source_path}")
        elif "EXISTS" in result.get("stdout", ""):
            # Count files (rough estimate)
            count_result = ssh_conn.execute_command(
                f"find {source_path} -type f 2>/dev/null | wc -l"
            )
            if count_result.get("success"):
                try:
                    estimated_files = int(count_result.get("stdout", "0").strip())
                    logger.info(f"Estimated files to scan: {estimated_files}")
                except:
                    pass
        
        # Check SonarQube server reachability from remote
        await update_job_status(job_id, ScanJobStatus.VALIDATING, "Testing SonarQube connectivity...", 10)
        
        # Use curl to test connectivity
        test_url = f"{sonar_host_url}/api/system/status"
        curl_cmd = f"curl -s -o /dev/null -w '%{{http_code}}' --connect-timeout 10 --max-time 15 {test_url}"
        
        result = ssh_conn.execute_command(curl_cmd)
        if result.get("success"):
            http_code = result.get("stdout", "").strip()
            if http_code in ["200", "401", "403"]:
                # 200 = OK, 401/403 = server is up but auth required (which is normal)
                logger.info(f"SonarQube server is reachable (HTTP {http_code})")
            else:
                if "localhost" in sonar_host_url or "127.0.0.1" in sonar_host_url:
                    errors.append(
                        f"Cannot reach SonarQube at {sonar_host_url} from remote server. "
                        f"'localhost' refers to the remote server itself, not your machine. "
                        f"Please provide your public IP or domain name."
                    )
                else:
                    errors.append(
                        f"Cannot reach SonarQube server at {sonar_host_url} (HTTP {http_code}). "
                        f"Please check firewall rules and server accessibility."
                    )
        else:
            # curl failed (might not be installed)
            if "localhost" in sonar_host_url or "127.0.0.1" in sonar_host_url:
                warnings.append(
                    f"Warning: Using 'localhost' in SonarQube URL. "
                    f"The remote server will try to connect to itself, not your machine. "
                    f"This will likely fail."
                )
        
        # Check disk space
        await update_job_status(job_id, ScanJobStatus.VALIDATING, "Checking disk space...", 15)
        df_result = ssh_conn.execute_command(f"df -BM {source_path} | tail -1 | awk '{{print $4}}'")
        if df_result.get("success"):
            available_space = df_result.get("stdout", "").strip()
            logger.info(f"Available disk space: {available_space}")
            # Parse space (e.g., "1024M")
            try:
                space_mb = int(available_space.replace("M", ""))
                if space_mb < 500:  # Less than 500MB
                    warnings.append(f"Low disk space: {space_mb}MB available. Scanner may fail.")
            except:
                pass
        
        return {
            "success": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "estimated_files": estimated_files
        }
        
    except Exception as e:
        logger.error(f"Pre-flight validation error: {e}", exc_info=True)
        return {
            "success": False,
            "errors": [f"Validation error: {str(e)}"],
            "warnings": warnings,
            "estimated_files": 0
        }


async def store_report_in_db(job_id: str, project_key: str, user_id: str, report_data: Dict[str, Any]) -> Optional[str]:
    """Store SonarQube report in database"""
    try:
        # Extract key information
        measures = report_data.get("measures", [])
        issues = report_data.get("issues", {})
        quality_gate = report_data.get("quality_gate", {})
        project_info = report_data.get("project_info", {})
        
        # Convert measures list to dict
        measures_dict = {}
        for measure in measures:
            measures_dict[measure.get("metric", "")] = measure.get("value", "")
        
        # Count issues by type and severity
        issues_list = issues.get("items", [])
        bugs_count = sum(1 for i in issues_list if i.get("type") == "BUG")
        vulnerabilities_count = sum(1 for i in issues_list if i.get("type") == "VULNERABILITY")
        code_smells_count = sum(1 for i in issues_list if i.get("type") == "CODE_SMELL")
        security_hotspots_count = sum(1 for i in issues_list if i.get("type") == "SECURITY_HOTSPOT")
        
        blocker_issues = sum(1 for i in issues_list if i.get("severity") == "BLOCKER")
        critical_issues = sum(1 for i in issues_list if i.get("severity") == "CRITICAL")
        major_issues = sum(1 for i in issues_list if i.get("severity") == "MAJOR")
        minor_issues = sum(1 for i in issues_list if i.get("severity") == "MINOR")
        info_issues = sum(1 for i in issues_list if i.get("severity") == "INFO")
        
        # Create report document
        report = SonarQubeReport(
            scan_job_id=job_id,
            project_key=project_key,
            user_id=user_id,
            analysis_date=datetime.utcnow(),
            measures=measures_dict,
            total_issues=issues.get("total", 0),
            bugs_count=bugs_count,
            vulnerabilities_count=vulnerabilities_count,
            code_smells_count=code_smells_count,
            security_hotspots_count=security_hotspots_count,
            blocker_issues=blocker_issues,
            critical_issues=critical_issues,
            major_issues=major_issues,
            minor_issues=minor_issues,
            info_issues=info_issues,
            quality_gate_status=quality_gate.get("status", "NONE"),
            quality_gate_conditions=quality_gate.get("conditions", []),
            issues=issues_list[:100],  # Store top 100 issues
            full_report=report_data,
            project_info=project_info,
            lines_of_code=int(measures_dict.get("ncloc", 0) or 0),
            technical_debt_minutes=int(measures_dict.get("sqale_index", 0) or 0),
            reliability_rating=measures_dict.get("reliability_rating"),
            security_rating=measures_dict.get("security_rating"),
            maintainability_rating=measures_dict.get("sqale_rating"),
            cached=True,
            cache_expires_at=datetime.utcnow() + timedelta(hours=1)
        )
        
        await report.save()
        logger.info(f"Report stored in database: {report.id}")
        return str(report.id)
        
    except Exception as e:
        logger.error(f"Failed to store report in database: {e}", exc_info=True)
        return None


async def create_audit_log(user_id: str, action: str, project_key: str, success: bool, 
                          metadata: Optional[Dict] = None, error: Optional[str] = None,
                          remote_server: Optional[str] = None, source_path: Optional[str] = None):
    """Create audit log entry"""
    try:
        log = SonarQubeAuditLog(
            user_id=user_id,
            action=action,
            project_key=project_key,
            success=success,
            error_message=error,
            remote_server=remote_server,
            source_path=source_path,
            metadata=metadata or {}
        )
        await log.save()
    except Exception as e:
        logger.error(f"Failed to create audit log: {e}", exc_info=True)


@celery_app.task(bind=True, max_retries=3, default_retry_delay=60)
def scan_remote_code_async(self, job_id: str):
    """
    Async Celery task for remote SonarQube scanning
    
    This task:
    1. Validates the job and decrypts credentials
    2. Performs pre-flight checks
    3. Connects via SSH
    4. Runs the scanner (with auto-install if needed)
    5. Waits for Compute Engine to process results
    6. Fetches and stores the report
    7. Creates audit logs
    """
    # Create event loop for async operations
    # In Celery fork pool workers, we need to ensure a fresh event loop
    loop = get_or_create_event_loop()
    
    try:
        # Initialize MongoDB first
        loop.run_until_complete(ensure_mongodb_initialized())
        
        # Load job from database
        job = loop.run_until_complete(SonarQubeScanJob.get(job_id))
        if not job:
            logger.error(f"Job not found: {job_id}")
            return {"success": False, "error": "Job not found"}
        
        # Update job with Celery task ID
        job.celery_task_id = self.request.id
        loop.run_until_complete(job.save())
        
        # Decrypt credentials
        try:
            ssh_creds = json.loads(decrypt_data(job.ssh_credentials_encrypted))
            sonar_token = decrypt_data(job.sonar_token_encrypted)
        except Exception as e:
            error_msg = f"Failed to decrypt credentials: {str(e)}"
            logger.error(error_msg)
            loop.run_until_complete(update_job_status(job_id, ScanJobStatus.FAILED, error=error_msg))
            return {"success": False, "error": error_msg}
        
        # Connect via SSH
        loop.run_until_complete(update_job_status(
            job_id, ScanJobStatus.CONNECTING, "Connecting to remote server...", 20
        ))
        
        ssh_conn = SSHService.create_connection(
            hostname=job.ssh_hostname,
            port=job.ssh_port,
            username=job.ssh_username,
            **ssh_creds
        )
        
        if not ssh_conn.connect():
            error_msg = f"Failed to connect to SSH server {job.ssh_hostname}:{job.ssh_port}"
            logger.error(error_msg)
            loop.run_until_complete(update_job_status(job_id, ScanJobStatus.FAILED, error=error_msg))
            loop.run_until_complete(create_audit_log(
                job.user_id, "scan_failed", job.project_key, False, 
                error=error_msg, remote_server=job.ssh_hostname
            ))
            return {"success": False, "error": error_msg}
        
        try:
            # Pre-flight validation
            validation = loop.run_until_complete(
                pre_flight_validation(ssh_conn, job.source_path, job.sonar_host_url, job_id)
            )
            
            if not validation["success"]:
                error_msg = "Pre-flight validation failed: " + "; ".join(validation["errors"])
                logger.error(error_msg)
                loop.run_until_complete(update_job_status(job_id, ScanJobStatus.FAILED, error=error_msg))
                loop.run_until_complete(create_audit_log(
                    job.user_id, "scan_failed", job.project_key, False,
                    error=error_msg, remote_server=job.ssh_hostname, source_path=job.source_path
                ))
                ssh_conn.disconnect()
                return {"success": False, "error": error_msg, "validation": validation}
            
            # Log warnings if any
            if validation["warnings"]:
                for warning in validation["warnings"]:
                    logger.warning(warning)
            
            # Create scanner
            loop.run_until_complete(update_job_status(
                job_id, ScanJobStatus.SCANNING, "Initializing scanner...", 30
            ))
            
            scanner = RemoteSonarScanner(
                ssh_conn=ssh_conn,
                sonar_token=sonar_token,
                sonar_host_url=job.sonar_host_url
            )
            
            # Run scan
            loop.run_until_complete(update_job_status(
                job_id, ScanJobStatus.SCANNING, "Running code analysis...", 40
            ))
            
            scan_result = scanner.scan(
                project_key=job.project_key,
                project_name=job.project_name,
                source_path=job.source_path,
                exclusions=job.exclusions,
                prefer_docker=True,
                auto_install=True
            )
            
            # Store scan output
            job.scan_output = scan_result.get("stdout", "")[:10000]  # Limit to 10KB
            job.scan_errors = scan_result.get("stderr", "")[:10000]
            loop.run_until_complete(job.save())
            
            if not scan_result.get("success"):
                error_msg = scan_result.get("error", "Scan failed")
                logger.error(f"Scan failed: {error_msg}")
                loop.run_until_complete(update_job_status(job_id, ScanJobStatus.FAILED, error=error_msg))
                loop.run_until_complete(create_audit_log(
                    job.user_id, "scan_failed", job.project_key, False,
                    error=error_msg, remote_server=job.ssh_hostname, source_path=job.source_path
                ))
                ssh_conn.disconnect()
                
                # Retry on network errors
                if "connection" in error_msg.lower() or "timeout" in error_msg.lower():
                    raise self.retry(exc=Exception(error_msg))
                
                return {"success": False, "error": error_msg}
            
            logger.info(f"Scan completed successfully for {job.project_key}")
            
            # Wait for Compute Engine to process results
            loop.run_until_complete(update_job_status(
                job_id, ScanJobStatus.PROCESSING, "Waiting for analysis processing...", 70
            ))
            
            # Use Docker service name for worker if external URL fails (for local testing)
            # Remote server uses external URL, but worker can use Docker service name
            ce_host_url = job.sonar_host_url
            if "sonarqube.codsy.ai" in ce_host_url:
                # Try Docker service name first (for containers in same network)
                docker_urls = ["http://sonarqube:9000", "http://localhost:9000"]
                for docker_url in docker_urls:
                    try:
                        test_fetcher = SonarQubeReportFetcher(docker_url, sonar_token)
                        test_result = test_fetcher._make_request("/api/system/status")
                        if test_result:
                            ce_host_url = docker_url
                            logger.info(f"Using {docker_url} for CE polling (local testing)")
                            break
                    except Exception as e:
                        logger.debug(f"Failed to connect to {docker_url}: {e}")
                        continue
            
            ce_success = loop.run_until_complete(
                wait_for_ce_completion(job.project_key, ce_host_url, sonar_token, job_id, timeout=300)
            )
            
            if not ce_success:
                logger.warning("CE processing timeout, attempting to fetch report anyway")
            
            # Fetch report
            loop.run_until_complete(update_job_status(
                job_id, ScanJobStatus.FETCHING_REPORT, "Fetching analysis report...", 90
            ))
            
            # Use Docker service name for worker if external URL fails (for local testing)
            # Remote server uses external URL, but worker can use Docker service name
            report_host_url = job.sonar_host_url
            if "sonarqube.codsy.ai" in report_host_url:
                # Try Docker service name first (for containers in same network)
                docker_urls = ["http://sonarqube:9000", "http://localhost:9000"]
                for docker_url in docker_urls:
                    try:
                        test_fetcher = SonarQubeReportFetcher(docker_url, sonar_token)
                        test_result = test_fetcher._make_request("/api/system/status")
                        if test_result:
                            report_host_url = docker_url
                            logger.info(f"Using {docker_url} for report fetching (local testing)")
                            break
                    except Exception as e:
                        logger.debug(f"Failed to connect to {docker_url}: {e}")
                        continue
            
            fetcher = SonarQubeReportFetcher(report_host_url, sonar_token)
            report = fetcher.get_full_report(job.project_key)
            
            if not report.get("success"):
                error_msg = report.get("error", "Failed to fetch report")
                logger.error(f"Report fetch failed: {error_msg}")
                loop.run_until_complete(update_job_status(job_id, ScanJobStatus.FAILED, error=error_msg))
                ssh_conn.disconnect()
                return {"success": False, "error": error_msg}
            
            # Store report in database
            report_id = loop.run_until_complete(
                store_report_in_db(job_id, job.project_key, job.user_id, report)
            )
            
            if report_id:
                job.report_id = report_id
                loop.run_until_complete(job.save())
            
            # Mark job as completed
            loop.run_until_complete(update_job_status(
                job_id, ScanJobStatus.COMPLETED, "Scan completed successfully", 100
            ))
            
            # Create audit log
            loop.run_until_complete(create_audit_log(
                job.user_id, "scan_completed", job.project_key, True,
                metadata={
                    "duration_seconds": job.duration_seconds,
                    "total_issues": report.get("issues", {}).get("total", 0),
                    "quality_gate": report.get("quality_gate", {}).get("status", "UNKNOWN")
                },
                remote_server=job.ssh_hostname,
                source_path=job.source_path
            ))
            
            logger.info(f"Job {job_id} completed successfully")
            
            return {
                "success": True,
                "job_id": job_id,
                "project_key": job.project_key,
                "report_id": report_id,
                "quality_gate": report.get("quality_gate", {}).get("status", "UNKNOWN")
            }
            
        finally:
            ssh_conn.disconnect()
            
    except Exception as e:
        logger.error(f"Scan task failed: {e}", exc_info=True)
        
        try:
            loop.run_until_complete(update_job_status(job_id, ScanJobStatus.FAILED, error=str(e)))
            loop.run_until_complete(create_audit_log(
                job.user_id if 'job' in locals() else "unknown",
                "scan_failed",
                job.project_key if 'job' in locals() else "unknown",
                False,
                error=str(e)
            ))
        except:
            pass
        
        # Retry on network errors
        if "connection" in str(e).lower() or "timeout" in str(e).lower():
            job = loop.run_until_complete(SonarQubeScanJob.get(job_id))
            if job and job.retry_count < job.max_retries:
                job.retry_count += 1
                loop.run_until_complete(job.save())
                raise self.retry(exc=e, countdown=60 * (self.request.retries + 1))
        
        raise
    finally:
        loop.close()

